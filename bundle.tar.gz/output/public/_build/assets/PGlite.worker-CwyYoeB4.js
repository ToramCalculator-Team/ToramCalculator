var p$1=Object.create,i=Object.defineProperty,c=Object.getOwnPropertyDescriptor,f=Object.getOwnPropertyNames,l$2=Object.getPrototypeOf,s$1=Object.prototype.hasOwnProperty,a=e=>{throw TypeError(e)},_$1=(e,I,Hn)=>I in e?i(e,I,{enumerable:!0,configurable:!0,writable:!0,value:Hn}):e[I]=Hn,d=(e,I)=>()=>(e&&(I=e(e=0)),I),D$2=(e,I)=>()=>(I||e((I={exports:{}}).exports,I),I.exports),F$3=(e,I)=>{for(var Hn in I)i(e,Hn,{get:I[Hn],enumerable:!0})},g$4=(e,I,Hn,$n)=>{if(I&&typeof I=="object"||typeof I=="function")for(let qn of f(I))!s$1.call(e,qn)&&qn!==Hn&&i(e,qn,{get:()=>I[qn],enumerable:!($n=c(I,qn))||$n.enumerable});return e},L$2=(e,I,Hn)=>(Hn=e!=null?p$1(l$2(e)):{},g$4(i(Hn,"default",{value:e,enumerable:!0}),e)),P$2=(e,I,Hn)=>_$1(e,typeof I!="symbol"?I+"":I,Hn),n=(e,I,Hn)=>I.has(e)||a("Cannot "+Hn),h$1=(e,I,Hn)=>(n(e,I,"read from private field"),Hn?Hn.call(e):I.get(e)),R$2=(e,I,Hn)=>I.has(e)?a("Cannot add the same private member more than once"):I instanceof WeakSet?I.add(e):I.set(e,Hn),x$2=(e,I,Hn,$n)=>(n(e,I,"write to private field"),I.set(e,Hn),Hn),T=(e,I,Hn)=>(n(e,I,"access private method"),Hn),U$2=(e,I,Hn,$n)=>({set _(qn){x$2(e,I,qn)},get _(){return h$1(e,I,$n)}}),u$1=d(()=>{}),hn={};F$3(hn,{ABSTIME:()=>Et,ACLITEM:()=>Vt,BIT:()=>Wt,BOOL:()=>be,BPCHAR:()=>_e$1,BYTEA:()=>ge$1,CHAR:()=>gt,CID:()=>St,CIDR:()=>Tt,CIRCLE:()=>Ut,DATE:()=>He$1,FLOAT4:()=>je$1,FLOAT8:()=>Qe$1,GTSVECTOR:()=>rn,INET:()=>kt,INT2:()=>ve,INT4:()=>Ge,INT8:()=>we,INTERVAL:()=>vt,JSON:()=>Ae$1,JSONB:()=>Ye,MACADDR:()=>Ot,MACADDR8:()=>Nt,MONEY:()=>Lt,NUMERIC:()=>Qt,OID:()=>We$1,PATH:()=>Mt,PG_DEPENDENCIES:()=>en,PG_LSN:()=>Xt,PG_NDISTINCT:()=>Zt,PG_NODE_TREE:()=>Bt,POLYGON:()=>Rt,REFCURSOR:()=>_t,REGCLASS:()=>Yt,REGCONFIG:()=>sn,REGDICTIONARY:()=>an,REGNAMESPACE:()=>on,REGOPER:()=>Ht,REGOPERATOR:()=>qt,REGPROC:()=>wt,REGPROCEDURE:()=>zt,REGROLE:()=>un,REGTYPE:()=>$t,RELTIME:()=>Ct,SMGR:()=>It,TEXT:()=>F$2,TID:()=>At,TIME:()=>Ft,TIMESTAMP:()=>qe$1,TIMESTAMPTZ:()=>xe,TIMETZ:()=>Gt,TINTERVAL:()=>Pt,TSQUERY:()=>nn,TSVECTOR:()=>tn,TXID_SNAPSHOT:()=>Jt,UUID:()=>Kt,VARBIT:()=>jt,VARCHAR:()=>ze,XID:()=>xt,XML:()=>Dt,arrayParser:()=>yn,arraySerializer:()=>Ke$1,parseType:()=>ue$1,parsers:()=>ln,serializers:()=>cn,types:()=>$e});u$1();var ht=globalThis.JSON.parse,bt=globalThis.JSON.stringify,be=16,ge$1=17,gt=18,we=20,ve=21,Ge=23,wt=24,F$2=25,We$1=26,At=27,xt=28,St=29,Ae$1=114,Dt=142,Bt=194,It=210,Mt=602,Rt=604,Tt=650,je$1=700,Qe$1=701,Et=702,Ct=703,Pt=704,Ut=718,Nt=774,Lt=790,Ot=829,kt=869,Vt=1033,_e$1=1042,ze=1043,He$1=1082,Ft=1083,qe$1=1114,xe=1184,vt=1186,Gt=1266,Wt=1560,jt=1562,Qt=1700,_t=1790,zt=2202,Ht=2203,qt=2204,Yt=2205,$t=2206,Kt=2950,Jt=2970,Xt=3220,Zt=3361,en=3402,tn=3614,nn=3615,rn=3642,sn=3734,an=3769,Ye=3802,on=4089,un=4096,$e={string:{to:F$2,from:[F$2,ze,_e$1],serialize:e=>{if(typeof e=="string")return e;if(typeof e=="number")return e.toString();throw new Error("Invalid input for string type")},parse:e=>e},number:{to:0,from:[ve,Ge,We$1,je$1,Qe$1],serialize:e=>e.toString(),parse:e=>+e},bigint:{to:we,from:[we],serialize:e=>e.toString(),parse:e=>{let I=BigInt(e);return I<Number.MIN_SAFE_INTEGER||I>Number.MAX_SAFE_INTEGER?I:Number(I)}},json:{to:Ae$1,from:[Ae$1,Ye],serialize:e=>typeof e=="string"?e:bt(e),parse:e=>ht(e)},boolean:{to:be,from:[be],serialize:e=>{if(typeof e!="boolean")throw new Error("Invalid input for boolean type");return e?"t":"f"},parse:e=>e==="t"},date:{to:xe,from:[He$1,qe$1,xe],serialize:e=>{if(typeof e=="string")return e;if(typeof e=="number")return new Date(e).toISOString();if(e instanceof Date)return e.toISOString();throw new Error("Invalid input for date type")},parse:e=>new Date(e)},bytea:{to:ge$1,from:[ge$1],serialize:e=>{if(!(e instanceof Uint8Array))throw new Error("Invalid input for bytea type");return"\\x"+Array.from(e).map(I=>I.toString(16).padStart(2,"0")).join("")},parse:e=>{let I=e.slice(2);return Uint8Array.from({length:I.length/2},(Hn,$n)=>parseInt(I.substring($n*2,($n+1)*2),16))}}},Se=pn($e),ln=Se.parsers,cn=Se.serializers;function ue$1(e,I,Hn){if(e===null)return null;let $n=Hn?.[I]??Se.parsers[I];return $n?$n(e,I):e}function pn(e){return Object.keys(e).reduce(({parsers:I,serializers:Hn},$n)=>{let{to:qn,from:Xn,serialize:Yn,parse:Kn}=e[$n];return Hn[qn]=Yn,Hn[$n]=Yn,I[$n]=Kn,Array.isArray(Xn)?Xn.forEach(Jn=>{I[Jn]=Kn,Hn[Jn]=Yn}):(I[Xn]=Kn,Hn[Xn]=Yn),{parsers:I,serializers:Hn}},{parsers:{},serializers:{}})}var dn=/\\/g,fn=/"/g;function mn(e){return e.replace(dn,"\\\\").replace(fn,'\\"')}function Ke$1(e,I,Hn){if(Array.isArray(e)===!1)return e;if(!e.length)return"{}";let $n=e[0],qn=Hn===1020?";":",";return Array.isArray($n)?`{${e.map(Xn=>Ke$1(Xn,I,Hn)).join(qn)}}`:`{${e.map(Xn=>(Xn===void 0&&(Xn=null),Xn===null?"null":'"'+mn(I?I(Xn):Xn.toString())+'"')).join(qn)}}`}var he={i:0,char:null,str:"",quoted:!1,last:0,p:null};function yn(e,I,Hn){return he.i=he.last=0,Je(he,e,I,Hn)[0]}function Je(e,I,Hn,$n){let qn=[],Xn=$n===1020?";":",";for(;e.i<I.length;e.i++){if(e.char=I[e.i],e.quoted)e.char==="\\"?e.str+=I[++e.i]:e.char==='"'?(qn.push(Hn?Hn(e.str):e.str),e.str="",e.quoted=I[e.i+1]==='"',e.last=e.i+2):e.str+=e.char;else if(e.char==='"')e.quoted=!0;else if(e.char==="{")e.last=++e.i,qn.push(Je(e,I,Hn,$n));else if(e.char==="}"){e.quoted=!1,e.last<e.i&&qn.push(Hn?Hn(I.slice(e.last,e.i)):I.slice(e.last,e.i)),e.last=e.i+1;break}else e.char===Xn&&e.p!=="}"&&e.p!=='"'&&(qn.push(Hn?Hn(I.slice(e.last,e.i)):I.slice(e.last,e.i)),e.last=e.i+1);e.p=e.char}return e.last<e.i&&qn.push(Hn?Hn(I.slice(e.last,e.i+1)):I.slice(e.last,e.i+1)),qn}var wn={};F$3(wn,{parseDescribeStatementResults:()=>De,parseResults:()=>bn});u$1();function bn(e,I,Hn,$n){let qn=[],Xn={rows:[],fields:[]},Yn=0,Kn={...I,...Hn?.parsers};return e.forEach(Jn=>{switch(Jn.name){case"rowDescription":{let Zn=Jn;Xn.fields=Zn.fields.map(ea=>({name:ea.name,dataTypeID:ea.dataTypeID}));break}case"dataRow":{if(!Xn)break;let Zn=Jn;Hn?.rowMode==="array"?Xn.rows.push(Zn.fields.map((ea,aa)=>ue$1(ea,Xn.fields[aa].dataTypeID,Kn))):Xn.rows.push(Object.fromEntries(Zn.fields.map((ea,aa)=>[Xn.fields[aa].name,ue$1(ea,Xn.fields[aa].dataTypeID,Kn)])));break}case"commandComplete":{Yn+=gn(Jn),qn.push({...Xn,affectedRows:Yn,...$n?{blob:$n}:{}}),Xn={rows:[],fields:[]};break}}}),qn.length===0&&qn.push({affectedRows:0,rows:[],fields:[]}),qn}function gn(e){let I=e.text.split(" ");switch(I[0]){case"INSERT":return parseInt(I[2],10);case"UPDATE":case"DELETE":case"COPY":return parseInt(I[1],10);default:return 0}}function De(e){let I=e.find(Hn=>Hn.name==="parameterDescription");return I?I.dataTypeIDs:[]}var Ue$1={};F$3(Ue$1,{AuthenticationCleartextPassword:()=>G$2,AuthenticationMD5Password:()=>W$2,AuthenticationOk:()=>v,AuthenticationSASL:()=>j$3,AuthenticationSASLContinue:()=>Q,AuthenticationSASLFinal:()=>_,BackendKeyDataMessage:()=>J$1,CommandCompleteMessage:()=>ee$2,CopyDataMessage:()=>z$1,CopyResponse:()=>H$3,DataRowMessage:()=>te$1,DatabaseError:()=>E,Field:()=>q$3,NoticeMessage:()=>ne,NotificationResponseMessage:()=>X$1,ParameterDescriptionMessage:()=>$$1,ParameterStatusMessage:()=>K$2,ReadyForQueryMessage:()=>Z$1,RowDescriptionMessage:()=>Y$1,bindComplete:()=>Ie$1,closeComplete:()=>Me,copyDone:()=>Pe$1,emptyQuery:()=>Ce,noData:()=>Re,parseComplete:()=>Be,portalSuspended:()=>Te$1,replicationStart:()=>Ee});u$1();var Be={name:"parseComplete",length:5},Ie$1={name:"bindComplete",length:5},Me={name:"closeComplete",length:5},Re={name:"noData",length:5},Te$1={name:"portalSuspended",length:5},Ee={name:"replicationStart",length:4},Ce={name:"emptyQuery",length:4},Pe$1={name:"copyDone",length:4},v=class{constructor(e){this.length=e,this.name="authenticationOk"}},G$2=class{constructor(I){this.length=I,this.name="authenticationCleartextPassword"}},W$2=class{constructor(I,Hn){this.length=I,this.salt=Hn,this.name="authenticationMD5Password"}},j$3=class{constructor(I,Hn){this.length=I,this.mechanisms=Hn,this.name="authenticationSASL"}},Q=class{constructor(e,I){this.length=e,this.data=I,this.name="authenticationSASLContinue"}},_=class{constructor(e,I){this.length=e,this.data=I,this.name="authenticationSASLFinal"}},E=class extends Error{constructor(e,I,Hn){super(e),this.length=I,this.name=Hn}},z$1=class{constructor(I,Hn){this.length=I,this.chunk=Hn,this.name="copyData"}},H$3=class{constructor(I,Hn,$n,qn){this.length=I,this.name=Hn,this.binary=$n,this.columnTypes=new Array(qn)}},q$3=class{constructor(I,Hn,$n,qn,Xn,Yn,Kn){this.name=I,this.tableID=Hn,this.columnID=$n,this.dataTypeID=qn,this.dataTypeSize=Xn,this.dataTypeModifier=Yn,this.format=Kn}},Y$1=class{constructor(I,Hn){this.length=I,this.fieldCount=Hn,this.name="rowDescription",this.fields=new Array(this.fieldCount)}},$$1=class{constructor(I,Hn){this.length=I,this.parameterCount=Hn,this.name="parameterDescription",this.dataTypeIDs=new Array(this.parameterCount)}},K$2=class{constructor(I,Hn,$n){this.length=I,this.parameterName=Hn,this.parameterValue=$n,this.name="parameterStatus"}},J$1=class{constructor(I,Hn,$n){this.length=I,this.processID=Hn,this.secretKey=$n,this.name="backendKeyData"}},X$1=class{constructor(I,Hn,$n,qn){this.length=I,this.processId=Hn,this.channel=$n,this.payload=qn,this.name="notification"}},Z$1=class{constructor(I,Hn){this.length=I,this.status=Hn,this.name="readyForQuery"}},ee$2=class{constructor(I,Hn){this.length=I,this.text=Hn,this.name="commandComplete"}},te$1=class{constructor(I,Hn){this.length=I,this.fields=Hn,this.name="dataRow",this.fieldCount=Hn.length}},ne=class{constructor(e,I){this.length=e,this.message=I,this.name="notice"}},zn={};F$3(zn,{Parser:()=>ye,messages:()=>Ue$1,serialize:()=>O$1});u$1();u$1();u$1();u$1();function C$1(e){let I=e.length;for(let Hn=e.length-1;Hn>=0;Hn--){let $n=e.charCodeAt(Hn);$n>127&&$n<=2047?I++:$n>2047&&$n<=65535&&(I+=2),$n>=56320&&$n<=57343&&Hn--}return I}var b$1,g$3,U$1,ce$2,N,x$1,le,P$1,Xe,R$1=class{constructor(I=256){this.size=I,R$2(this,x$1),R$2(this,b$1),R$2(this,g$3,5),R$2(this,U$1,!1),R$2(this,ce$2,new TextEncoder),R$2(this,N,0),x$2(this,b$1,T(this,x$1,le).call(this,I))}addInt32(I){return T(this,x$1,P$1).call(this,4),h$1(this,b$1).setInt32(h$1(this,g$3),I,h$1(this,U$1)),x$2(this,g$3,h$1(this,g$3)+4),this}addInt16(I){return T(this,x$1,P$1).call(this,2),h$1(this,b$1).setInt16(h$1(this,g$3),I,h$1(this,U$1)),x$2(this,g$3,h$1(this,g$3)+2),this}addCString(I){return I&&this.addString(I),T(this,x$1,P$1).call(this,1),h$1(this,b$1).setUint8(h$1(this,g$3),0),U$2(this,g$3)._++,this}addString(I=""){let Hn=C$1(I);return T(this,x$1,P$1).call(this,Hn),h$1(this,ce$2).encodeInto(I,new Uint8Array(h$1(this,b$1).buffer,h$1(this,g$3))),x$2(this,g$3,h$1(this,g$3)+Hn),this}add(I){return T(this,x$1,P$1).call(this,I.byteLength),new Uint8Array(h$1(this,b$1).buffer).set(new Uint8Array(I),h$1(this,g$3)),x$2(this,g$3,h$1(this,g$3)+I.byteLength),this}flush(I){let Hn=T(this,x$1,Xe).call(this,I);return x$2(this,g$3,5),x$2(this,b$1,T(this,x$1,le).call(this,this.size)),new Uint8Array(Hn)}};b$1=new WeakMap,g$3=new WeakMap,U$1=new WeakMap,ce$2=new WeakMap,N=new WeakMap,x$1=new WeakSet,le=function(e){return new DataView(new ArrayBuffer(e))},P$1=function(e){if(h$1(this,b$1).byteLength-h$1(this,g$3)<e){let I=h$1(this,b$1).buffer,Hn=I.byteLength+(I.byteLength>>1)+e;x$2(this,b$1,T(this,x$1,le).call(this,Hn)),new Uint8Array(h$1(this,b$1).buffer).set(new Uint8Array(I))}},Xe=function(e){if(e){h$1(this,b$1).setUint8(h$1(this,N),e);let I=h$1(this,g$3)-(h$1(this,N)+1);h$1(this,b$1).setInt32(h$1(this,N)+1,I,h$1(this,U$1))}return h$1(this,b$1).buffer.slice(e?0:5,h$1(this,g$3))};var m=new R$1,An=e=>{m.addInt16(3).addInt16(0);for(let $n of Object.keys(e))m.addCString($n).addCString(e[$n]);m.addCString("client_encoding").addCString("UTF8");let I=m.addCString("").flush(),Hn=I.byteLength+4;return new R$1().addInt32(Hn).add(I).flush()},xn=()=>{let e=new DataView(new ArrayBuffer(8));return e.setInt32(0,8,!1),e.setInt32(4,80877103,!1),new Uint8Array(e.buffer)},Sn=e=>m.addCString(e).flush(112),Dn=(e,I)=>(m.addCString(e).addInt32(C$1(I)).addString(I),m.flush(112)),Bn=e=>m.addString(e).flush(112),In=e=>m.addCString(e).flush(81),Mn=[],Rn=e=>{let I=e.name??"";I.length>63&&(console.error("Warning! Postgres only supports 63 characters for query names."),console.error("You supplied %s (%s)",I,I.length),console.error("This can cause conflicts and silent errors executing queries"));let Hn=m.addCString(I).addCString(e.text).addInt16(e.types?.length??0);return e.types?.forEach($n=>Hn.addInt32($n)),m.flush(80)},L$1=new R$1,Tn=(e,I)=>{for(let Hn=0;Hn<e.length;Hn++){let $n=I?I(e[Hn],Hn):e[Hn];if($n===null)m.addInt16(0),L$1.addInt32(-1);else if($n instanceof ArrayBuffer||ArrayBuffer.isView($n)){let qn=ArrayBuffer.isView($n)?$n.buffer.slice($n.byteOffset,$n.byteOffset+$n.byteLength):$n;m.addInt16(1),L$1.addInt32(qn.byteLength),L$1.add(qn)}else m.addInt16(0),L$1.addInt32(C$1($n)),L$1.addString($n)}},En=(e={})=>{let I=e.portal??"",Hn=e.statement??"",$n=e.binary??!1,qn=e.values??Mn,Xn=qn.length;return m.addCString(I).addCString(Hn),m.addInt16(Xn),Tn(qn,e.valueMapper),m.addInt16(Xn),m.add(L$1.flush()),m.addInt16($n?1:0),m.flush(66)},Cn=new Uint8Array([69,0,0,0,9,0,0,0,0,0]),Pn=e=>{if(!e||!e.portal&&!e.rows)return Cn;let I=e.portal??"",Hn=e.rows??0,$n=C$1(I),qn=4+$n+1+4,Xn=new DataView(new ArrayBuffer(1+qn));return Xn.setUint8(0,69),Xn.setInt32(1,qn,!1),new TextEncoder().encodeInto(I,new Uint8Array(Xn.buffer,5)),Xn.setUint8($n+5,0),Xn.setUint32(Xn.byteLength-4,Hn,!1),new Uint8Array(Xn.buffer)},Un=(e,I)=>{let Hn=new DataView(new ArrayBuffer(16));return Hn.setInt32(0,16,!1),Hn.setInt16(4,1234,!1),Hn.setInt16(6,5678,!1),Hn.setInt32(8,e,!1),Hn.setInt32(12,I,!1),new Uint8Array(Hn.buffer)},Ne=(e,I)=>{let Hn=new R$1;return Hn.addCString(I),Hn.flush(e)},Nn=m.addCString("P").flush(68),Ln=m.addCString("S").flush(68),On=e=>e.name?Ne(68,`${e.type}${e.name??""}`):e.type==="P"?Nn:Ln,kn=e=>{let I=`${e.type}${e.name??""}`;return Ne(67,I)},Vn=e=>m.add(e).flush(100),Fn=e=>Ne(102,e),pe$1=e=>new Uint8Array([e,0,0,0,4]),vn=pe$1(72),Gn=pe$1(83),Wn=pe$1(88),jn=pe$1(99),O$1={startup:An,password:Sn,requestSsl:xn,sendSASLInitialResponseMessage:Dn,sendSCRAMClientFinalMessage:Bn,query:In,parse:Rn,bind:En,execute:Pn,describe:On,close:kn,flush:()=>vn,sync:()=>Gn,end:()=>Wn,copyData:Vn,copyDone:()=>jn,copyFail:Fn,cancel:Un};u$1();u$1();var Le={text:0,binary:1};u$1();var Qn=new ArrayBuffer(0),M$1,w$1,fe,me$1,re$1,de=class{constructor(e=0){R$2(this,M$1,new DataView(Qn)),R$2(this,w$1),R$2(this,fe,"utf-8"),R$2(this,me$1,new TextDecoder(h$1(this,fe))),R$2(this,re$1,!1),x$2(this,w$1,e)}setBuffer(e,I){x$2(this,w$1,e),x$2(this,M$1,new DataView(I))}int16(){let e=h$1(this,M$1).getInt16(h$1(this,w$1),h$1(this,re$1));return x$2(this,w$1,h$1(this,w$1)+2),e}byte(){let e=h$1(this,M$1).getUint8(h$1(this,w$1));return U$2(this,w$1)._++,e}int32(){let e=h$1(this,M$1).getInt32(h$1(this,w$1),h$1(this,re$1));return x$2(this,w$1,h$1(this,w$1)+4),e}string(e){return h$1(this,me$1).decode(this.bytes(e))}cstring(){let e=h$1(this,w$1),I=e;for(;h$1(this,M$1).getUint8(I++)!==0;);let Hn=this.string(I-e-1);return x$2(this,w$1,I),Hn}bytes(e){let I=h$1(this,M$1).buffer.slice(h$1(this,w$1),h$1(this,w$1)+e);return x$2(this,w$1,h$1(this,w$1)+e),new Uint8Array(I)}};M$1=new WeakMap,w$1=new WeakMap,fe=new WeakMap,me$1=new WeakMap,re$1=new WeakMap;var Oe=1,_n=4,Ze=Oe+_n,et=new ArrayBuffer(0),A,S$1,D$1,o$1,l$1,tt,nt,rt,st,it,at,ot,ke$1,ut,lt,ct,pt,dt,ft,mt,yt,Ve$1,ye=class{constructor(){R$2(this,l$1),R$2(this,A,new DataView(et)),R$2(this,S$1,0),R$2(this,D$1,0),R$2(this,o$1,new de)}parse(e,I){T(this,l$1,tt).call(this,ArrayBuffer.isView(e)?e.buffer.slice(e.byteOffset,e.byteOffset+e.byteLength):e);let Hn=h$1(this,D$1)+h$1(this,S$1),$n=h$1(this,D$1);for(;$n+Ze<=Hn;){let qn=h$1(this,A).getUint8($n),Xn=h$1(this,A).getUint32($n+Oe,!1),Yn=Oe+Xn;if(Yn+$n<=Hn){let Kn=T(this,l$1,nt).call(this,$n+Ze,qn,Xn,h$1(this,A).buffer);I(Kn),$n+=Yn}else break}$n===Hn?(x$2(this,A,new DataView(et)),x$2(this,S$1,0),x$2(this,D$1,0)):(x$2(this,S$1,Hn-$n),x$2(this,D$1,$n))}};A=new WeakMap,S$1=new WeakMap,D$1=new WeakMap,o$1=new WeakMap,l$1=new WeakSet,tt=function(e){if(h$1(this,S$1)>0){let I=h$1(this,S$1)+e.byteLength;if(I+h$1(this,D$1)>h$1(this,A).byteLength){let Hn;if(I<=h$1(this,A).byteLength&&h$1(this,D$1)>=h$1(this,S$1))Hn=h$1(this,A).buffer;else{let $n=h$1(this,A).byteLength*2;for(;I>=$n;)$n*=2;Hn=new ArrayBuffer($n)}new Uint8Array(Hn).set(new Uint8Array(h$1(this,A).buffer,h$1(this,D$1),h$1(this,S$1))),x$2(this,A,new DataView(Hn)),x$2(this,D$1,0)}new Uint8Array(h$1(this,A).buffer).set(new Uint8Array(e),h$1(this,D$1)+h$1(this,S$1)),x$2(this,S$1,I)}else x$2(this,A,new DataView(e)),x$2(this,D$1,0),x$2(this,S$1,e.byteLength)},nt=function(e,I,Hn,$n){switch(I){case 50:return Ie$1;case 49:return Be;case 51:return Me;case 110:return Re;case 115:return Te$1;case 99:return Pe$1;case 87:return Ee;case 73:return Ce;case 68:return T(this,l$1,dt).call(this,e,Hn,$n);case 67:return T(this,l$1,st).call(this,e,Hn,$n);case 90:return T(this,l$1,rt).call(this,e,Hn,$n);case 65:return T(this,l$1,ut).call(this,e,Hn,$n);case 82:return T(this,l$1,yt).call(this,e,Hn,$n);case 83:return T(this,l$1,ft).call(this,e,Hn,$n);case 75:return T(this,l$1,mt).call(this,e,Hn,$n);case 69:return T(this,l$1,Ve$1).call(this,e,Hn,$n,"error");case 78:return T(this,l$1,Ve$1).call(this,e,Hn,$n,"notice");case 84:return T(this,l$1,lt).call(this,e,Hn,$n);case 116:return T(this,l$1,pt).call(this,e,Hn,$n);case 71:return T(this,l$1,at).call(this,e,Hn,$n);case 72:return T(this,l$1,ot).call(this,e,Hn,$n);case 100:return T(this,l$1,it).call(this,e,Hn,$n);default:return new E("received invalid response: "+I.toString(16),Hn,"error")}},rt=function(e,I,Hn){h$1(this,o$1).setBuffer(e,Hn);let $n=h$1(this,o$1).string(1);return new Z$1(I,$n)},st=function(e,I,Hn){h$1(this,o$1).setBuffer(e,Hn);let $n=h$1(this,o$1).cstring();return new ee$2(I,$n)},it=function(e,I,Hn){let $n=Hn.slice(e,e+(I-4));return new z$1(I,new Uint8Array($n))},at=function(e,I,Hn){return T(this,l$1,ke$1).call(this,e,I,Hn,"copyInResponse")},ot=function(e,I,Hn){return T(this,l$1,ke$1).call(this,e,I,Hn,"copyOutResponse")},ke$1=function(e,I,Hn,$n){h$1(this,o$1).setBuffer(e,Hn);let qn=h$1(this,o$1).byte()!==0,Xn=h$1(this,o$1).int16(),Yn=new H$3(I,$n,qn,Xn);for(let Kn=0;Kn<Xn;Kn++)Yn.columnTypes[Kn]=h$1(this,o$1).int16();return Yn},ut=function(e,I,Hn){h$1(this,o$1).setBuffer(e,Hn);let $n=h$1(this,o$1).int32(),qn=h$1(this,o$1).cstring(),Xn=h$1(this,o$1).cstring();return new X$1(I,$n,qn,Xn)},lt=function(e,I,Hn){h$1(this,o$1).setBuffer(e,Hn);let $n=h$1(this,o$1).int16(),qn=new Y$1(I,$n);for(let Xn=0;Xn<$n;Xn++)qn.fields[Xn]=T(this,l$1,ct).call(this);return qn},ct=function(){let e=h$1(this,o$1).cstring(),I=h$1(this,o$1).int32(),Hn=h$1(this,o$1).int16(),$n=h$1(this,o$1).int32(),qn=h$1(this,o$1).int16(),Xn=h$1(this,o$1).int32(),Yn=h$1(this,o$1).int16()===0?Le.text:Le.binary;return new q$3(e,I,Hn,$n,qn,Xn,Yn)},pt=function(e,I,Hn){h$1(this,o$1).setBuffer(e,Hn);let $n=h$1(this,o$1).int16(),qn=new $$1(I,$n);for(let Xn=0;Xn<$n;Xn++)qn.dataTypeIDs[Xn]=h$1(this,o$1).int32();return qn},dt=function(e,I,Hn){h$1(this,o$1).setBuffer(e,Hn);let $n=h$1(this,o$1).int16(),qn=new Array($n);for(let Xn=0;Xn<$n;Xn++){let Yn=h$1(this,o$1).int32();qn[Xn]=Yn===-1?null:h$1(this,o$1).string(Yn)}return new te$1(I,qn)},ft=function(e,I,Hn){h$1(this,o$1).setBuffer(e,Hn);let $n=h$1(this,o$1).cstring(),qn=h$1(this,o$1).cstring();return new K$2(I,$n,qn)},mt=function(e,I,Hn){h$1(this,o$1).setBuffer(e,Hn);let $n=h$1(this,o$1).int32(),qn=h$1(this,o$1).int32();return new J$1(I,$n,qn)},yt=function(e,I,Hn){h$1(this,o$1).setBuffer(e,Hn);let $n=h$1(this,o$1).int32();switch($n){case 0:return new v(I);case 3:return new G$2(I);case 5:return new W$2(I,h$1(this,o$1).bytes(4));case 10:{let qn=[];for(;;){let Xn=h$1(this,o$1).cstring();if(Xn.length===0)return new j$3(I,qn);qn.push(Xn)}}case 11:return new Q(I,h$1(this,o$1).string(I-8));case 12:return new _(I,h$1(this,o$1).string(I-8));default:throw new Error("Unknown authenticationOk message type "+$n)}},Ve$1=function(e,I,Hn,$n){h$1(this,o$1).setBuffer(e,Hn);let qn={},Xn=h$1(this,o$1).string(1);for(;Xn!=="\0";)qn[Xn]=h$1(this,o$1).cstring(),Xn=h$1(this,o$1).string(1);let Yn=qn.M,Kn=$n==="notice"?new ne(I,Yn):new E(Yn,I,$n);return Kn.severity=qn.S,Kn.code=qn.C,Kn.detail=qn.D,Kn.hint=qn.H,Kn.position=qn.P,Kn.internalPosition=qn.p,Kn.internalQuery=qn.q,Kn.where=qn.W,Kn.schema=qn.s,Kn.table=qn.t,Kn.column=qn.c,Kn.dataType=qn.d,Kn.constraint=qn.n,Kn.file=qn.F,Kn.line=qn.L,Kn.routine=qn.R,Kn};u$1();var Fe$1=typeof process=="object"&&typeof process.versions=="object"&&typeof process.versions.node=="string",se$2;async function Rr(){if(Fe$1||se$2)return;let e=new URL("/_build/assets/postgres-CyuUVpXN.wasm",import.meta.url);se$2=fetch(e)}var k$1;async function Tr(e,I){if(I||k$1)return WebAssembly.instantiate(I||k$1,e),{instance:await WebAssembly.instantiate(I||k$1,e),module:I||k$1};let Hn=new URL("/_build/assets/postgres-CyuUVpXN.wasm",import.meta.url);if(Fe$1){let $n=await(await import("./__vite-browser-external-9wXp6ZBx.js")).readFile(Hn),{module:qn,instance:Xn}=await WebAssembly.instantiate($n,e);return k$1=qn,{instance:Xn,module:qn}}else{se$2||(se$2=fetch(Hn));let $n=await se$2,{module:qn,instance:Xn}=await WebAssembly.instantiateStreaming($n,e);return k$1=qn,{instance:Xn,module:qn}}}async function Er(){let e=new URL("/_build/assets/postgres-CkP7QCDB.data",import.meta.url);return Fe$1?(await(await import("./__vite-browser-external-9wXp6ZBx.js")).readFile(e)).buffer:(await fetch(e)).arrayBuffer()}var Cr=()=>{if(globalThis.crypto?.randomUUID)return globalThis.crypto.randomUUID();let e=new Uint8Array(16);if(globalThis.crypto?.getRandomValues)globalThis.crypto.getRandomValues(e);else for(let Hn=0;Hn<e.length;Hn++)e[Hn]=Math.floor(Math.random()*256);e[6]=e[6]&15|64,e[8]=e[8]&63|128;let I=[];return e.forEach(Hn=>{I.push(Hn.toString(16).padStart(2,"0"))}),I.slice(0,4).join("")+"-"+I.slice(4,6).join("")+"-"+I.slice(6,8).join("")+"-"+I.slice(8,10).join("")+"-"+I.slice(10).join("")};async function Pr(e,I,Hn,$n){if(!Hn||Hn.length===0)return I;$n=$n??e;let qn;try{await e.execProtocol(O$1.parse({text:I}),{syncToFs:!1}),qn=De((await e.execProtocol(O$1.describe({type:"S"}),{syncToFs:!1})).messages)}finally{await e.execProtocol(O$1.sync(),{syncToFs:!1})}let Xn=I.replace(/\$([0-9]+)/g,(Yn,Kn)=>"%"+Kn+"L");return(await $n.query(`SELECT format($1, ${Hn.map((Yn,Kn)=>`$${Kn+2}`).join(", ")}) as query`,[Xn,...Hn],{paramTypes:[F$2,...qn]})).rows[0].query}function Ur(e){let I,Hn=!1,$n=async()=>{if(!I){Hn=!1;return}Hn=!0;let{args:qn,resolve:Xn,reject:Yn}=I;I=void 0;try{let Kn=await e(...qn);Xn(Kn)}catch(Kn){Yn(Kn)}finally{$n()}};return async(...qn)=>{I&&I.resolve(void 0);let Xn=new Promise((Yn,Kn)=>{I={args:qn,resolve:Yn,reject:Kn}});return Hn||$n(),Xn}}function Nr(e){let I;return e.startsWith('"')&&e.endsWith('"')?I=e.substring(1,e.length-1):I=e.toLowerCase(),I}u$1();var o={part:"part",container:"container"};function s(e,I,...Hn){let $n=e.length-1,qn=Hn.length-1;if(qn!==-1){if(qn===0){e[$n]=e[$n]+Hn[0]+I;return}e[$n]=e[$n]+Hn[0],e.push(...Hn.slice(1,qn)),e.push(Hn[qn]+I)}}function y(e,...I){let Hn=[e[0]];Hn.raw=[e.raw[0]];let $n=[];for(let qn=0;qn<I.length;qn++){let Xn=I[qn],Yn=qn+1;if(Xn?._templateType===o.part){s(Hn,e[Yn],Xn.str),s(Hn.raw,e.raw[Yn],Xn.str);continue}if(Xn?._templateType===o.container){s(Hn,e[Yn],...Xn.strings),s(Hn.raw,e.raw[Yn],...Xn.strings.raw),$n.push(...Xn.values);continue}Hn.push(e[Yn]),Hn.raw.push(e.raw[Yn]),$n.push(Xn)}return{_templateType:"container",strings:Hn,values:$n}}function g$2(e,...I){let{strings:Hn,values:$n}=y(e,...I);return{query:[Hn[0],...$n.flatMap((qn,Xn)=>[`$${Xn+1}`,Hn[Xn+1]])].join(""),params:$n}}u$1();var b,u,r,l,g$1,h,R,z=class{constructor(){R$2(this,r),this.serializers={...cn},this.parsers={...ln},R$2(this,b,!1),R$2(this,u,!1)}async _initArrayTypes({force:e=!1}={}){if(h$1(this,b)&&!e)return;x$2(this,b,!0);let I=await this.query(`
      SELECT b.oid, b.typarray
      FROM pg_catalog.pg_type a
      LEFT JOIN pg_catalog.pg_type b ON b.oid = a.typelem
      WHERE a.typcategory = 'A'
      GROUP BY b.oid, b.typarray
      ORDER BY b.oid
    `);for(let Hn of I.rows)this.serializers[Hn.typarray]=$n=>Ke$1($n,this.serializers[Hn.oid],Hn.typarray),this.parsers[Hn.typarray]=$n=>yn($n,this.parsers[Hn.oid],Hn.typarray)}async refreshArrayTypes(){await this._initArrayTypes({force:!0})}async query(e,I,Hn){return await this._checkReady(),await this._runExclusiveTransaction(async()=>await T(this,r,g$1).call(this,e,I,Hn))}async sql(e,...I){let{query:Hn,params:$n}=g$2(e,...I);return await this.query(Hn,$n)}async exec(e,I){return await this._checkReady(),await this._runExclusiveTransaction(async()=>await T(this,r,h).call(this,e,I))}async describeQuery(e,I){try{await T(this,r,l).call(this,O$1.parse({text:e,types:I?.paramTypes}),I);let Hn=await T(this,r,l).call(this,O$1.describe({type:"S"}),I),$n=Hn.messages.find(Kn=>Kn.name==="parameterDescription"),qn=Hn.messages.find(Kn=>Kn.name==="rowDescription"),Xn=$n?.dataTypeIDs.map(Kn=>({dataTypeID:Kn,serializer:this.serializers[Kn]}))??[],Yn=qn?.fields.map(Kn=>({name:Kn.name,dataTypeID:Kn.dataTypeID,parser:this.parsers[Kn.dataTypeID]}))??[];return{queryParams:Xn,resultFields:Yn}}finally{await T(this,r,l).call(this,O$1.sync(),I)}}async transaction(e){return await this._checkReady(),await this._runExclusiveTransaction(async()=>{await T(this,r,h).call(this,"BEGIN"),x$2(this,u,!0);let I=!1,Hn=()=>{if(I)throw new Error("Transaction is closed")},$n={query:async(qn,Xn,Yn)=>(Hn(),await T(this,r,g$1).call(this,qn,Xn,Yn)),sql:async(qn,...Xn)=>{let{query:Yn,params:Kn}=g$2(qn,...Xn);return await T(this,r,g$1).call(this,Yn,Kn)},exec:async(qn,Xn)=>(Hn(),await T(this,r,h).call(this,qn,Xn)),rollback:async()=>{Hn(),await T(this,r,h).call(this,"ROLLBACK"),I=!0},get closed(){return I}};try{let qn=await e($n);return I||(I=!0,await T(this,r,h).call(this,"COMMIT")),x$2(this,u,!1),qn}catch(qn){throw I||await T(this,r,h).call(this,"ROLLBACK"),x$2(this,u,!1),qn}})}async runExclusive(e){return await this._runExclusiveQuery(e)}};b=new WeakMap,u=new WeakMap,r=new WeakSet,l=async function(e,I={}){return await this.execProtocol(e,{...I,syncToFs:!1})},g$1=async function(e,I=[],Hn){return await this._runExclusiveQuery(async()=>{T(this,r,R).call(this,"runQuery",e,I,Hn),await this._handleBlob(Hn?.blob);let $n;try{let{messages:Xn}=await T(this,r,l).call(this,O$1.parse({text:e,types:Hn?.paramTypes}),Hn),Yn=De((await T(this,r,l).call(this,O$1.describe({type:"S"}),Hn)).messages),Kn=I.map((Jn,Zn)=>{let ea=Yn[Zn];if(Jn==null)return null;let aa=Hn?.serializers?.[ea]??this.serializers[ea];return aa?aa(Jn):Jn.toString()});$n=[...Xn,...(await T(this,r,l).call(this,O$1.bind({values:Kn}),Hn)).messages,...(await T(this,r,l).call(this,O$1.describe({type:"P"}),Hn)).messages,...(await T(this,r,l).call(this,O$1.execute({}),Hn)).messages]}finally{await T(this,r,l).call(this,O$1.sync(),Hn)}await this._cleanupBlob(),h$1(this,u)||await this.syncToFs();let qn=await this._getWrittenBlob();return bn($n,this.parsers,Hn,qn)[0]})},h=async function(e,I){return await this._runExclusiveQuery(async()=>{T(this,r,R).call(this,"runExec",e,I),await this._handleBlob(I?.blob);let Hn;try{Hn=(await T(this,r,l).call(this,O$1.query(e),I)).messages}finally{await T(this,r,l).call(this,O$1.sync(),I)}this._cleanupBlob(),h$1(this,u)||await this.syncToFs();let $n=await this._getWrittenBlob();return bn(Hn,this.parsers,I,$n)})},R=function(...e){this.debug>0&&console.log(...e)};u$1();async function se$1({init:e}){postMessage({type:"here"});let I=await new Promise(Jn=>{addEventListener("message",Zn=>{Zn.data.type==="init"&&Jn(Zn.data.options)},{once:!0})}),Hn=I.id??`${import.meta.url}:${I.dataDir??""}`;postMessage({type:"ready",id:Hn});let $n=`pglite-election-lock:${Hn}`,qn=`pglite-broadcast:${Hn}`,Xn=new BroadcastChannel(qn),Yn=new Set;await q$2($n);let Kn=e(I);Xn.onmessage=async Jn=>{let Zn=Jn.data;switch(Zn.type){case"tab-here":V$2(Zn.id,await Kn,Yn);break}},Xn.postMessage({type:"leader-here",id:Hn}),postMessage({type:"leader-now"}),(await Kn).onNotification((Jn,Zn)=>{Xn.postMessage({type:"notify",channel:Jn,payload:Zn})})}function V$2(e,I,Hn){if(Hn.has(e))return;Hn.add(e);let $n=`pglite-tab:${e}`,qn=`pglite-tab-close:${e}`,Xn=new BroadcastChannel($n);navigator.locks.request(qn,()=>new Promise(Kn=>{Xn.close(),Hn.delete(e),Kn()}));let Yn=X(e,I);Xn.addEventListener("message",async Kn=>{let Jn=Kn.data;switch(Jn.type){case"rpc-call":{await I.waitReady;let{callId:Zn,method:ea,args:aa}=Jn;try{let oa=await Yn[ea](...aa);Xn.postMessage({type:"rpc-return",callId:Zn,result:oa})}catch(oa){console.error(oa),Xn.postMessage({type:"rpc-error",callId:Zn,error:{message:oa.message}})}break}}}),Xn.postMessage({type:"connected"})}function X(e,I){let Hn=null,$n=null,qn=`pglite-tab-close:${e}`;return q$2(qn).then(()=>{$n&&I.exec("ROLLBACK"),Hn?.(),$n?.()}),{async getDebugLevel(){return I.debug},async close(){await I.close()},async execProtocol(Xn){let{messages:Yn,data:Kn}=await I.execProtocol(Xn);if(Kn.byteLength!==Kn.buffer.byteLength){let Jn=new ArrayBuffer(Kn.byteLength),Zn=new Uint8Array(Jn);return Zn.set(Kn),{messages:Yn,data:Zn}}else return{messages:Yn,data:Kn}},async execProtocolRaw(Xn){let Yn=await I.execProtocolRaw(Xn);if(Yn.byteLength!==Yn.buffer.byteLength){let Kn=new ArrayBuffer(Yn.byteLength),Jn=new Uint8Array(Kn);return Jn.set(Yn),Jn}else return Yn},async dumpDataDir(){return await I.dumpDataDir()},async syncToFs(){return await I.syncToFs()},async _handleBlob(Xn){return await I._handleBlob(Xn)},async _getWrittenBlob(){return await I._getWrittenBlob()},async _cleanupBlob(){return await I._cleanupBlob()},async _checkReady(){return await I._checkReady()},async _acquireQueryLock(){return new Promise(Xn=>{I._runExclusiveQuery(()=>new Promise(Yn=>{Hn=Yn,Xn()}))})},async _releaseQueryLock(){Hn?.(),Hn=null},async _acquireTransactionLock(){return new Promise(Xn=>{I._runExclusiveTransaction(()=>new Promise(Yn=>{$n=Yn,Xn()}))})},async _releaseTransactionLock(){$n?.(),$n=null}}}async function q$2(e){let I;return await new Promise(Hn=>{navigator.locks.request(e,()=>new Promise($n=>{I=$n,Hn()}))}),I}var w=D$2((e,I)=>{u$1();var Hn=9007199254740991,$n=function(Ea){return Ea}();function qn(Ea){return Ea===$n}function Xn(Ea){return typeof Ea=="string"||Object.prototype.toString.call(Ea)=="[object String]"}function Yn(Ea){return Object.prototype.toString.call(Ea)=="[object Date]"}function Kn(Ea){return Ea!==null&&typeof Ea=="object"}function Jn(Ea){return typeof Ea=="function"}function Zn(Ea){return typeof Ea=="number"&&Ea>-1&&Ea%1==0&&Ea<=Hn}function ea(Ea){return Object.prototype.toString.call(Ea)=="[object Array]"}function aa(Ea){return Kn(Ea)&&!Jn(Ea)&&Zn(Ea.length)}function oa(Ea){return Object.prototype.toString.call(Ea)=="[object ArrayBuffer]"}function la(Ea,na){return Array.prototype.map.call(Ea,na)}function ra(Ea,na){var ta=$n;return Jn(na)&&Array.prototype.every.call(Ea,function(sa,ca,_a){var pa=na(sa,ca,_a);return pa&&(ta=sa),!pa}),ta}function ia(Ea){return Object.assign.apply(null,arguments)}function da(Ea){var na,ta,sa;if(Xn(Ea)){for(ta=Ea.length,sa=new Uint8Array(ta),na=0;na<ta;na++)sa[na]=Ea.charCodeAt(na)&255;return sa}return oa(Ea)?new Uint8Array(Ea):Kn(Ea)&&oa(Ea.buffer)?new Uint8Array(Ea.buffer):aa(Ea)?new Uint8Array(Ea):Kn(Ea)&&Jn(Ea.toString)?da(Ea.toString()):new Uint8Array}I.exports.MAX_SAFE_INTEGER=Hn,I.exports.isUndefined=qn,I.exports.isString=Xn,I.exports.isObject=Kn,I.exports.isDateTime=Yn,I.exports.isFunction=Jn,I.exports.isArray=ea,I.exports.isArrayLike=aa,I.exports.isArrayBuffer=oa,I.exports.map=la,I.exports.find=ra,I.exports.extend=ia,I.exports.toUint8Array=da}),x=D$2((e,I)=>{u$1();var Hn="\0";I.exports={NULL_CHAR:Hn,TMAGIC:"ustar"+Hn+"00",OLDGNU_MAGIC:"ustar  "+Hn,REGTYPE:0,LNKTYPE:1,SYMTYPE:2,CHRTYPE:3,BLKTYPE:4,DIRTYPE:5,FIFOTYPE:6,CONTTYPE:7,TSUID:parseInt("4000",8),TSGID:parseInt("2000",8),TSVTX:parseInt("1000",8),TUREAD:parseInt("0400",8),TUWRITE:parseInt("0200",8),TUEXEC:parseInt("0100",8),TGREAD:parseInt("0040",8),TGWRITE:parseInt("0020",8),TGEXEC:parseInt("0010",8),TOREAD:parseInt("0004",8),TOWRITE:parseInt("0002",8),TOEXEC:parseInt("0001",8),TPERMALL:parseInt("0777",8),TPERMMASK:parseInt("0777",8)}}),L=D$2((e,I)=>{u$1();var Hn=w(),$n=x(),qn=512,Xn=$n.TPERMALL,Yn=0,Kn=0,Jn=[["name",100,0,function(na,ta){return aa(na[ta[0]],ta[1])},function(na,ta,sa){return ra(na.slice(ta,ta+sa[1]))}],["mode",8,100,function(na,ta){var sa=na[ta[0]]||Xn;return sa=sa&$n.TPERMMASK,oa(sa,ta[1],Xn)},function(na,ta,sa){var ca=ia(na.slice(ta,ta+sa[1]));return ca&=$n.TPERMMASK,ca}],["uid",8,108,function(na,ta){return oa(na[ta[0]],ta[1],Yn)},function(na,ta,sa){return ia(na.slice(ta,ta+sa[1]))}],["gid",8,116,function(na,ta){return oa(na[ta[0]],ta[1],Kn)},function(na,ta,sa){return ia(na.slice(ta,ta+sa[1]))}],["size",12,124,function(na,ta){return oa(na.data.length,ta[1])},function(na,ta,sa){return ia(na.slice(ta,ta+sa[1]))}],["modifyTime",12,136,function(na,ta){return la(na[ta[0]],ta[1])},function(na,ta,sa){return da(na.slice(ta,ta+sa[1]))}],["checksum",8,148,function(na,ta){return"        "},function(na,ta,sa){return ia(na.slice(ta,ta+sa[1]))}],["type",1,156,function(na,ta){return""+(parseInt(na[ta[0]],10)||0)%8},function(na,ta,sa){return(parseInt(String.fromCharCode(na[ta]),10)||0)%8}],["linkName",100,157,function(na,ta){return""},function(na,ta,sa){return ra(na.slice(ta,ta+sa[1]))}],["ustar",8,257,function(na,ta){return $n.TMAGIC},function(na,ta,sa){return ea(ra(na.slice(ta,ta+sa[1]),!0))},function(na,ta){return na[ta[0]]==$n.TMAGIC||na[ta[0]]==$n.OLDGNU_MAGIC}],["owner",32,265,function(na,ta){return aa(na[ta[0]],ta[1])},function(na,ta,sa){return ra(na.slice(ta,ta+sa[1]))}],["group",32,297,function(na,ta){return aa(na[ta[0]],ta[1])},function(na,ta,sa){return ra(na.slice(ta,ta+sa[1]))}],["majorNumber",8,329,function(na,ta){return""},function(na,ta,sa){return ia(na.slice(ta,ta+sa[1]))}],["minorNumber",8,337,function(na,ta){return""},function(na,ta,sa){return ia(na.slice(ta,ta+sa[1]))}],["prefix",131,345,function(na,ta){return aa(na[ta[0]],ta[1])},function(na,ta,sa){return ra(na.slice(ta,ta+sa[1]))}],["accessTime",12,476,function(na,ta){return la(na[ta[0]],ta[1])},function(na,ta,sa){return da(na.slice(ta,ta+sa[1]))}],["createTime",12,488,function(na,ta){return la(na[ta[0]],ta[1])},function(na,ta,sa){return da(na.slice(ta,ta+sa[1]))}]],Zn=function(na){var ta=na[na.length-1];return ta[2]+ta[1]}(Jn);function ea(na){if(na.length==8){var ta=na.split("");if(ta[5]==$n.NULL_CHAR)return(ta[6]==" "||ta[6]==$n.NULL_CHAR)&&(ta[6]="0"),(ta[7]==" "||ta[7]==$n.NULL_CHAR)&&(ta[7]="0"),ta=ta.join(""),ta==$n.TMAGIC?ta:na;if(ta[7]==$n.NULL_CHAR)return ta[5]==$n.NULL_CHAR&&(ta[5]=" "),ta[6]==$n.NULL_CHAR&&(ta[6]=" "),ta==$n.OLDGNU_MAGIC?ta:na}return na}function aa(na,ta){return ta-=1,Hn.isUndefined(na)&&(na=""),na=(""+na).substr(0,ta),na+$n.NULL_CHAR}function oa(na,ta,sa){for(sa=parseInt(sa)||0,ta-=1,na=(parseInt(na)||sa).toString(8).substr(-ta,ta);na.length<ta;)na="0"+na;return na+$n.NULL_CHAR}function la(na,ta){if(Hn.isDateTime(na))na=Math.floor(1*na/1e3);else if(na=parseInt(na,10),isFinite(na)){if(na<=0)return""}else na=Math.floor(1*new Date/1e3);return oa(na,ta,0)}function ra(na,ta){var sa=String.fromCharCode.apply(null,na);if(ta)return sa;var ca=sa.indexOf($n.NULL_CHAR);return ca>=0?sa.substr(0,ca):sa}function ia(na){var ta=String.fromCharCode.apply(null,na);return parseInt(ta.replace(/^0+$/g,""),8)||0}function da(na){return na.length==0||na[0]==0?null:new Date(1e3*ia(na))}function Ea(na,ta,sa){var ca=parseInt(ta,10)||0,_a=Math.min(ca+Zn,na.length),pa=0,Sa=0,Na=0;sa&&Jn.every(function(Aa){return Aa[0]=="checksum"?(Sa=ca+Aa[2],Na=Sa+Aa[1],!1):!0});for(var ma=32,Ia=ca;Ia<_a;Ia++){var ua=Ia>=Sa&&Ia<Na?ma:na[Ia];pa=(pa+ua)%262144}return pa}I.exports.recordSize=qn,I.exports.defaultFileMode=Xn,I.exports.defaultUid=Yn,I.exports.defaultGid=Kn,I.exports.posixHeader=Jn,I.exports.effectiveHeaderSize=Zn,I.exports.calculateChecksum=Ea,I.exports.formatTarString=aa,I.exports.formatTarNumber=oa,I.exports.formatTarDateTime=la,I.exports.parseTarString=ra,I.exports.parseTarNumber=ia,I.exports.parseTarDateTime=da}),er=D$2((e,I)=>{u$1();var Hn=x(),$n=w(),qn=L();function Xn(aa){return qn.recordSize}function Yn(aa){return Math.ceil(aa.data.length/qn.recordSize)*qn.recordSize}function Kn(aa){var oa=0;return aa.forEach(function(la){oa+=Xn()+Yn(la)}),oa+=qn.recordSize*2,new Uint8Array(oa)}function Jn(aa,oa,la){la=parseInt(la)||0;var ra=la;qn.posixHeader.forEach(function(ta){for(var sa=ta[3](oa,ta),ca=sa.length,_a=0;_a<ca;_a+=1)aa[ra+_a]=sa.charCodeAt(_a)&255;ra+=ta[1]});var ia=$n.find(qn.posixHeader,function(ta){return ta[0]=="checksum"});if(ia){var da=qn.calculateChecksum(aa,la,!0),Ea=qn.formatTarNumber(da,ia[1]-2)+Hn.NULL_CHAR+" ";ra=la+ia[2];for(var na=0;na<Ea.length;na+=1)aa[ra]=Ea.charCodeAt(na)&255,ra++}return la+Xn()}function Zn(aa,oa,la){return la=parseInt(la,10)||0,aa.set(oa.data,la),la+Yn(oa)}function ea(aa){aa=$n.map(aa,function(ra){return $n.extend({},ra,{data:$n.toUint8Array(ra.data)})});var oa=Kn(aa),la=0;return aa.forEach(function(ra){la=Jn(oa,ra,la),la=Zn(oa,ra,la)}),oa}I.exports.tar=ea}),nr=D$2((e,I)=>{u$1();var Hn=x(),$n=w(),qn=L(),Xn={extractData:!0,checkHeader:!0,checkChecksum:!0,checkFileSize:!0},Yn={size:!0,checksum:!0,ustar:!0},Kn={unexpectedEndOfFile:"Unexpected end of file.",fileCorrupted:"File is corrupted.",checksumCheckFailed:"Checksum check failed."};function Jn(ia){return qn.recordSize}function Zn(ia){return Math.ceil(ia/qn.recordSize)*qn.recordSize}function ea(ia,da){for(var Ea=da,na=Math.min(ia.length,da+qn.recordSize*2),ta=Ea;ta<na;ta++)if(ia[ta]!=0)return!1;return!0}function aa(ia,da,Ea){if(ia.length-da<qn.recordSize){if(Ea.checkFileSize)throw new Error(Kn.unexpectedEndOfFile);return null}da=parseInt(da)||0;var na={},ta=da;if(qn.posixHeader.forEach(function(_a){na[_a[0]]=_a[4](ia,ta,_a),ta+=_a[1]}),na.type!=0&&(na.size=0),Ea.checkHeader&&qn.posixHeader.forEach(function(_a){if($n.isFunction(_a[5])&&!_a[5](na,_a)){var pa=new Error(Kn.fileCorrupted);throw pa.data={offset:da+_a[2],field:_a[0]},pa}}),Ea.checkChecksum){var sa=qn.calculateChecksum(ia,da,!0);if(sa!=na.checksum){var ca=new Error(Kn.checksumCheckFailed);throw ca.data={offset:da,header:na,checksum:sa},ca}}return na}function oa(ia,da,Ea,na){return na.extractData?Ea.size<=0?new Uint8Array:ia.slice(da,da+Ea.size):null}function la(ia,da){var Ea={};return qn.posixHeader.forEach(function(na){var ta=na[0];Yn[ta]||(Ea[ta]=ia[ta])}),Ea.isOldGNUFormat=ia.ustar==Hn.OLDGNU_MAGIC,da&&(Ea.data=da),Ea}function ra(ia,da){da=$n.extend({},Xn,da);for(var Ea=[],na=0,ta=ia.length;ta-na>=qn.recordSize;){ia=$n.toUint8Array(ia);var sa=aa(ia,na,da);if(!sa)break;na+=Jn();var ca=oa(ia,na,sa,da);if(Ea.push(la(sa,ca)),na+=Zn(sa.size),ea(ia,na))break}return Ea}I.exports.untar=ra}),or=D$2((e,I)=>{u$1();var Hn=w(),$n=x(),qn=er(),Xn=nr();Hn.extend(I.exports,qn,Xn,$n)});u$1();u$1();var g=L$2(or());async function H$2(e,I,Hn="pgdata",$n="auto"){let qn=Br(e,I),[Xn,Yn]=await qr(qn,$n),Kn=Hn+(Yn?".tar.gz":".tar"),Jn=Yn?"application/x-gzip":"application/x-tar";return typeof File<"u"?new File([Xn],Kn,{type:Jn}):new Blob([Xn],{type:Jn})}var Hr=["application/x-gtar","application/x-tar+gzip","application/x-gzip","application/gzip"];async function ce$1(e,I,Hn){let $n=new Uint8Array(await I.arrayBuffer()),qn=typeof File<"u"&&I instanceof File?I.name:void 0;(Hr.includes(I.type)||qn?.endsWith(".tgz")||qn?.endsWith(".tar.gz"))&&($n=await ar($n));let Xn;try{Xn=(0,g.untar)($n)}catch(Yn){if(Yn instanceof Error&&Yn.message.includes("File is corrupted"))$n=await ar($n),Xn=(0,g.untar)($n);else throw Yn}for(let Yn of Xn){let Kn=Hn+Yn.name,Jn=Kn.split("/").slice(0,-1);for(let Zn=1;Zn<=Jn.length;Zn++){let ea=Jn.slice(0,Zn).join("/");e.analyzePath(ea).exists||e.mkdir(ea)}Yn.type===g.REGTYPE?(e.writeFile(Kn,Yn.data),e.utime(Kn,sr(Yn.modifyTime),sr(Yn.modifyTime))):Yn.type===g.DIRTYPE&&e.mkdir(Kn)}}function jr(e,I){let Hn=[],$n=qn=>{e.readdir(qn).forEach(Xn=>{if(Xn==="."||Xn==="..")return;let Yn=qn+"/"+Xn,Kn=e.stat(Yn),Jn=e.isFile(Kn.mode)?e.readFile(Yn,{encoding:"binary"}):new Uint8Array(0);Hn.push({name:Yn.substring(I.length),mode:Kn.mode,size:Kn.size,type:e.isFile(Kn.mode)?g.REGTYPE:g.DIRTYPE,modifyTime:Kn.mtime,data:Jn}),e.isDir(Kn.mode)&&$n(Yn)})};return $n(I),Hn}function Br(e,I){let Hn=jr(e,I);return(0,g.tar)(Hn)}async function qr(e,I="auto"){if(I==="none")return[e,!1];if(typeof CompressionStream<"u")return[await Yr(e),!0];if(typeof process<"u"&&process.versions&&process.versions.node)return[await Wr(e),!0];if(I==="auto")return[e,!1];throw new Error("Compression not supported in this environment")}async function Yr(e){let I=new CompressionStream("gzip"),Hn=I.writable.getWriter(),$n=I.readable.getReader();Hn.write(e),Hn.close();let qn=[];for(;;){let{value:Kn,done:Jn}=await $n.read();if(Jn)break;Kn&&qn.push(Kn)}let Xn=new Uint8Array(qn.reduce((Kn,Jn)=>Kn+Jn.length,0)),Yn=0;return qn.forEach(Kn=>{Xn.set(Kn,Yn),Yn+=Kn.length}),Xn}async function Wr(e){let{promisify:I}=await import("./__vite-browser-external-9wXp6ZBx.js"),{gzip:Hn}=await import("./__vite-browser-external-9wXp6ZBx.js");return await I(Hn)(e)}async function ar(e){if(typeof CompressionStream<"u")return await Xr(e);if(typeof process<"u"&&process.versions&&process.versions.node)return await Kr(e);throw new Error("Unsupported environment for decompression")}async function Xr(e){let I=new DecompressionStream("gzip"),Hn=I.writable.getWriter(),$n=I.readable.getReader();Hn.write(e),Hn.close();let qn=[];for(;;){let{value:Kn,done:Jn}=await $n.read();if(Jn)break;Kn&&qn.push(Kn)}let Xn=new Uint8Array(qn.reduce((Kn,Jn)=>Kn+Jn.length,0)),Yn=0;return qn.forEach(Kn=>{Xn.set(Kn,Yn),Yn+=Kn.length}),Xn}async function Kr(e){let{promisify:I}=await import("./__vite-browser-external-9wXp6ZBx.js"),{gunzip:Hn}=await import("./__vite-browser-external-9wXp6ZBx.js");return await I(Hn)(e)}function sr(e){return e?typeof e=="number"?e:Math.floor(e.getTime()/1e3):Math.floor(Date.now()/1e3)}var Vr="/tmp/pglite",C=Vr+"/base",ur=class{constructor(e){this.dataDir=e}async init(e,I){return this.pg=e,{emscriptenOpts:I}}async syncToFs(e){}async initialSyncFs(){}async closeFs(){}async dumpTar(e,I){return H$2(this.pg.Module.FS,C,e,I)}},cr=class{constructor(e,{debug:I=!1}={}){this.dataDir=e,this.debug=I}async syncToFs(e){}async initialSyncFs(){}async closeFs(){}async dumpTar(e,I){return H$2(this.pg.Module.FS,C,e,I)}async init(e,I){return this.pg=e,{emscriptenOpts:{...I,preRun:[...I.preRun||[],Hn=>{let $n=Zr(Hn,this);Hn.FS.mkdir(C),Hn.FS.mount($n,{},C)}]}}}},pr={EBADF:8,EBADFD:127,EEXIST:20,EINVAL:28,EISDIR:31,ENODEV:43,ENOENT:44,ENOTDIR:54,ENOTEMPTY:55},Zr=(e,I)=>{let Hn=e.FS,$n=I.debug?console.log:null,qn={tryFSOperation(Xn){try{return Xn()}catch(Yn){throw Yn.code?Yn.code==="UNKNOWN"?new Hn.ErrnoError(pr.EINVAL):new Hn.ErrnoError(Yn.code):Yn}},mount(Xn){return qn.createNode(null,"/",16895,0)},syncfs(Xn,Yn,Kn){},createNode(Xn,Yn,Kn,Jn){if(!Hn.isDir(Kn)&&!Hn.isFile(Kn))throw new Hn.ErrnoError(28);let Zn=Hn.createNode(Xn,Yn,Kn);return Zn.node_ops=qn.node_ops,Zn.stream_ops=qn.stream_ops,Zn},getMode:function(Xn){return $n?.("getMode",Xn),qn.tryFSOperation(()=>I.lstat(Xn).mode)},realPath:function(Xn){let Yn=[];for(;Xn.parent!==Xn;)Yn.push(Xn.name),Xn=Xn.parent;return Yn.push(Xn.mount.opts.root),Yn.reverse(),Yn.join("/")},node_ops:{getattr(Xn){$n?.("getattr",qn.realPath(Xn));let Yn=qn.realPath(Xn);return qn.tryFSOperation(()=>{let Kn=I.lstat(Yn);return{...Kn,dev:0,ino:Xn.id,nlink:1,rdev:Xn.rdev,atime:new Date(Kn.atime),mtime:new Date(Kn.mtime),ctime:new Date(Kn.ctime)}})},setattr(Xn,Yn){$n?.("setattr",qn.realPath(Xn),Yn);let Kn=qn.realPath(Xn);qn.tryFSOperation(()=>{Yn.mode!==void 0&&I.chmod(Kn,Yn.mode),Yn.size!==void 0&&I.truncate(Kn,Yn.size),Yn.timestamp!==void 0&&I.utimes(Kn,Yn.timestamp,Yn.timestamp),Yn.size!==void 0&&I.truncate(Kn,Yn.size)})},lookup(Xn,Yn){$n?.("lookup",qn.realPath(Xn),Yn);let Kn=[qn.realPath(Xn),Yn].join("/"),Jn=qn.getMode(Kn);return qn.createNode(Xn,Yn,Jn)},mknod(Xn,Yn,Kn,Jn){$n?.("mknod",qn.realPath(Xn),Yn,Kn,Jn);let Zn=qn.createNode(Xn,Yn,Kn,Jn),ea=qn.realPath(Zn);return qn.tryFSOperation(()=>(Hn.isDir(Zn.mode)?I.mkdir(ea,{mode:Kn}):I.writeFile(ea,"",{mode:Kn}),Zn))},rename(Xn,Yn,Kn){$n?.("rename",qn.realPath(Xn),qn.realPath(Yn),Kn);let Jn=qn.realPath(Xn),Zn=[qn.realPath(Yn),Kn].join("/");qn.tryFSOperation(()=>{I.rename(Jn,Zn)}),Xn.name=Kn},unlink(Xn,Yn){$n?.("unlink",qn.realPath(Xn),Yn);let Kn=[qn.realPath(Xn),Yn].join("/");try{I.unlink(Kn)}catch{}},rmdir(Xn,Yn){$n?.("rmdir",qn.realPath(Xn),Yn);let Kn=[qn.realPath(Xn),Yn].join("/");return qn.tryFSOperation(()=>{I.rmdir(Kn)})},readdir(Xn){$n?.("readdir",qn.realPath(Xn));let Yn=qn.realPath(Xn);return qn.tryFSOperation(()=>I.readdir(Yn))},symlink(Xn,Yn,Kn){throw $n?.("symlink",qn.realPath(Xn),Yn,Kn),new Hn.ErrnoError(63)},readlink(Xn){throw $n?.("readlink",qn.realPath(Xn)),new Hn.ErrnoError(63)}},stream_ops:{open(Xn){$n?.("open stream",qn.realPath(Xn.node));let Yn=qn.realPath(Xn.node);return qn.tryFSOperation(()=>{Hn.isFile(Xn.node.mode)&&(Xn.shared.refcount=1,Xn.nfd=I.open(Yn))})},close(Xn){return $n?.("close stream",qn.realPath(Xn.node)),qn.tryFSOperation(()=>{Hn.isFile(Xn.node.mode)&&Xn.nfd&&--Xn.shared.refcount===0&&I.close(Xn.nfd)})},dup(Xn){$n?.("dup stream",qn.realPath(Xn.node)),Xn.shared.refcount++},read(Xn,Yn,Kn,Jn,Zn){return $n?.("read stream",qn.realPath(Xn.node),Kn,Jn,Zn),Jn===0?0:qn.tryFSOperation(()=>I.read(Xn.nfd,Yn,Kn,Jn,Zn))},write(Xn,Yn,Kn,Jn,Zn){return $n?.("write stream",qn.realPath(Xn.node),Kn,Jn,Zn),qn.tryFSOperation(()=>I.write(Xn.nfd,Yn.buffer,Kn,Jn,Zn))},llseek(Xn,Yn,Kn){$n?.("llseek stream",qn.realPath(Xn.node),Yn,Kn);let Jn=Yn;if(Kn===1?Jn+=Xn.position:Kn===2&&Hn.isFile(Xn.node.mode)&&qn.tryFSOperation(()=>{let Zn=I.fstat(Xn.nfd);Jn+=Zn.size}),Jn<0)throw new Hn.ErrnoError(28);return Jn},mmap(Xn,Yn,Kn,Jn,Zn){if($n?.("mmap stream",qn.realPath(Xn.node),Yn,Kn,Jn,Zn),!Hn.isFile(Xn.node.mode))throw new Hn.ErrnoError(pr.ENODEV);let ea=e.mmapAlloc(Yn);return qn.stream_ops.read(Xn,e.HEAP8,ea,Yn,Kn),{ptr:ea,allocated:!0}},msync(Xn,Yn,Kn,Jn,Zn){return $n?.("msync stream",qn.realPath(Xn.node),Kn,Jn,Zn),qn.stream_ops.write(Xn,Yn,0,Jn,Kn),0}}};return qn};u$1();u$1();u$1();var He=new Error("request for lock canceled"),We=function(e,I,Hn,$n){function qn(Xn){return Xn instanceof Hn?Xn:new Hn(function(Yn){Yn(Xn)})}return new(Hn||(Hn=Promise))(function(Xn,Yn){function Kn(ea){try{Zn($n.next(ea))}catch(aa){Yn(aa)}}function Jn(ea){try{Zn($n.throw(ea))}catch(aa){Yn(aa)}}function Zn(ea){ea.done?Xn(ea.value):qn(ea.value).then(Kn,Jn)}Zn(($n=$n.apply(e,[])).next())})},ce=class{constructor(e,I=He){this._value=e,this._cancelError=I,this._weightedQueues=[],this._weightedWaiters=[]}acquire(e=1){if(e<=0)throw new Error(`invalid weight ${e}: must be positive`);return new Promise((I,Hn)=>{this._weightedQueues[e-1]||(this._weightedQueues[e-1]=[]),this._weightedQueues[e-1].push({resolve:I,reject:Hn}),this._dispatch()})}runExclusive(e,I=1){return We(this,void 0,void 0,function*(){let[Hn,$n]=yield this.acquire(I);try{return yield e(Hn)}finally{$n()}})}waitForUnlock(e=1){if(e<=0)throw new Error(`invalid weight ${e}: must be positive`);return new Promise(I=>{this._weightedWaiters[e-1]||(this._weightedWaiters[e-1]=[]),this._weightedWaiters[e-1].push(I),this._dispatch()})}isLocked(){return this._value<=0}getValue(){return this._value}setValue(e){this._value=e,this._dispatch()}release(e=1){if(e<=0)throw new Error(`invalid weight ${e}: must be positive`);this._value+=e,this._dispatch()}cancel(){this._weightedQueues.forEach(e=>e.forEach(I=>I.reject(this._cancelError))),this._weightedQueues=[]}_dispatch(){var e;for(let I=this._value;I>0;I--){let Hn=(e=this._weightedQueues[I-1])===null||e===void 0?void 0:e.shift();if(!Hn)continue;let $n=this._value,qn=I;this._value-=I,I=this._value+1,Hn.resolve([$n,this._newReleaser(qn)])}this._drainUnlockWaiters()}_newReleaser(e){let I=!1;return()=>{I||(I=!0,this.release(e))}}_drainUnlockWaiters(){for(let e=this._value;e>0;e--)this._weightedWaiters[e-1]&&(this._weightedWaiters[e-1].forEach(I=>I()),this._weightedWaiters[e-1]=[])}},je=function(e,I,Hn,$n){function qn(Xn){return Xn instanceof Hn?Xn:new Hn(function(Yn){Yn(Xn)})}return new(Hn||(Hn=Promise))(function(Xn,Yn){function Kn(ea){try{Zn($n.next(ea))}catch(aa){Yn(aa)}}function Jn(ea){try{Zn($n.throw(ea))}catch(aa){Yn(aa)}}function Zn(ea){ea.done?Xn(ea.value):qn(ea.value).then(Kn,Jn)}Zn(($n=$n.apply(e,[])).next())})},H$1=class{constructor(I){this._semaphore=new ce(1,I)}acquire(){return je(this,void 0,void 0,function*(){let[,I]=yield this._semaphore.acquire();return I})}runExclusive(I){return this._semaphore.runExclusive(()=>I())}isLocked(){return this._semaphore.isLocked()}waitForUnlock(){return this._semaphore.waitForUnlock()}release(){this._semaphore.isLocked()&&this._semaphore.release()}cancel(){return this._semaphore.cancel()}};u$1();var Ie=L$2(or());async function ge(e){if(Fe$1){let I=await import("./__vite-browser-external-9wXp6ZBx.js"),Hn=await import("./__vite-browser-external-9wXp6ZBx.js"),{Writable:$n}=await import("./__vite-browser-external-9wXp6ZBx.js"),{pipeline:qn}=await import("./__vite-browser-external-9wXp6ZBx.js");if(!I.existsSync(e))throw new Error(`Extension bundle not found: ${e}`);let Xn=Hn.createGunzip(),Yn=[];return await qn(I.createReadStream(e),Xn,new $n({write(Kn,Jn,Zn){Yn.push(Kn),Zn()}})),new Blob(Yn)}else{let I=await fetch(e.toString());if(!I.ok||!I.body)return null;if(I.headers.get("Content-Encoding")==="gzip")return I.blob();{let Hn=new DecompressionStream("gzip");return new Response(I.body.pipeThrough(Hn)).blob()}}}async function Pe(e,I){for(let Hn in e.pg_extensions){let $n;try{$n=await e.pg_extensions[Hn]}catch(qn){console.error("Failed to fetch extension:",Hn,qn);continue}if($n){let qn=new Uint8Array(await $n.arrayBuffer());Ve(e,Hn,qn,I)}else console.error("Could not get binary data for extension:",Hn)}}function Ve(e,I,Hn,$n){Ie.default.untar(Hn).forEach(qn=>{if(!qn.name.startsWith(".")){let Xn=e.WASM_PREFIX+"/"+qn.name;if(qn.name.endsWith(".so")){let Yn=(...Jn)=>{$n("pgfs:ext OK",Xn,Jn)},Kn=(...Jn)=>{$n("pgfs:ext FAIL",Xn,Jn)};e.FS.createPreloadedFile(Ke(Xn),qn.name.split("/").pop().slice(0,-3),qn.data,!0,!0,Yn,Kn,!1)}else e.FS.writeFile(Xn,qn.data)}})}function Ke(e){let I=e.lastIndexOf("/");return I>0?e.slice(0,I):e}u$1();u$1();var ee$1=class extends ur{async init(I,Hn){return this.pg=I,{emscriptenOpts:{...Hn,preRun:[...Hn.preRun||[],$n=>{let qn=$n.FS.filesystems.IDBFS;$n.FS.mkdir("/pglite"),$n.FS.mkdir(`/pglite/${this.dataDir}`),$n.FS.mount(qn,{},`/pglite/${this.dataDir}`),$n.FS.symlink(`/pglite/${this.dataDir}`,C)}]}}}initialSyncFs(){return new Promise((I,Hn)=>{this.pg.Module.FS.syncfs(!0,$n=>{$n?Hn($n):I()})})}syncToFs(I){return new Promise((Hn,$n)=>{this.pg.Module.FS.syncfs(!1,qn=>{qn?$n(qn):Hn()})})}async closeFs(){let I=this.pg.Module.FS.filesystems.IDBFS.dbs[this.dataDir];I&&I.close(),this.pg.Module.FS.quit()}};u$1();var te=class extends ur{async closeFs(){this.pg.Module.FS.quit()}};function Fe(e){let I;if(e?.startsWith("file://")){if(e=e.slice(7),!e)throw new Error("Invalid dataDir, must be a valid path");I="nodefs"}else e?.startsWith("idb://")?(e=e.slice(6),I="idbfs"):e?.startsWith("opfs-ahp://")?(e=e.slice(11),I="opfs-ahp"):!e||e?.startsWith("memory://")?I="memoryfs":I="nodefs";return{dataDir:e,fsType:I}}async function Ae(e,I){let Hn;if(e&&I==="nodefs"){let{NodeFS:$n}=await import("./nodefs-LGIbJnh3.js");Hn=new $n(e)}else if(e&&I==="idbfs")Hn=new ee$1(e);else if(e&&I==="opfs-ahp"){let{OpfsAhpFS:$n}=await import("./opfs-ahp-D7M8L902.js");Hn=new $n(e)}else Hn=new te;return Hn}u$1();u$1();var Qe=(()=>{var _scriptName=import.meta.url;return async function(moduleArg={}){var moduleRtn,Module=moduleArg,readyPromiseResolve,readyPromiseReject,readyPromise=new Promise((e,I)=>{readyPromiseResolve=e,readyPromiseReject=I}),ENVIRONMENT_IS_WEB=typeof window=="object",ENVIRONMENT_IS_WORKER=typeof WorkerGlobalScope<"u",ENVIRONMENT_IS_NODE=typeof process=="object"&&typeof process.versions=="object"&&typeof process.versions.node=="string"&&process.type!="renderer";if(ENVIRONMENT_IS_NODE){let{createRequire:e}=await import("./__vite-browser-external-9wXp6ZBx.js"),I=import.meta.url;I.startsWith("data:")&&(I="/");var require=e(I)}Module.expectedDataFileDownloads??(Module.expectedDataFileDownloads=0),Module.expectedDataFileDownloads++,(()=>{var e=typeof ENVIRONMENT_IS_PTHREAD<"u"&&ENVIRONMENT_IS_PTHREAD,I=typeof ENVIRONMENT_IS_WASM_WORKER<"u"&&ENVIRONMENT_IS_WASM_WORKER;if(e||I)return;var Hn=typeof process=="object"&&typeof process.versions=="object"&&typeof process.versions.node=="string";function $n(qn){typeof window=="object"?window.encodeURIComponent(window.location.pathname.substring(0,window.location.pathname.lastIndexOf("/"))+"/"):typeof process>"u"&&typeof location<"u"&&encodeURIComponent(location.pathname.substring(0,location.pathname.lastIndexOf("/"))+"/");var Xn="postgres.data",Yn="postgres.data",Kn=Module.locateFile?Module.locateFile(Yn,""):Yn,Jn=qn.remote_package_size;function Zn(ra,ia,da,Ea){if(Hn){require("fs").readFile(ra,(na,ta)=>{na?Ea(na):da(ta.buffer)});return}Module.dataFileDownloads??(Module.dataFileDownloads={}),fetch(ra).catch(na=>Promise.reject(new Error(`Network Error: ${ra}`,{cause:na}))).then(na=>{if(!na.ok)return Promise.reject(new Error(`${na.status}: ${na.url}`));if(!na.body&&na.arrayBuffer)return na.arrayBuffer().then(da);let ta=na.body.getReader(),sa=()=>ta.read().then(Na).catch(ma=>Promise.reject(new Error(`Unexpected error while handling : ${na.url} ${ma}`,{cause:ma}))),ca=[],_a=na.headers,pa=Number(_a.get("Content-Length")??ia),Sa=0,Na=({done:ma,value:Ia})=>{if(ma){let ua=new Uint8Array(ca.map(Ta=>Ta.length).reduce((Ta,Ra)=>Ta+Ra,0)),Aa=0;for(let Ta of ca)ua.set(Ta,Aa),Aa+=Ta.length;da(ua.buffer)}else{ca.push(Ia),Sa+=Ia.length,Module.dataFileDownloads[ra]={loaded:Sa,total:pa};let ua=0,Aa=0;for(let Ta of Object.values(Module.dataFileDownloads))ua+=Ta.loaded,Aa+=Ta.total;return Module.setStatus?.(`Downloading data... (${ua}/${Aa})`),sa()}};return Module.setStatus?.("Downloading data..."),sa()})}function ea(ra){console.error("package error:",ra)}var aa=null,oa=Module.getPreloadedPackage?Module.getPreloadedPackage(Kn,Jn):null;oa||Zn(Kn,Jn,ra=>{aa?(aa(ra),aa=null):oa=ra},ea);function la(ra){function ia(sa,ca){if(!sa)throw ca+new Error().stack}ra.FS_createPath("/","home",!0,!0),ra.FS_createPath("/home","web_user",!0,!0),ra.FS_createPath("/","tmp",!0,!0),ra.FS_createPath("/tmp","pglite",!0,!0),ra.FS_createPath("/tmp/pglite","bin",!0,!0),ra.FS_createPath("/tmp/pglite","lib",!0,!0),ra.FS_createPath("/tmp/pglite/lib","postgresql",!0,!0),ra.FS_createPath("/tmp/pglite/lib/postgresql","pgxs",!0,!0),ra.FS_createPath("/tmp/pglite/lib/postgresql/pgxs","config",!0,!0),ra.FS_createPath("/tmp/pglite/lib/postgresql/pgxs","src",!0,!0),ra.FS_createPath("/tmp/pglite/lib/postgresql/pgxs/src","makefiles",!0,!0),ra.FS_createPath("/tmp/pglite/lib/postgresql/pgxs/src","test",!0,!0),ra.FS_createPath("/tmp/pglite/lib/postgresql/pgxs/src/test","isolation",!0,!0),ra.FS_createPath("/tmp/pglite/lib/postgresql/pgxs/src/test","regress",!0,!0),ra.FS_createPath("/tmp/pglite","share",!0,!0),ra.FS_createPath("/tmp/pglite/share","postgresql",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql","extension",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql","timezone",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","Africa",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","America",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone/America","Argentina",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone/America","Indiana",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone/America","Kentucky",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone/America","North_Dakota",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","Antarctica",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","Arctic",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","Asia",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","Atlantic",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","Australia",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","Brazil",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","Canada",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","Chile",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","Etc",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","Europe",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","Indian",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","Mexico",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","Pacific",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql/timezone","US",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql","timezonesets",!0,!0),ra.FS_createPath("/tmp/pglite/share/postgresql","tsearch_data",!0,!0);function da(sa,ca,_a){this.start=sa,this.end=ca,this.audio=_a}da.prototype={requests:{},open:function(sa,ca){this.name=ca,this.requests[ca]=this,ra.addRunDependency(`fp ${this.name}`)},send:function(){},onload:function(){var sa=this.byteArray.subarray(this.start,this.end);this.finish(sa)},finish:function(sa){var ca=this;ra.FS_createDataFile(this.name,null,sa,!0,!0,!0),ra.removeRunDependency(`fp ${ca.name}`),this.requests[this.name]=null}};for(var Ea=qn.files,na=0;na<Ea.length;++na)new da(Ea[na].start,Ea[na].end,Ea[na].audio||0).open("GET",Ea[na].filename);function ta(sa){ia(sa,"Loading data file failed."),ia(sa.constructor.name===ArrayBuffer.name,"bad input to processPackageData");var ca=new Uint8Array(sa);da.prototype.byteArray=ca;for(var _a=qn.files,pa=0;pa<_a.length;++pa)da.prototype.requests[_a[pa].filename].onload();ra.removeRunDependency("datafile_postgres.data")}ra.addRunDependency("datafile_postgres.data"),ra.preloadResults??(ra.preloadResults={}),ra.preloadResults[Xn]={fromCache:!1},oa?(ta(oa),oa=null):aa=ta}Module.calledRun?la(Module):(Module.preRun??(Module.preRun=[])).push(la)}$n({files:[{filename:"/home/web_user/.pgpass",start:0,end:204},{filename:"/tmp/pglite/bin/initdb",start:204,end:216},{filename:"/tmp/pglite/bin/postgres",start:216,end:228},{filename:"/tmp/pglite/lib/postgresql/cyrillic_and_mic.so",start:228,end:20397},{filename:"/tmp/pglite/lib/postgresql/dict_snowball.so",start:20397,end:1581299},{filename:"/tmp/pglite/lib/postgresql/euc2004_sjis2004.so",start:1581299,end:1592382},{filename:"/tmp/pglite/lib/postgresql/euc_cn_and_mic.so",start:1592382,end:1599256},{filename:"/tmp/pglite/lib/postgresql/euc_jp_and_sjis.so",start:1599256,end:1622931},{filename:"/tmp/pglite/lib/postgresql/euc_kr_and_mic.so",start:1622931,end:1630057},{filename:"/tmp/pglite/lib/postgresql/euc_tw_and_big5.so",start:1630057,end:1651566},{filename:"/tmp/pglite/lib/postgresql/latin2_and_win1250.so",start:1651566,end:1660345},{filename:"/tmp/pglite/lib/postgresql/latin_and_mic.so",start:1660345,end:1668272},{filename:"/tmp/pglite/lib/postgresql/libpqwalreceiver.so",start:1668272,end:2186522},{filename:"/tmp/pglite/lib/postgresql/pgoutput.so",start:2186522,end:2303364},{filename:"/tmp/pglite/lib/postgresql/pgxs/config/install-sh",start:2303364,end:2317361},{filename:"/tmp/pglite/lib/postgresql/pgxs/config/missing",start:2317361,end:2318709},{filename:"/tmp/pglite/lib/postgresql/pgxs/src/Makefile.global",start:2318709,end:2354956},{filename:"/tmp/pglite/lib/postgresql/pgxs/src/Makefile.port",start:2354956,end:2355232},{filename:"/tmp/pglite/lib/postgresql/pgxs/src/Makefile.shlib",start:2355232,end:2371270},{filename:"/tmp/pglite/lib/postgresql/pgxs/src/makefiles/pgxs.mk",start:2371270,end:2386198},{filename:"/tmp/pglite/lib/postgresql/pgxs/src/nls-global.mk",start:2386198,end:2393083},{filename:"/tmp/pglite/lib/postgresql/pgxs/src/test/isolation/isolationtester.cjs",start:2393083,end:2589770},{filename:"/tmp/pglite/lib/postgresql/pgxs/src/test/isolation/pg_isolation_regress.cjs",start:2589770,end:2742128},{filename:"/tmp/pglite/lib/postgresql/pgxs/src/test/regress/pg_regress.cjs",start:2742128,end:2894476},{filename:"/tmp/pglite/lib/postgresql/plpgsql.so",start:2894476,end:3653241},{filename:"/tmp/pglite/password",start:3653241,end:3653250},{filename:"/tmp/pglite/share/postgresql/errcodes.txt",start:3653250,end:3686708},{filename:"/tmp/pglite/share/postgresql/extension/plpgsql--1.0.sql",start:3686708,end:3687366},{filename:"/tmp/pglite/share/postgresql/extension/plpgsql.control",start:3687366,end:3687559},{filename:"/tmp/pglite/share/postgresql/fix-CVE-2024-4317.sql",start:3687559,end:3693324},{filename:"/tmp/pglite/share/postgresql/information_schema.sql",start:3693324,end:3808299},{filename:"/tmp/pglite/share/postgresql/pg_hba.conf.sample",start:3808299,end:3813924},{filename:"/tmp/pglite/share/postgresql/pg_ident.conf.sample",start:3813924,end:3816564},{filename:"/tmp/pglite/share/postgresql/pg_service.conf.sample",start:3816564,end:3817168},{filename:"/tmp/pglite/share/postgresql/postgres.bki",start:3817168,end:4761272},{filename:"/tmp/pglite/share/postgresql/postgresql.conf.sample",start:4761272,end:4790919},{filename:"/tmp/pglite/share/postgresql/psqlrc.sample",start:4790919,end:4791197},{filename:"/tmp/pglite/share/postgresql/snowball_create.sql",start:4791197,end:4835373},{filename:"/tmp/pglite/share/postgresql/sql_features.txt",start:4835373,end:4871054},{filename:"/tmp/pglite/share/postgresql/system_constraints.sql",start:4871054,end:4879949},{filename:"/tmp/pglite/share/postgresql/system_functions.sql",start:4879949,end:4903264},{filename:"/tmp/pglite/share/postgresql/system_views.sql",start:4903264,end:4953537},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Abidjan",start:4953537,end:4953667},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Accra",start:4953667,end:4953797},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Addis_Ababa",start:4953797,end:4953988},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Algiers",start:4953988,end:4954458},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Asmara",start:4954458,end:4954649},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Asmera",start:4954649,end:4954840},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Bamako",start:4954840,end:4954970},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Bangui",start:4954970,end:4955150},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Banjul",start:4955150,end:4955280},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Bissau",start:4955280,end:4955429},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Blantyre",start:4955429,end:4955560},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Brazzaville",start:4955560,end:4955740},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Bujumbura",start:4955740,end:4955871},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Cairo",start:4955871,end:4957180},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Casablanca",start:4957180,end:4959099},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Ceuta",start:4959099,end:4959661},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Conakry",start:4959661,end:4959791},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Dakar",start:4959791,end:4959921},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Dar_es_Salaam",start:4959921,end:4960112},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Djibouti",start:4960112,end:4960303},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Douala",start:4960303,end:4960483},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/El_Aaiun",start:4960483,end:4962313},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Freetown",start:4962313,end:4962443},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Gaborone",start:4962443,end:4962574},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Harare",start:4962574,end:4962705},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Johannesburg",start:4962705,end:4962895},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Juba",start:4962895,end:4963353},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Kampala",start:4963353,end:4963544},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Khartoum",start:4963544,end:4964002},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Kigali",start:4964002,end:4964133},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Kinshasa",start:4964133,end:4964313},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Lagos",start:4964313,end:4964493},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Libreville",start:4964493,end:4964673},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Lome",start:4964673,end:4964803},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Luanda",start:4964803,end:4964983},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Lubumbashi",start:4964983,end:4965114},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Lusaka",start:4965114,end:4965245},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Malabo",start:4965245,end:4965425},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Maputo",start:4965425,end:4965556},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Maseru",start:4965556,end:4965746},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Mbabane",start:4965746,end:4965936},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Mogadishu",start:4965936,end:4966127},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Monrovia",start:4966127,end:4966291},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Nairobi",start:4966291,end:4966482},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Ndjamena",start:4966482,end:4966642},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Niamey",start:4966642,end:4966822},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Nouakchott",start:4966822,end:4966952},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Ouagadougou",start:4966952,end:4967082},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Porto-Novo",start:4967082,end:4967262},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Sao_Tome",start:4967262,end:4967435},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Timbuktu",start:4967435,end:4967565},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Tripoli",start:4967565,end:4967996},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Tunis",start:4967996,end:4968445},{filename:"/tmp/pglite/share/postgresql/timezone/Africa/Windhoek",start:4968445,end:4969083},{filename:"/tmp/pglite/share/postgresql/timezone/America/Adak",start:4969083,end:4970052},{filename:"/tmp/pglite/share/postgresql/timezone/America/Anchorage",start:4970052,end:4971029},{filename:"/tmp/pglite/share/postgresql/timezone/America/Anguilla",start:4971029,end:4971206},{filename:"/tmp/pglite/share/postgresql/timezone/America/Antigua",start:4971206,end:4971383},{filename:"/tmp/pglite/share/postgresql/timezone/America/Araguaina",start:4971383,end:4971975},{filename:"/tmp/pglite/share/postgresql/timezone/America/Argentina/Buenos_Aires",start:4971975,end:4972683},{filename:"/tmp/pglite/share/postgresql/timezone/America/Argentina/Catamarca",start:4972683,end:4973391},{filename:"/tmp/pglite/share/postgresql/timezone/America/Argentina/ComodRivadavia",start:4973391,end:4974099},{filename:"/tmp/pglite/share/postgresql/timezone/America/Argentina/Cordoba",start:4974099,end:4974807},{filename:"/tmp/pglite/share/postgresql/timezone/America/Argentina/Jujuy",start:4974807,end:4975497},{filename:"/tmp/pglite/share/postgresql/timezone/America/Argentina/La_Rioja",start:4975497,end:4976214},{filename:"/tmp/pglite/share/postgresql/timezone/America/Argentina/Mendoza",start:4976214,end:4976922},{filename:"/tmp/pglite/share/postgresql/timezone/America/Argentina/Rio_Gallegos",start:4976922,end:4977630},{filename:"/tmp/pglite/share/postgresql/timezone/America/Argentina/Salta",start:4977630,end:4978320},{filename:"/tmp/pglite/share/postgresql/timezone/America/Argentina/San_Juan",start:4978320,end:4979037},{filename:"/tmp/pglite/share/postgresql/timezone/America/Argentina/San_Luis",start:4979037,end:4979754},{filename:"/tmp/pglite/share/postgresql/timezone/America/Argentina/Tucuman",start:4979754,end:4980480},{filename:"/tmp/pglite/share/postgresql/timezone/America/Argentina/Ushuaia",start:4980480,end:4981188},{filename:"/tmp/pglite/share/postgresql/timezone/America/Aruba",start:4981188,end:4981365},{filename:"/tmp/pglite/share/postgresql/timezone/America/Asuncion",start:4981365,end:4982249},{filename:"/tmp/pglite/share/postgresql/timezone/America/Atikokan",start:4982249,end:4982398},{filename:"/tmp/pglite/share/postgresql/timezone/America/Atka",start:4982398,end:4983367},{filename:"/tmp/pglite/share/postgresql/timezone/America/Bahia",start:4983367,end:4984049},{filename:"/tmp/pglite/share/postgresql/timezone/America/Bahia_Banderas",start:4984049,end:4984777},{filename:"/tmp/pglite/share/postgresql/timezone/America/Barbados",start:4984777,end:4985055},{filename:"/tmp/pglite/share/postgresql/timezone/America/Belem",start:4985055,end:4985449},{filename:"/tmp/pglite/share/postgresql/timezone/America/Belize",start:4985449,end:4986494},{filename:"/tmp/pglite/share/postgresql/timezone/America/Blanc-Sablon",start:4986494,end:4986671},{filename:"/tmp/pglite/share/postgresql/timezone/America/Boa_Vista",start:4986671,end:4987101},{filename:"/tmp/pglite/share/postgresql/timezone/America/Bogota",start:4987101,end:4987280},{filename:"/tmp/pglite/share/postgresql/timezone/America/Boise",start:4987280,end:4988279},{filename:"/tmp/pglite/share/postgresql/timezone/America/Buenos_Aires",start:4988279,end:4988987},{filename:"/tmp/pglite/share/postgresql/timezone/America/Cambridge_Bay",start:4988987,end:4989870},{filename:"/tmp/pglite/share/postgresql/timezone/America/Campo_Grande",start:4989870,end:4990822},{filename:"/tmp/pglite/share/postgresql/timezone/America/Cancun",start:4990822,end:4991351},{filename:"/tmp/pglite/share/postgresql/timezone/America/Caracas",start:4991351,end:4991541},{filename:"/tmp/pglite/share/postgresql/timezone/America/Catamarca",start:4991541,end:4992249},{filename:"/tmp/pglite/share/postgresql/timezone/America/Cayenne",start:4992249,end:4992400},{filename:"/tmp/pglite/share/postgresql/timezone/America/Cayman",start:4992400,end:4992549},{filename:"/tmp/pglite/share/postgresql/timezone/America/Chicago",start:4992549,end:4994303},{filename:"/tmp/pglite/share/postgresql/timezone/America/Chihuahua",start:4994303,end:4994994},{filename:"/tmp/pglite/share/postgresql/timezone/America/Ciudad_Juarez",start:4994994,end:4995712},{filename:"/tmp/pglite/share/postgresql/timezone/America/Coral_Harbour",start:4995712,end:4995861},{filename:"/tmp/pglite/share/postgresql/timezone/America/Cordoba",start:4995861,end:4996569},{filename:"/tmp/pglite/share/postgresql/timezone/America/Costa_Rica",start:4996569,end:4996801},{filename:"/tmp/pglite/share/postgresql/timezone/America/Creston",start:4996801,end:4997041},{filename:"/tmp/pglite/share/postgresql/timezone/America/Cuiaba",start:4997041,end:4997975},{filename:"/tmp/pglite/share/postgresql/timezone/America/Curacao",start:4997975,end:4998152},{filename:"/tmp/pglite/share/postgresql/timezone/America/Danmarkshavn",start:4998152,end:4998599},{filename:"/tmp/pglite/share/postgresql/timezone/America/Dawson",start:4998599,end:4999628},{filename:"/tmp/pglite/share/postgresql/timezone/America/Dawson_Creek",start:4999628,end:5000311},{filename:"/tmp/pglite/share/postgresql/timezone/America/Denver",start:5000311,end:5001353},{filename:"/tmp/pglite/share/postgresql/timezone/America/Detroit",start:5001353,end:5002252},{filename:"/tmp/pglite/share/postgresql/timezone/America/Dominica",start:5002252,end:5002429},{filename:"/tmp/pglite/share/postgresql/timezone/America/Edmonton",start:5002429,end:5003399},{filename:"/tmp/pglite/share/postgresql/timezone/America/Eirunepe",start:5003399,end:5003835},{filename:"/tmp/pglite/share/postgresql/timezone/America/El_Salvador",start:5003835,end:5004011},{filename:"/tmp/pglite/share/postgresql/timezone/America/Ensenada",start:5004011,end:5005036},{filename:"/tmp/pglite/share/postgresql/timezone/America/Fort_Nelson",start:5005036,end:5006484},{filename:"/tmp/pglite/share/postgresql/timezone/America/Fort_Wayne",start:5006484,end:5007015},{filename:"/tmp/pglite/share/postgresql/timezone/America/Fortaleza",start:5007015,end:5007499},{filename:"/tmp/pglite/share/postgresql/timezone/America/Glace_Bay",start:5007499,end:5008379},{filename:"/tmp/pglite/share/postgresql/timezone/America/Godthab",start:5008379,end:5009344},{filename:"/tmp/pglite/share/postgresql/timezone/America/Goose_Bay",start:5009344,end:5010924},{filename:"/tmp/pglite/share/postgresql/timezone/America/Grand_Turk",start:5010924,end:5011777},{filename:"/tmp/pglite/share/postgresql/timezone/America/Grenada",start:5011777,end:5011954},{filename:"/tmp/pglite/share/postgresql/timezone/America/Guadeloupe",start:5011954,end:5012131},{filename:"/tmp/pglite/share/postgresql/timezone/America/Guatemala",start:5012131,end:5012343},{filename:"/tmp/pglite/share/postgresql/timezone/America/Guayaquil",start:5012343,end:5012522},{filename:"/tmp/pglite/share/postgresql/timezone/America/Guyana",start:5012522,end:5012703},{filename:"/tmp/pglite/share/postgresql/timezone/America/Halifax",start:5012703,end:5014375},{filename:"/tmp/pglite/share/postgresql/timezone/America/Havana",start:5014375,end:5015492},{filename:"/tmp/pglite/share/postgresql/timezone/America/Hermosillo",start:5015492,end:5015778},{filename:"/tmp/pglite/share/postgresql/timezone/America/Indiana/Indianapolis",start:5015778,end:5016309},{filename:"/tmp/pglite/share/postgresql/timezone/America/Indiana/Knox",start:5016309,end:5017325},{filename:"/tmp/pglite/share/postgresql/timezone/America/Indiana/Marengo",start:5017325,end:5017892},{filename:"/tmp/pglite/share/postgresql/timezone/America/Indiana/Petersburg",start:5017892,end:5018575},{filename:"/tmp/pglite/share/postgresql/timezone/America/Indiana/Tell_City",start:5018575,end:5019097},{filename:"/tmp/pglite/share/postgresql/timezone/America/Indiana/Vevay",start:5019097,end:5019466},{filename:"/tmp/pglite/share/postgresql/timezone/America/Indiana/Vincennes",start:5019466,end:5020024},{filename:"/tmp/pglite/share/postgresql/timezone/America/Indiana/Winamac",start:5020024,end:5020636},{filename:"/tmp/pglite/share/postgresql/timezone/America/Indianapolis",start:5020636,end:5021167},{filename:"/tmp/pglite/share/postgresql/timezone/America/Inuvik",start:5021167,end:5021984},{filename:"/tmp/pglite/share/postgresql/timezone/America/Iqaluit",start:5021984,end:5022839},{filename:"/tmp/pglite/share/postgresql/timezone/America/Jamaica",start:5022839,end:5023178},{filename:"/tmp/pglite/share/postgresql/timezone/America/Jujuy",start:5023178,end:5023868},{filename:"/tmp/pglite/share/postgresql/timezone/America/Juneau",start:5023868,end:5024834},{filename:"/tmp/pglite/share/postgresql/timezone/America/Kentucky/Louisville",start:5024834,end:5026076},{filename:"/tmp/pglite/share/postgresql/timezone/America/Kentucky/Monticello",start:5026076,end:5027048},{filename:"/tmp/pglite/share/postgresql/timezone/America/Knox_IN",start:5027048,end:5028064},{filename:"/tmp/pglite/share/postgresql/timezone/America/Kralendijk",start:5028064,end:5028241},{filename:"/tmp/pglite/share/postgresql/timezone/America/La_Paz",start:5028241,end:5028411},{filename:"/tmp/pglite/share/postgresql/timezone/America/Lima",start:5028411,end:5028694},{filename:"/tmp/pglite/share/postgresql/timezone/America/Los_Angeles",start:5028694,end:5029988},{filename:"/tmp/pglite/share/postgresql/timezone/America/Louisville",start:5029988,end:5031230},{filename:"/tmp/pglite/share/postgresql/timezone/America/Lower_Princes",start:5031230,end:5031407},{filename:"/tmp/pglite/share/postgresql/timezone/America/Maceio",start:5031407,end:5031909},{filename:"/tmp/pglite/share/postgresql/timezone/America/Managua",start:5031909,end:5032204},{filename:"/tmp/pglite/share/postgresql/timezone/America/Manaus",start:5032204,end:5032616},{filename:"/tmp/pglite/share/postgresql/timezone/America/Marigot",start:5032616,end:5032793},{filename:"/tmp/pglite/share/postgresql/timezone/America/Martinique",start:5032793,end:5032971},{filename:"/tmp/pglite/share/postgresql/timezone/America/Matamoros",start:5032971,end:5033408},{filename:"/tmp/pglite/share/postgresql/timezone/America/Mazatlan",start:5033408,end:5034126},{filename:"/tmp/pglite/share/postgresql/timezone/America/Mendoza",start:5034126,end:5034834},{filename:"/tmp/pglite/share/postgresql/timezone/America/Menominee",start:5034834,end:5035751},{filename:"/tmp/pglite/share/postgresql/timezone/America/Merida",start:5035751,end:5036405},{filename:"/tmp/pglite/share/postgresql/timezone/America/Metlakatla",start:5036405,end:5037e3},{filename:"/tmp/pglite/share/postgresql/timezone/America/Mexico_City",start:5037e3,end:5037773},{filename:"/tmp/pglite/share/postgresql/timezone/America/Miquelon",start:5037773,end:5038323},{filename:"/tmp/pglite/share/postgresql/timezone/America/Moncton",start:5038323,end:5039816},{filename:"/tmp/pglite/share/postgresql/timezone/America/Monterrey",start:5039816,end:5040460},{filename:"/tmp/pglite/share/postgresql/timezone/America/Montevideo",start:5040460,end:5041429},{filename:"/tmp/pglite/share/postgresql/timezone/America/Montreal",start:5041429,end:5043146},{filename:"/tmp/pglite/share/postgresql/timezone/America/Montserrat",start:5043146,end:5043323},{filename:"/tmp/pglite/share/postgresql/timezone/America/Nassau",start:5043323,end:5045040},{filename:"/tmp/pglite/share/postgresql/timezone/America/New_York",start:5045040,end:5046784},{filename:"/tmp/pglite/share/postgresql/timezone/America/Nipigon",start:5046784,end:5048501},{filename:"/tmp/pglite/share/postgresql/timezone/America/Nome",start:5048501,end:5049476},{filename:"/tmp/pglite/share/postgresql/timezone/America/Noronha",start:5049476,end:5049960},{filename:"/tmp/pglite/share/postgresql/timezone/America/North_Dakota/Beulah",start:5049960,end:5051003},{filename:"/tmp/pglite/share/postgresql/timezone/America/North_Dakota/Center",start:5051003,end:5051993},{filename:"/tmp/pglite/share/postgresql/timezone/America/North_Dakota/New_Salem",start:5051993,end:5052983},{filename:"/tmp/pglite/share/postgresql/timezone/America/Nuuk",start:5052983,end:5053948},{filename:"/tmp/pglite/share/postgresql/timezone/America/Ojinaga",start:5053948,end:5054657},{filename:"/tmp/pglite/share/postgresql/timezone/America/Panama",start:5054657,end:5054806},{filename:"/tmp/pglite/share/postgresql/timezone/America/Pangnirtung",start:5054806,end:5055661},{filename:"/tmp/pglite/share/postgresql/timezone/America/Paramaribo",start:5055661,end:5055848},{filename:"/tmp/pglite/share/postgresql/timezone/America/Phoenix",start:5055848,end:5056088},{filename:"/tmp/pglite/share/postgresql/timezone/America/Port-au-Prince",start:5056088,end:5056653},{filename:"/tmp/pglite/share/postgresql/timezone/America/Port_of_Spain",start:5056653,end:5056830},{filename:"/tmp/pglite/share/postgresql/timezone/America/Porto_Acre",start:5056830,end:5057248},{filename:"/tmp/pglite/share/postgresql/timezone/America/Porto_Velho",start:5057248,end:5057642},{filename:"/tmp/pglite/share/postgresql/timezone/America/Puerto_Rico",start:5057642,end:5057819},{filename:"/tmp/pglite/share/postgresql/timezone/America/Punta_Arenas",start:5057819,end:5059037},{filename:"/tmp/pglite/share/postgresql/timezone/America/Rainy_River",start:5059037,end:5060331},{filename:"/tmp/pglite/share/postgresql/timezone/America/Rankin_Inlet",start:5060331,end:5061138},{filename:"/tmp/pglite/share/postgresql/timezone/America/Recife",start:5061138,end:5061622},{filename:"/tmp/pglite/share/postgresql/timezone/America/Regina",start:5061622,end:5062260},{filename:"/tmp/pglite/share/postgresql/timezone/America/Resolute",start:5062260,end:5063067},{filename:"/tmp/pglite/share/postgresql/timezone/America/Rio_Branco",start:5063067,end:5063485},{filename:"/tmp/pglite/share/postgresql/timezone/America/Rosario",start:5063485,end:5064193},{filename:"/tmp/pglite/share/postgresql/timezone/America/Santa_Isabel",start:5064193,end:5065218},{filename:"/tmp/pglite/share/postgresql/timezone/America/Santarem",start:5065218,end:5065627},{filename:"/tmp/pglite/share/postgresql/timezone/America/Santiago",start:5065627,end:5066981},{filename:"/tmp/pglite/share/postgresql/timezone/America/Santo_Domingo",start:5066981,end:5067298},{filename:"/tmp/pglite/share/postgresql/timezone/America/Sao_Paulo",start:5067298,end:5068250},{filename:"/tmp/pglite/share/postgresql/timezone/America/Scoresbysund",start:5068250,end:5069234},{filename:"/tmp/pglite/share/postgresql/timezone/America/Shiprock",start:5069234,end:5070276},{filename:"/tmp/pglite/share/postgresql/timezone/America/Sitka",start:5070276,end:5071232},{filename:"/tmp/pglite/share/postgresql/timezone/America/St_Barthelemy",start:5071232,end:5071409},{filename:"/tmp/pglite/share/postgresql/timezone/America/St_Johns",start:5071409,end:5073287},{filename:"/tmp/pglite/share/postgresql/timezone/America/St_Kitts",start:5073287,end:5073464},{filename:"/tmp/pglite/share/postgresql/timezone/America/St_Lucia",start:5073464,end:5073641},{filename:"/tmp/pglite/share/postgresql/timezone/America/St_Thomas",start:5073641,end:5073818},{filename:"/tmp/pglite/share/postgresql/timezone/America/St_Vincent",start:5073818,end:5073995},{filename:"/tmp/pglite/share/postgresql/timezone/America/Swift_Current",start:5073995,end:5074363},{filename:"/tmp/pglite/share/postgresql/timezone/America/Tegucigalpa",start:5074363,end:5074557},{filename:"/tmp/pglite/share/postgresql/timezone/America/Thule",start:5074557,end:5075012},{filename:"/tmp/pglite/share/postgresql/timezone/America/Thunder_Bay",start:5075012,end:5076729},{filename:"/tmp/pglite/share/postgresql/timezone/America/Tijuana",start:5076729,end:5077754},{filename:"/tmp/pglite/share/postgresql/timezone/America/Toronto",start:5077754,end:5079471},{filename:"/tmp/pglite/share/postgresql/timezone/America/Tortola",start:5079471,end:5079648},{filename:"/tmp/pglite/share/postgresql/timezone/America/Vancouver",start:5079648,end:5080978},{filename:"/tmp/pglite/share/postgresql/timezone/America/Virgin",start:5080978,end:5081155},{filename:"/tmp/pglite/share/postgresql/timezone/America/Whitehorse",start:5081155,end:5082184},{filename:"/tmp/pglite/share/postgresql/timezone/America/Winnipeg",start:5082184,end:5083478},{filename:"/tmp/pglite/share/postgresql/timezone/America/Yakutat",start:5083478,end:5084424},{filename:"/tmp/pglite/share/postgresql/timezone/America/Yellowknife",start:5084424,end:5085394},{filename:"/tmp/pglite/share/postgresql/timezone/Antarctica/Casey",start:5085394,end:5085681},{filename:"/tmp/pglite/share/postgresql/timezone/Antarctica/Davis",start:5085681,end:5085878},{filename:"/tmp/pglite/share/postgresql/timezone/Antarctica/DumontDUrville",start:5085878,end:5086032},{filename:"/tmp/pglite/share/postgresql/timezone/Antarctica/Macquarie",start:5086032,end:5087008},{filename:"/tmp/pglite/share/postgresql/timezone/Antarctica/Mawson",start:5087008,end:5087160},{filename:"/tmp/pglite/share/postgresql/timezone/Antarctica/McMurdo",start:5087160,end:5088203},{filename:"/tmp/pglite/share/postgresql/timezone/Antarctica/Palmer",start:5088203,end:5089090},{filename:"/tmp/pglite/share/postgresql/timezone/Antarctica/Rothera",start:5089090,end:5089222},{filename:"/tmp/pglite/share/postgresql/timezone/Antarctica/South_Pole",start:5089222,end:5090265},{filename:"/tmp/pglite/share/postgresql/timezone/Antarctica/Syowa",start:5090265,end:5090398},{filename:"/tmp/pglite/share/postgresql/timezone/Antarctica/Troll",start:5090398,end:5090575},{filename:"/tmp/pglite/share/postgresql/timezone/Antarctica/Vostok",start:5090575,end:5090745},{filename:"/tmp/pglite/share/postgresql/timezone/Arctic/Longyearbyen",start:5090745,end:5091450},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Aden",start:5091450,end:5091583},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Almaty",start:5091583,end:5092201},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Amman",start:5092201,end:5093129},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Anadyr",start:5093129,end:5093872},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Aqtau",start:5093872,end:5094478},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Aqtobe",start:5094478,end:5095093},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Ashgabat",start:5095093,end:5095468},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Ashkhabad",start:5095468,end:5095843},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Atyrau",start:5095843,end:5096459},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Baghdad",start:5096459,end:5097089},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Bahrain",start:5097089,end:5097241},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Baku",start:5097241,end:5097985},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Bangkok",start:5097985,end:5098137},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Barnaul",start:5098137,end:5098890},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Beirut",start:5098890,end:5099622},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Bishkek",start:5099622,end:5100240},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Brunei",start:5100240,end:5100560},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Calcutta",start:5100560,end:5100780},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Chita",start:5100780,end:5101530},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Choibalsan",start:5101530,end:5102149},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Chongqing",start:5102149,end:5102542},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Chungking",start:5102542,end:5102935},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Colombo",start:5102935,end:5103182},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Dacca",start:5103182,end:5103413},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Damascus",start:5103413,end:5104647},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Dhaka",start:5104647,end:5104878},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Dili",start:5104878,end:5105048},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Dubai",start:5105048,end:5105181},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Dushanbe",start:5105181,end:5105547},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Famagusta",start:5105547,end:5106487},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Gaza",start:5106487,end:5108933},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Harbin",start:5108933,end:5109326},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Hebron",start:5109326,end:5111790},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Ho_Chi_Minh",start:5111790,end:5112026},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Hong_Kong",start:5112026,end:5112801},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Hovd",start:5112801,end:5113395},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Irkutsk",start:5113395,end:5114155},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Istanbul",start:5114155,end:5115355},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Jakarta",start:5115355,end:5115603},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Jayapura",start:5115603,end:5115774},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Jerusalem",start:5115774,end:5116848},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Kabul",start:5116848,end:5117007},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Kamchatka",start:5117007,end:5117734},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Karachi",start:5117734,end:5118e3},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Kashgar",start:5118e3,end:5118133},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Kathmandu",start:5118133,end:5118294},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Katmandu",start:5118294,end:5118455},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Khandyga",start:5118455,end:5119230},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Kolkata",start:5119230,end:5119450},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Krasnoyarsk",start:5119450,end:5120191},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Kuala_Lumpur",start:5120191,end:5120447},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Kuching",start:5120447,end:5120767},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Kuwait",start:5120767,end:5120900},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Macao",start:5120900,end:5121691},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Macau",start:5121691,end:5122482},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Magadan",start:5122482,end:5123233},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Makassar",start:5123233,end:5123423},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Manila",start:5123423,end:5123661},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Muscat",start:5123661,end:5123794},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Nicosia",start:5123794,end:5124391},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Novokuznetsk",start:5124391,end:5125117},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Novosibirsk",start:5125117,end:5125870},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Omsk",start:5125870,end:5126611},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Oral",start:5126611,end:5127236},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Phnom_Penh",start:5127236,end:5127388},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Pontianak",start:5127388,end:5127635},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Pyongyang",start:5127635,end:5127818},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Qatar",start:5127818,end:5127970},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Qostanay",start:5127970,end:5128594},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Qyzylorda",start:5128594,end:5129218},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Rangoon",start:5129218,end:5129405},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Riyadh",start:5129405,end:5129538},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Saigon",start:5129538,end:5129774},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Sakhalin",start:5129774,end:5130529},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Samarkand",start:5130529,end:5130895},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Seoul",start:5130895,end:5131310},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Shanghai",start:5131310,end:5131703},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Singapore",start:5131703,end:5131959},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Srednekolymsk",start:5131959,end:5132701},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Taipei",start:5132701,end:5133212},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Tashkent",start:5133212,end:5133578},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Tbilisi",start:5133578,end:5134207},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Tehran",start:5134207,end:5135019},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Tel_Aviv",start:5135019,end:5136093},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Thimbu",start:5136093,end:5136247},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Thimphu",start:5136247,end:5136401},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Tokyo",start:5136401,end:5136614},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Tomsk",start:5136614,end:5137367},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Ujung_Pandang",start:5137367,end:5137557},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Ulaanbaatar",start:5137557,end:5138151},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Ulan_Bator",start:5138151,end:5138745},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Urumqi",start:5138745,end:5138878},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Ust-Nera",start:5138878,end:5139649},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Vientiane",start:5139649,end:5139801},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Vladivostok",start:5139801,end:5140543},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Yakutsk",start:5140543,end:5141284},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Yangon",start:5141284,end:5141471},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Yekaterinburg",start:5141471,end:5142231},{filename:"/tmp/pglite/share/postgresql/timezone/Asia/Yerevan",start:5142231,end:5142939},{filename:"/tmp/pglite/share/postgresql/timezone/Atlantic/Azores",start:5142939,end:5144392},{filename:"/tmp/pglite/share/postgresql/timezone/Atlantic/Bermuda",start:5144392,end:5145416},{filename:"/tmp/pglite/share/postgresql/timezone/Atlantic/Canary",start:5145416,end:5145894},{filename:"/tmp/pglite/share/postgresql/timezone/Atlantic/Cape_Verde",start:5145894,end:5146069},{filename:"/tmp/pglite/share/postgresql/timezone/Atlantic/Faeroe",start:5146069,end:5146510},{filename:"/tmp/pglite/share/postgresql/timezone/Atlantic/Faroe",start:5146510,end:5146951},{filename:"/tmp/pglite/share/postgresql/timezone/Atlantic/Jan_Mayen",start:5146951,end:5147656},{filename:"/tmp/pglite/share/postgresql/timezone/Atlantic/Madeira",start:5147656,end:5149109},{filename:"/tmp/pglite/share/postgresql/timezone/Atlantic/Reykjavik",start:5149109,end:5149239},{filename:"/tmp/pglite/share/postgresql/timezone/Atlantic/South_Georgia",start:5149239,end:5149371},{filename:"/tmp/pglite/share/postgresql/timezone/Atlantic/St_Helena",start:5149371,end:5149501},{filename:"/tmp/pglite/share/postgresql/timezone/Atlantic/Stanley",start:5149501,end:5150290},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/ACT",start:5150290,end:5151194},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Adelaide",start:5151194,end:5152115},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Brisbane",start:5152115,end:5152404},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Broken_Hill",start:5152404,end:5153345},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Canberra",start:5153345,end:5154249},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Currie",start:5154249,end:5155252},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Darwin",start:5155252,end:5155486},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Eucla",start:5155486,end:5155800},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Hobart",start:5155800,end:5156803},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/LHI",start:5156803,end:5157495},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Lindeman",start:5157495,end:5157820},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Lord_Howe",start:5157820,end:5158512},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Melbourne",start:5158512,end:5159416},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/NSW",start:5159416,end:5160320},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/North",start:5160320,end:5160554},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Perth",start:5160554,end:5160860},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Queensland",start:5160860,end:5161149},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/South",start:5161149,end:5162070},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Sydney",start:5162070,end:5162974},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Tasmania",start:5162974,end:5163977},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Victoria",start:5163977,end:5164881},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/West",start:5164881,end:5165187},{filename:"/tmp/pglite/share/postgresql/timezone/Australia/Yancowinna",start:5165187,end:5166128},{filename:"/tmp/pglite/share/postgresql/timezone/Brazil/Acre",start:5166128,end:5166546},{filename:"/tmp/pglite/share/postgresql/timezone/Brazil/DeNoronha",start:5166546,end:5167030},{filename:"/tmp/pglite/share/postgresql/timezone/Brazil/East",start:5167030,end:5167982},{filename:"/tmp/pglite/share/postgresql/timezone/Brazil/West",start:5167982,end:5168394},{filename:"/tmp/pglite/share/postgresql/timezone/CET",start:5168394,end:5169015},{filename:"/tmp/pglite/share/postgresql/timezone/CST6CDT",start:5169015,end:5169966},{filename:"/tmp/pglite/share/postgresql/timezone/Canada/Atlantic",start:5169966,end:5171638},{filename:"/tmp/pglite/share/postgresql/timezone/Canada/Central",start:5171638,end:5172932},{filename:"/tmp/pglite/share/postgresql/timezone/Canada/Eastern",start:5172932,end:5174649},{filename:"/tmp/pglite/share/postgresql/timezone/Canada/Mountain",start:5174649,end:5175619},{filename:"/tmp/pglite/share/postgresql/timezone/Canada/Newfoundland",start:5175619,end:5177497},{filename:"/tmp/pglite/share/postgresql/timezone/Canada/Pacific",start:5177497,end:5178827},{filename:"/tmp/pglite/share/postgresql/timezone/Canada/Saskatchewan",start:5178827,end:5179465},{filename:"/tmp/pglite/share/postgresql/timezone/Canada/Yukon",start:5179465,end:5180494},{filename:"/tmp/pglite/share/postgresql/timezone/Chile/Continental",start:5180494,end:5181848},{filename:"/tmp/pglite/share/postgresql/timezone/Chile/EasterIsland",start:5181848,end:5183022},{filename:"/tmp/pglite/share/postgresql/timezone/Cuba",start:5183022,end:5184139},{filename:"/tmp/pglite/share/postgresql/timezone/EET",start:5184139,end:5184636},{filename:"/tmp/pglite/share/postgresql/timezone/EST",start:5184636,end:5184747},{filename:"/tmp/pglite/share/postgresql/timezone/EST5EDT",start:5184747,end:5185698},{filename:"/tmp/pglite/share/postgresql/timezone/Egypt",start:5185698,end:5187007},{filename:"/tmp/pglite/share/postgresql/timezone/Eire",start:5187007,end:5188503},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT",start:5188503,end:5188614},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT+0",start:5188614,end:5188725},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT+1",start:5188725,end:5188838},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT+10",start:5188838,end:5188952},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT+11",start:5188952,end:5189066},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT+12",start:5189066,end:5189180},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT+2",start:5189180,end:5189293},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT+3",start:5189293,end:5189406},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT+4",start:5189406,end:5189519},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT+5",start:5189519,end:5189632},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT+6",start:5189632,end:5189745},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT+7",start:5189745,end:5189858},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT+8",start:5189858,end:5189971},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT+9",start:5189971,end:5190084},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-0",start:5190084,end:5190195},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-1",start:5190195,end:5190309},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-10",start:5190309,end:5190424},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-11",start:5190424,end:5190539},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-12",start:5190539,end:5190654},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-13",start:5190654,end:5190769},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-14",start:5190769,end:5190884},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-2",start:5190884,end:5190998},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-3",start:5190998,end:5191112},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-4",start:5191112,end:5191226},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-5",start:5191226,end:5191340},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-6",start:5191340,end:5191454},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-7",start:5191454,end:5191568},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-8",start:5191568,end:5191682},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT-9",start:5191682,end:5191796},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/GMT0",start:5191796,end:5191907},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/Greenwich",start:5191907,end:5192018},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/UCT",start:5192018,end:5192129},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/UTC",start:5192129,end:5192240},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/Universal",start:5192240,end:5192351},{filename:"/tmp/pglite/share/postgresql/timezone/Etc/Zulu",start:5192351,end:5192462},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Amsterdam",start:5192462,end:5193565},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Andorra",start:5193565,end:5193954},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Astrakhan",start:5193954,end:5194680},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Athens",start:5194680,end:5195362},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Belfast",start:5195362,end:5196961},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Belgrade",start:5196961,end:5197439},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Berlin",start:5197439,end:5198144},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Bratislava",start:5198144,end:5198867},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Brussels",start:5198867,end:5199970},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Bucharest",start:5199970,end:5200631},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Budapest",start:5200631,end:5201397},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Busingen",start:5201397,end:5201894},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Chisinau",start:5201894,end:5202649},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Copenhagen",start:5202649,end:5203354},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Dublin",start:5203354,end:5204850},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Gibraltar",start:5204850,end:5206070},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Guernsey",start:5206070,end:5207669},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Helsinki",start:5207669,end:5208150},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Isle_of_Man",start:5208150,end:5209749},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Istanbul",start:5209749,end:5210949},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Jersey",start:5210949,end:5212548},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Kaliningrad",start:5212548,end:5213452},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Kiev",start:5213452,end:5214010},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Kirov",start:5214010,end:5214745},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Kyiv",start:5214745,end:5215303},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Lisbon",start:5215303,end:5216757},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Ljubljana",start:5216757,end:5217235},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/London",start:5217235,end:5218834},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Luxembourg",start:5218834,end:5219937},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Madrid",start:5219937,end:5220834},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Malta",start:5220834,end:5221762},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Mariehamn",start:5221762,end:5222243},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Minsk",start:5222243,end:5223051},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Monaco",start:5223051,end:5224156},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Moscow",start:5224156,end:5225064},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Nicosia",start:5225064,end:5225661},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Oslo",start:5225661,end:5226366},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Paris",start:5226366,end:5227471},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Podgorica",start:5227471,end:5227949},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Prague",start:5227949,end:5228672},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Riga",start:5228672,end:5229366},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Rome",start:5229366,end:5230313},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Samara",start:5230313,end:5231045},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/San_Marino",start:5231045,end:5231992},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Sarajevo",start:5231992,end:5232470},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Saratov",start:5232470,end:5233196},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Simferopol",start:5233196,end:5234061},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Skopje",start:5234061,end:5234539},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Sofia",start:5234539,end:5235131},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Stockholm",start:5235131,end:5235836},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Tallinn",start:5235836,end:5236511},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Tirane",start:5236511,end:5237115},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Tiraspol",start:5237115,end:5237870},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Ulyanovsk",start:5237870,end:5238630},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Uzhgorod",start:5238630,end:5239188},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Vaduz",start:5239188,end:5239685},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Vatican",start:5239685,end:5240632},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Vienna",start:5240632,end:5241290},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Vilnius",start:5241290,end:5241966},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Volgograd",start:5241966,end:5242719},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Warsaw",start:5242719,end:5243642},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Zagreb",start:5243642,end:5244120},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Zaporozhye",start:5244120,end:5244678},{filename:"/tmp/pglite/share/postgresql/timezone/Europe/Zurich",start:5244678,end:5245175},{filename:"/tmp/pglite/share/postgresql/timezone/Factory",start:5245175,end:5245288},{filename:"/tmp/pglite/share/postgresql/timezone/GB",start:5245288,end:5246887},{filename:"/tmp/pglite/share/postgresql/timezone/GB-Eire",start:5246887,end:5248486},{filename:"/tmp/pglite/share/postgresql/timezone/GMT",start:5248486,end:5248597},{filename:"/tmp/pglite/share/postgresql/timezone/GMT+0",start:5248597,end:5248708},{filename:"/tmp/pglite/share/postgresql/timezone/GMT-0",start:5248708,end:5248819},{filename:"/tmp/pglite/share/postgresql/timezone/GMT0",start:5248819,end:5248930},{filename:"/tmp/pglite/share/postgresql/timezone/Greenwich",start:5248930,end:5249041},{filename:"/tmp/pglite/share/postgresql/timezone/HST",start:5249041,end:5249153},{filename:"/tmp/pglite/share/postgresql/timezone/Hongkong",start:5249153,end:5249928},{filename:"/tmp/pglite/share/postgresql/timezone/Iceland",start:5249928,end:5250058},{filename:"/tmp/pglite/share/postgresql/timezone/Indian/Antananarivo",start:5250058,end:5250249},{filename:"/tmp/pglite/share/postgresql/timezone/Indian/Chagos",start:5250249,end:5250401},{filename:"/tmp/pglite/share/postgresql/timezone/Indian/Christmas",start:5250401,end:5250553},{filename:"/tmp/pglite/share/postgresql/timezone/Indian/Cocos",start:5250553,end:5250740},{filename:"/tmp/pglite/share/postgresql/timezone/Indian/Comoro",start:5250740,end:5250931},{filename:"/tmp/pglite/share/postgresql/timezone/Indian/Kerguelen",start:5250931,end:5251083},{filename:"/tmp/pglite/share/postgresql/timezone/Indian/Mahe",start:5251083,end:5251216},{filename:"/tmp/pglite/share/postgresql/timezone/Indian/Maldives",start:5251216,end:5251368},{filename:"/tmp/pglite/share/postgresql/timezone/Indian/Mauritius",start:5251368,end:5251547},{filename:"/tmp/pglite/share/postgresql/timezone/Indian/Mayotte",start:5251547,end:5251738},{filename:"/tmp/pglite/share/postgresql/timezone/Indian/Reunion",start:5251738,end:5251871},{filename:"/tmp/pglite/share/postgresql/timezone/Iran",start:5251871,end:5252683},{filename:"/tmp/pglite/share/postgresql/timezone/Israel",start:5252683,end:5253757},{filename:"/tmp/pglite/share/postgresql/timezone/Jamaica",start:5253757,end:5254096},{filename:"/tmp/pglite/share/postgresql/timezone/Japan",start:5254096,end:5254309},{filename:"/tmp/pglite/share/postgresql/timezone/Kwajalein",start:5254309,end:5254528},{filename:"/tmp/pglite/share/postgresql/timezone/Libya",start:5254528,end:5254959},{filename:"/tmp/pglite/share/postgresql/timezone/MET",start:5254959,end:5255580},{filename:"/tmp/pglite/share/postgresql/timezone/MST",start:5255580,end:5255691},{filename:"/tmp/pglite/share/postgresql/timezone/MST7MDT",start:5255691,end:5256642},{filename:"/tmp/pglite/share/postgresql/timezone/Mexico/BajaNorte",start:5256642,end:5257667},{filename:"/tmp/pglite/share/postgresql/timezone/Mexico/BajaSur",start:5257667,end:5258385},{filename:"/tmp/pglite/share/postgresql/timezone/Mexico/General",start:5258385,end:5259158},{filename:"/tmp/pglite/share/postgresql/timezone/NZ",start:5259158,end:5260201},{filename:"/tmp/pglite/share/postgresql/timezone/NZ-CHAT",start:5260201,end:5261009},{filename:"/tmp/pglite/share/postgresql/timezone/Navajo",start:5261009,end:5262051},{filename:"/tmp/pglite/share/postgresql/timezone/PRC",start:5262051,end:5262444},{filename:"/tmp/pglite/share/postgresql/timezone/PST8PDT",start:5262444,end:5263395},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Apia",start:5263395,end:5263802},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Auckland",start:5263802,end:5264845},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Bougainville",start:5264845,end:5265046},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Chatham",start:5265046,end:5265854},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Chuuk",start:5265854,end:5266008},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Easter",start:5266008,end:5267182},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Efate",start:5267182,end:5267524},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Enderbury",start:5267524,end:5267696},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Fakaofo",start:5267696,end:5267849},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Fiji",start:5267849,end:5268245},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Funafuti",start:5268245,end:5268379},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Galapagos",start:5268379,end:5268554},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Gambier",start:5268554,end:5268686},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Guadalcanal",start:5268686,end:5268820},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Guam",start:5268820,end:5269170},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Honolulu",start:5269170,end:5269391},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Johnston",start:5269391,end:5269612},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Kanton",start:5269612,end:5269784},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Kiritimati",start:5269784,end:5269958},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Kosrae",start:5269958,end:5270200},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Kwajalein",start:5270200,end:5270419},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Majuro",start:5270419,end:5270553},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Marquesas",start:5270553,end:5270692},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Midway",start:5270692,end:5270838},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Nauru",start:5270838,end:5271021},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Niue",start:5271021,end:5271175},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Norfolk",start:5271175,end:5271422},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Noumea",start:5271422,end:5271620},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Pago_Pago",start:5271620,end:5271766},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Palau",start:5271766,end:5271914},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Pitcairn",start:5271914,end:5272067},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Pohnpei",start:5272067,end:5272201},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Ponape",start:5272201,end:5272335},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Port_Moresby",start:5272335,end:5272489},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Rarotonga",start:5272489,end:5272895},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Saipan",start:5272895,end:5273245},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Samoa",start:5273245,end:5273391},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Tahiti",start:5273391,end:5273524},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Tarawa",start:5273524,end:5273658},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Tongatapu",start:5273658,end:5273895},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Truk",start:5273895,end:5274049},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Wake",start:5274049,end:5274183},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Wallis",start:5274183,end:5274317},{filename:"/tmp/pglite/share/postgresql/timezone/Pacific/Yap",start:5274317,end:5274471},{filename:"/tmp/pglite/share/postgresql/timezone/Poland",start:5274471,end:5275394},{filename:"/tmp/pglite/share/postgresql/timezone/Portugal",start:5275394,end:5276848},{filename:"/tmp/pglite/share/postgresql/timezone/ROC",start:5276848,end:5277359},{filename:"/tmp/pglite/share/postgresql/timezone/ROK",start:5277359,end:5277774},{filename:"/tmp/pglite/share/postgresql/timezone/Singapore",start:5277774,end:5278030},{filename:"/tmp/pglite/share/postgresql/timezone/Turkey",start:5278030,end:5279230},{filename:"/tmp/pglite/share/postgresql/timezone/UCT",start:5279230,end:5279341},{filename:"/tmp/pglite/share/postgresql/timezone/US/Alaska",start:5279341,end:5280318},{filename:"/tmp/pglite/share/postgresql/timezone/US/Aleutian",start:5280318,end:5281287},{filename:"/tmp/pglite/share/postgresql/timezone/US/Arizona",start:5281287,end:5281527},{filename:"/tmp/pglite/share/postgresql/timezone/US/Central",start:5281527,end:5283281},{filename:"/tmp/pglite/share/postgresql/timezone/US/East-Indiana",start:5283281,end:5283812},{filename:"/tmp/pglite/share/postgresql/timezone/US/Eastern",start:5283812,end:5285556},{filename:"/tmp/pglite/share/postgresql/timezone/US/Hawaii",start:5285556,end:5285777},{filename:"/tmp/pglite/share/postgresql/timezone/US/Indiana-Starke",start:5285777,end:5286793},{filename:"/tmp/pglite/share/postgresql/timezone/US/Michigan",start:5286793,end:5287692},{filename:"/tmp/pglite/share/postgresql/timezone/US/Mountain",start:5287692,end:5288734},{filename:"/tmp/pglite/share/postgresql/timezone/US/Pacific",start:5288734,end:5290028},{filename:"/tmp/pglite/share/postgresql/timezone/US/Samoa",start:5290028,end:5290174},{filename:"/tmp/pglite/share/postgresql/timezone/UTC",start:5290174,end:5290285},{filename:"/tmp/pglite/share/postgresql/timezone/Universal",start:5290285,end:5290396},{filename:"/tmp/pglite/share/postgresql/timezone/W-SU",start:5290396,end:5291304},{filename:"/tmp/pglite/share/postgresql/timezone/WET",start:5291304,end:5291798},{filename:"/tmp/pglite/share/postgresql/timezone/Zulu",start:5291798,end:5291909},{filename:"/tmp/pglite/share/postgresql/timezonesets/Africa.txt",start:5291909,end:5298882},{filename:"/tmp/pglite/share/postgresql/timezonesets/America.txt",start:5298882,end:5309889},{filename:"/tmp/pglite/share/postgresql/timezonesets/Antarctica.txt",start:5309889,end:5311023},{filename:"/tmp/pglite/share/postgresql/timezonesets/Asia.txt",start:5311023,end:5319334},{filename:"/tmp/pglite/share/postgresql/timezonesets/Atlantic.txt",start:5319334,end:5322867},{filename:"/tmp/pglite/share/postgresql/timezonesets/Australia",start:5322867,end:5324002},{filename:"/tmp/pglite/share/postgresql/timezonesets/Australia.txt",start:5324002,end:5327386},{filename:"/tmp/pglite/share/postgresql/timezonesets/Default",start:5327386,end:5354636},{filename:"/tmp/pglite/share/postgresql/timezonesets/Etc.txt",start:5354636,end:5355886},{filename:"/tmp/pglite/share/postgresql/timezonesets/Europe.txt",start:5355886,end:5364668},{filename:"/tmp/pglite/share/postgresql/timezonesets/India",start:5364668,end:5365261},{filename:"/tmp/pglite/share/postgresql/timezonesets/Indian.txt",start:5365261,end:5366522},{filename:"/tmp/pglite/share/postgresql/timezonesets/Pacific.txt",start:5366522,end:5370290},{filename:"/tmp/pglite/share/postgresql/tsearch_data/danish.stop",start:5370290,end:5370714},{filename:"/tmp/pglite/share/postgresql/tsearch_data/dutch.stop",start:5370714,end:5371167},{filename:"/tmp/pglite/share/postgresql/tsearch_data/english.stop",start:5371167,end:5371789},{filename:"/tmp/pglite/share/postgresql/tsearch_data/finnish.stop",start:5371789,end:5373368},{filename:"/tmp/pglite/share/postgresql/tsearch_data/french.stop",start:5373368,end:5374173},{filename:"/tmp/pglite/share/postgresql/tsearch_data/german.stop",start:5374173,end:5375522},{filename:"/tmp/pglite/share/postgresql/tsearch_data/hungarian.stop",start:5375522,end:5376749},{filename:"/tmp/pglite/share/postgresql/tsearch_data/hunspell_sample.affix",start:5376749,end:5376992},{filename:"/tmp/pglite/share/postgresql/tsearch_data/hunspell_sample_long.affix",start:5376992,end:5377625},{filename:"/tmp/pglite/share/postgresql/tsearch_data/hunspell_sample_long.dict",start:5377625,end:5377723},{filename:"/tmp/pglite/share/postgresql/tsearch_data/hunspell_sample_num.affix",start:5377723,end:5378185},{filename:"/tmp/pglite/share/postgresql/tsearch_data/hunspell_sample_num.dict",start:5378185,end:5378314},{filename:"/tmp/pglite/share/postgresql/tsearch_data/ispell_sample.affix",start:5378314,end:5378779},{filename:"/tmp/pglite/share/postgresql/tsearch_data/ispell_sample.dict",start:5378779,end:5378860},{filename:"/tmp/pglite/share/postgresql/tsearch_data/italian.stop",start:5378860,end:5380514},{filename:"/tmp/pglite/share/postgresql/tsearch_data/nepali.stop",start:5380514,end:5384775},{filename:"/tmp/pglite/share/postgresql/tsearch_data/norwegian.stop",start:5384775,end:5385626},{filename:"/tmp/pglite/share/postgresql/tsearch_data/portuguese.stop",start:5385626,end:5386893},{filename:"/tmp/pglite/share/postgresql/tsearch_data/russian.stop",start:5386893,end:5388128},{filename:"/tmp/pglite/share/postgresql/tsearch_data/spanish.stop",start:5388128,end:5390306},{filename:"/tmp/pglite/share/postgresql/tsearch_data/swedish.stop",start:5390306,end:5390865},{filename:"/tmp/pglite/share/postgresql/tsearch_data/synonym_sample.syn",start:5390865,end:5390938},{filename:"/tmp/pglite/share/postgresql/tsearch_data/thesaurus_sample.ths",start:5390938,end:5391411},{filename:"/tmp/pglite/share/postgresql/tsearch_data/turkish.stop",start:5391411,end:5391671},{filename:"/tmp/pglite/share/postgresql/tsearch_data/unaccent.rules",start:5391671,end:5401610},{filename:"/tmp/pglite/share/postgresql/tsearch_data/xsyn_sample.rules",start:5401610,end:5401749}],remote_package_size:5401749})})();var moduleOverrides=Object.assign({},Module),arguments_=[],thisProgram="./this.program",quit_=(e,I)=>{throw I},scriptDirectory="";function locateFile(e){return Module.locateFile?Module.locateFile(e,scriptDirectory):scriptDirectory+e}var readAsync,readBinary;if(ENVIRONMENT_IS_NODE){var fs=require("fs"),nodePath=require("path");import.meta.url.startsWith("data:")||(scriptDirectory=nodePath.dirname(require("url").fileURLToPath(import.meta.url))+"/"),readBinary=e=>{e=isFileURI(e)?new URL(e):e;var I=fs.readFileSync(e);return I},readAsync=async(e,I=!0)=>{e=isFileURI(e)?new URL(e):e;var Hn=fs.readFileSync(e,I?void 0:"utf8");return Hn},!Module.thisProgram&&process.argv.length>1&&(thisProgram=process.argv[1].replace(/\\/g,"/")),arguments_=process.argv.slice(2),quit_=(e,I)=>{throw process.exitCode=e,I}}else(ENVIRONMENT_IS_WEB||ENVIRONMENT_IS_WORKER)&&(ENVIRONMENT_IS_WORKER?scriptDirectory=self.location.href:typeof document<"u"&&document.currentScript&&(scriptDirectory=document.currentScript.src),_scriptName&&(scriptDirectory=_scriptName),scriptDirectory.startsWith("blob:")?scriptDirectory="":scriptDirectory=scriptDirectory.substr(0,scriptDirectory.replace(/[?#].*/,"").lastIndexOf("/")+1),readAsync=async e=>{var I=await fetch(e,{credentials:"same-origin"});if(I.ok)return I.arrayBuffer();throw new Error(I.status+" : "+I.url)});var out=Module.print||console.log.bind(console),err=Module.printErr||console.error.bind(console);Object.assign(Module,moduleOverrides),moduleOverrides=null,Module.arguments&&(arguments_=Module.arguments),Module.thisProgram&&(thisProgram=Module.thisProgram);var dynamicLibraries=Module.dynamicLibraries||[],wasmBinary=Module.wasmBinary,wasmMemory,ABORT=!1,EXITSTATUS;function assert(e,I){e||abort(I)}var HEAP8,HEAPU8,HEAP16,HEAPU16,HEAP32,HEAPU32,HEAPF32,HEAP64,HEAPF64;function updateMemoryViews(){var e=wasmMemory.buffer;Module.HEAP8=HEAP8=new Int8Array(e),Module.HEAP16=HEAP16=new Int16Array(e),Module.HEAPU8=HEAPU8=new Uint8Array(e),Module.HEAPU16=HEAPU16=new Uint16Array(e),Module.HEAP32=HEAP32=new Int32Array(e),Module.HEAPU32=HEAPU32=new Uint32Array(e),Module.HEAPF32=HEAPF32=new Float32Array(e),Module.HEAPF64=HEAPF64=new Float64Array(e),Module.HEAP64=HEAP64=new BigInt64Array(e),Module.HEAPU64=new BigUint64Array(e)}if(Module.wasmMemory)wasmMemory=Module.wasmMemory;else{var INITIAL_MEMORY=Module.INITIAL_MEMORY||134217728;wasmMemory=new WebAssembly.Memory({initial:INITIAL_MEMORY/65536,maximum:32768})}updateMemoryViews();var __ATPRERUN__=[],__ATINIT__=[],__ATMAIN__=[],__ATPOSTRUN__=[],__RELOC_FUNCS__=[],runtimeInitialized=!1;function preRun(){if(Module.preRun)for(typeof Module.preRun=="function"&&(Module.preRun=[Module.preRun]);Module.preRun.length;)addOnPreRun(Module.preRun.shift());callRuntimeCallbacks(__ATPRERUN__)}function initRuntime(){runtimeInitialized=!0,callRuntimeCallbacks(__RELOC_FUNCS__),!Module.noFSInit&&!FS.initialized&&FS.init(),FS.ignorePermissions=!1,SOCKFS.root=FS.mount(SOCKFS,{},null),PIPEFS.root=FS.mount(PIPEFS,{},null),callRuntimeCallbacks(__ATINIT__)}function preMain(){callRuntimeCallbacks(__ATMAIN__)}function postRun(){if(Module.postRun)for(typeof Module.postRun=="function"&&(Module.postRun=[Module.postRun]);Module.postRun.length;)addOnPostRun(Module.postRun.shift());callRuntimeCallbacks(__ATPOSTRUN__)}function addOnPreRun(e){__ATPRERUN__.unshift(e)}function addOnInit(e){__ATINIT__.unshift(e)}function addOnPostRun(e){__ATPOSTRUN__.unshift(e)}var runDependencies=0,dependenciesFulfilled=null;function addRunDependency(e){runDependencies++,Module.monitorRunDependencies?.(runDependencies)}function removeRunDependency(e){if(runDependencies--,Module.monitorRunDependencies?.(runDependencies),runDependencies==0&&dependenciesFulfilled){var I=dependenciesFulfilled;dependenciesFulfilled=null,I()}}function abort(e){Module.onAbort?.(e),e="Aborted("+e+")",err(e),ABORT=!0,e+=". Build with -sASSERTIONS for more info.";var I=new WebAssembly.RuntimeError(e);throw readyPromiseReject(I),I}var dataURIPrefix="data:application/octet-stream;base64,",isDataURI=e=>e.startsWith(dataURIPrefix),isFileURI=e=>e.startsWith("file://");function findWasmBinary(){if(Module.locateFile){var e="postgres.wasm";return isDataURI(e)?e:locateFile(e)}return new URL("/_build/assets/postgres-CyuUVpXN.wasm",import.meta.url).href}var wasmBinaryFile;function getBinarySync(e){if(e==wasmBinaryFile&&wasmBinary)return new Uint8Array(wasmBinary);if(readBinary)return readBinary(e);throw"both async and sync fetching of the wasm failed"}async function getWasmBinary(e){if(!wasmBinary)try{var I=await readAsync(e);return new Uint8Array(I)}catch{}return getBinarySync(e)}async function instantiateArrayBuffer(e,I){try{var Hn=await getWasmBinary(e),$n=await WebAssembly.instantiate(Hn,I);return $n}catch(qn){err(`failed to asynchronously prepare wasm: ${qn}`),abort(qn)}}async function instantiateAsync(e,I,Hn){if(!e&&typeof WebAssembly.instantiateStreaming=="function"&&!isDataURI(I)&&!ENVIRONMENT_IS_NODE&&typeof fetch=="function")try{var $n=fetch(I,{credentials:"same-origin"}),qn=await WebAssembly.instantiateStreaming($n,Hn);return qn}catch(Xn){err(`wasm streaming compile failed: ${Xn}`),err("falling back to ArrayBuffer instantiation")}return instantiateArrayBuffer(I,Hn)}function getWasmImports(){return{env:wasmImports,wasi_snapshot_preview1:wasmImports,"GOT.mem":new Proxy(wasmImports,GOTHandler),"GOT.func":new Proxy(wasmImports,GOTHandler)}}async function createWasm(){function e(qn,Xn){wasmExports=qn.exports,wasmExports=relocateExports(wasmExports,16777216);var Yn=getDylinkMetadata(Xn);return Yn.neededDynlibs&&(dynamicLibraries=Yn.neededDynlibs.concat(dynamicLibraries)),mergeLibSymbols(wasmExports),LDSO.init(),loadDylibs(),addOnInit(wasmExports.__wasm_call_ctors),__RELOC_FUNCS__.push(wasmExports.__wasm_apply_data_relocs),removeRunDependency(),wasmExports}addRunDependency();function I(qn){e(qn.instance,qn.module)}var Hn=getWasmImports();if(Module.instantiateWasm)try{return Module.instantiateWasm(Hn,e)}catch(qn){err(`Module.instantiateWasm callback failed with error: ${qn}`),readyPromiseReject(qn)}wasmBinaryFile??(wasmBinaryFile=findWasmBinary());try{var $n=await instantiateAsync(wasmBinary,wasmBinaryFile,Hn);return I($n),$n}catch(qn){readyPromiseReject(qn);return}}var ASM_CONSTS={18792944:e=>{Module.is_worker=typeof WorkerGlobalScope<"u"&&self instanceof WorkerGlobalScope,Module.FD_BUFFER_MAX=e,Module.emscripten_copy_to=console.warn},18793117:()=>{Module.postMessage=function(e){console.log("# 1252: onCustomMessage:",__FILE__,e)}},18793242:()=>{if(Module.is_worker){let e=function(I){console.log("onCustomMessage:",I)};Module.onCustomMessage=e}else Module.postMessage=function(e){switch(e.type){case"raw":{stringToUTF8(e.data,shm_rawinput,Module.FD_BUFFER_MAX);break}case"stdin":{stringToUTF8(e.data,1,Module.FD_BUFFER_MAX);break}case"rcon":{stringToUTF8(e.data,shm_rcon,Module.FD_BUFFER_MAX);break}default:console.warn("custom_postMessage?",e)}}}};function is_web_env(){try{if(window)return 1}catch{return 0}}is_web_env.sig="i";class ExitStatus{constructor(I){P$2(this,"name","ExitStatus"),this.message=`Program terminated with exit(${I})`,this.status=I}}var GOT={},currentModuleWeakSymbols=new Set([]),GOTHandler={get(e,I){var Hn=GOT[I];return Hn||(Hn=GOT[I]=new WebAssembly.Global({value:"i32",mutable:!0})),currentModuleWeakSymbols.has(I)||(Hn.required=!0),Hn}},callRuntimeCallbacks=e=>{for(;e.length>0;)e.shift()(Module)},UTF8Decoder=typeof TextDecoder<"u"?new TextDecoder:void 0,UTF8ArrayToString=(e,I=0,Hn=NaN)=>{for(var $n=I+Hn,qn=I;e[qn]&&!(qn>=$n);)++qn;if(qn-I>16&&e.buffer&&UTF8Decoder)return UTF8Decoder.decode(e.subarray(I,qn));for(var Xn="";I<qn;){var Yn=e[I++];if(!(Yn&128)){Xn+=String.fromCharCode(Yn);continue}var Kn=e[I++]&63;if((Yn&224)==192){Xn+=String.fromCharCode((Yn&31)<<6|Kn);continue}var Jn=e[I++]&63;if((Yn&240)==224?Yn=(Yn&15)<<12|Kn<<6|Jn:Yn=(Yn&7)<<18|Kn<<12|Jn<<6|e[I++]&63,Yn<65536)Xn+=String.fromCharCode(Yn);else{var Zn=Yn-65536;Xn+=String.fromCharCode(55296|Zn>>10,56320|Zn&1023)}}return Xn},getDylinkMetadata=e=>{var I=0,Hn=0;function $n(){return e[I++]}function qn(){for(var ua=0,Aa=1;;){var Ta=e[I++];if(ua+=(Ta&127)*Aa,Aa*=128,!(Ta&128))break}return ua}function Xn(){var ua=qn();return I+=ua,UTF8ArrayToString(e,I-ua,ua)}function Yn(ua,Aa){if(ua)throw new Error(Aa)}var Kn="dylink.0";if(e instanceof WebAssembly.Module){var Jn=WebAssembly.Module.customSections(e,Kn);Jn.length===0&&(Kn="dylink",Jn=WebAssembly.Module.customSections(e,Kn)),Yn(Jn.length===0,"need dylink section"),e=new Uint8Array(Jn[0]),Hn=e.length}else{var Zn=new Uint32Array(new Uint8Array(e.subarray(0,24)).buffer),ea=Zn[0]==1836278016;Yn(!ea,"need to see wasm magic number"),Yn(e[8]!==0,"need the dylink section to be first"),I=9;var aa=qn();Hn=I+aa,Kn=Xn()}var oa={neededDynlibs:[],tlsExports:new Set,weakImports:new Set};if(Kn=="dylink"){oa.memorySize=qn(),oa.memoryAlign=qn(),oa.tableSize=qn(),oa.tableAlign=qn();for(var la=qn(),ra=0;ra<la;++ra){var ia=Xn();oa.neededDynlibs.push(ia)}}else{Yn(Kn!=="dylink.0");for(var da=1,Ea=2,na=3,ta=4,sa=256,ca=3,_a=1;I<Hn;){var pa=$n(),Sa=qn();if(pa===da)oa.memorySize=qn(),oa.memoryAlign=qn(),oa.tableSize=qn(),oa.tableAlign=qn();else if(pa===Ea)for(var la=qn(),ra=0;ra<la;++ra)ia=Xn(),oa.neededDynlibs.push(ia);else if(pa===na)for(var Na=qn();Na--;){var ma=Xn(),Ia=qn();Ia&sa&&oa.tlsExports.add(ma)}else if(pa===ta)for(var Na=qn();Na--;){Xn();var ma=Xn(),Ia=qn();(Ia&ca)==_a&&oa.weakImports.add(ma)}else I+=Sa}}return oa};function getValue(e,I="i8"){switch(I.endsWith("*")&&(I="*"),I){case"i1":return HEAP8[e];case"i8":return HEAP8[e];case"i16":return HEAP16[e>>1];case"i32":return HEAP32[e>>2];case"i64":return HEAP64[e>>3];case"float":return HEAPF32[e>>2];case"double":return HEAPF64[e>>3];case"*":return HEAPU32[e>>2];default:abort(`invalid type for getValue: ${I}`)}}var newDSO=(e,I,Hn)=>{var $n={refcount:1/0,name:e,exports:Hn,global:!0};return LDSO.loadedLibsByName[e]=$n,I!=null&&(LDSO.loadedLibsByHandle[I]=$n),$n},LDSO={loadedLibsByName:{},loadedLibsByHandle:{},init(){newDSO("__main__",0,wasmImports)}},___heap_base=23144432,alignMemory=(e,I)=>Math.ceil(e/I)*I,getMemory=e=>{if(runtimeInitialized)return _calloc(e,1);var I=___heap_base,Hn=I+alignMemory(e,16);return ___heap_base=Hn,GOT.__heap_base.value=Hn,I},isInternalSym=e=>["__cpp_exception","__c_longjmp","__wasm_apply_data_relocs","__dso_handle","__tls_size","__tls_align","__set_stack_limits","_emscripten_tls_init","__wasm_init_tls","__wasm_call_ctors","__start_em_asm","__stop_em_asm","__start_em_js","__stop_em_js"].includes(e)||e.startsWith("__em_js__"),uleb128Encode=(e,I)=>{e<128?I.push(e):I.push(e%128|128,e>>7)},sigToWasmTypes=e=>{for(var I={i:"i32",j:"i64",f:"f32",d:"f64",e:"externref",p:"i32"},Hn={parameters:[],results:e[0]=="v"?[]:[I[e[0]]]},$n=1;$n<e.length;++$n)Hn.parameters.push(I[e[$n]]);return Hn},generateFuncType=(e,I)=>{var Hn=e.slice(0,1),$n=e.slice(1),qn={i:127,p:127,j:126,f:125,d:124,e:111};I.push(96),uleb128Encode($n.length,I);for(var Xn=0;Xn<$n.length;++Xn)I.push(qn[$n[Xn]]);Hn=="v"?I.push(0):I.push(1,qn[Hn])},convertJsFunctionToWasm=(e,I)=>{if(typeof WebAssembly.Function=="function")return new WebAssembly.Function(sigToWasmTypes(I),e);var Hn=[1];generateFuncType(I,Hn);var $n=[0,97,115,109,1,0,0,0,1];uleb128Encode(Hn.length,$n),$n.push(...Hn),$n.push(2,7,1,1,101,1,102,0,0,7,5,1,1,102,0,0);var qn=new WebAssembly.Module(new Uint8Array($n)),Xn=new WebAssembly.Instance(qn,{e:{f:e}}),Yn=Xn.exports.f;return Yn},wasmTableMirror=[],wasmTable=new WebAssembly.Table({initial:5360,element:"anyfunc"}),getWasmTableEntry=e=>{var I=wasmTableMirror[e];return I||(e>=wasmTableMirror.length&&(wasmTableMirror.length=e+1),wasmTableMirror[e]=I=wasmTable.get(e)),I},updateTableMap=(e,I)=>{if(functionsInTableMap)for(var Hn=e;Hn<e+I;Hn++){var $n=getWasmTableEntry(Hn);$n&&functionsInTableMap.set($n,Hn)}},functionsInTableMap,getFunctionAddress=e=>(functionsInTableMap||(functionsInTableMap=new WeakMap,updateTableMap(0,wasmTable.length)),functionsInTableMap.get(e)||0),freeTableIndexes=[],getEmptyTableSlot=()=>{if(freeTableIndexes.length)return freeTableIndexes.pop();try{wasmTable.grow(1)}catch(e){throw e instanceof RangeError?"Unable to grow wasm table. Set ALLOW_TABLE_GROWTH.":e}return wasmTable.length-1},setWasmTableEntry=(e,I)=>{wasmTable.set(e,I),wasmTableMirror[e]=wasmTable.get(e)},addFunction=(e,I)=>{var Hn=getFunctionAddress(e);if(Hn)return Hn;var $n=getEmptyTableSlot();try{setWasmTableEntry($n,e)}catch(Xn){if(!(Xn instanceof TypeError))throw Xn;var qn=convertJsFunctionToWasm(e,I);setWasmTableEntry($n,qn)}return functionsInTableMap.set(e,$n),$n},updateGOT=(e,I)=>{for(var Hn in e)if(!isInternalSym(Hn)){var $n=e[Hn];GOT[Hn]||(GOT[Hn]=new WebAssembly.Global({value:"i32",mutable:!0})),GOT[Hn].value==0&&(typeof $n=="function"?GOT[Hn].value=addFunction($n):typeof $n=="number"?GOT[Hn].value=$n:err(`unhandled export type for '${Hn}': ${typeof $n}`))}},relocateExports=(e,I,Hn)=>{var $n={};for(var qn in e){var Xn=e[qn];typeof Xn=="object"&&(Xn=Xn.value),typeof Xn=="number"&&(Xn+=I),$n[qn]=Xn}return updateGOT($n),$n},isSymbolDefined=e=>{var I=wasmImports[e];return!(!I||I.stub)},dynCall=(e,I,Hn=[])=>{var $n=getWasmTableEntry(I)(...Hn);return $n},stackSave=()=>_emscripten_stack_get_current(),stackRestore=e=>__emscripten_stack_restore(e),createInvokeFunction=e=>(I,...Hn)=>{var $n=stackSave();try{return dynCall(e,I,Hn)}catch(qn){if(stackRestore($n),qn!==qn+0)throw qn;if(_setThrew(1,0),e[0]=="j")return 0n}},resolveGlobalSymbol=(e,I=!1)=>{var Hn;return isSymbolDefined(e)?Hn=wasmImports[e]:e.startsWith("invoke_")&&(Hn=wasmImports[e]=createInvokeFunction(e.split("_")[1])),{sym:Hn,name:e}},UTF8ToString=(e,I)=>e?UTF8ArrayToString(HEAPU8,e,I):"",loadWebAssemblyModule=(binary,flags,libName,localScope,handle)=>{var metadata=getDylinkMetadata(binary);currentModuleWeakSymbols=metadata.weakImports;function loadModule(){var firstLoad=!handle||!HEAP8[handle+8];if(firstLoad){var memAlign=Math.pow(2,metadata.memoryAlign),memoryBase=metadata.memorySize?alignMemory(getMemory(metadata.memorySize+memAlign),memAlign):0,tableBase=metadata.tableSize?wasmTable.length:0;handle&&(HEAP8[handle+8]=1,HEAPU32[handle+12>>2]=memoryBase,HEAP32[handle+16>>2]=metadata.memorySize,HEAPU32[handle+20>>2]=tableBase,HEAP32[handle+24>>2]=metadata.tableSize)}else memoryBase=HEAPU32[handle+12>>2],tableBase=HEAPU32[handle+20>>2];var tableGrowthNeeded=tableBase+metadata.tableSize-wasmTable.length;tableGrowthNeeded>0&&wasmTable.grow(tableGrowthNeeded);var moduleExports;function resolveSymbol(e){var I=resolveGlobalSymbol(e).sym;return!I&&localScope&&(I=localScope[e]),I||(I=moduleExports[e]),I}var proxyHandler={get(e,I){switch(I){case"__memory_base":return memoryBase;case"__table_base":return tableBase}if(I in wasmImports&&!wasmImports[I].stub)return wasmImports[I];if(!(I in e)){var Hn;e[I]=(...$n)=>(Hn||(Hn=resolveSymbol(I)),Hn(...$n))}return e[I]}},proxy=new Proxy({},proxyHandler),info={"GOT.mem":new Proxy({},GOTHandler),"GOT.func":new Proxy({},GOTHandler),env:proxy,wasi_snapshot_preview1:proxy};function postInstantiation(module,instance){updateTableMap(tableBase,metadata.tableSize),moduleExports=relocateExports(instance.exports,memoryBase),flags.allowUndefined||reportUndefinedSymbols();function addEmAsm(addr,body){for(var args=[],arity=0;arity<16&&body.indexOf("$"+arity)!=-1;arity++)args.push("$"+arity);args=args.join(",");var func=`(${args}) => { ${body} };`;ASM_CONSTS[start]=eval(func)}if("__start_em_asm"in moduleExports)for(var start=moduleExports.__start_em_asm,stop=moduleExports.__stop_em_asm;start<stop;){var jsString=UTF8ToString(start);addEmAsm(start,jsString),start=HEAPU8.indexOf(0,start)+1}function addEmJs(name,cSig,body){var jsArgs=[];if(cSig=cSig.slice(1,-1),cSig!="void"){cSig=cSig.split(",");for(var i in cSig){var jsArg=cSig[i].split(" ").pop();jsArgs.push(jsArg.replaceAll("*",""))}}var func=`(${jsArgs}) => ${body};`;moduleExports[name]=eval(func)}for(var name in moduleExports)if(name.startsWith("__em_js__")){var start=moduleExports[name],jsString=UTF8ToString(start),parts=jsString.split("<::>");addEmJs(name.replace("__em_js__",""),parts[0],parts[1]),delete moduleExports[name]}var applyRelocs=moduleExports.__wasm_apply_data_relocs;applyRelocs&&(runtimeInitialized?applyRelocs():__RELOC_FUNCS__.push(applyRelocs));var init=moduleExports.__wasm_call_ctors;return init&&(runtimeInitialized?init():__ATINIT__.push(init)),moduleExports}if(flags.loadAsync){if(binary instanceof WebAssembly.Module){var instance=new WebAssembly.Instance(binary,info);return Promise.resolve(postInstantiation(binary,instance))}return WebAssembly.instantiate(binary,info).then(e=>postInstantiation(e.module,e.instance))}var module=binary instanceof WebAssembly.Module?binary:new WebAssembly.Module(binary),instance=new WebAssembly.Instance(module,info);return postInstantiation(module,instance)}return flags.loadAsync?metadata.neededDynlibs.reduce((e,I)=>e.then(()=>loadDynamicLibrary(I,flags,localScope)),Promise.resolve()).then(loadModule):(metadata.neededDynlibs.forEach(e=>loadDynamicLibrary(e,flags,localScope)),loadModule())},mergeLibSymbols=(e,I)=>{for(var[Hn,$n]of Object.entries(e)){let qn=Yn=>{isSymbolDefined(Yn)||(wasmImports[Yn]=$n)};qn(Hn);let Xn="__main_argc_argv";Hn=="main"&&qn(Xn),Hn==Xn&&qn("main")}},asyncLoad=async e=>{var I=await readAsync(e);return new Uint8Array(I)},preloadPlugins=Module.preloadPlugins||[],registerWasmPlugin=()=>{var e={promiseChainEnd:Promise.resolve(),canHandle:I=>!Module.noWasmDecoding&&I.endsWith(".so"),handle:(I,Hn,$n,qn)=>{e.promiseChainEnd=e.promiseChainEnd.then(()=>loadWebAssemblyModule(I,{loadAsync:!0,nodelete:!0},Hn,{})).then(Xn=>{preloadedWasm[Hn]=Xn,$n(I)},Xn=>{err(`failed to instantiate wasm: ${Hn}: ${Xn}`),qn()})}};preloadPlugins.push(e)},preloadedWasm={};function loadDynamicLibrary(e,I={global:!0,nodelete:!0},Hn,$n){var qn=LDSO.loadedLibsByName[e];if(qn)return I.global?qn.global||(qn.global=!0,mergeLibSymbols(qn.exports)):Hn&&Object.assign(Hn,qn.exports),I.nodelete&&qn.refcount!==1/0&&(qn.refcount=1/0),qn.refcount++,$n&&(LDSO.loadedLibsByHandle[$n]=qn),I.loadAsync?Promise.resolve(!0):!0;qn=newDSO(e,$n,"loading"),qn.refcount=I.nodelete?1/0:1,qn.global=I.global;function Xn(){if($n){var Jn=HEAPU32[$n+28>>2],Zn=HEAPU32[$n+32>>2];if(Jn&&Zn){var ea=HEAP8.slice(Jn,Jn+Zn);return I.loadAsync?Promise.resolve(ea):ea}}var aa=locateFile(e);if(I.loadAsync)return asyncLoad(aa);if(!readBinary)throw new Error(`${aa}: file not found, and synchronous loading of external files is not available`);return readBinary(aa)}function Yn(){var Jn=preloadedWasm[e];return Jn?I.loadAsync?Promise.resolve(Jn):Jn:I.loadAsync?Xn().then(Zn=>loadWebAssemblyModule(Zn,I,e,Hn,$n)):loadWebAssemblyModule(Xn(),I,e,Hn,$n)}function Kn(Jn){qn.global?mergeLibSymbols(Jn):Hn&&Object.assign(Hn,Jn),qn.exports=Jn}return I.loadAsync?Yn().then(Jn=>(Kn(Jn),!0)):(Kn(Yn()),!0)}var reportUndefinedSymbols=()=>{for(var[e,I]of Object.entries(GOT))if(I.value==0){var Hn=resolveGlobalSymbol(e,!0).sym;if(!Hn&&!I.required)continue;if(typeof Hn=="function")I.value=addFunction(Hn,Hn.sig);else if(typeof Hn=="number")I.value=Hn;else throw new Error(`bad export type for '${e}': ${typeof Hn}`)}},loadDylibs=()=>{if(!dynamicLibraries.length){reportUndefinedSymbols();return}addRunDependency(),dynamicLibraries.reduce((e,I)=>e.then(()=>loadDynamicLibrary(I,{loadAsync:!0,global:!0,nodelete:!0,allowUndefined:!0})),Promise.resolve()).then(()=>{reportUndefinedSymbols(),removeRunDependency()})},noExitRuntime=Module.noExitRuntime||!0;function setValue(e,I,Hn="i8"){switch(Hn.endsWith("*")&&(Hn="*"),Hn){case"i1":HEAP8[e]=I;break;case"i8":HEAP8[e]=I;break;case"i16":HEAP16[e>>1]=I;break;case"i32":HEAP32[e>>2]=I;break;case"i64":HEAP64[e>>3]=BigInt(I);break;case"float":HEAPF32[e>>2]=I;break;case"double":HEAPF64[e>>3]=I;break;case"*":HEAPU32[e>>2]=I;break;default:abort(`invalid type for setValue: ${Hn}`)}}var ___assert_fail=(e,I,Hn,$n)=>abort(`Assertion failed: ${UTF8ToString(e)}, at: `+[I?UTF8ToString(I):"unknown filename",Hn,$n?UTF8ToString($n):"unknown function"]);___assert_fail.sig="vppip";var ___call_sighandler=(e,I)=>getWasmTableEntry(e)(I);___call_sighandler.sig="vpi";var ___memory_base=new WebAssembly.Global({value:"i32",mutable:!1},16777216),___stack_pointer=new WebAssembly.Global({value:"i32",mutable:!0},23144432),PATH={isAbs:e=>e.charAt(0)==="/",splitPath:e=>{var I=/^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;return I.exec(e).slice(1)},normalizeArray:(e,I)=>{for(var Hn=0,$n=e.length-1;$n>=0;$n--){var qn=e[$n];qn==="."?e.splice($n,1):qn===".."?(e.splice($n,1),Hn++):Hn&&(e.splice($n,1),Hn--)}if(I)for(;Hn;Hn--)e.unshift("..");return e},normalize:e=>{var I=PATH.isAbs(e),Hn=e.substr(-1)==="/";return e=PATH.normalizeArray(e.split("/").filter($n=>!!$n),!I).join("/"),!e&&!I&&(e="."),e&&Hn&&(e+="/"),(I?"/":"")+e},dirname:e=>{var I=PATH.splitPath(e),Hn=I[0],$n=I[1];return!Hn&&!$n?".":($n&&($n=$n.substr(0,$n.length-1)),Hn+$n)},basename:e=>{if(e==="/")return"/";e=PATH.normalize(e),e=e.replace(/\/$/,"");var I=e.lastIndexOf("/");return I===-1?e:e.substr(I+1)},join:(...e)=>PATH.normalize(e.join("/")),join2:(e,I)=>PATH.normalize(e+"/"+I)},initRandomFill=()=>{if(typeof crypto=="object"&&typeof crypto.getRandomValues=="function")return $n=>crypto.getRandomValues($n);if(ENVIRONMENT_IS_NODE)try{var e=require("crypto"),I=e.randomFillSync;if(I)return $n=>e.randomFillSync($n);var Hn=e.randomBytes;return $n=>($n.set(Hn($n.byteLength)),$n)}catch{}abort("initRandomDevice")},randomFill=e=>(randomFill=initRandomFill())(e),PATH_FS={resolve:(...e)=>{for(var I="",Hn=!1,$n=e.length-1;$n>=-1&&!Hn;$n--){var qn=$n>=0?e[$n]:FS.cwd();if(typeof qn!="string")throw new TypeError("Arguments to path.resolve must be strings");if(!qn)return"";I=qn+"/"+I,Hn=PATH.isAbs(qn)}return I=PATH.normalizeArray(I.split("/").filter(Xn=>!!Xn),!Hn).join("/"),(Hn?"/":"")+I||"."},relative:(e,I)=>{e=PATH_FS.resolve(e).substr(1),I=PATH_FS.resolve(I).substr(1);function Hn(Zn){for(var ea=0;ea<Zn.length&&Zn[ea]==="";ea++);for(var aa=Zn.length-1;aa>=0&&Zn[aa]==="";aa--);return ea>aa?[]:Zn.slice(ea,aa-ea+1)}for(var $n=Hn(e.split("/")),qn=Hn(I.split("/")),Xn=Math.min($n.length,qn.length),Yn=Xn,Kn=0;Kn<Xn;Kn++)if($n[Kn]!==qn[Kn]){Yn=Kn;break}for(var Jn=[],Kn=Yn;Kn<$n.length;Kn++)Jn.push("..");return Jn=Jn.concat(qn.slice(Yn)),Jn.join("/")}},FS_stdin_getChar_buffer=[],lengthBytesUTF8=e=>{for(var I=0,Hn=0;Hn<e.length;++Hn){var $n=e.charCodeAt(Hn);$n<=127?I++:$n<=2047?I+=2:$n>=55296&&$n<=57343?(I+=4,++Hn):I+=3}return I},stringToUTF8Array=(e,I,Hn,$n)=>{if(!($n>0))return 0;for(var qn=Hn,Xn=Hn+$n-1,Yn=0;Yn<e.length;++Yn){var Kn=e.charCodeAt(Yn);if(Kn>=55296&&Kn<=57343){var Jn=e.charCodeAt(++Yn);Kn=65536+((Kn&1023)<<10)|Jn&1023}if(Kn<=127){if(Hn>=Xn)break;I[Hn++]=Kn}else if(Kn<=2047){if(Hn+1>=Xn)break;I[Hn++]=192|Kn>>6,I[Hn++]=128|Kn&63}else if(Kn<=65535){if(Hn+2>=Xn)break;I[Hn++]=224|Kn>>12,I[Hn++]=128|Kn>>6&63,I[Hn++]=128|Kn&63}else{if(Hn+3>=Xn)break;I[Hn++]=240|Kn>>18,I[Hn++]=128|Kn>>12&63,I[Hn++]=128|Kn>>6&63,I[Hn++]=128|Kn&63}}return I[Hn]=0,Hn-qn};function intArrayFromString(e,I,Hn){var $n=lengthBytesUTF8(e)+1,qn=new Array($n),Xn=stringToUTF8Array(e,qn,0,qn.length);return qn.length=Xn,qn}var FS_stdin_getChar=()=>{if(!FS_stdin_getChar_buffer.length){var e=null;if(ENVIRONMENT_IS_NODE){var I=256,Hn=Buffer.alloc(I),$n=0,qn=process.stdin.fd;try{$n=fs.readSync(qn,Hn,0,I)}catch(Xn){if(Xn.toString().includes("EOF"))$n=0;else throw Xn}$n>0&&(e=Hn.slice(0,$n).toString("utf-8"))}else typeof window<"u"&&typeof window.prompt=="function"&&(e=window.prompt("Input: "),e!==null&&(e+=`
`));if(!e)return null;FS_stdin_getChar_buffer=intArrayFromString(e)}return FS_stdin_getChar_buffer.shift()},TTY={ttys:[],init(){},shutdown(){},register(e,I){TTY.ttys[e]={input:[],output:[],ops:I},FS.registerDevice(e,TTY.stream_ops)},stream_ops:{open(e){var I=TTY.ttys[e.node.rdev];if(!I)throw new FS.ErrnoError(43);e.tty=I,e.seekable=!1},close(e){e.tty.ops.fsync(e.tty)},fsync(e){e.tty.ops.fsync(e.tty)},read(e,I,Hn,$n,qn){if(!e.tty||!e.tty.ops.get_char)throw new FS.ErrnoError(60);for(var Xn=0,Yn=0;Yn<$n;Yn++){var Kn;try{Kn=e.tty.ops.get_char(e.tty)}catch{throw new FS.ErrnoError(29)}if(Kn===void 0&&Xn===0)throw new FS.ErrnoError(6);if(Kn==null)break;Xn++,I[Hn+Yn]=Kn}return Xn&&(e.node.atime=Date.now()),Xn},write(e,I,Hn,$n,qn){if(!e.tty||!e.tty.ops.put_char)throw new FS.ErrnoError(60);try{for(var Xn=0;Xn<$n;Xn++)e.tty.ops.put_char(e.tty,I[Hn+Xn])}catch{throw new FS.ErrnoError(29)}return $n&&(e.node.mtime=e.node.ctime=Date.now()),Xn}},default_tty_ops:{get_char(e){return FS_stdin_getChar()},put_char(e,I){I===null||I===10?(out(UTF8ArrayToString(e.output)),e.output=[]):I!=0&&e.output.push(I)},fsync(e){e.output&&e.output.length>0&&(out(UTF8ArrayToString(e.output)),e.output=[])},ioctl_tcgets(e){return{c_iflag:25856,c_oflag:5,c_cflag:191,c_lflag:35387,c_cc:[3,28,127,21,4,0,1,0,17,19,26,0,18,15,23,22,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}},ioctl_tcsets(e,I,Hn){return 0},ioctl_tiocgwinsz(e){return[24,80]}},default_tty1_ops:{put_char(e,I){I===null||I===10?(err(UTF8ArrayToString(e.output)),e.output=[]):I!=0&&e.output.push(I)},fsync(e){e.output&&e.output.length>0&&(err(UTF8ArrayToString(e.output)),e.output=[])}}},zeroMemory=(e,I)=>{HEAPU8.fill(0,e,e+I)},mmapAlloc=e=>{e=alignMemory(e,65536);var I=_emscripten_builtin_memalign(65536,e);return I&&zeroMemory(I,e),I},MEMFS={ops_table:null,mount(e){return MEMFS.createNode(null,"/",16895,0)},createNode(e,I,Hn,$n){if(FS.isBlkdev(Hn)||FS.isFIFO(Hn))throw new FS.ErrnoError(63);MEMFS.ops_table||(MEMFS.ops_table={dir:{node:{getattr:MEMFS.node_ops.getattr,setattr:MEMFS.node_ops.setattr,lookup:MEMFS.node_ops.lookup,mknod:MEMFS.node_ops.mknod,rename:MEMFS.node_ops.rename,unlink:MEMFS.node_ops.unlink,rmdir:MEMFS.node_ops.rmdir,readdir:MEMFS.node_ops.readdir,symlink:MEMFS.node_ops.symlink},stream:{llseek:MEMFS.stream_ops.llseek}},file:{node:{getattr:MEMFS.node_ops.getattr,setattr:MEMFS.node_ops.setattr},stream:{llseek:MEMFS.stream_ops.llseek,read:MEMFS.stream_ops.read,write:MEMFS.stream_ops.write,allocate:MEMFS.stream_ops.allocate,mmap:MEMFS.stream_ops.mmap,msync:MEMFS.stream_ops.msync}},link:{node:{getattr:MEMFS.node_ops.getattr,setattr:MEMFS.node_ops.setattr,readlink:MEMFS.node_ops.readlink},stream:{}},chrdev:{node:{getattr:MEMFS.node_ops.getattr,setattr:MEMFS.node_ops.setattr},stream:FS.chrdev_stream_ops}});var qn=FS.createNode(e,I,Hn,$n);return FS.isDir(qn.mode)?(qn.node_ops=MEMFS.ops_table.dir.node,qn.stream_ops=MEMFS.ops_table.dir.stream,qn.contents={}):FS.isFile(qn.mode)?(qn.node_ops=MEMFS.ops_table.file.node,qn.stream_ops=MEMFS.ops_table.file.stream,qn.usedBytes=0,qn.contents=null):FS.isLink(qn.mode)?(qn.node_ops=MEMFS.ops_table.link.node,qn.stream_ops=MEMFS.ops_table.link.stream):FS.isChrdev(qn.mode)&&(qn.node_ops=MEMFS.ops_table.chrdev.node,qn.stream_ops=MEMFS.ops_table.chrdev.stream),qn.atime=qn.mtime=qn.ctime=Date.now(),e&&(e.contents[I]=qn,e.atime=e.mtime=e.ctime=qn.atime),qn},getFileDataAsTypedArray(e){return e.contents?e.contents.subarray?e.contents.subarray(0,e.usedBytes):new Uint8Array(e.contents):new Uint8Array(0)},expandFileStorage(e,I){var Hn=e.contents?e.contents.length:0;if(!(Hn>=I)){var $n=1048576;I=Math.max(I,Hn*(Hn<$n?2:1.125)>>>0),Hn!=0&&(I=Math.max(I,256));var qn=e.contents;e.contents=new Uint8Array(I),e.usedBytes>0&&e.contents.set(qn.subarray(0,e.usedBytes),0)}},resizeFileStorage(e,I){if(e.usedBytes!=I)if(I==0)e.contents=null,e.usedBytes=0;else{var Hn=e.contents;e.contents=new Uint8Array(I),Hn&&e.contents.set(Hn.subarray(0,Math.min(I,e.usedBytes))),e.usedBytes=I}},node_ops:{getattr(e){var I={};return I.dev=FS.isChrdev(e.mode)?e.id:1,I.ino=e.id,I.mode=e.mode,I.nlink=1,I.uid=0,I.gid=0,I.rdev=e.rdev,FS.isDir(e.mode)?I.size=4096:FS.isFile(e.mode)?I.size=e.usedBytes:FS.isLink(e.mode)?I.size=e.link.length:I.size=0,I.atime=new Date(e.atime),I.mtime=new Date(e.mtime),I.ctime=new Date(e.ctime),I.blksize=4096,I.blocks=Math.ceil(I.size/I.blksize),I},setattr(e,I){for(let Hn of["mode","atime","mtime","ctime"])I[Hn]&&(e[Hn]=I[Hn]);I.size!==void 0&&MEMFS.resizeFileStorage(e,I.size)},lookup(e,I){throw MEMFS.doesNotExistError},mknod(e,I,Hn,$n){return MEMFS.createNode(e,I,Hn,$n)},rename(e,I,Hn){var $n;try{$n=FS.lookupNode(I,Hn)}catch{}if($n){if(FS.isDir(e.mode))for(var qn in $n.contents)throw new FS.ErrnoError(55);FS.hashRemoveNode($n)}delete e.parent.contents[e.name],I.contents[Hn]=e,e.name=Hn,I.ctime=I.mtime=e.parent.ctime=e.parent.mtime=Date.now()},unlink(e,I){delete e.contents[I],e.ctime=e.mtime=Date.now()},rmdir(e,I){var Hn=FS.lookupNode(e,I);for(var $n in Hn.contents)throw new FS.ErrnoError(55);delete e.contents[I],e.ctime=e.mtime=Date.now()},readdir(e){return[".","..",...Object.keys(e.contents)]},symlink(e,I,Hn){var $n=MEMFS.createNode(e,I,41471,0);return $n.link=Hn,$n},readlink(e){if(!FS.isLink(e.mode))throw new FS.ErrnoError(28);return e.link}},stream_ops:{read(e,I,Hn,$n,qn){var Xn=e.node.contents;if(qn>=e.node.usedBytes)return 0;var Yn=Math.min(e.node.usedBytes-qn,$n);if(Yn>8&&Xn.subarray)I.set(Xn.subarray(qn,qn+Yn),Hn);else for(var Kn=0;Kn<Yn;Kn++)I[Hn+Kn]=Xn[qn+Kn];return Yn},write(e,I,Hn,$n,qn,Xn){if(I.buffer===HEAP8.buffer&&(Xn=!1),!$n)return 0;var Yn=e.node;if(Yn.mtime=Yn.ctime=Date.now(),I.subarray&&(!Yn.contents||Yn.contents.subarray)){if(Xn)return Yn.contents=I.subarray(Hn,Hn+$n),Yn.usedBytes=$n,$n;if(Yn.usedBytes===0&&qn===0)return Yn.contents=I.slice(Hn,Hn+$n),Yn.usedBytes=$n,$n;if(qn+$n<=Yn.usedBytes)return Yn.contents.set(I.subarray(Hn,Hn+$n),qn),$n}if(MEMFS.expandFileStorage(Yn,qn+$n),Yn.contents.subarray&&I.subarray)Yn.contents.set(I.subarray(Hn,Hn+$n),qn);else for(var Kn=0;Kn<$n;Kn++)Yn.contents[qn+Kn]=I[Hn+Kn];return Yn.usedBytes=Math.max(Yn.usedBytes,qn+$n),$n},llseek(e,I,Hn){var $n=I;if(Hn===1?$n+=e.position:Hn===2&&FS.isFile(e.node.mode)&&($n+=e.node.usedBytes),$n<0)throw new FS.ErrnoError(28);return $n},allocate(e,I,Hn){MEMFS.expandFileStorage(e.node,I+Hn),e.node.usedBytes=Math.max(e.node.usedBytes,I+Hn)},mmap(e,I,Hn,$n,qn){if(!FS.isFile(e.node.mode))throw new FS.ErrnoError(43);var Xn,Yn,Kn=e.node.contents;if(!(qn&2)&&Kn&&Kn.buffer===HEAP8.buffer)Yn=!1,Xn=Kn.byteOffset;else{if(Yn=!0,Xn=mmapAlloc(I),!Xn)throw new FS.ErrnoError(48);Kn&&((Hn>0||Hn+I<Kn.length)&&(Kn.subarray?Kn=Kn.subarray(Hn,Hn+I):Kn=Array.prototype.slice.call(Kn,Hn,Hn+I)),HEAP8.set(Kn,Xn))}return{ptr:Xn,allocated:Yn}},msync(e,I,Hn,$n,qn){return MEMFS.stream_ops.write(e,I,0,$n,Hn,!1),0}}},FS_createDataFile=(e,I,Hn,$n,qn,Xn)=>{FS.createDataFile(e,I,Hn,$n,qn,Xn)},FS_handledByPreloadPlugin=(e,I,Hn,$n)=>{typeof Browser<"u"&&Browser.init();var qn=!1;return preloadPlugins.forEach(Xn=>{qn||Xn.canHandle(I)&&(Xn.handle(e,I,Hn,$n),qn=!0)}),qn},FS_createPreloadedFile=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn)=>{var ea=I?PATH_FS.resolve(PATH.join2(e,I)):e;function aa(oa){function la(ra){Zn?.(),Kn||FS_createDataFile(e,I,ra,$n,qn,Jn),Xn?.(),removeRunDependency()}FS_handledByPreloadPlugin(oa,ea,la,()=>{Yn?.(),removeRunDependency()})||la(oa)}addRunDependency(),typeof Hn=="string"?asyncLoad(Hn).then(aa,Yn):aa(Hn)},FS_modeStringToFlags=e=>{var I={r:0,"r+":2,w:577,"w+":578,a:1089,"a+":1090},Hn=I[e];if(typeof Hn>"u")throw new Error(`Unknown file open mode: ${e}`);return Hn},FS_getMode=(e,I)=>{var Hn=0;return e&&(Hn|=365),I&&(Hn|=146),Hn},IDBFS={dbs:{},indexedDB:()=>{if(typeof indexedDB<"u")return indexedDB;var e=null;return typeof window=="object"&&(e=window.indexedDB||window.mozIndexedDB||window.webkitIndexedDB||window.msIndexedDB),e},DB_VERSION:21,DB_STORE_NAME:"FILE_DATA",queuePersist:e=>{function I(){e.idbPersistState==="again"?Hn():e.idbPersistState=0}function Hn(){e.idbPersistState="idb",IDBFS.syncfs(e,!1,I)}e.idbPersistState?e.idbPersistState==="idb"&&(e.idbPersistState="again"):e.idbPersistState=setTimeout(Hn,0)},mount:e=>{var I=MEMFS.mount(e);if(e?.opts?.autoPersist){I.idbPersistState=0;var Hn=I.node_ops;I.node_ops=Object.assign({},I.node_ops),I.node_ops.mknod=($n,qn,Xn,Yn)=>{var Kn=Hn.mknod($n,qn,Xn,Yn);return Kn.node_ops=I.node_ops,Kn.idbfs_mount=I.mount,Kn.memfs_stream_ops=Kn.stream_ops,Kn.stream_ops=Object.assign({},Kn.stream_ops),Kn.stream_ops.write=(Jn,Zn,ea,aa,oa,la)=>(Jn.node.isModified=!0,Kn.memfs_stream_ops.write(Jn,Zn,ea,aa,oa,la)),Kn.stream_ops.close=Jn=>{var Zn=Jn.node;if(Zn.isModified&&(IDBFS.queuePersist(Zn.idbfs_mount),Zn.isModified=!1),Zn.memfs_stream_ops.close)return Zn.memfs_stream_ops.close(Jn)},Kn},I.node_ops.mkdir=(...$n)=>(IDBFS.queuePersist(I.mount),Hn.mkdir(...$n)),I.node_ops.rmdir=(...$n)=>(IDBFS.queuePersist(I.mount),Hn.rmdir(...$n)),I.node_ops.symlink=(...$n)=>(IDBFS.queuePersist(I.mount),Hn.symlink(...$n)),I.node_ops.unlink=(...$n)=>(IDBFS.queuePersist(I.mount),Hn.unlink(...$n)),I.node_ops.rename=(...$n)=>(IDBFS.queuePersist(I.mount),Hn.rename(...$n))}return I},syncfs:(e,I,Hn)=>{IDBFS.getLocalSet(e,($n,qn)=>{if($n)return Hn($n);IDBFS.getRemoteSet(e,(Xn,Yn)=>{if(Xn)return Hn(Xn);var Kn=I?Yn:qn,Jn=I?qn:Yn;IDBFS.reconcile(Kn,Jn,Hn)})})},quit:()=>{Object.values(IDBFS.dbs).forEach(e=>e.close()),IDBFS.dbs={}},getDB:(e,I)=>{var Hn=IDBFS.dbs[e];if(Hn)return I(null,Hn);var $n;try{$n=IDBFS.indexedDB().open(e,IDBFS.DB_VERSION)}catch(qn){return I(qn)}if(!$n)return I("Unable to connect to IndexedDB");$n.onupgradeneeded=qn=>{var Xn=qn.target.result,Yn=qn.target.transaction,Kn;Xn.objectStoreNames.contains(IDBFS.DB_STORE_NAME)?Kn=Yn.objectStore(IDBFS.DB_STORE_NAME):Kn=Xn.createObjectStore(IDBFS.DB_STORE_NAME),Kn.indexNames.contains("timestamp")||Kn.createIndex("timestamp","timestamp",{unique:!1})},$n.onsuccess=()=>{Hn=$n.result,IDBFS.dbs[e]=Hn,I(null,Hn)},$n.onerror=qn=>{I(qn.target.error),qn.preventDefault()}},getLocalSet:(e,I)=>{var Hn={};function $n(Jn){return Jn!=="."&&Jn!==".."}function qn(Jn){return Zn=>PATH.join2(Jn,Zn)}for(var Xn=FS.readdir(e.mountpoint).filter($n).map(qn(e.mountpoint));Xn.length;){var Yn=Xn.pop(),Kn;try{Kn=FS.stat(Yn)}catch(Jn){return I(Jn)}FS.isDir(Kn.mode)&&Xn.push(...FS.readdir(Yn).filter($n).map(qn(Yn))),Hn[Yn]={timestamp:Kn.mtime}}return I(null,{type:"local",entries:Hn})},getRemoteSet:(e,I)=>{var Hn={};IDBFS.getDB(e.mountpoint,($n,qn)=>{if($n)return I($n);try{var Xn=qn.transaction([IDBFS.DB_STORE_NAME],"readonly");Xn.onerror=Jn=>{I(Jn.target.error),Jn.preventDefault()};var Yn=Xn.objectStore(IDBFS.DB_STORE_NAME),Kn=Yn.index("timestamp");Kn.openKeyCursor().onsuccess=Jn=>{var Zn=Jn.target.result;if(!Zn)return I(null,{type:"remote",db:qn,entries:Hn});Hn[Zn.primaryKey]={timestamp:Zn.key},Zn.continue()}}catch(Jn){return I(Jn)}})},loadLocalEntry:(e,I)=>{var Hn,$n;try{var qn=FS.lookupPath(e);$n=qn.node,Hn=FS.stat(e)}catch(Xn){return I(Xn)}return FS.isDir(Hn.mode)?I(null,{timestamp:Hn.mtime,mode:Hn.mode}):FS.isFile(Hn.mode)?($n.contents=MEMFS.getFileDataAsTypedArray($n),I(null,{timestamp:Hn.mtime,mode:Hn.mode,contents:$n.contents})):I(new Error("node type not supported"))},storeLocalEntry:(e,I,Hn)=>{try{if(FS.isDir(I.mode))FS.mkdirTree(e,I.mode);else if(FS.isFile(I.mode))FS.writeFile(e,I.contents,{canOwn:!0});else return Hn(new Error("node type not supported"));FS.chmod(e,I.mode),FS.utime(e,I.timestamp,I.timestamp)}catch($n){return Hn($n)}Hn(null)},removeLocalEntry:(e,I)=>{try{var Hn=FS.stat(e);FS.isDir(Hn.mode)?FS.rmdir(e):FS.isFile(Hn.mode)&&FS.unlink(e)}catch($n){return I($n)}I(null)},loadRemoteEntry:(e,I,Hn)=>{var $n=e.get(I);$n.onsuccess=qn=>Hn(null,qn.target.result),$n.onerror=qn=>{Hn(qn.target.error),qn.preventDefault()}},storeRemoteEntry:(e,I,Hn,$n)=>{try{var qn=e.put(Hn,I)}catch(Xn){$n(Xn);return}qn.onsuccess=Xn=>$n(),qn.onerror=Xn=>{$n(Xn.target.error),Xn.preventDefault()}},removeRemoteEntry:(e,I,Hn)=>{var $n=e.delete(I);$n.onsuccess=qn=>Hn(),$n.onerror=qn=>{Hn(qn.target.error),qn.preventDefault()}},reconcile:(e,I,Hn)=>{var $n=0,qn=[];Object.keys(e.entries).forEach(aa=>{var oa=e.entries[aa],la=I.entries[aa];(!la||oa.timestamp.getTime()!=la.timestamp.getTime())&&(qn.push(aa),$n++)});var Xn=[];if(Object.keys(I.entries).forEach(aa=>{e.entries[aa]||(Xn.push(aa),$n++)}),!$n)return Hn(null);var Yn=!1,Kn=e.type==="remote"?e.db:I.db,Jn=Kn.transaction([IDBFS.DB_STORE_NAME],"readwrite"),Zn=Jn.objectStore(IDBFS.DB_STORE_NAME);function ea(aa){if(aa&&!Yn)return Yn=!0,Hn(aa)}Jn.onerror=Jn.onabort=aa=>{ea(aa.target.error),aa.preventDefault()},Jn.oncomplete=aa=>{Yn||Hn(null)},qn.sort().forEach(aa=>{I.type==="local"?IDBFS.loadRemoteEntry(Zn,aa,(oa,la)=>{if(oa)return ea(oa);IDBFS.storeLocalEntry(aa,la,ea)}):IDBFS.loadLocalEntry(aa,(oa,la)=>{if(oa)return ea(oa);IDBFS.storeRemoteEntry(Zn,aa,la,ea)})}),Xn.sort().reverse().forEach(aa=>{I.type==="local"?IDBFS.removeLocalEntry(aa,ea):IDBFS.removeRemoteEntry(Zn,aa,ea)})}},ERRNO_CODES={EPERM:63,ENOENT:44,ESRCH:71,EINTR:27,EIO:29,ENXIO:60,E2BIG:1,ENOEXEC:45,EBADF:8,ECHILD:12,EAGAIN:6,EWOULDBLOCK:6,ENOMEM:48,EACCES:2,EFAULT:21,ENOTBLK:105,EBUSY:10,EEXIST:20,EXDEV:75,ENODEV:43,ENOTDIR:54,EISDIR:31,EINVAL:28,ENFILE:41,EMFILE:33,ENOTTY:59,ETXTBSY:74,EFBIG:22,ENOSPC:51,ESPIPE:70,EROFS:69,EMLINK:34,EPIPE:64,EDOM:18,ERANGE:68,ENOMSG:49,EIDRM:24,ECHRNG:106,EL2NSYNC:156,EL3HLT:107,EL3RST:108,ELNRNG:109,EUNATCH:110,ENOCSI:111,EL2HLT:112,EDEADLK:16,ENOLCK:46,EBADE:113,EBADR:114,EXFULL:115,ENOANO:104,EBADRQC:103,EBADSLT:102,EDEADLOCK:16,EBFONT:101,ENOSTR:100,ENODATA:116,ETIME:117,ENOSR:118,ENONET:119,ENOPKG:120,EREMOTE:121,ENOLINK:47,EADV:122,ESRMNT:123,ECOMM:124,EPROTO:65,EMULTIHOP:36,EDOTDOT:125,EBADMSG:9,ENOTUNIQ:126,EBADFD:127,EREMCHG:128,ELIBACC:129,ELIBBAD:130,ELIBSCN:131,ELIBMAX:132,ELIBEXEC:133,ENOSYS:52,ENOTEMPTY:55,ENAMETOOLONG:37,ELOOP:32,EOPNOTSUPP:138,EPFNOSUPPORT:139,ECONNRESET:15,ENOBUFS:42,EAFNOSUPPORT:5,EPROTOTYPE:67,ENOTSOCK:57,ENOPROTOOPT:50,ESHUTDOWN:140,ECONNREFUSED:14,EADDRINUSE:3,ECONNABORTED:13,ENETUNREACH:40,ENETDOWN:38,ETIMEDOUT:73,EHOSTDOWN:142,EHOSTUNREACH:23,EINPROGRESS:26,EALREADY:7,EDESTADDRREQ:17,EMSGSIZE:35,EPROTONOSUPPORT:66,ESOCKTNOSUPPORT:137,EADDRNOTAVAIL:4,ENETRESET:39,EISCONN:30,ENOTCONN:53,ETOOMANYREFS:141,EUSERS:136,EDQUOT:19,ESTALE:72,ENOTSUP:138,ENOMEDIUM:148,EILSEQ:25,EOVERFLOW:61,ECANCELED:11,ENOTRECOVERABLE:56,EOWNERDEAD:62,ESTRPIPE:135},NODEFS={isWindows:!1,staticInit(){NODEFS.isWindows=!!process.platform.match(/^win/);var e=process.binding("constants");e.fs&&(e=e.fs),NODEFS.flagsForNodeMap={1024:e.O_APPEND,64:e.O_CREAT,128:e.O_EXCL,256:e.O_NOCTTY,0:e.O_RDONLY,2:e.O_RDWR,4096:e.O_SYNC,512:e.O_TRUNC,1:e.O_WRONLY,131072:e.O_NOFOLLOW}},convertNodeCode(e){var I=e.code;return ERRNO_CODES[I]},tryFSOperation(e){try{return e()}catch(I){throw I.code?I.code==="UNKNOWN"?new FS.ErrnoError(28):new FS.ErrnoError(NODEFS.convertNodeCode(I)):I}},mount(e){return NODEFS.createNode(null,"/",NODEFS.getMode(e.opts.root),0)},createNode(e,I,Hn,$n){if(!FS.isDir(Hn)&&!FS.isFile(Hn)&&!FS.isLink(Hn))throw new FS.ErrnoError(28);var qn=FS.createNode(e,I,Hn);return qn.node_ops=NODEFS.node_ops,qn.stream_ops=NODEFS.stream_ops,qn},getMode(e){return NODEFS.tryFSOperation(()=>{var I=fs.lstatSync(e).mode;return NODEFS.isWindows&&(I|=(I&292)>>2),I})},realPath(e){for(var I=[];e.parent!==e;)I.push(e.name),e=e.parent;return I.push(e.mount.opts.root),I.reverse(),PATH.join(...I)},flagsForNode(e){e&=-2097153,e&=-2049,e&=-32769,e&=-524289,e&=-65537;var I=0;for(var Hn in NODEFS.flagsForNodeMap)e&Hn&&(I|=NODEFS.flagsForNodeMap[Hn],e^=Hn);if(e)throw new FS.ErrnoError(28);return I},node_ops:{getattr(e){var I=NODEFS.realPath(e),Hn;return NODEFS.tryFSOperation(()=>Hn=fs.lstatSync(I)),NODEFS.isWindows&&(Hn.blksize||(Hn.blksize=4096),Hn.blocks||(Hn.blocks=(Hn.size+Hn.blksize-1)/Hn.blksize|0),Hn.mode|=(Hn.mode&292)>>2),{dev:Hn.dev,ino:Hn.ino,mode:Hn.mode,nlink:Hn.nlink,uid:Hn.uid,gid:Hn.gid,rdev:Hn.rdev,size:Hn.size,atime:Hn.atime,mtime:Hn.mtime,ctime:Hn.ctime,blksize:Hn.blksize,blocks:Hn.blocks}},setattr(e,I){var Hn=NODEFS.realPath(e);NODEFS.tryFSOperation(()=>{if(I.mode!==void 0){var $n=I.mode;NODEFS.isWindows&&($n&=384),fs.chmodSync(Hn,$n),e.mode=I.mode}if(I.atime||I.mtime){var qn=I.atime&&new Date(I.atime),Xn=I.mtime&&new Date(I.mtime);fs.utimesSync(Hn,qn,Xn)}I.size!==void 0&&fs.truncateSync(Hn,I.size)})},lookup(e,I){var Hn=PATH.join2(NODEFS.realPath(e),I),$n=NODEFS.getMode(Hn);return NODEFS.createNode(e,I,$n)},mknod(e,I,Hn,$n){var qn=NODEFS.createNode(e,I,Hn,$n),Xn=NODEFS.realPath(qn);return NODEFS.tryFSOperation(()=>{FS.isDir(qn.mode)?fs.mkdirSync(Xn,qn.mode):fs.writeFileSync(Xn,"",{mode:qn.mode})}),qn},rename(e,I,Hn){var $n=NODEFS.realPath(e),qn=PATH.join2(NODEFS.realPath(I),Hn);try{FS.unlink(qn)}catch{}NODEFS.tryFSOperation(()=>fs.renameSync($n,qn)),e.name=Hn},unlink(e,I){var Hn=PATH.join2(NODEFS.realPath(e),I);NODEFS.tryFSOperation(()=>fs.unlinkSync(Hn))},rmdir(e,I){var Hn=PATH.join2(NODEFS.realPath(e),I);NODEFS.tryFSOperation(()=>fs.rmdirSync(Hn))},readdir(e){var I=NODEFS.realPath(e);return NODEFS.tryFSOperation(()=>fs.readdirSync(I))},symlink(e,I,Hn){var $n=PATH.join2(NODEFS.realPath(e),I);NODEFS.tryFSOperation(()=>fs.symlinkSync(Hn,$n))},readlink(e){var I=NODEFS.realPath(e);return NODEFS.tryFSOperation(()=>fs.readlinkSync(I))},statfs(e){var I=NODEFS.tryFSOperation(()=>fs.statfsSync(e));return I.frsize=I.bsize,I}},stream_ops:{open(e){var I=NODEFS.realPath(e.node);NODEFS.tryFSOperation(()=>{FS.isFile(e.node.mode)&&(e.shared.refcount=1,e.nfd=fs.openSync(I,NODEFS.flagsForNode(e.flags)))})},close(e){NODEFS.tryFSOperation(()=>{FS.isFile(e.node.mode)&&e.nfd&&--e.shared.refcount===0&&fs.closeSync(e.nfd)})},dup(e){e.shared.refcount++},read(e,I,Hn,$n,qn){return $n===0?0:NODEFS.tryFSOperation(()=>fs.readSync(e.nfd,new Int8Array(I.buffer,Hn,$n),0,$n,qn))},write(e,I,Hn,$n,qn){return NODEFS.tryFSOperation(()=>fs.writeSync(e.nfd,new Int8Array(I.buffer,Hn,$n),0,$n,qn))},llseek(e,I,Hn){var $n=I;if(Hn===1?$n+=e.position:Hn===2&&FS.isFile(e.node.mode)&&NODEFS.tryFSOperation(()=>{var qn=fs.fstatSync(e.nfd);$n+=qn.size}),$n<0)throw new FS.ErrnoError(28);return $n},mmap(e,I,Hn,$n,qn){if(!FS.isFile(e.node.mode))throw new FS.ErrnoError(43);var Xn=mmapAlloc(I);return NODEFS.stream_ops.read(e,HEAP8,Xn,I,Hn),{ptr:Xn,allocated:!0}},msync(e,I,Hn,$n,qn){return NODEFS.stream_ops.write(e,I,0,$n,Hn,!1),0}}},FS={root:null,mounts:[],devices:{},streams:[],nextInode:1,nameTable:null,currentPath:"/",initialized:!1,ignorePermissions:!0,ErrnoError:class{constructor(e){P$2(this,"name","ErrnoError"),this.errno=e}},filesystems:null,syncFSRequests:0,readFiles:{},FSStream:class{constructor(){P$2(this,"shared",{})}get object(){return this.node}set object(e){this.node=e}get isRead(){return(this.flags&2097155)!==1}get isWrite(){return(this.flags&2097155)!==0}get isAppend(){return this.flags&1024}get flags(){return this.shared.flags}set flags(e){this.shared.flags=e}get position(){return this.shared.position}set position(e){this.shared.position=e}},FSNode:class{constructor(e,I,Hn,$n){P$2(this,"node_ops",{}),P$2(this,"stream_ops",{}),P$2(this,"readMode",365),P$2(this,"writeMode",146),P$2(this,"mounted",null),e||(e=this),this.parent=e,this.mount=e.mount,this.id=FS.nextInode++,this.name=I,this.mode=Hn,this.rdev=$n,this.atime=this.mtime=this.ctime=Date.now()}get read(){return(this.mode&this.readMode)===this.readMode}set read(e){e?this.mode|=this.readMode:this.mode&=~this.readMode}get write(){return(this.mode&this.writeMode)===this.writeMode}set write(e){e?this.mode|=this.writeMode:this.mode&=~this.writeMode}get isFolder(){return FS.isDir(this.mode)}get isDevice(){return FS.isChrdev(this.mode)}},lookupPath(e,I={}){if(!e)return{path:"",node:null};I.follow_mount??(I.follow_mount=!0),PATH.isAbs(e)||(e=FS.cwd()+"/"+e);e:for(var Hn=0;Hn<40;Hn++){for(var $n=e.split("/").filter(Zn=>!!Zn&&Zn!=="."),qn=FS.root,Xn="/",Yn=0;Yn<$n.length;Yn++){var Kn=Yn===$n.length-1;if(Kn&&I.parent)break;if($n[Yn]===".."){Xn=PATH.dirname(Xn),qn=qn.parent;continue}Xn=PATH.join2(Xn,$n[Yn]);try{qn=FS.lookupNode(qn,$n[Yn])}catch(Zn){if(Zn?.errno===44&&Kn&&I.noent_okay)return{path:Xn};throw Zn}if(FS.isMountpoint(qn)&&(!Kn||I.follow_mount)&&(qn=qn.mounted.root),FS.isLink(qn.mode)&&(!Kn||I.follow)){if(!qn.node_ops.readlink)throw new FS.ErrnoError(52);var Jn=qn.node_ops.readlink(qn);PATH.isAbs(Jn)||(Jn=PATH.dirname(Xn)+"/"+Jn),e=Jn+"/"+$n.slice(Yn+1).join("/");continue e}}return{path:Xn,node:qn}}throw new FS.ErrnoError(32)},getPath(e){for(var I;;){if(FS.isRoot(e)){var Hn=e.mount.mountpoint;return I?Hn[Hn.length-1]!=="/"?`${Hn}/${I}`:Hn+I:Hn}I=I?`${e.name}/${I}`:e.name,e=e.parent}},hashName(e,I){for(var Hn=0,$n=0;$n<I.length;$n++)Hn=(Hn<<5)-Hn+I.charCodeAt($n)|0;return(e+Hn>>>0)%FS.nameTable.length},hashAddNode(e){var I=FS.hashName(e.parent.id,e.name);e.name_next=FS.nameTable[I],FS.nameTable[I]=e},hashRemoveNode(e){var I=FS.hashName(e.parent.id,e.name);if(FS.nameTable[I]===e)FS.nameTable[I]=e.name_next;else for(var Hn=FS.nameTable[I];Hn;){if(Hn.name_next===e){Hn.name_next=e.name_next;break}Hn=Hn.name_next}},lookupNode(e,I){var Hn=FS.mayLookup(e);if(Hn)throw new FS.ErrnoError(Hn);for(var $n=FS.hashName(e.id,I),qn=FS.nameTable[$n];qn;qn=qn.name_next){var Xn=qn.name;if(qn.parent.id===e.id&&Xn===I)return qn}return FS.lookup(e,I)},createNode(e,I,Hn,$n){var qn=new FS.FSNode(e,I,Hn,$n);return FS.hashAddNode(qn),qn},destroyNode(e){FS.hashRemoveNode(e)},isRoot(e){return e===e.parent},isMountpoint(e){return!!e.mounted},isFile(e){return(e&61440)===32768},isDir(e){return(e&61440)===16384},isLink(e){return(e&61440)===40960},isChrdev(e){return(e&61440)===8192},isBlkdev(e){return(e&61440)===24576},isFIFO(e){return(e&61440)===4096},isSocket(e){return(e&49152)===49152},flagsToPermissionString(e){var I=["r","w","rw"][e&3];return e&512&&(I+="w"),I},nodePermissions(e,I){return FS.ignorePermissions?0:I.includes("r")&&!(e.mode&292)||I.includes("w")&&!(e.mode&146)||I.includes("x")&&!(e.mode&73)?2:0},mayLookup(e){if(!FS.isDir(e.mode))return 54;var I=FS.nodePermissions(e,"x");return I||(e.node_ops.lookup?0:2)},mayCreate(e,I){if(!FS.isDir(e.mode))return 54;try{var Hn=FS.lookupNode(e,I);return 20}catch{}return FS.nodePermissions(e,"wx")},mayDelete(e,I,Hn){var $n;try{$n=FS.lookupNode(e,I)}catch(Xn){return Xn.errno}var qn=FS.nodePermissions(e,"wx");if(qn)return qn;if(Hn){if(!FS.isDir($n.mode))return 54;if(FS.isRoot($n)||FS.getPath($n)===FS.cwd())return 10}else if(FS.isDir($n.mode))return 31;return 0},mayOpen(e,I){return e?FS.isLink(e.mode)?32:FS.isDir(e.mode)&&(FS.flagsToPermissionString(I)!=="r"||I&512)?31:FS.nodePermissions(e,FS.flagsToPermissionString(I)):44},MAX_OPEN_FDS:4096,nextfd(){for(var e=0;e<=FS.MAX_OPEN_FDS;e++)if(!FS.streams[e])return e;throw new FS.ErrnoError(33)},getStreamChecked(e){var I=FS.getStream(e);if(!I)throw new FS.ErrnoError(8);return I},getStream:e=>FS.streams[e],createStream(e,I=-1){return e=Object.assign(new FS.FSStream,e),I==-1&&(I=FS.nextfd()),e.fd=I,FS.streams[I]=e,e},closeStream(e){FS.streams[e]=null},dupStream(e,I=-1){var Hn=FS.createStream(e,I);return Hn.stream_ops?.dup?.(Hn),Hn},chrdev_stream_ops:{open(e){var I=FS.getDevice(e.node.rdev);e.stream_ops=I.stream_ops,e.stream_ops.open?.(e)},llseek(){throw new FS.ErrnoError(70)}},major:e=>e>>8,minor:e=>e&255,makedev:(e,I)=>e<<8|I,registerDevice(e,I){FS.devices[e]={stream_ops:I}},getDevice:e=>FS.devices[e],getMounts(e){for(var I=[],Hn=[e];Hn.length;){var $n=Hn.pop();I.push($n),Hn.push(...$n.mounts)}return I},syncfs(e,I){typeof e=="function"&&(I=e,e=!1),FS.syncFSRequests++,FS.syncFSRequests>1&&err(`warning: ${FS.syncFSRequests} FS.syncfs operations in flight at once, probably just doing extra work`);var Hn=FS.getMounts(FS.root.mount),$n=0;function qn(Yn){return FS.syncFSRequests--,I(Yn)}function Xn(Yn){if(Yn)return Xn.errored?void 0:(Xn.errored=!0,qn(Yn));++$n>=Hn.length&&qn(null)}Hn.forEach(Yn=>{if(!Yn.type.syncfs)return Xn(null);Yn.type.syncfs(Yn,e,Xn)})},mount(e,I,Hn){var $n=Hn==="/",qn=!Hn,Xn;if($n&&FS.root)throw new FS.ErrnoError(10);if(!$n&&!qn){var Yn=FS.lookupPath(Hn,{follow_mount:!1});if(Hn=Yn.path,Xn=Yn.node,FS.isMountpoint(Xn))throw new FS.ErrnoError(10);if(!FS.isDir(Xn.mode))throw new FS.ErrnoError(54)}var Kn={type:e,opts:I,mountpoint:Hn,mounts:[]},Jn=e.mount(Kn);return Jn.mount=Kn,Kn.root=Jn,$n?FS.root=Jn:Xn&&(Xn.mounted=Kn,Xn.mount&&Xn.mount.mounts.push(Kn)),Jn},unmount(e){var I=FS.lookupPath(e,{follow_mount:!1});if(!FS.isMountpoint(I.node))throw new FS.ErrnoError(28);var Hn=I.node,$n=Hn.mounted,qn=FS.getMounts($n);Object.keys(FS.nameTable).forEach(Yn=>{for(var Kn=FS.nameTable[Yn];Kn;){var Jn=Kn.name_next;qn.includes(Kn.mount)&&FS.destroyNode(Kn),Kn=Jn}}),Hn.mounted=null;var Xn=Hn.mount.mounts.indexOf($n);Hn.mount.mounts.splice(Xn,1)},lookup(e,I){return e.node_ops.lookup(e,I)},mknod(e,I,Hn){var $n=FS.lookupPath(e,{parent:!0}),qn=$n.node,Xn=PATH.basename(e);if(!Xn||Xn==="."||Xn==="..")throw new FS.ErrnoError(28);var Yn=FS.mayCreate(qn,Xn);if(Yn)throw new FS.ErrnoError(Yn);if(!qn.node_ops.mknod)throw new FS.ErrnoError(63);return qn.node_ops.mknod(qn,Xn,I,Hn)},statfs(e){var I={bsize:4096,frsize:4096,blocks:1e6,bfree:5e5,bavail:5e5,files:FS.nextInode,ffree:FS.nextInode-1,fsid:42,flags:2,namelen:255},Hn=FS.lookupPath(e,{follow:!0}).node;return Hn?.node_ops.statfs&&Object.assign(I,Hn.node_ops.statfs(Hn.mount.opts.root)),I},create(e,I=438){return I&=4095,I|=32768,FS.mknod(e,I,0)},mkdir(e,I=511){return I&=1023,I|=16384,FS.mknod(e,I,0)},mkdirTree(e,I){for(var Hn=e.split("/"),$n="",qn=0;qn<Hn.length;++qn)if(Hn[qn]){$n+="/"+Hn[qn];try{FS.mkdir($n,I)}catch(Xn){if(Xn.errno!=20)throw Xn}}},mkdev(e,I,Hn){return typeof Hn>"u"&&(Hn=I,I=438),I|=8192,FS.mknod(e,I,Hn)},symlink(e,I){if(!PATH_FS.resolve(e))throw new FS.ErrnoError(44);var Hn=FS.lookupPath(I,{parent:!0}),$n=Hn.node;if(!$n)throw new FS.ErrnoError(44);var qn=PATH.basename(I),Xn=FS.mayCreate($n,qn);if(Xn)throw new FS.ErrnoError(Xn);if(!$n.node_ops.symlink)throw new FS.ErrnoError(63);return $n.node_ops.symlink($n,qn,e)},rename(e,I){var Hn=PATH.dirname(e),$n=PATH.dirname(I),qn=PATH.basename(e),Xn=PATH.basename(I),Yn,Kn,Jn;if(Yn=FS.lookupPath(e,{parent:!0}),Kn=Yn.node,Yn=FS.lookupPath(I,{parent:!0}),Jn=Yn.node,!Kn||!Jn)throw new FS.ErrnoError(44);if(Kn.mount!==Jn.mount)throw new FS.ErrnoError(75);var Zn=FS.lookupNode(Kn,qn),ea=PATH_FS.relative(e,$n);if(ea.charAt(0)!==".")throw new FS.ErrnoError(28);if(ea=PATH_FS.relative(I,Hn),ea.charAt(0)!==".")throw new FS.ErrnoError(55);var aa;try{aa=FS.lookupNode(Jn,Xn)}catch{}if(Zn!==aa){var oa=FS.isDir(Zn.mode),la=FS.mayDelete(Kn,qn,oa);if(la)throw new FS.ErrnoError(la);if(la=aa?FS.mayDelete(Jn,Xn,oa):FS.mayCreate(Jn,Xn),la)throw new FS.ErrnoError(la);if(!Kn.node_ops.rename)throw new FS.ErrnoError(63);if(FS.isMountpoint(Zn)||aa&&FS.isMountpoint(aa))throw new FS.ErrnoError(10);if(Jn!==Kn&&(la=FS.nodePermissions(Kn,"w"),la))throw new FS.ErrnoError(la);FS.hashRemoveNode(Zn);try{Kn.node_ops.rename(Zn,Jn,Xn),Zn.parent=Jn}catch(ra){throw ra}finally{FS.hashAddNode(Zn)}}},rmdir(e){var I=FS.lookupPath(e,{parent:!0}),Hn=I.node,$n=PATH.basename(e),qn=FS.lookupNode(Hn,$n),Xn=FS.mayDelete(Hn,$n,!0);if(Xn)throw new FS.ErrnoError(Xn);if(!Hn.node_ops.rmdir)throw new FS.ErrnoError(63);if(FS.isMountpoint(qn))throw new FS.ErrnoError(10);Hn.node_ops.rmdir(Hn,$n),FS.destroyNode(qn)},readdir(e){var I=FS.lookupPath(e,{follow:!0}),Hn=I.node;if(!Hn.node_ops.readdir)throw new FS.ErrnoError(54);return Hn.node_ops.readdir(Hn)},unlink(e){var I=FS.lookupPath(e,{parent:!0}),Hn=I.node;if(!Hn)throw new FS.ErrnoError(44);var $n=PATH.basename(e),qn=FS.lookupNode(Hn,$n),Xn=FS.mayDelete(Hn,$n,!1);if(Xn)throw new FS.ErrnoError(Xn);if(!Hn.node_ops.unlink)throw new FS.ErrnoError(63);if(FS.isMountpoint(qn))throw new FS.ErrnoError(10);Hn.node_ops.unlink(Hn,$n),FS.destroyNode(qn)},readlink(e){var I=FS.lookupPath(e),Hn=I.node;if(!Hn)throw new FS.ErrnoError(44);if(!Hn.node_ops.readlink)throw new FS.ErrnoError(28);return Hn.node_ops.readlink(Hn)},stat(e,I){var Hn=FS.lookupPath(e,{follow:!I}),$n=Hn.node;if(!$n)throw new FS.ErrnoError(44);if(!$n.node_ops.getattr)throw new FS.ErrnoError(63);return $n.node_ops.getattr($n)},lstat(e){return FS.stat(e,!0)},chmod(e,I,Hn){var $n;if(typeof e=="string"){var qn=FS.lookupPath(e,{follow:!Hn});$n=qn.node}else $n=e;if(!$n.node_ops.setattr)throw new FS.ErrnoError(63);$n.node_ops.setattr($n,{mode:I&4095|$n.mode&-4096,ctime:Date.now()})},lchmod(e,I){FS.chmod(e,I,!0)},fchmod(e,I){var Hn=FS.getStreamChecked(e);FS.chmod(Hn.node,I)},chown(e,I,Hn,$n){var qn;if(typeof e=="string"){var Xn=FS.lookupPath(e,{follow:!$n});qn=Xn.node}else qn=e;if(!qn.node_ops.setattr)throw new FS.ErrnoError(63);qn.node_ops.setattr(qn,{timestamp:Date.now()})},lchown(e,I,Hn){FS.chown(e,I,Hn,!0)},fchown(e,I,Hn){var $n=FS.getStreamChecked(e);FS.chown($n.node,I,Hn)},truncate(e,I){if(I<0)throw new FS.ErrnoError(28);var Hn;if(typeof e=="string"){var $n=FS.lookupPath(e,{follow:!0});Hn=$n.node}else Hn=e;if(!Hn.node_ops.setattr)throw new FS.ErrnoError(63);if(FS.isDir(Hn.mode))throw new FS.ErrnoError(31);if(!FS.isFile(Hn.mode))throw new FS.ErrnoError(28);var qn=FS.nodePermissions(Hn,"w");if(qn)throw new FS.ErrnoError(qn);Hn.node_ops.setattr(Hn,{size:I,timestamp:Date.now()})},ftruncate(e,I){var Hn=FS.getStreamChecked(e);if(!(Hn.flags&2097155))throw new FS.ErrnoError(28);FS.truncate(Hn.node,I)},utime(e,I,Hn){var $n=FS.lookupPath(e,{follow:!0}),qn=$n.node;qn.node_ops.setattr(qn,{atime:I,mtime:Hn})},open(e,I,Hn=438){if(e==="")throw new FS.ErrnoError(44);I=typeof I=="string"?FS_modeStringToFlags(I):I,I&64?Hn=Hn&4095|32768:Hn=0;var $n;if(typeof e=="object")$n=e;else{var qn=FS.lookupPath(e,{follow:!(I&131072),noent_okay:!0});$n=qn.node,e=qn.path}var Xn=!1;if(I&64)if($n){if(I&128)throw new FS.ErrnoError(20)}else $n=FS.mknod(e,Hn,0),Xn=!0;if(!$n)throw new FS.ErrnoError(44);if(FS.isChrdev($n.mode)&&(I&=-513),I&65536&&!FS.isDir($n.mode))throw new FS.ErrnoError(54);if(!Xn){var Yn=FS.mayOpen($n,I);if(Yn)throw new FS.ErrnoError(Yn)}I&512&&!Xn&&FS.truncate($n,0),I&=-131713;var Kn=FS.createStream({node:$n,path:FS.getPath($n),flags:I,seekable:!0,position:0,stream_ops:$n.stream_ops,ungotten:[],error:!1});return Kn.stream_ops.open&&Kn.stream_ops.open(Kn),Module.logReadFiles&&!(I&1)&&(e in FS.readFiles||(FS.readFiles[e]=1)),Kn},close(e){if(FS.isClosed(e))throw new FS.ErrnoError(8);e.getdents&&(e.getdents=null);try{e.stream_ops.close&&e.stream_ops.close(e)}catch(I){throw I}finally{FS.closeStream(e.fd)}e.fd=null},isClosed(e){return e.fd===null},llseek(e,I,Hn){if(FS.isClosed(e))throw new FS.ErrnoError(8);if(!e.seekable||!e.stream_ops.llseek)throw new FS.ErrnoError(70);if(Hn!=0&&Hn!=1&&Hn!=2)throw new FS.ErrnoError(28);return e.position=e.stream_ops.llseek(e,I,Hn),e.ungotten=[],e.position},read(e,I,Hn,$n,qn){if($n<0||qn<0)throw new FS.ErrnoError(28);if(FS.isClosed(e))throw new FS.ErrnoError(8);if((e.flags&2097155)===1)throw new FS.ErrnoError(8);if(FS.isDir(e.node.mode))throw new FS.ErrnoError(31);if(!e.stream_ops.read)throw new FS.ErrnoError(28);var Xn=typeof qn<"u";if(!Xn)qn=e.position;else if(!e.seekable)throw new FS.ErrnoError(70);var Yn=e.stream_ops.read(e,I,Hn,$n,qn);return Xn||(e.position+=Yn),Yn},write(e,I,Hn,$n,qn,Xn){if($n<0||qn<0)throw new FS.ErrnoError(28);if(FS.isClosed(e))throw new FS.ErrnoError(8);if(!(e.flags&2097155))throw new FS.ErrnoError(8);if(FS.isDir(e.node.mode))throw new FS.ErrnoError(31);if(!e.stream_ops.write)throw new FS.ErrnoError(28);e.seekable&&e.flags&1024&&FS.llseek(e,0,2);var Yn=typeof qn<"u";if(!Yn)qn=e.position;else if(!e.seekable)throw new FS.ErrnoError(70);var Kn=e.stream_ops.write(e,I,Hn,$n,qn,Xn);return Yn||(e.position+=Kn),Kn},allocate(e,I,Hn){if(FS.isClosed(e))throw new FS.ErrnoError(8);if(I<0||Hn<=0)throw new FS.ErrnoError(28);if(!(e.flags&2097155))throw new FS.ErrnoError(8);if(!FS.isFile(e.node.mode)&&!FS.isDir(e.node.mode))throw new FS.ErrnoError(43);if(!e.stream_ops.allocate)throw new FS.ErrnoError(138);e.stream_ops.allocate(e,I,Hn)},mmap(e,I,Hn,$n,qn){if($n&2&&!(qn&2)&&(e.flags&2097155)!==2)throw new FS.ErrnoError(2);if((e.flags&2097155)===1)throw new FS.ErrnoError(2);if(!e.stream_ops.mmap)throw new FS.ErrnoError(43);if(!I)throw new FS.ErrnoError(28);return e.stream_ops.mmap(e,I,Hn,$n,qn)},msync(e,I,Hn,$n,qn){return e.stream_ops.msync?e.stream_ops.msync(e,I,Hn,$n,qn):0},ioctl(e,I,Hn){if(!e.stream_ops.ioctl)throw new FS.ErrnoError(59);return e.stream_ops.ioctl(e,I,Hn)},readFile(e,I={}){if(I.flags=I.flags||0,I.encoding=I.encoding||"binary",I.encoding!=="utf8"&&I.encoding!=="binary")throw new Error(`Invalid encoding type "${I.encoding}"`);var Hn,$n=FS.open(e,I.flags),qn=FS.stat(e),Xn=qn.size,Yn=new Uint8Array(Xn);return FS.read($n,Yn,0,Xn,0),I.encoding==="utf8"?Hn=UTF8ArrayToString(Yn):I.encoding==="binary"&&(Hn=Yn),FS.close($n),Hn},writeFile(e,I,Hn={}){Hn.flags=Hn.flags||577;var $n=FS.open(e,Hn.flags,Hn.mode);if(typeof I=="string"){var qn=new Uint8Array(lengthBytesUTF8(I)+1),Xn=stringToUTF8Array(I,qn,0,qn.length);FS.write($n,qn,0,Xn,void 0,Hn.canOwn)}else if(ArrayBuffer.isView(I))FS.write($n,I,0,I.byteLength,void 0,Hn.canOwn);else throw new Error("Unsupported data type");FS.close($n)},cwd:()=>FS.currentPath,chdir(e){var I=FS.lookupPath(e,{follow:!0});if(I.node===null)throw new FS.ErrnoError(44);if(!FS.isDir(I.node.mode))throw new FS.ErrnoError(54);var Hn=FS.nodePermissions(I.node,"x");if(Hn)throw new FS.ErrnoError(Hn);FS.currentPath=I.path},createDefaultDirectories(){FS.mkdir("/tmp"),FS.mkdir("/home"),FS.mkdir("/home/web_user")},createDefaultDevices(){FS.mkdir("/dev"),FS.registerDevice(FS.makedev(1,3),{read:()=>0,write:($n,qn,Xn,Yn,Kn)=>Yn,llseek:()=>0}),FS.mkdev("/dev/null",FS.makedev(1,3)),TTY.register(FS.makedev(5,0),TTY.default_tty_ops),TTY.register(FS.makedev(6,0),TTY.default_tty1_ops),FS.mkdev("/dev/tty",FS.makedev(5,0)),FS.mkdev("/dev/tty1",FS.makedev(6,0));var e=new Uint8Array(1024),I=0,Hn=()=>(I===0&&(I=randomFill(e).byteLength),e[--I]);FS.createDevice("/dev","random",Hn),FS.createDevice("/dev","urandom",Hn),FS.mkdir("/dev/shm"),FS.mkdir("/dev/shm/tmp")},createSpecialDirectories(){FS.mkdir("/proc");var e=FS.mkdir("/proc/self");FS.mkdir("/proc/self/fd"),FS.mount({mount(){var I=FS.createNode(e,"fd",16895,73);return I.stream_ops={llseek:MEMFS.stream_ops.llseek},I.node_ops={lookup(Hn,$n){var qn=+$n,Xn=FS.getStreamChecked(qn),Yn={parent:null,mount:{mountpoint:"fake"},node_ops:{readlink:()=>Xn.path},id:qn+1};return Yn.parent=Yn,Yn},readdir(){return Array.from(FS.streams.entries()).filter(([Hn,$n])=>$n).map(([Hn,$n])=>Hn.toString())}},I}},{},"/proc/self/fd")},createStandardStreams(e,I,Hn){e?FS.createDevice("/dev","stdin",e):FS.symlink("/dev/tty","/dev/stdin"),I?FS.createDevice("/dev","stdout",null,I):FS.symlink("/dev/tty","/dev/stdout"),Hn?FS.createDevice("/dev","stderr",null,Hn):FS.symlink("/dev/tty1","/dev/stderr"),FS.open("/dev/stdin",0),FS.open("/dev/stdout",1),FS.open("/dev/stderr",1)},staticInit(){FS.nameTable=new Array(4096),FS.mount(MEMFS,{},"/"),FS.createDefaultDirectories(),FS.createDefaultDevices(),FS.createSpecialDirectories(),FS.filesystems={MEMFS,IDBFS,NODEFS}},init(e,I,Hn){FS.initialized=!0,e??(e=Module.stdin),I??(I=Module.stdout),Hn??(Hn=Module.stderr),FS.createStandardStreams(e,I,Hn)},quit(){FS.initialized=!1,_fflush(0);for(var e=0;e<FS.streams.length;e++){var I=FS.streams[e];I&&FS.close(I)}},findObject(e,I){var Hn=FS.analyzePath(e,I);return Hn.exists?Hn.object:null},analyzePath(e,I){try{var Hn=FS.lookupPath(e,{follow:!I});e=Hn.path}catch{}var $n={isRoot:!1,exists:!1,error:0,name:null,path:null,object:null,parentExists:!1,parentPath:null,parentObject:null};try{var Hn=FS.lookupPath(e,{parent:!0});$n.parentExists=!0,$n.parentPath=Hn.path,$n.parentObject=Hn.node,$n.name=PATH.basename(e),Hn=FS.lookupPath(e,{follow:!I}),$n.exists=!0,$n.path=Hn.path,$n.object=Hn.node,$n.name=Hn.node.name,$n.isRoot=Hn.path==="/"}catch(qn){$n.error=qn.errno}return $n},createPath(e,I,Hn,$n){e=typeof e=="string"?e:FS.getPath(e);for(var qn=I.split("/").reverse();qn.length;){var Xn=qn.pop();if(Xn){var Yn=PATH.join2(e,Xn);try{FS.mkdir(Yn)}catch{}e=Yn}}return Yn},createFile(e,I,Hn,$n,qn){var Xn=PATH.join2(typeof e=="string"?e:FS.getPath(e),I),Yn=FS_getMode($n,qn);return FS.create(Xn,Yn)},createDataFile(e,I,Hn,$n,qn,Xn){var Yn=I;e&&(e=typeof e=="string"?e:FS.getPath(e),Yn=I?PATH.join2(e,I):e);var Kn=FS_getMode($n,qn),Jn=FS.create(Yn,Kn);if(Hn){if(typeof Hn=="string"){for(var Zn=new Array(Hn.length),ea=0,aa=Hn.length;ea<aa;++ea)Zn[ea]=Hn.charCodeAt(ea);Hn=Zn}FS.chmod(Jn,Kn|146);var oa=FS.open(Jn,577);FS.write(oa,Hn,0,Hn.length,0,Xn),FS.close(oa),FS.chmod(Jn,Kn)}},createDevice(e,I,Hn,$n){var qn,Xn=PATH.join2(typeof e=="string"?e:FS.getPath(e),I),Yn=FS_getMode(!!Hn,!!$n);(qn=FS.createDevice).major??(qn.major=64);var Kn=FS.makedev(FS.createDevice.major++,0);return FS.registerDevice(Kn,{open(Jn){Jn.seekable=!1},close(Jn){$n?.buffer?.length&&$n(10)},read(Jn,Zn,ea,aa,oa){for(var la=0,ra=0;ra<aa;ra++){var ia;try{ia=Hn()}catch{throw new FS.ErrnoError(29)}if(ia===void 0&&la===0)throw new FS.ErrnoError(6);if(ia==null)break;la++,Zn[ea+ra]=ia}return la&&(Jn.node.atime=Date.now()),la},write(Jn,Zn,ea,aa,oa){for(var la=0;la<aa;la++)try{$n(Zn[ea+la])}catch{throw new FS.ErrnoError(29)}return aa&&(Jn.node.mtime=Jn.node.ctime=Date.now()),la}}),FS.mkdev(Xn,Yn,Kn)},forceLoadFile(e){if(e.isDevice||e.isFolder||e.link||e.contents)return!0;if(typeof XMLHttpRequest<"u")throw new Error("Lazy loading should have been performed (contents set) in createLazyFile, but it was not. Lazy loading only works in web workers. Use --embed-file or --preload-file in emcc on the main thread.");try{e.contents=readBinary(e.url),e.usedBytes=e.contents.length}catch{throw new FS.ErrnoError(29)}},createLazyFile(e,I,Hn,$n,qn){class Xn{constructor(){P$2(this,"lengthKnown",!1),P$2(this,"chunks",[])}get(la){if(!(la>this.length-1||la<0)){var ra=la%this.chunkSize,ia=la/this.chunkSize|0;return this.getter(ia)[ra]}}setDataGetter(la){this.getter=la}cacheLength(){var la=new XMLHttpRequest;if(la.open("HEAD",Hn,!1),la.send(null),!(la.status>=200&&la.status<300||la.status===304))throw new Error("Couldn't load "+Hn+". Status: "+la.status);var ra=Number(la.getResponseHeader("Content-length")),ia,da=(ia=la.getResponseHeader("Accept-Ranges"))&&ia==="bytes",Ea=(ia=la.getResponseHeader("Content-Encoding"))&&ia==="gzip",na=1024*1024;da||(na=ra);var ta=(ca,_a)=>{if(ca>_a)throw new Error("invalid range ("+ca+", "+_a+") or no bytes requested!");if(_a>ra-1)throw new Error("only "+ra+" bytes available! programmer error!");var pa=new XMLHttpRequest;if(pa.open("GET",Hn,!1),ra!==na&&pa.setRequestHeader("Range","bytes="+ca+"-"+_a),pa.responseType="arraybuffer",pa.overrideMimeType&&pa.overrideMimeType("text/plain; charset=x-user-defined"),pa.send(null),!(pa.status>=200&&pa.status<300||pa.status===304))throw new Error("Couldn't load "+Hn+". Status: "+pa.status);return pa.response!==void 0?new Uint8Array(pa.response||[]):intArrayFromString(pa.responseText||"")},sa=this;sa.setDataGetter(ca=>{var _a=ca*na,pa=(ca+1)*na-1;if(pa=Math.min(pa,ra-1),typeof sa.chunks[ca]>"u"&&(sa.chunks[ca]=ta(_a,pa)),typeof sa.chunks[ca]>"u")throw new Error("doXHR failed!");return sa.chunks[ca]}),(Ea||!ra)&&(na=ra=1,ra=this.getter(0).length,na=ra,out("LazyFiles on gzip forces download of the whole file when length is accessed")),this._length=ra,this._chunkSize=na,this.lengthKnown=!0}get length(){return this.lengthKnown||this.cacheLength(),this._length}get chunkSize(){return this.lengthKnown||this.cacheLength(),this._chunkSize}}if(typeof XMLHttpRequest<"u"){if(!ENVIRONMENT_IS_WORKER)throw"Cannot do synchronous binary XHRs outside webworkers in modern browsers. Use --embed-file or --preload-file in emcc";var Yn=new Xn,Kn={isDevice:!1,contents:Yn}}else var Kn={isDevice:!1,url:Hn};var Jn=FS.createFile(e,I,Kn,$n,qn);Kn.contents?Jn.contents=Kn.contents:Kn.url&&(Jn.contents=null,Jn.url=Kn.url),Object.defineProperties(Jn,{usedBytes:{get:function(){return this.contents.length}}});var Zn={},ea=Object.keys(Jn.stream_ops);ea.forEach(oa=>{var la=Jn.stream_ops[oa];Zn[oa]=(...ra)=>(FS.forceLoadFile(Jn),la(...ra))});function aa(oa,la,ra,ia,da){var Ea=oa.node.contents;if(da>=Ea.length)return 0;var na=Math.min(Ea.length-da,ia);if(Ea.slice)for(var ta=0;ta<na;ta++)la[ra+ta]=Ea[da+ta];else for(var ta=0;ta<na;ta++)la[ra+ta]=Ea.get(da+ta);return na}return Zn.read=(oa,la,ra,ia,da)=>(FS.forceLoadFile(Jn),aa(oa,la,ra,ia,da)),Zn.mmap=(oa,la,ra,ia,da)=>{FS.forceLoadFile(Jn);var Ea=mmapAlloc(la);if(!Ea)throw new FS.ErrnoError(48);return aa(oa,HEAP8,Ea,la,ra),{ptr:Ea,allocated:!0}},Jn.stream_ops=Zn,Jn}},SYSCALLS={DEFAULT_POLLMASK:5,calculateAt(e,I,Hn){if(PATH.isAbs(I))return I;var $n;if(e===-100)$n=FS.cwd();else{var qn=SYSCALLS.getStreamFromFD(e);$n=qn.path}if(I.length==0){if(!Hn)throw new FS.ErrnoError(44);return $n}return $n+"/"+I},doStat(e,I,Hn){var $n=e(I);HEAP32[Hn>>2]=$n.dev,HEAP32[Hn+4>>2]=$n.mode,HEAPU32[Hn+8>>2]=$n.nlink,HEAP32[Hn+12>>2]=$n.uid,HEAP32[Hn+16>>2]=$n.gid,HEAP32[Hn+20>>2]=$n.rdev,HEAP64[Hn+24>>3]=BigInt($n.size),HEAP32[Hn+32>>2]=4096,HEAP32[Hn+36>>2]=$n.blocks;var qn=$n.atime.getTime(),Xn=$n.mtime.getTime(),Yn=$n.ctime.getTime();return HEAP64[Hn+40>>3]=BigInt(Math.floor(qn/1e3)),HEAPU32[Hn+48>>2]=qn%1e3*1e3*1e3,HEAP64[Hn+56>>3]=BigInt(Math.floor(Xn/1e3)),HEAPU32[Hn+64>>2]=Xn%1e3*1e3*1e3,HEAP64[Hn+72>>3]=BigInt(Math.floor(Yn/1e3)),HEAPU32[Hn+80>>2]=Yn%1e3*1e3*1e3,HEAP64[Hn+88>>3]=BigInt($n.ino),0},doMsync(e,I,Hn,$n,qn){if(!FS.isFile(I.node.mode))throw new FS.ErrnoError(43);if($n&2)return 0;var Xn=HEAPU8.slice(e,e+Hn);FS.msync(I,Xn,qn,Hn,$n)},getStreamFromFD(e){var I=FS.getStreamChecked(e);return I},varargs:void 0,getStr(e){var I=UTF8ToString(e);return I}},___syscall__newselect=function(e,I,Hn,$n,qn){try{for(var Xn=0,Yn=I?HEAP32[I>>2]:0,Kn=I?HEAP32[I+4>>2]:0,Jn=Hn?HEAP32[Hn>>2]:0,Zn=Hn?HEAP32[Hn+4>>2]:0,ea=$n?HEAP32[$n>>2]:0,aa=$n?HEAP32[$n+4>>2]:0,oa=0,la=0,ra=0,ia=0,da=0,Ea=0,na=(I?HEAP32[I>>2]:0)|(Hn?HEAP32[Hn>>2]:0)|($n?HEAP32[$n>>2]:0),ta=(I?HEAP32[I+4>>2]:0)|(Hn?HEAP32[Hn+4>>2]:0)|($n?HEAP32[$n+4>>2]:0),sa=(ua,Aa,Ta,Ra)=>ua<32?Aa&Ra:Ta&Ra,ca=0;ca<e;ca++){var _a=1<<ca%32;if(sa(ca,na,ta,_a)){var pa=SYSCALLS.getStreamFromFD(ca),Sa=SYSCALLS.DEFAULT_POLLMASK;if(pa.stream_ops.poll){var Na=-1;if(qn){var ma=I?HEAP32[qn>>2]:0,Ia=I?HEAP32[qn+4>>2]:0;Na=(ma+Ia/1e6)*1e3}Sa=pa.stream_ops.poll(pa,Na)}Sa&1&&sa(ca,Yn,Kn,_a)&&(ca<32?oa=oa|_a:la=la|_a,Xn++),Sa&4&&sa(ca,Jn,Zn,_a)&&(ca<32?ra=ra|_a:ia=ia|_a,Xn++),Sa&2&&sa(ca,ea,aa,_a)&&(ca<32?da=da|_a:Ea=Ea|_a,Xn++)}}return I&&(HEAP32[I>>2]=oa,HEAP32[I+4>>2]=la),Hn&&(HEAP32[Hn>>2]=ra,HEAP32[Hn+4>>2]=ia),$n&&(HEAP32[$n>>2]=da,HEAP32[$n+4>>2]=Ea),Xn}catch(ua){if(typeof FS>"u"||ua.name!=="ErrnoError")throw ua;return-ua.errno}};___syscall__newselect.sig="iipppp";var SOCKFS={websocketArgs:{},callbacks:{},on(e,I){SOCKFS.callbacks[e]=I},emit(e,I){SOCKFS.callbacks[e]?.(I)},mount(e){return SOCKFS.websocketArgs=Module.websocket||{},(Module.websocket??(Module.websocket={})).on=SOCKFS.on,FS.createNode(null,"/",16895,0)},createSocket(e,I,Hn){I&=-526337;var $n=I==1;if($n&&Hn&&Hn!=6)throw new FS.ErrnoError(66);var qn={family:e,type:I,protocol:Hn,server:null,error:null,peers:{},pending:[],recv_queue:[],sock_ops:SOCKFS.websocket_sock_ops},Xn=SOCKFS.nextname(),Yn=FS.createNode(SOCKFS.root,Xn,49152,0);Yn.sock=qn;var Kn=FS.createStream({path:Xn,node:Yn,flags:2,seekable:!1,stream_ops:SOCKFS.stream_ops});return qn.stream=Kn,qn},getSocket(e){var I=FS.getStream(e);return!I||!FS.isSocket(I.node.mode)?null:I.node.sock},stream_ops:{poll(e){var I=e.node.sock;return I.sock_ops.poll(I)},ioctl(e,I,Hn){var $n=e.node.sock;return $n.sock_ops.ioctl($n,I,Hn)},read(e,I,Hn,$n,qn){var Xn=e.node.sock,Yn=Xn.sock_ops.recvmsg(Xn,$n);return Yn?(I.set(Yn.buffer,Hn),Yn.buffer.length):0},write(e,I,Hn,$n,qn){var Xn=e.node.sock;return Xn.sock_ops.sendmsg(Xn,I,Hn,$n)},close(e){var I=e.node.sock;I.sock_ops.close(I)}},nextname(){return SOCKFS.nextname.current||(SOCKFS.nextname.current=0),`socket[${SOCKFS.nextname.current++}]`},websocket_sock_ops:{createPeer(e,I,Hn){var $n;if(typeof I=="object"&&($n=I,I=null,Hn=null),$n)if($n._socket)I=$n._socket.remoteAddress,Hn=$n._socket.remotePort;else{var qn=/ws[s]?:\/\/([^:]+):(\d+)/.exec($n.url);if(!qn)throw new Error("WebSocket URL must be in the format ws(s)://address:port");I=qn[1],Hn=parseInt(qn[2],10)}else try{var Xn="ws:#".replace("#","//"),Yn="binary",Kn=void 0;if(SOCKFS.websocketArgs.url&&(Xn=SOCKFS.websocketArgs.url),SOCKFS.websocketArgs.subprotocol?Yn=SOCKFS.websocketArgs.subprotocol:SOCKFS.websocketArgs.subprotocol===null&&(Yn="null"),Xn==="ws://"||Xn==="wss://"){var Jn=I.split("/");Xn=Xn+Jn[0]+":"+Hn+"/"+Jn.slice(1).join("/")}Yn!=="null"&&(Yn=Yn.replace(/^ +| +$/g,"").split(/ *, */),Kn=Yn);var Zn;ENVIRONMENT_IS_NODE?Zn=require("ws"):Zn=WebSocket,$n=new Zn(Xn,Kn),$n.binaryType="arraybuffer"}catch{throw new FS.ErrnoError(23)}var ea={addr:I,port:Hn,socket:$n,msg_send_queue:[]};return SOCKFS.websocket_sock_ops.addPeer(e,ea),SOCKFS.websocket_sock_ops.handlePeerEvents(e,ea),e.type===2&&typeof e.sport<"u"&&ea.msg_send_queue.push(new Uint8Array([255,255,255,255,112,111,114,116,(e.sport&65280)>>8,e.sport&255])),ea},getPeer(e,I,Hn){return e.peers[I+":"+Hn]},addPeer(e,I){e.peers[I.addr+":"+I.port]=I},removePeer(e,I){delete e.peers[I.addr+":"+I.port]},handlePeerEvents(e,I){var Hn=!0,$n=function(){e.connecting=!1,SOCKFS.emit("open",e.stream.fd);try{for(var Xn=I.msg_send_queue.shift();Xn;)I.socket.send(Xn),Xn=I.msg_send_queue.shift()}catch{I.socket.close()}};function qn(Xn){if(typeof Xn=="string"){var Yn=new TextEncoder;Xn=Yn.encode(Xn)}else{if(assert(Xn.byteLength!==void 0),Xn.byteLength==0)return;Xn=new Uint8Array(Xn)}var Kn=Hn;if(Hn=!1,Kn&&Xn.length===10&&Xn[0]===255&&Xn[1]===255&&Xn[2]===255&&Xn[3]===255&&Xn[4]===112&&Xn[5]===111&&Xn[6]===114&&Xn[7]===116){var Jn=Xn[8]<<8|Xn[9];SOCKFS.websocket_sock_ops.removePeer(e,I),I.port=Jn,SOCKFS.websocket_sock_ops.addPeer(e,I);return}e.recv_queue.push({addr:I.addr,port:I.port,data:Xn}),SOCKFS.emit("message",e.stream.fd)}ENVIRONMENT_IS_NODE?(I.socket.on("open",$n),I.socket.on("message",function(Xn,Yn){Yn&&qn(new Uint8Array(Xn).buffer)}),I.socket.on("close",function(){SOCKFS.emit("close",e.stream.fd)}),I.socket.on("error",function(Xn){e.error=14,SOCKFS.emit("error",[e.stream.fd,e.error,"ECONNREFUSED: Connection refused"])})):(I.socket.onopen=$n,I.socket.onclose=function(){SOCKFS.emit("close",e.stream.fd)},I.socket.onmessage=function(Xn){qn(Xn.data)},I.socket.onerror=function(Xn){e.error=14,SOCKFS.emit("error",[e.stream.fd,e.error,"ECONNREFUSED: Connection refused"])})},poll(e){if(e.type===1&&e.server)return e.pending.length?65:0;var I=0,Hn=e.type===1?SOCKFS.websocket_sock_ops.getPeer(e,e.daddr,e.dport):null;return(e.recv_queue.length||!Hn||Hn&&Hn.socket.readyState===Hn.socket.CLOSING||Hn&&Hn.socket.readyState===Hn.socket.CLOSED)&&(I|=65),(!Hn||Hn&&Hn.socket.readyState===Hn.socket.OPEN)&&(I|=4),(Hn&&Hn.socket.readyState===Hn.socket.CLOSING||Hn&&Hn.socket.readyState===Hn.socket.CLOSED)&&(e.connecting?I|=4:I|=16),I},ioctl(e,I,Hn){switch(I){case 21531:var $n=0;return e.recv_queue.length&&($n=e.recv_queue[0].data.length),HEAP32[Hn>>2]=$n,0;default:return 28}},close(e){if(e.server){try{e.server.close()}catch{}e.server=null}for(var I=Object.keys(e.peers),Hn=0;Hn<I.length;Hn++){var $n=e.peers[I[Hn]];try{$n.socket.close()}catch{}SOCKFS.websocket_sock_ops.removePeer(e,$n)}return 0},bind(e,I,Hn){if(typeof e.saddr<"u"||typeof e.sport<"u")throw new FS.ErrnoError(28);if(e.saddr=I,e.sport=Hn,e.type===2){e.server&&(e.server.close(),e.server=null);try{e.sock_ops.listen(e,0)}catch($n){if($n.name!=="ErrnoError"||$n.errno!==138)throw $n}}},connect(e,I,Hn){if(e.server)throw new FS.ErrnoError(138);if(typeof e.daddr<"u"&&typeof e.dport<"u"){var $n=SOCKFS.websocket_sock_ops.getPeer(e,e.daddr,e.dport);if($n)throw $n.socket.readyState===$n.socket.CONNECTING?new FS.ErrnoError(7):new FS.ErrnoError(30)}var qn=SOCKFS.websocket_sock_ops.createPeer(e,I,Hn);e.daddr=qn.addr,e.dport=qn.port,e.connecting=!0},listen(e,I){if(!ENVIRONMENT_IS_NODE)throw new FS.ErrnoError(138);if(e.server)throw new FS.ErrnoError(28);var Hn=require("ws").Server,$n=e.saddr;e.server=new Hn({host:$n,port:e.sport}),SOCKFS.emit("listen",e.stream.fd),e.server.on("connection",function(qn){if(e.type===1){var Xn=SOCKFS.createSocket(e.family,e.type,e.protocol),Yn=SOCKFS.websocket_sock_ops.createPeer(Xn,qn);Xn.daddr=Yn.addr,Xn.dport=Yn.port,e.pending.push(Xn),SOCKFS.emit("connection",Xn.stream.fd)}else SOCKFS.websocket_sock_ops.createPeer(e,qn),SOCKFS.emit("connection",e.stream.fd)}),e.server.on("close",function(){SOCKFS.emit("close",e.stream.fd),e.server=null}),e.server.on("error",function(qn){e.error=23,SOCKFS.emit("error",[e.stream.fd,e.error,"EHOSTUNREACH: Host is unreachable"])})},accept(e){if(!e.server||!e.pending.length)throw new FS.ErrnoError(28);var I=e.pending.shift();return I.stream.flags=e.stream.flags,I},getname(e,I){var Hn,$n;if(I){if(e.daddr===void 0||e.dport===void 0)throw new FS.ErrnoError(53);Hn=e.daddr,$n=e.dport}else Hn=e.saddr||0,$n=e.sport||0;return{addr:Hn,port:$n}},sendmsg(e,I,Hn,$n,qn,Xn){if(e.type===2){if((qn===void 0||Xn===void 0)&&(qn=e.daddr,Xn=e.dport),qn===void 0||Xn===void 0)throw new FS.ErrnoError(17)}else qn=e.daddr,Xn=e.dport;var Yn=SOCKFS.websocket_sock_ops.getPeer(e,qn,Xn);if(e.type===1&&(!Yn||Yn.socket.readyState===Yn.socket.CLOSING||Yn.socket.readyState===Yn.socket.CLOSED))throw new FS.ErrnoError(53);ArrayBuffer.isView(I)&&(Hn+=I.byteOffset,I=I.buffer);var Kn=I.slice(Hn,Hn+$n);if(!Yn||Yn.socket.readyState!==Yn.socket.OPEN)return e.type===2&&(!Yn||Yn.socket.readyState===Yn.socket.CLOSING||Yn.socket.readyState===Yn.socket.CLOSED)&&(Yn=SOCKFS.websocket_sock_ops.createPeer(e,qn,Xn)),Yn.msg_send_queue.push(Kn),$n;try{return Yn.socket.send(Kn),$n}catch{throw new FS.ErrnoError(28)}},recvmsg(e,I){if(e.type===1&&e.server)throw new FS.ErrnoError(53);var Hn=e.recv_queue.shift();if(!Hn){if(e.type===1){var $n=SOCKFS.websocket_sock_ops.getPeer(e,e.daddr,e.dport);if(!$n)throw new FS.ErrnoError(53);if($n.socket.readyState===$n.socket.CLOSING||$n.socket.readyState===$n.socket.CLOSED)return null;throw new FS.ErrnoError(6)}throw new FS.ErrnoError(6)}var qn=Hn.data.byteLength||Hn.data.length,Xn=Hn.data.byteOffset||0,Yn=Hn.data.buffer||Hn.data,Kn=Math.min(I,qn),Jn={buffer:new Uint8Array(Yn,Xn,Kn),addr:Hn.addr,port:Hn.port};if(e.type===1&&Kn<qn){var Zn=qn-Kn;Hn.data=new Uint8Array(Yn,Xn+Kn,Zn),e.recv_queue.unshift(Hn)}return Jn}}},getSocketFromFD=e=>{var I=SOCKFS.getSocket(e);if(!I)throw new FS.ErrnoError(8);return I},inetNtop4=e=>(e&255)+"."+(e>>8&255)+"."+(e>>16&255)+"."+(e>>24&255),inetNtop6=e=>{var I="",Hn=0,$n=0,qn=0,Xn=0,Yn=0,Kn=0,Jn=[e[0]&65535,e[0]>>16,e[1]&65535,e[1]>>16,e[2]&65535,e[2]>>16,e[3]&65535,e[3]>>16],Zn=!0,ea="";for(Kn=0;Kn<5;Kn++)if(Jn[Kn]!==0){Zn=!1;break}if(Zn){if(ea=inetNtop4(Jn[6]|Jn[7]<<16),Jn[5]===-1)return I="::ffff:",I+=ea,I;if(Jn[5]===0)return I="::",ea==="0.0.0.0"&&(ea=""),ea==="0.0.0.1"&&(ea="1"),I+=ea,I}for(Hn=0;Hn<8;Hn++)Jn[Hn]===0&&(Hn-qn>1&&(Yn=0),qn=Hn,Yn++),Yn>$n&&($n=Yn,Xn=Hn-$n+1);for(Hn=0;Hn<8;Hn++){if($n>1&&Jn[Hn]===0&&Hn>=Xn&&Hn<Xn+$n){Hn===Xn&&(I+=":",Xn===0&&(I+=":"));continue}I+=Number(_ntohs(Jn[Hn]&65535)).toString(16),I+=Hn<7?":":""}return I},readSockaddr=(e,I)=>{var Hn=HEAP16[e>>1],$n=_ntohs(HEAPU16[e+2>>1]),qn;switch(Hn){case 2:if(I!==16)return{errno:28};qn=HEAP32[e+4>>2],qn=inetNtop4(qn);break;case 10:if(I!==28)return{errno:28};qn=[HEAP32[e+8>>2],HEAP32[e+12>>2],HEAP32[e+16>>2],HEAP32[e+20>>2]],qn=inetNtop6(qn);break;default:return{errno:5}}return{family:Hn,addr:qn,port:$n}},inetPton4=e=>{for(var I=e.split("."),Hn=0;Hn<4;Hn++){var $n=Number(I[Hn]);if(isNaN($n))return null;I[Hn]=$n}return(I[0]|I[1]<<8|I[2]<<16|I[3]<<24)>>>0},jstoi_q=e=>parseInt(e),inetPton6=e=>{var I,Hn,$n,qn,Xn=/^((?=.*::)(?!.*::.+::)(::)?([\dA-F]{1,4}:(:|\b)|){5}|([\dA-F]{1,4}:){6})((([\dA-F]{1,4}((?!\3)::|:\b|$))|(?!\2\3)){2}|(((2[0-4]|1\d|[1-9])?\d|25[0-5])\.?\b){4})$/i,Yn=[];if(!Xn.test(e))return null;if(e==="::")return[0,0,0,0,0,0,0,0];for(e.startsWith("::")?e=e.replace("::","Z:"):e=e.replace("::",":Z:"),e.indexOf(".")>0?(e=e.replace(new RegExp("[.]","g"),":"),I=e.split(":"),I[I.length-4]=jstoi_q(I[I.length-4])+jstoi_q(I[I.length-3])*256,I[I.length-3]=jstoi_q(I[I.length-2])+jstoi_q(I[I.length-1])*256,I=I.slice(0,I.length-2)):I=e.split(":"),$n=0,qn=0,Hn=0;Hn<I.length;Hn++)if(typeof I[Hn]=="string")if(I[Hn]==="Z"){for(qn=0;qn<8-I.length+1;qn++)Yn[Hn+qn]=0;$n=qn-1}else Yn[Hn+$n]=_htons(parseInt(I[Hn],16));else Yn[Hn+$n]=I[Hn];return[Yn[1]<<16|Yn[0],Yn[3]<<16|Yn[2],Yn[5]<<16|Yn[4],Yn[7]<<16|Yn[6]]},DNS={address_map:{id:1,addrs:{},names:{}},lookup_name(e){var I=inetPton4(e);if(I!==null||(I=inetPton6(e),I!==null))return e;var Hn;if(DNS.address_map.addrs[e])Hn=DNS.address_map.addrs[e];else{var $n=DNS.address_map.id++;assert($n<65535,"exceeded max address mappings of 65535"),Hn="172.29."+($n&255)+"."+($n&65280),DNS.address_map.names[Hn]=e,DNS.address_map.addrs[e]=Hn}return Hn},lookup_addr(e){return DNS.address_map.names[e]?DNS.address_map.names[e]:null}},getSocketAddress=(e,I)=>{var Hn=readSockaddr(e,I);if(Hn.errno)throw new FS.ErrnoError(Hn.errno);return Hn.addr=DNS.lookup_addr(Hn.addr)||Hn.addr,Hn};function ___syscall_bind(e,I,Hn,$n,qn,Xn){try{var Yn=getSocketFromFD(e),Kn=getSocketAddress(I,Hn);return Yn.sock_ops.bind(Yn,Kn.addr,Kn.port),0}catch(Jn){if(typeof FS>"u"||Jn.name!=="ErrnoError")throw Jn;return-Jn.errno}}___syscall_bind.sig="iippiii";function ___syscall_chdir(e){try{return e=SYSCALLS.getStr(e),FS.chdir(e),0}catch(I){if(typeof FS>"u"||I.name!=="ErrnoError")throw I;return-I.errno}}___syscall_chdir.sig="ip";function ___syscall_chmod(e,I){try{return e=SYSCALLS.getStr(e),FS.chmod(e,I),0}catch(Hn){if(typeof FS>"u"||Hn.name!=="ErrnoError")throw Hn;return-Hn.errno}}___syscall_chmod.sig="ipi";function ___syscall_connect(e,I,Hn,$n,qn,Xn){try{var Yn=getSocketFromFD(e),Kn=getSocketAddress(I,Hn);return Yn.sock_ops.connect(Yn,Kn.addr,Kn.port),0}catch(Jn){if(typeof FS>"u"||Jn.name!=="ErrnoError")throw Jn;return-Jn.errno}}___syscall_connect.sig="iippiii";function ___syscall_dup(e){try{var I=SYSCALLS.getStreamFromFD(e);return FS.dupStream(I).fd}catch(Hn){if(typeof FS>"u"||Hn.name!=="ErrnoError")throw Hn;return-Hn.errno}}___syscall_dup.sig="ii";function ___syscall_dup3(e,I,Hn){try{var $n=SYSCALLS.getStreamFromFD(e);if($n.fd===I)return-28;if(I<0||I>=FS.MAX_OPEN_FDS)return-8;var qn=FS.getStream(I);return qn&&FS.close(qn),FS.dupStream($n,I).fd}catch(Xn){if(typeof FS>"u"||Xn.name!=="ErrnoError")throw Xn;return-Xn.errno}}___syscall_dup3.sig="iiii";function ___syscall_faccessat(e,I,Hn,$n){try{if(I=SYSCALLS.getStr(I),I=SYSCALLS.calculateAt(e,I),Hn&-8)return-28;var qn=FS.lookupPath(I,{follow:!0}),Xn=qn.node;if(!Xn)return-44;var Yn="";return Hn&4&&(Yn+="r"),Hn&2&&(Yn+="w"),Hn&1&&(Yn+="x"),Yn&&FS.nodePermissions(Xn,Yn)?-2:0}catch(Kn){if(typeof FS>"u"||Kn.name!=="ErrnoError")throw Kn;return-Kn.errno}}___syscall_faccessat.sig="iipii";var ___syscall_fadvise64=(e,I,Hn,$n)=>0;___syscall_fadvise64.sig="iijji";var INT53_MAX=9007199254740992,INT53_MIN=-9007199254740992,bigintToI53Checked=e=>e<INT53_MIN||e>INT53_MAX?NaN:Number(e);function ___syscall_fallocate(e,I,Hn,$n){Hn=bigintToI53Checked(Hn),$n=bigintToI53Checked($n);try{if(isNaN(Hn))return 61;var qn=SYSCALLS.getStreamFromFD(e);return FS.allocate(qn,Hn,$n),0}catch(Xn){if(typeof FS>"u"||Xn.name!=="ErrnoError")throw Xn;return-Xn.errno}}___syscall_fallocate.sig="iiijj";var syscallGetVarargI=()=>{var e=HEAP32[+SYSCALLS.varargs>>2];return SYSCALLS.varargs+=4,e},syscallGetVarargP=syscallGetVarargI;function ___syscall_fcntl64(e,I,Hn){SYSCALLS.varargs=Hn;try{var $n=SYSCALLS.getStreamFromFD(e);switch(I){case 0:{var qn=syscallGetVarargI();if(qn<0)return-28;for(;FS.streams[qn];)qn++;var Xn;return Xn=FS.dupStream($n,qn),Xn.fd}case 1:case 2:return 0;case 3:return $n.flags;case 4:{var qn=syscallGetVarargI();return $n.flags|=qn,0}case 12:{var qn=syscallGetVarargP(),Yn=0;return HEAP16[qn+Yn>>1]=2,0}case 13:case 14:return 0}return-28}catch(Kn){if(typeof FS>"u"||Kn.name!=="ErrnoError")throw Kn;return-Kn.errno}}___syscall_fcntl64.sig="iiip";function ___syscall_fdatasync(e){try{var I=SYSCALLS.getStreamFromFD(e);return 0}catch(Hn){if(typeof FS>"u"||Hn.name!=="ErrnoError")throw Hn;return-Hn.errno}}___syscall_fdatasync.sig="ii";function ___syscall_fstat64(e,I){try{var Hn=SYSCALLS.getStreamFromFD(e);return SYSCALLS.doStat(FS.stat,Hn.path,I)}catch($n){if(typeof FS>"u"||$n.name!=="ErrnoError")throw $n;return-$n.errno}}___syscall_fstat64.sig="iip";function ___syscall_ftruncate64(e,I){I=bigintToI53Checked(I);try{return isNaN(I)?61:(FS.ftruncate(e,I),0)}catch(Hn){if(typeof FS>"u"||Hn.name!=="ErrnoError")throw Hn;return-Hn.errno}}___syscall_ftruncate64.sig="iij";var stringToUTF8=(e,I,Hn)=>stringToUTF8Array(e,HEAPU8,I,Hn);function ___syscall_getcwd(e,I){try{if(I===0)return-28;var Hn=FS.cwd(),$n=lengthBytesUTF8(Hn)+1;return I<$n?-68:(stringToUTF8(Hn,e,I),$n)}catch(qn){if(typeof FS>"u"||qn.name!=="ErrnoError")throw qn;return-qn.errno}}___syscall_getcwd.sig="ipp";function ___syscall_getdents64(e,I,Hn){try{var $n=SYSCALLS.getStreamFromFD(e);$n.getdents||($n.getdents=FS.readdir($n.path));for(var qn=280,Xn=0,Yn=FS.llseek($n,0,1),Kn=Math.floor(Yn/qn),Jn=Math.min($n.getdents.length,Kn+Math.floor(Hn/qn)),Zn=Kn;Zn<Jn;Zn++){var ea,aa,oa=$n.getdents[Zn];if(oa===".")ea=$n.node.id,aa=4;else if(oa===".."){var la=FS.lookupPath($n.path,{parent:!0});ea=la.node.id,aa=4}else{var ra;try{ra=FS.lookupNode($n.node,oa)}catch(ia){if(ia?.errno===28)continue;throw ia}ea=ra.id,aa=FS.isChrdev(ra.mode)?2:FS.isDir(ra.mode)?4:FS.isLink(ra.mode)?10:8}HEAP64[I+Xn>>3]=BigInt(ea),HEAP64[I+Xn+8>>3]=BigInt((Zn+1)*qn),HEAP16[I+Xn+16>>1]=280,HEAP8[I+Xn+18]=aa,stringToUTF8(oa,I+Xn+19,256),Xn+=qn}return FS.llseek($n,Zn*qn,0),Xn}catch(ia){if(typeof FS>"u"||ia.name!=="ErrnoError")throw ia;return-ia.errno}}___syscall_getdents64.sig="iipp";var writeSockaddr=(e,I,Hn,$n,qn)=>{switch(I){case 2:Hn=inetPton4(Hn),zeroMemory(e,16),qn&&(HEAP32[qn>>2]=16),HEAP16[e>>1]=I,HEAP32[e+4>>2]=Hn,HEAP16[e+2>>1]=_htons($n);break;case 10:Hn=inetPton6(Hn),zeroMemory(e,28),qn&&(HEAP32[qn>>2]=28),HEAP32[e>>2]=I,HEAP32[e+8>>2]=Hn[0],HEAP32[e+12>>2]=Hn[1],HEAP32[e+16>>2]=Hn[2],HEAP32[e+20>>2]=Hn[3],HEAP16[e+2>>1]=_htons($n);break;default:return 5}return 0};function ___syscall_getsockname(e,I,Hn,$n,qn,Xn){try{var Yn=getSocketFromFD(e),Kn=writeSockaddr(I,Yn.family,DNS.lookup_name(Yn.saddr||"0.0.0.0"),Yn.sport,Hn);return 0}catch(Jn){if(typeof FS>"u"||Jn.name!=="ErrnoError")throw Jn;return-Jn.errno}}___syscall_getsockname.sig="iippiii";function ___syscall_getsockopt(e,I,Hn,$n,qn,Xn){try{var Yn=getSocketFromFD(e);return I===1&&Hn===4?(HEAP32[$n>>2]=Yn.error,HEAP32[qn>>2]=4,Yn.error=null,0):-50}catch(Kn){if(typeof FS>"u"||Kn.name!=="ErrnoError")throw Kn;return-Kn.errno}}___syscall_getsockopt.sig="iiiippi";function ___syscall_ioctl(e,I,Hn){SYSCALLS.varargs=Hn;try{var $n=SYSCALLS.getStreamFromFD(e);switch(I){case 21509:return $n.tty?0:-59;case 21505:{if(!$n.tty)return-59;if($n.tty.ops.ioctl_tcgets){var qn=$n.tty.ops.ioctl_tcgets($n),Xn=syscallGetVarargP();HEAP32[Xn>>2]=qn.c_iflag||0,HEAP32[Xn+4>>2]=qn.c_oflag||0,HEAP32[Xn+8>>2]=qn.c_cflag||0,HEAP32[Xn+12>>2]=qn.c_lflag||0;for(var Yn=0;Yn<32;Yn++)HEAP8[Xn+Yn+17]=qn.c_cc[Yn]||0;return 0}return 0}case 21510:case 21511:case 21512:return $n.tty?0:-59;case 21506:case 21507:case 21508:{if(!$n.tty)return-59;if($n.tty.ops.ioctl_tcsets){for(var Xn=syscallGetVarargP(),Kn=HEAP32[Xn>>2],Jn=HEAP32[Xn+4>>2],Zn=HEAP32[Xn+8>>2],ea=HEAP32[Xn+12>>2],aa=[],Yn=0;Yn<32;Yn++)aa.push(HEAP8[Xn+Yn+17]);return $n.tty.ops.ioctl_tcsets($n.tty,I,{c_iflag:Kn,c_oflag:Jn,c_cflag:Zn,c_lflag:ea,c_cc:aa})}return 0}case 21519:{if(!$n.tty)return-59;var Xn=syscallGetVarargP();return HEAP32[Xn>>2]=0,0}case 21520:return $n.tty?-28:-59;case 21531:{var Xn=syscallGetVarargP();return FS.ioctl($n,I,Xn)}case 21523:{if(!$n.tty)return-59;if($n.tty.ops.ioctl_tiocgwinsz){var oa=$n.tty.ops.ioctl_tiocgwinsz($n.tty),Xn=syscallGetVarargP();HEAP16[Xn>>1]=oa[0],HEAP16[Xn+2>>1]=oa[1]}return 0}case 21524:return $n.tty?0:-59;case 21515:return $n.tty?0:-59;default:return-28}}catch(la){if(typeof FS>"u"||la.name!=="ErrnoError")throw la;return-la.errno}}___syscall_ioctl.sig="iiip";function ___syscall_lstat64(e,I){try{return e=SYSCALLS.getStr(e),SYSCALLS.doStat(FS.lstat,e,I)}catch(Hn){if(typeof FS>"u"||Hn.name!=="ErrnoError")throw Hn;return-Hn.errno}}___syscall_lstat64.sig="ipp";function ___syscall_mkdirat(e,I,Hn){try{return I=SYSCALLS.getStr(I),I=SYSCALLS.calculateAt(e,I),FS.mkdir(I,Hn,0),0}catch($n){if(typeof FS>"u"||$n.name!=="ErrnoError")throw $n;return-$n.errno}}___syscall_mkdirat.sig="iipi";function ___syscall_newfstatat(e,I,Hn,$n){try{I=SYSCALLS.getStr(I);var qn=$n&256,Xn=$n&4096;return $n=$n&-6401,I=SYSCALLS.calculateAt(e,I,Xn),SYSCALLS.doStat(qn?FS.lstat:FS.stat,I,Hn)}catch(Yn){if(typeof FS>"u"||Yn.name!=="ErrnoError")throw Yn;return-Yn.errno}}___syscall_newfstatat.sig="iippi";function ___syscall_openat(e,I,Hn,$n){SYSCALLS.varargs=$n;try{I=SYSCALLS.getStr(I),I=SYSCALLS.calculateAt(e,I);var qn=$n?syscallGetVarargI():0;return FS.open(I,Hn,qn).fd}catch(Xn){if(typeof FS>"u"||Xn.name!=="ErrnoError")throw Xn;return-Xn.errno}}___syscall_openat.sig="iipip";var PIPEFS={BUCKET_BUFFER_SIZE:8192,mount(e){return FS.createNode(null,"/",16895,0)},createPipe(){var e={buckets:[],refcnt:2};e.buckets.push({buffer:new Uint8Array(PIPEFS.BUCKET_BUFFER_SIZE),offset:0,roffset:0});var I=PIPEFS.nextname(),Hn=PIPEFS.nextname(),$n=FS.createNode(PIPEFS.root,I,4096,0),qn=FS.createNode(PIPEFS.root,Hn,4096,0);$n.pipe=e,qn.pipe=e;var Xn=FS.createStream({path:I,node:$n,flags:0,seekable:!1,stream_ops:PIPEFS.stream_ops});$n.stream=Xn;var Yn=FS.createStream({path:Hn,node:qn,flags:1,seekable:!1,stream_ops:PIPEFS.stream_ops});return qn.stream=Yn,{readable_fd:Xn.fd,writable_fd:Yn.fd}},stream_ops:{poll(e){var I=e.node.pipe;if((e.flags&2097155)===1)return 260;if(I.buckets.length>0)for(var Hn=0;Hn<I.buckets.length;Hn++){var $n=I.buckets[Hn];if($n.offset-$n.roffset>0)return 65}return 0},ioctl(e,I,Hn){return 28},fsync(e){return 28},read(e,I,Hn,$n,qn){for(var Xn=e.node.pipe,Yn=0,Kn=0;Kn<Xn.buckets.length;Kn++){var Jn=Xn.buckets[Kn];Yn+=Jn.offset-Jn.roffset}var Zn=I.subarray(Hn,Hn+$n);if($n<=0)return 0;if(Yn==0)throw new FS.ErrnoError(6);for(var ea=Math.min(Yn,$n),aa=ea,oa=0,Kn=0;Kn<Xn.buckets.length;Kn++){var la=Xn.buckets[Kn],ra=la.offset-la.roffset;if(ea<=ra){var ia=la.buffer.subarray(la.roffset,la.offset);ea<ra?(ia=ia.subarray(0,ea),la.roffset+=ea):oa++,Zn.set(ia);break}else{var ia=la.buffer.subarray(la.roffset,la.offset);Zn.set(ia),Zn=Zn.subarray(ia.byteLength),ea-=ia.byteLength,oa++}}return oa&&oa==Xn.buckets.length&&(oa--,Xn.buckets[oa].offset=0,Xn.buckets[oa].roffset=0),Xn.buckets.splice(0,oa),aa},write(e,I,Hn,$n,qn){var Xn=e.node.pipe,Yn=I.subarray(Hn,Hn+$n),Kn=Yn.byteLength;if(Kn<=0)return 0;var Jn=null;Xn.buckets.length==0?(Jn={buffer:new Uint8Array(PIPEFS.BUCKET_BUFFER_SIZE),offset:0,roffset:0},Xn.buckets.push(Jn)):Jn=Xn.buckets[Xn.buckets.length-1],assert(Jn.offset<=PIPEFS.BUCKET_BUFFER_SIZE);var Zn=PIPEFS.BUCKET_BUFFER_SIZE-Jn.offset;if(Zn>=Kn)return Jn.buffer.set(Yn,Jn.offset),Jn.offset+=Kn,Kn;Zn>0&&(Jn.buffer.set(Yn.subarray(0,Zn),Jn.offset),Jn.offset+=Zn,Yn=Yn.subarray(Zn,Yn.byteLength));for(var ea=Yn.byteLength/PIPEFS.BUCKET_BUFFER_SIZE|0,aa=Yn.byteLength%PIPEFS.BUCKET_BUFFER_SIZE,oa=0;oa<ea;oa++){var la={buffer:new Uint8Array(PIPEFS.BUCKET_BUFFER_SIZE),offset:PIPEFS.BUCKET_BUFFER_SIZE,roffset:0};Xn.buckets.push(la),la.buffer.set(Yn.subarray(0,PIPEFS.BUCKET_BUFFER_SIZE)),Yn=Yn.subarray(PIPEFS.BUCKET_BUFFER_SIZE,Yn.byteLength)}if(aa>0){var la={buffer:new Uint8Array(PIPEFS.BUCKET_BUFFER_SIZE),offset:Yn.byteLength,roffset:0};Xn.buckets.push(la),la.buffer.set(Yn)}return Kn},close(e){var I=e.node.pipe;I.refcnt--,I.refcnt===0&&(I.buckets=null)}},nextname(){return PIPEFS.nextname.current||(PIPEFS.nextname.current=0),"pipe["+PIPEFS.nextname.current+++"]"}};function ___syscall_pipe(e){try{if(e==0)throw new FS.ErrnoError(21);var I=PIPEFS.createPipe();return HEAP32[e>>2]=I.readable_fd,HEAP32[e+4>>2]=I.writable_fd,0}catch(Hn){if(typeof FS>"u"||Hn.name!=="ErrnoError")throw Hn;return-Hn.errno}}___syscall_pipe.sig="ip";function ___syscall_poll(e,I,Hn){try{for(var $n=0,qn=0;qn<I;qn++){var Xn=e+8*qn,Yn=HEAP32[Xn>>2],Kn=HEAP16[Xn+4>>1],Jn=32,Zn=FS.getStream(Yn);Zn&&(Jn=SYSCALLS.DEFAULT_POLLMASK,Zn.stream_ops.poll&&(Jn=Zn.stream_ops.poll(Zn,-1))),Jn&=Kn|8|16,Jn&&$n++,HEAP16[Xn+6>>1]=Jn}return $n}catch(ea){if(typeof FS>"u"||ea.name!=="ErrnoError")throw ea;return-ea.errno}}___syscall_poll.sig="ipii";function ___syscall_readlinkat(e,I,Hn,$n){try{if(I=SYSCALLS.getStr(I),I=SYSCALLS.calculateAt(e,I),$n<=0)return-28;var qn=FS.readlink(I),Xn=Math.min($n,lengthBytesUTF8(qn)),Yn=HEAP8[Hn+Xn];return stringToUTF8(qn,Hn,$n+1),HEAP8[Hn+Xn]=Yn,Xn}catch(Kn){if(typeof FS>"u"||Kn.name!=="ErrnoError")throw Kn;return-Kn.errno}}___syscall_readlinkat.sig="iippp";function ___syscall_recvfrom(e,I,Hn,$n,qn,Xn){try{var Yn=getSocketFromFD(e),Kn=Yn.sock_ops.recvmsg(Yn,Hn);if(!Kn)return 0;if(qn)var Jn=writeSockaddr(qn,Yn.family,DNS.lookup_name(Kn.addr),Kn.port,Xn);return HEAPU8.set(Kn.buffer,I),Kn.buffer.byteLength}catch(Zn){if(typeof FS>"u"||Zn.name!=="ErrnoError")throw Zn;return-Zn.errno}}___syscall_recvfrom.sig="iippipp";function ___syscall_renameat(e,I,Hn,$n){try{return I=SYSCALLS.getStr(I),$n=SYSCALLS.getStr($n),I=SYSCALLS.calculateAt(e,I),$n=SYSCALLS.calculateAt(Hn,$n),FS.rename(I,$n),0}catch(qn){if(typeof FS>"u"||qn.name!=="ErrnoError")throw qn;return-qn.errno}}___syscall_renameat.sig="iipip";function ___syscall_rmdir(e){try{return e=SYSCALLS.getStr(e),FS.rmdir(e),0}catch(I){if(typeof FS>"u"||I.name!=="ErrnoError")throw I;return-I.errno}}___syscall_rmdir.sig="ip";function ___syscall_sendto(e,I,Hn,$n,qn,Xn){try{var Yn=getSocketFromFD(e);if(!qn)return FS.write(Yn.stream,HEAP8,I,Hn);var Kn=getSocketAddress(qn,Xn);return Yn.sock_ops.sendmsg(Yn,HEAP8,I,Hn,Kn.addr,Kn.port)}catch(Jn){if(typeof FS>"u"||Jn.name!=="ErrnoError")throw Jn;return-Jn.errno}}___syscall_sendto.sig="iippipp";function ___syscall_socket(e,I,Hn){try{var $n=SOCKFS.createSocket(e,I,Hn);return $n.stream.fd}catch(qn){if(typeof FS>"u"||qn.name!=="ErrnoError")throw qn;return-qn.errno}}___syscall_socket.sig="iiiiiii";function ___syscall_stat64(e,I){try{return e=SYSCALLS.getStr(e),SYSCALLS.doStat(FS.stat,e,I)}catch(Hn){if(typeof FS>"u"||Hn.name!=="ErrnoError")throw Hn;return-Hn.errno}}___syscall_stat64.sig="ipp";function ___syscall_symlinkat(e,I,Hn){try{return e=SYSCALLS.getStr(e),Hn=SYSCALLS.getStr(Hn),Hn=SYSCALLS.calculateAt(I,Hn),FS.symlink(e,Hn),0}catch($n){if(typeof FS>"u"||$n.name!=="ErrnoError")throw $n;return-$n.errno}}___syscall_symlinkat.sig="ipip";function ___syscall_truncate64(e,I){I=bigintToI53Checked(I);try{return isNaN(I)?61:(e=SYSCALLS.getStr(e),FS.truncate(e,I),0)}catch(Hn){if(typeof FS>"u"||Hn.name!=="ErrnoError")throw Hn;return-Hn.errno}}___syscall_truncate64.sig="ipj";function ___syscall_unlinkat(e,I,Hn){try{return I=SYSCALLS.getStr(I),I=SYSCALLS.calculateAt(e,I),Hn===0?FS.unlink(I):Hn===512?FS.rmdir(I):abort("Invalid flags passed to unlinkat"),0}catch($n){if(typeof FS>"u"||$n.name!=="ErrnoError")throw $n;return-$n.errno}}___syscall_unlinkat.sig="iipi";var ___table_base=new WebAssembly.Global({value:"i32",mutable:!1},1),__abort_js=()=>abort("");__abort_js.sig="v";var ENV={},stackAlloc=e=>__emscripten_stack_alloc(e),stringToUTF8OnStack=e=>{var I=lengthBytesUTF8(e)+1,Hn=stackAlloc(I);return stringToUTF8(e,Hn,I),Hn},dlSetError=e=>{var I=stackSave(),Hn=stringToUTF8OnStack(e);___dl_seterr(Hn,0),stackRestore(I)},dlopenInternal=(e,I)=>{var Hn=UTF8ToString(e+36),$n=HEAP32[e+4>>2];Hn=PATH.normalize(Hn);var qn=!!($n&256),Xn=qn?null:{},Yn={global:qn,nodelete:!!($n&4096),loadAsync:I.loadAsync};try{return loadDynamicLibrary(Hn,Yn,Xn,e)}catch(Kn){return dlSetError(`Could not load dynamic lib: ${Hn}
${Kn}`),0}},__dlopen_js=e=>dlopenInternal(e,{loadAsync:!1});__dlopen_js.sig="pp";var __dlsym_js=(e,I,Hn)=>{I=UTF8ToString(I);var $n,qn,Xn=LDSO.loadedLibsByHandle[e];if(!Xn.exports.hasOwnProperty(I)||Xn.exports[I].stub)return dlSetError(`Tried to lookup unknown symbol "${I}" in dynamic lib: ${Xn.name}`),0;if(qn=Object.keys(Xn.exports).indexOf(I),$n=Xn.exports[I],typeof $n=="function"){var Yn=getFunctionAddress($n);Yn?$n=Yn:($n=addFunction($n,$n.sig),HEAPU32[Hn>>2]=qn)}return $n};__dlsym_js.sig="pppp";var __emscripten_memcpy_js=(e,I,Hn)=>HEAPU8.copyWithin(e,I,I+Hn);__emscripten_memcpy_js.sig="vppp";var runtimeKeepaliveCounter=0,__emscripten_runtime_keepalive_clear=()=>{noExitRuntime=!1,runtimeKeepaliveCounter=0};__emscripten_runtime_keepalive_clear.sig="v";var __emscripten_system=e=>{if(ENVIRONMENT_IS_NODE){if(!e)return 1;var I=UTF8ToString(e);if(!I.length)return 0;var Hn=require("child_process"),$n=Hn.spawnSync(I,[],{shell:!0,stdio:"inherit"}),qn=(Yn,Kn)=>Yn<<8|Kn;if($n.status===null){var Xn=Yn=>{switch(Yn){case"SIGHUP":return 1;case"SIGQUIT":return 3;case"SIGFPE":return 8;case"SIGKILL":return 9;case"SIGALRM":return 14;case"SIGTERM":return 15;default:return 2}};return qn(0,Xn($n.signal))}return qn($n.status,0)}return e?-52:0};__emscripten_system.sig="ip";var __emscripten_throw_longjmp=()=>{throw 1/0};__emscripten_throw_longjmp.sig="v";function __gmtime_js(e,I){e=bigintToI53Checked(e);var Hn=new Date(e*1e3);HEAP32[I>>2]=Hn.getUTCSeconds(),HEAP32[I+4>>2]=Hn.getUTCMinutes(),HEAP32[I+8>>2]=Hn.getUTCHours(),HEAP32[I+12>>2]=Hn.getUTCDate(),HEAP32[I+16>>2]=Hn.getUTCMonth(),HEAP32[I+20>>2]=Hn.getUTCFullYear()-1900,HEAP32[I+24>>2]=Hn.getUTCDay();var $n=Date.UTC(Hn.getUTCFullYear(),0,1,0,0,0,0),qn=(Hn.getTime()-$n)/(1e3*60*60*24)|0;HEAP32[I+28>>2]=qn}__gmtime_js.sig="vjp";var isLeapYear=e=>e%4===0&&(e%100!==0||e%400===0),MONTH_DAYS_LEAP_CUMULATIVE=[0,31,60,91,121,152,182,213,244,274,305,335],MONTH_DAYS_REGULAR_CUMULATIVE=[0,31,59,90,120,151,181,212,243,273,304,334],ydayFromDate=e=>{var I=isLeapYear(e.getFullYear()),Hn=I?MONTH_DAYS_LEAP_CUMULATIVE:MONTH_DAYS_REGULAR_CUMULATIVE,$n=Hn[e.getMonth()]+e.getDate()-1;return $n};function __localtime_js(e,I){e=bigintToI53Checked(e);var Hn=new Date(e*1e3);HEAP32[I>>2]=Hn.getSeconds(),HEAP32[I+4>>2]=Hn.getMinutes(),HEAP32[I+8>>2]=Hn.getHours(),HEAP32[I+12>>2]=Hn.getDate(),HEAP32[I+16>>2]=Hn.getMonth(),HEAP32[I+20>>2]=Hn.getFullYear()-1900,HEAP32[I+24>>2]=Hn.getDay();var $n=ydayFromDate(Hn)|0;HEAP32[I+28>>2]=$n,HEAP32[I+36>>2]=-(Hn.getTimezoneOffset()*60);var qn=new Date(Hn.getFullYear(),0,1),Xn=new Date(Hn.getFullYear(),6,1).getTimezoneOffset(),Yn=qn.getTimezoneOffset(),Kn=(Xn!=Yn&&Hn.getTimezoneOffset()==Math.min(Yn,Xn))|0;HEAP32[I+32>>2]=Kn}__localtime_js.sig="vjp";function __mmap_js(e,I,Hn,$n,qn,Xn,Yn){qn=bigintToI53Checked(qn);try{if(isNaN(qn))return 61;var Kn=SYSCALLS.getStreamFromFD($n),Jn=FS.mmap(Kn,e,qn,I,Hn),Zn=Jn.ptr;return HEAP32[Xn>>2]=Jn.allocated,HEAPU32[Yn>>2]=Zn,0}catch(ea){if(typeof FS>"u"||ea.name!=="ErrnoError")throw ea;return-ea.errno}}__mmap_js.sig="ipiiijpp";function __munmap_js(e,I,Hn,$n,qn,Xn){Xn=bigintToI53Checked(Xn);try{var Yn=SYSCALLS.getStreamFromFD(qn);Hn&2&&SYSCALLS.doMsync(e,Yn,I,$n,Xn)}catch(Kn){if(typeof FS>"u"||Kn.name!=="ErrnoError")throw Kn;return-Kn.errno}}__munmap_js.sig="ippiiij";var timers={},handleException=e=>{if(e instanceof ExitStatus||e=="unwind")return EXITSTATUS;quit_(1,e)},keepRuntimeAlive=()=>noExitRuntime||runtimeKeepaliveCounter>0,_proc_exit=e=>{EXITSTATUS=e,keepRuntimeAlive()||(Module.onExit?.(e),ABORT=!0),quit_(e,new ExitStatus(e))};_proc_exit.sig="vi";var exitJS=(e,I)=>{EXITSTATUS=e,_proc_exit(e)},_exit=exitJS;_exit.sig="vi";var maybeExit=()=>{if(!keepRuntimeAlive())try{_exit(EXITSTATUS)}catch(e){handleException(e)}},callUserCallback=e=>{if(!ABORT)try{e(),maybeExit()}catch(I){handleException(I)}},_emscripten_get_now=()=>performance.now();_emscripten_get_now.sig="d";var __setitimer_js=(e,I)=>{if(timers[e]&&(clearTimeout(timers[e].id),delete timers[e]),!I)return 0;var Hn=setTimeout(()=>{delete timers[e],callUserCallback(()=>__emscripten_timeout(e,_emscripten_get_now()))},I);return timers[e]={id:Hn,timeout_ms:I},0};__setitimer_js.sig="iid";var __tzset_js=(e,I,Hn,$n)=>{var qn=new Date().getFullYear(),Xn=new Date(qn,0,1),Yn=new Date(qn,6,1),Kn=Xn.getTimezoneOffset(),Jn=Yn.getTimezoneOffset(),Zn=Math.max(Kn,Jn);HEAPU32[e>>2]=Zn*60,HEAP32[I>>2]=+(Kn!=Jn);var ea=la=>{var ra=la>=0?"-":"+",ia=Math.abs(la),da=String(Math.floor(ia/60)).padStart(2,"0"),Ea=String(ia%60).padStart(2,"0");return`UTC${ra}${da}${Ea}`},aa=ea(Kn),oa=ea(Jn);Jn<Kn?(stringToUTF8(aa,Hn,17),stringToUTF8(oa,$n,17)):(stringToUTF8(aa,$n,17),stringToUTF8(oa,Hn,17))};__tzset_js.sig="vpppp";var _emscripten_date_now=()=>Date.now();_emscripten_date_now.sig="d";var checkWasiClock=e=>e>=0&&e<=3;function _clock_time_get(e,I,Hn){if(!checkWasiClock(e))return 28;var $n;e===0?$n=_emscripten_date_now():$n=_emscripten_get_now();var qn=Math.round($n*1e3*1e3);return HEAP64[Hn>>3]=BigInt(qn),0}_clock_time_get.sig="iijp";var readEmAsmArgsArray=[],readEmAsmArgs=(e,I)=>{readEmAsmArgsArray.length=0;for(var Hn;Hn=HEAPU8[e++];){var $n=Hn!=105;$n&=Hn!=112,I+=$n&&I%8?4:0,readEmAsmArgsArray.push(Hn==112?HEAPU32[I>>2]:Hn==106?HEAP64[I>>3]:Hn==105?HEAP32[I>>2]:HEAPF64[I>>3]),I+=$n?8:4}return readEmAsmArgsArray},runEmAsmFunction=(e,I,Hn)=>{var $n=readEmAsmArgs(I,Hn);return ASM_CONSTS[e](...$n)},_emscripten_asm_const_int=(e,I,Hn)=>runEmAsmFunction(e,I,Hn);_emscripten_asm_const_int.sig="ippp";var _emscripten_force_exit=e=>{__emscripten_runtime_keepalive_clear(),_exit(e)};_emscripten_force_exit.sig="vi";var getHeapMax=()=>2147483648,growMemory=e=>{var I=wasmMemory.buffer,Hn=(e-I.byteLength+65535)/65536|0;try{return wasmMemory.grow(Hn),updateMemoryViews(),1}catch{}},_emscripten_resize_heap=e=>{var I=HEAPU8.length;e>>>=0;var Hn=getHeapMax();if(e>Hn)return!1;for(var $n=1;$n<=4;$n*=2){var qn=I*(1+.2/$n);qn=Math.min(qn,e+100663296);var Xn=Math.min(Hn,alignMemory(Math.max(e,qn),65536)),Yn=growMemory(Xn);if(Yn)return!0}return!1};_emscripten_resize_heap.sig="ip";var _emscripten_set_main_loop_timing=(e,I)=>{if(MainLoop.timingMode=e,MainLoop.timingValue=I,!MainLoop.func)return 1;if(MainLoop.running||(MainLoop.running=!0),e==0)MainLoop.scheduler=function(){var Xn=Math.max(0,MainLoop.tickStartTime+I-_emscripten_get_now())|0;setTimeout(MainLoop.runner,Xn)},MainLoop.method="timeout";else if(e==1)MainLoop.scheduler=function(){MainLoop.requestAnimationFrame(MainLoop.runner)},MainLoop.method="rAF";else if(e==2){if(typeof MainLoop.setImmediate>"u")if(typeof setImmediate>"u"){var Hn=[],$n="setimmediate",qn=Xn=>{(Xn.data===$n||Xn.data.target===$n)&&(Xn.stopPropagation(),Hn.shift()())};addEventListener("message",qn,!0),MainLoop.setImmediate=Xn=>{Hn.push(Xn),ENVIRONMENT_IS_WORKER?(Module.setImmediates??(Module.setImmediates=[]),Module.setImmediates.push(Xn),postMessage({target:$n})):postMessage($n,"*")}}else MainLoop.setImmediate=setImmediate;MainLoop.scheduler=function(){MainLoop.setImmediate(MainLoop.runner)},MainLoop.method="immediate"}return 0};_emscripten_set_main_loop_timing.sig="iii";var MainLoop={running:!1,scheduler:null,method:"",currentlyRunningMainloop:0,func:null,arg:0,timingMode:0,timingValue:0,currentFrameNumber:0,queue:[],preMainLoop:[],postMainLoop:[],pause(){MainLoop.scheduler=null,MainLoop.currentlyRunningMainloop++},resume(){MainLoop.currentlyRunningMainloop++;var e=MainLoop.timingMode,I=MainLoop.timingValue,Hn=MainLoop.func;MainLoop.func=null,setMainLoop(Hn,0,!1,MainLoop.arg,!0),_emscripten_set_main_loop_timing(e,I),MainLoop.scheduler()},updateStatus(){if(Module.setStatus){var e=Module.statusMessage||"Please wait...",I=MainLoop.remainingBlockers??0,Hn=MainLoop.expectedBlockers??0;I?I<Hn?Module.setStatus("{message} ({expected - remaining}/{expected})"):Module.setStatus(e):Module.setStatus("")}},init(){Module.preMainLoop&&MainLoop.preMainLoop.push(Module.preMainLoop),Module.postMainLoop&&MainLoop.postMainLoop.push(Module.postMainLoop)},runIter(e){if(!ABORT){for(var I of MainLoop.preMainLoop)if(I()===!1)return;callUserCallback(e);for(var Hn of MainLoop.postMainLoop)Hn()}},nextRAF:0,fakeRequestAnimationFrame(e){var I=Date.now();if(MainLoop.nextRAF===0)MainLoop.nextRAF=I+1e3/60;else for(;I+2>=MainLoop.nextRAF;)MainLoop.nextRAF+=1e3/60;var Hn=Math.max(MainLoop.nextRAF-I,0);setTimeout(e,Hn)},requestAnimationFrame(e){if(typeof requestAnimationFrame=="function"){requestAnimationFrame(e);return}var I=MainLoop.fakeRequestAnimationFrame;I(e)}},setMainLoop=(e,I,Hn,$n,qn)=>{MainLoop.func=e,MainLoop.arg=$n;var Xn=MainLoop.currentlyRunningMainloop;function Yn(){return Xn<MainLoop.currentlyRunningMainloop?(maybeExit(),!1):!0}if(MainLoop.running=!1,MainLoop.runner=function(){if(!ABORT){if(MainLoop.queue.length>0){var Kn=MainLoop.queue.shift();if(Kn.func(Kn.arg),MainLoop.remainingBlockers){var Jn=MainLoop.remainingBlockers,Zn=Jn%1==0?Jn-1:Math.floor(Jn);Kn.counted?MainLoop.remainingBlockers=Zn:(Zn=Zn+.5,MainLoop.remainingBlockers=(8*Jn+Zn)/9)}if(MainLoop.updateStatus(),!Yn())return;setTimeout(MainLoop.runner,0);return}if(Yn()){if(MainLoop.currentFrameNumber=MainLoop.currentFrameNumber+1|0,MainLoop.timingMode==1&&MainLoop.timingValue>1&&MainLoop.currentFrameNumber%MainLoop.timingValue!=0){MainLoop.scheduler();return}else MainLoop.timingMode==0&&(MainLoop.tickStartTime=_emscripten_get_now());MainLoop.runIter(e),Yn()&&MainLoop.scheduler()}}},qn||(I&&I>0?_emscripten_set_main_loop_timing(0,1e3/I):_emscripten_set_main_loop_timing(1,1),MainLoop.scheduler()),Hn)throw"unwind"},_emscripten_set_main_loop=(e,I,Hn)=>{var $n=getWasmTableEntry(e);setMainLoop($n,I,Hn)};_emscripten_set_main_loop.sig="vpii";var getExecutableName=()=>thisProgram||"./this.program",getEnvStrings=()=>{if(!getEnvStrings.strings){var e=(typeof navigator=="object"&&navigator.languages&&navigator.languages[0]||"C").replace("-","_")+".UTF-8",I={USER:"web_user",LOGNAME:"web_user",PATH:"/",PWD:"/",HOME:"/home/web_user",LANG:e,_:getExecutableName()};for(var Hn in ENV)ENV[Hn]===void 0?delete I[Hn]:I[Hn]=ENV[Hn];var $n=[];for(var Hn in I)$n.push(`${Hn}=${I[Hn]}`);getEnvStrings.strings=$n}return getEnvStrings.strings},stringToAscii=(e,I)=>{for(var Hn=0;Hn<e.length;++Hn)HEAP8[I++]=e.charCodeAt(Hn);HEAP8[I]=0},_environ_get=(e,I)=>{var Hn=0;return getEnvStrings().forEach(($n,qn)=>{var Xn=I+Hn;HEAPU32[e+qn*4>>2]=Xn,stringToAscii($n,Xn),Hn+=$n.length+1}),0};_environ_get.sig="ipp";var _environ_sizes_get=(e,I)=>{var Hn=getEnvStrings();HEAPU32[e>>2]=Hn.length;var $n=0;return Hn.forEach(qn=>$n+=qn.length+1),HEAPU32[I>>2]=$n,0};_environ_sizes_get.sig="ipp";function _fd_close(e){try{var I=SYSCALLS.getStreamFromFD(e);return FS.close(I),0}catch(Hn){if(typeof FS>"u"||Hn.name!=="ErrnoError")throw Hn;return Hn.errno}}_fd_close.sig="ii";function _fd_fdstat_get(e,I){try{var Hn=0,$n=0,qn=0,Xn=SYSCALLS.getStreamFromFD(e),Yn=Xn.tty?2:FS.isDir(Xn.mode)?3:FS.isLink(Xn.mode)?7:4;return HEAP8[I]=Yn,HEAP16[I+2>>1]=qn,HEAP64[I+8>>3]=BigInt(Hn),HEAP64[I+16>>3]=BigInt($n),0}catch(Kn){if(typeof FS>"u"||Kn.name!=="ErrnoError")throw Kn;return Kn.errno}}_fd_fdstat_get.sig="iip";var doReadv=(e,I,Hn,$n)=>{for(var qn=0,Xn=0;Xn<Hn;Xn++){var Yn=HEAPU32[I>>2],Kn=HEAPU32[I+4>>2];I+=8;var Jn=FS.read(e,HEAP8,Yn,Kn,$n);if(Jn<0)return-1;if(qn+=Jn,Jn<Kn)break;typeof $n<"u"&&($n+=Jn)}return qn};function _fd_pread(e,I,Hn,$n,qn){$n=bigintToI53Checked($n);try{if(isNaN($n))return 61;var Xn=SYSCALLS.getStreamFromFD(e),Yn=doReadv(Xn,I,Hn,$n);return HEAPU32[qn>>2]=Yn,0}catch(Kn){if(typeof FS>"u"||Kn.name!=="ErrnoError")throw Kn;return Kn.errno}}_fd_pread.sig="iippjp";var doWritev=(e,I,Hn,$n)=>{for(var qn=0,Xn=0;Xn<Hn;Xn++){var Yn=HEAPU32[I>>2],Kn=HEAPU32[I+4>>2];I+=8;var Jn=FS.write(e,HEAP8,Yn,Kn,$n);if(Jn<0)return-1;if(qn+=Jn,Jn<Kn)break;typeof $n<"u"&&($n+=Jn)}return qn};function _fd_pwrite(e,I,Hn,$n,qn){$n=bigintToI53Checked($n);try{if(isNaN($n))return 61;var Xn=SYSCALLS.getStreamFromFD(e),Yn=doWritev(Xn,I,Hn,$n);return HEAPU32[qn>>2]=Yn,0}catch(Kn){if(typeof FS>"u"||Kn.name!=="ErrnoError")throw Kn;return Kn.errno}}_fd_pwrite.sig="iippjp";function _fd_read(e,I,Hn,$n){try{var qn=SYSCALLS.getStreamFromFD(e),Xn=doReadv(qn,I,Hn);return HEAPU32[$n>>2]=Xn,0}catch(Yn){if(typeof FS>"u"||Yn.name!=="ErrnoError")throw Yn;return Yn.errno}}_fd_read.sig="iippp";function _fd_seek(e,I,Hn,$n){I=bigintToI53Checked(I);try{if(isNaN(I))return 61;var qn=SYSCALLS.getStreamFromFD(e);return FS.llseek(qn,I,Hn),HEAP64[$n>>3]=BigInt(qn.position),qn.getdents&&I===0&&Hn===0&&(qn.getdents=null),0}catch(Xn){if(typeof FS>"u"||Xn.name!=="ErrnoError")throw Xn;return Xn.errno}}_fd_seek.sig="iijip";function _fd_sync(e){try{var I=SYSCALLS.getStreamFromFD(e);return I.stream_ops?.fsync?I.stream_ops.fsync(I):0}catch(Hn){if(typeof FS>"u"||Hn.name!=="ErrnoError")throw Hn;return Hn.errno}}_fd_sync.sig="ii";function _fd_write(e,I,Hn,$n){try{var qn=SYSCALLS.getStreamFromFD(e),Xn=doWritev(qn,I,Hn);return HEAPU32[$n>>2]=Xn,0}catch(Yn){if(typeof FS>"u"||Yn.name!=="ErrnoError")throw Yn;return Yn.errno}}_fd_write.sig="iippp";var _getaddrinfo=(e,I,Hn,$n)=>{var qn=0,Xn=0,Yn=0,Kn=0,Jn=0,Zn=0,ea;function aa(oa,la,ra,ia,da,Ea){var na,ta,sa,ca;return ta=oa===10?28:16,da=oa===10?inetNtop6(da):inetNtop4(da),na=_malloc(ta),ca=writeSockaddr(na,oa,da,Ea),assert(!ca),sa=_malloc(32),HEAP32[sa+4>>2]=oa,HEAP32[sa+8>>2]=la,HEAP32[sa+12>>2]=ra,HEAPU32[sa+24>>2]=ia,HEAPU32[sa+20>>2]=na,oa===10?HEAP32[sa+16>>2]=28:HEAP32[sa+16>>2]=16,HEAP32[sa+28>>2]=0,sa}if(Hn&&(Yn=HEAP32[Hn>>2],Kn=HEAP32[Hn+4>>2],Jn=HEAP32[Hn+8>>2],Zn=HEAP32[Hn+12>>2]),Jn&&!Zn&&(Zn=Jn===2?17:6),!Jn&&Zn&&(Jn=Zn===17?2:1),Zn===0&&(Zn=6),Jn===0&&(Jn=1),!e&&!I)return-2;if(Yn&-1088||Hn!==0&&HEAP32[Hn>>2]&2&&!e)return-1;if(Yn&32)return-2;if(Jn!==0&&Jn!==1&&Jn!==2)return-7;if(Kn!==0&&Kn!==2&&Kn!==10)return-6;if(I&&(I=UTF8ToString(I),Xn=parseInt(I,10),isNaN(Xn)))return Yn&1024?-2:-8;if(!e)return Kn===0&&(Kn=2),Yn&1||(Kn===2?qn=_htonl(2130706433):qn=[0,0,0,_htonl(1)]),ea=aa(Kn,Jn,Zn,null,qn,Xn),HEAPU32[$n>>2]=ea,0;if(e=UTF8ToString(e),qn=inetPton4(e),qn!==null)if(Kn===0||Kn===2)Kn=2;else if(Kn===10&&Yn&8)qn=[0,0,_htonl(65535),qn],Kn=10;else return-2;else if(qn=inetPton6(e),qn!==null)if(Kn===0||Kn===10)Kn=10;else return-2;return qn!=null?(ea=aa(Kn,Jn,Zn,e,qn,Xn),HEAPU32[$n>>2]=ea,0):Yn&4?-2:(e=DNS.lookup_name(e),qn=inetPton4(e),Kn===0?Kn=2:Kn===10&&(qn=[0,0,_htonl(65535),qn]),ea=aa(Kn,Jn,Zn,null,qn,Xn),HEAPU32[$n>>2]=ea,0)};_getaddrinfo.sig="ipppp";var _getnameinfo=(e,I,Hn,$n,qn,Xn,Yn)=>{var Kn=readSockaddr(e,I);if(Kn.errno)return-6;var Jn=Kn.port,Zn=Kn.addr,ea=!1;if(Hn&&$n){var aa;if(Yn&1||!(aa=DNS.lookup_addr(Zn))){if(Yn&8)return-2}else Zn=aa;var oa=stringToUTF8(Zn,Hn,$n);oa+1>=$n&&(ea=!0)}if(qn&&Xn){Jn=""+Jn;var oa=stringToUTF8(Jn,qn,Xn);oa+1>=Xn&&(ea=!0)}return ea?-12:0};_getnameinfo.sig="ipipipii";var stringToNewUTF8=e=>{var I=lengthBytesUTF8(e)+1,Hn=_malloc(I);return Hn&&stringToUTF8(e,Hn,I),Hn},getCFunc=e=>{var I=Module["_"+e];return I},writeArrayToMemory=(e,I)=>{HEAP8.set(e,I)},ccall=(e,I,Hn,$n,qn)=>{var Xn={string:ra=>{var ia=0;return ra!=null&&ra!==0&&(ia=stringToUTF8OnStack(ra)),ia},array:ra=>{var ia=stackAlloc(ra.length);return writeArrayToMemory(ra,ia),ia}};function Yn(ra){return I==="string"?UTF8ToString(ra):I==="boolean"?!!ra:ra}var Kn=getCFunc(e),Jn=[],Zn=0;if($n)for(var ea=0;ea<$n.length;ea++){var aa=Xn[Hn[ea]];aa?(Zn===0&&(Zn=stackSave()),Jn[ea]=aa($n[ea])):Jn[ea]=$n[ea]}var oa=Kn(...Jn);function la(ra){return Zn!==0&&stackRestore(Zn),Yn(ra)}return oa=la(oa),oa},cwrap=(e,I,Hn,$n)=>{var qn=!Hn||Hn.every(Yn=>Yn==="number"||Yn==="boolean"),Xn=I!=="string";return Xn&&qn&&!$n?getCFunc(e):(...Yn)=>ccall(e,I,Hn,Yn)},FS_createPath=FS.createPath,FS_unlink=e=>FS.unlink(e),FS_createLazyFile=FS.createLazyFile,FS_createDevice=FS.createDevice,setTempRet0=e=>__emscripten_tempret_set(e),_setTempRet0=setTempRet0;Module._setTempRet0=_setTempRet0;var getTempRet0=e=>__emscripten_tempret_get(),_getTempRet0=getTempRet0;Module._getTempRet0=_getTempRet0,registerWasmPlugin(),FS.createPreloadedFile=FS_createPreloadedFile,FS.staticInit(),Module.FS_createPath=FS.createPath,Module.FS_createDataFile=FS.createDataFile,Module.FS_createPreloadedFile=FS.createPreloadedFile,Module.FS_unlink=FS.unlink,Module.FS_createLazyFile=FS.createLazyFile,Module.FS_createDevice=FS.createDevice,MEMFS.doesNotExistError=new FS.ErrnoError(44),MEMFS.doesNotExistError.stack="<generic error, no stack>",ENVIRONMENT_IS_NODE&&NODEFS.staticInit(),Module.requestAnimationFrame=MainLoop.requestAnimationFrame,Module.pauseMainLoop=MainLoop.pause,Module.resumeMainLoop=MainLoop.resume,MainLoop.init();var wasmImports={__assert_fail:___assert_fail,__call_sighandler:___call_sighandler,__heap_base:___heap_base,__indirect_function_table:wasmTable,__memory_base:___memory_base,__stack_pointer:___stack_pointer,__syscall__newselect:___syscall__newselect,__syscall_bind:___syscall_bind,__syscall_chdir:___syscall_chdir,__syscall_chmod:___syscall_chmod,__syscall_connect:___syscall_connect,__syscall_dup:___syscall_dup,__syscall_dup3:___syscall_dup3,__syscall_faccessat:___syscall_faccessat,__syscall_fadvise64:___syscall_fadvise64,__syscall_fallocate:___syscall_fallocate,__syscall_fcntl64:___syscall_fcntl64,__syscall_fdatasync:___syscall_fdatasync,__syscall_fstat64:___syscall_fstat64,__syscall_ftruncate64:___syscall_ftruncate64,__syscall_getcwd:___syscall_getcwd,__syscall_getdents64:___syscall_getdents64,__syscall_getsockname:___syscall_getsockname,__syscall_getsockopt:___syscall_getsockopt,__syscall_ioctl:___syscall_ioctl,__syscall_lstat64:___syscall_lstat64,__syscall_mkdirat:___syscall_mkdirat,__syscall_newfstatat:___syscall_newfstatat,__syscall_openat:___syscall_openat,__syscall_pipe:___syscall_pipe,__syscall_poll:___syscall_poll,__syscall_readlinkat:___syscall_readlinkat,__syscall_recvfrom:___syscall_recvfrom,__syscall_renameat:___syscall_renameat,__syscall_rmdir:___syscall_rmdir,__syscall_sendto:___syscall_sendto,__syscall_socket:___syscall_socket,__syscall_stat64:___syscall_stat64,__syscall_symlinkat:___syscall_symlinkat,__syscall_truncate64:___syscall_truncate64,__syscall_unlinkat:___syscall_unlinkat,__table_base:___table_base,_abort_js:__abort_js,_dlopen_js:__dlopen_js,_dlsym_js:__dlsym_js,_emscripten_memcpy_js:__emscripten_memcpy_js,_emscripten_runtime_keepalive_clear:__emscripten_runtime_keepalive_clear,_emscripten_system:__emscripten_system,_emscripten_throw_longjmp:__emscripten_throw_longjmp,_gmtime_js:__gmtime_js,_localtime_js:__localtime_js,_mmap_js:__mmap_js,_munmap_js:__munmap_js,_setitimer_js:__setitimer_js,_tzset_js:__tzset_js,clock_time_get:_clock_time_get,emscripten_asm_const_int:_emscripten_asm_const_int,emscripten_date_now:_emscripten_date_now,emscripten_force_exit:_emscripten_force_exit,emscripten_get_now:_emscripten_get_now,emscripten_resize_heap:_emscripten_resize_heap,emscripten_set_main_loop:_emscripten_set_main_loop,environ_get:_environ_get,environ_sizes_get:_environ_sizes_get,exit:_exit,fd_close:_fd_close,fd_fdstat_get:_fd_fdstat_get,fd_pread:_fd_pread,fd_pwrite:_fd_pwrite,fd_read:_fd_read,fd_seek:_fd_seek,fd_sync:_fd_sync,fd_write:_fd_write,getTempRet0:_getTempRet0,getaddrinfo:_getaddrinfo,getnameinfo:_getnameinfo,invoke_di,invoke_i,invoke_id,invoke_ii,invoke_iii,invoke_iiii,invoke_iiiii,invoke_iiiiii,invoke_iiiiiii,invoke_iiiiiiii,invoke_iiiiiiiii,invoke_iiiiiiiiii,invoke_iiiiiiiiiiiiiiiii,invoke_iiiiiji,invoke_iiiij,invoke_iiiijii,invoke_iiij,invoke_iiji,invoke_ij,invoke_ijiiiii,invoke_ijiiiiii,invoke_ji,invoke_jii,invoke_jiiii,invoke_jiiiii,invoke_jiiiiiiii,invoke_v,invoke_vi,invoke_vid,invoke_vii,invoke_viii,invoke_viiii,invoke_viiiii,invoke_viiiiii,invoke_viiiiiii,invoke_viiiiiiii,invoke_viiiiiiiii,invoke_viiiiiiiiiiii,invoke_viiij,invoke_viij,invoke_viiji,invoke_viijii,invoke_viijiiii,invoke_vij,invoke_viji,invoke_vijiji,invoke_vj,invoke_vji,is_web_env,memory:wasmMemory,proc_exit:_proc_exit,setTempRet0:_setTempRet0},wasmExports;createWasm(),Module._ScanKeywordLookup=(e,I)=>(Module._ScanKeywordLookup=wasmExports.ScanKeywordLookup)(e,I),Module._pg_snprintf=(e,I,Hn,$n)=>(Module._pg_snprintf=wasmExports.pg_snprintf)(e,I,Hn,$n),Module._strlen=e=>(Module._strlen=wasmExports.strlen)(e),Module._memset=(e,I,Hn)=>(Module._memset=wasmExports.memset)(e,I,Hn),Module._strchr=(e,I)=>(Module._strchr=wasmExports.strchr)(e,I),Module._PQserverVersion=e=>(Module._PQserverVersion=wasmExports.PQserverVersion)(e),Module._strstr=(e,I)=>(Module._strstr=wasmExports.strstr)(e,I),Module._pg_fprintf=(e,I,Hn)=>(Module._pg_fprintf=wasmExports.pg_fprintf)(e,I,Hn),Module._strspn=(e,I)=>(Module._strspn=wasmExports.strspn)(e,I);var _malloc=Module._malloc=e=>(_malloc=Module._malloc=wasmExports.malloc)(e);Module._pg_strcasecmp=(e,I)=>(Module._pg_strcasecmp=wasmExports.pg_strcasecmp)(e,I),Module._strcmp=(e,I)=>(Module._strcmp=wasmExports.strcmp)(e,I),Module._free=e=>(Module._free=wasmExports.free)(e),Module._pg_tolower=e=>(Module._pg_tolower=wasmExports.pg_tolower)(e),Module._memchr=(e,I,Hn)=>(Module._memchr=wasmExports.memchr)(e,I,Hn),Module._getenv=e=>(Module._getenv=wasmExports.getenv)(e),Module._fileno=e=>(Module._fileno=wasmExports.fileno)(e),Module._isatty=e=>(Module._isatty=wasmExports.isatty)(e),Module._strdup=e=>(Module._strdup=wasmExports.strdup)(e),Module.___errno_location=()=>(Module.___errno_location=wasmExports.__errno_location)();var _fflush=Module._fflush=e=>(_fflush=Module._fflush=wasmExports.fflush)(e);Module._pg_vsnprintf=(e,I,Hn,$n)=>(Module._pg_vsnprintf=wasmExports.pg_vsnprintf)(e,I,Hn,$n),Module._pg_malloc_extended=(e,I)=>(Module._pg_malloc_extended=wasmExports.pg_malloc_extended)(e,I),Module._PageInit=(e,I,Hn)=>(Module._PageInit=wasmExports.PageInit)(e,I,Hn),Module._pg_checksum_page=(e,I)=>(Module._pg_checksum_page=wasmExports.pg_checksum_page)(e,I),Module._errstart=(e,I)=>(Module._errstart=wasmExports.errstart)(e,I),Module._errcode=e=>(Module._errcode=wasmExports.errcode)(e),Module._errmsg=(e,I)=>(Module._errmsg=wasmExports.errmsg)(e,I),Module._errfinish=(e,I,Hn)=>(Module._errfinish=wasmExports.errfinish)(e,I,Hn),Module._PageAddItemExtended=(e,I,Hn,$n,qn)=>(Module._PageAddItemExtended=wasmExports.PageAddItemExtended)(e,I,Hn,$n,qn),Module._errstart_cold=(e,I)=>(Module._errstart_cold=wasmExports.errstart_cold)(e,I),Module._puts=e=>(Module._puts=wasmExports.puts)(e),Module._errmsg_internal=(e,I)=>(Module._errmsg_internal=wasmExports.errmsg_internal)(e,I),Module._memmove=(e,I,Hn)=>(Module._memmove=wasmExports.memmove)(e,I,Hn),Module._memcpy=(e,I,Hn)=>(Module._memcpy=wasmExports.memcpy)(e,I,Hn),Module._palloc=e=>(Module._palloc=wasmExports.palloc)(e),Module._pfree=e=>(Module._pfree=wasmExports.pfree)(e),Module._PageGetFreeSpace=e=>(Module._PageGetFreeSpace=wasmExports.PageGetFreeSpace)(e),Module._PageGetExactFreeSpace=e=>(Module._PageGetExactFreeSpace=wasmExports.PageGetExactFreeSpace)(e),Module._PageGetHeapFreeSpace=e=>(Module._PageGetHeapFreeSpace=wasmExports.PageGetHeapFreeSpace)(e),Module._PageIndexMultiDelete=(e,I,Hn)=>(Module._PageIndexMultiDelete=wasmExports.PageIndexMultiDelete)(e,I,Hn),Module._PageIndexTupleOverwrite=(e,I,Hn,$n)=>(Module._PageIndexTupleOverwrite=wasmExports.PageIndexTupleOverwrite)(e,I,Hn,$n),Module._ItemPointerEquals=(e,I)=>(Module._ItemPointerEquals=wasmExports.ItemPointerEquals)(e,I),Module._ItemPointerCompare=(e,I)=>(Module._ItemPointerCompare=wasmExports.ItemPointerCompare)(e,I),Module._add_size=(e,I)=>(Module._add_size=wasmExports.add_size)(e,I),Module._ShmemInitStruct=(e,I,Hn)=>(Module._ShmemInitStruct=wasmExports.ShmemInitStruct)(e,I,Hn),Module._s_init_lock_sema=(e,I)=>(Module._s_init_lock_sema=wasmExports.s_init_lock_sema)(e,I),Module._LWLockAcquire=(e,I)=>(Module._LWLockAcquire=wasmExports.LWLockAcquire)(e,I),Module._LWLockRelease=e=>(Module._LWLockRelease=wasmExports.LWLockRelease)(e),Module._on_shmem_exit=(e,I)=>(Module._on_shmem_exit=wasmExports.on_shmem_exit)(e,I),Module._tas_sema=e=>(Module._tas_sema=wasmExports.tas_sema)(e),Module._s_lock=(e,I,Hn,$n)=>(Module._s_lock=wasmExports.s_lock)(e,I,Hn,$n),Module._s_unlock_sema=e=>(Module._s_unlock_sema=wasmExports.s_unlock_sema)(e),Module._StartTransactionCommand=()=>(Module._StartTransactionCommand=wasmExports.StartTransactionCommand)(),Module._CommitTransactionCommand=()=>(Module._CommitTransactionCommand=wasmExports.CommitTransactionCommand)(),Module._WaitLatch=(e,I,Hn,$n)=>(Module._WaitLatch=wasmExports.WaitLatch)(e,I,Hn,$n),Module._ResetLatch=e=>(Module._ResetLatch=wasmExports.ResetLatch)(e),Module._ProcessInterrupts=()=>(Module._ProcessInterrupts=wasmExports.ProcessInterrupts)(),Module._MemoryContextAlloc=(e,I)=>(Module._MemoryContextAlloc=wasmExports.MemoryContextAlloc)(e,I),Module._AllocateDir=e=>(Module._AllocateDir=wasmExports.AllocateDir)(e),Module._ReadDir=(e,I)=>(Module._ReadDir=wasmExports.ReadDir)(e,I),Module._strncmp=(e,I,Hn)=>(Module._strncmp=wasmExports.strncmp)(e,I,Hn),Module._unlink=e=>(Module._unlink=wasmExports.unlink)(e),Module._errcode_for_file_access=()=>(Module._errcode_for_file_access=wasmExports.errcode_for_file_access)(),Module._FreeDir=e=>(Module._FreeDir=wasmExports.FreeDir)(e),Module._pg_prng_uint32=e=>(Module._pg_prng_uint32=wasmExports.pg_prng_uint32)(e),Module._dsm_create=(e,I)=>(Module._dsm_create=wasmExports.dsm_create)(e,I),Module._dsm_attach=e=>(Module._dsm_attach=wasmExports.dsm_attach)(e),Module._dsm_detach=e=>(Module._dsm_detach=wasmExports.dsm_detach)(e),Module._dsm_segment_address=e=>(Module._dsm_segment_address=wasmExports.dsm_segment_address)(e),Module._dsm_segment_handle=e=>(Module._dsm_segment_handle=wasmExports.dsm_segment_handle)(e),Module._MemoryContextAllocZero=(e,I)=>(Module._MemoryContextAllocZero=wasmExports.MemoryContextAllocZero)(e,I),Module._read=(e,I,Hn)=>(Module._read=wasmExports.read)(e,I,Hn),Module._hash_create=(e,I,Hn,$n)=>(Module._hash_create=wasmExports.hash_create)(e,I,Hn,$n),Module._hash_destroy=e=>(Module._hash_destroy=wasmExports.hash_destroy)(e),Module._hash_seq_init=(e,I)=>(Module._hash_seq_init=wasmExports.hash_seq_init)(e,I),Module._hash_seq_search=e=>(Module._hash_seq_search=wasmExports.hash_seq_search)(e),Module._hash_search=(e,I,Hn,$n)=>(Module._hash_search=wasmExports.hash_search)(e,I,Hn,$n),Module._initStringInfo=e=>(Module._initStringInfo=wasmExports.initStringInfo)(e),Module._appendStringInfo=(e,I,Hn)=>(Module._appendStringInfo=wasmExports.appendStringInfo)(e,I,Hn),Module._GetCurrentTimestamp=()=>(Module._GetCurrentTimestamp=wasmExports.GetCurrentTimestamp)(),Module._pg_usleep=e=>(Module._pg_usleep=wasmExports.pg_usleep)(e),Module._errdetail=(e,I)=>(Module._errdetail=wasmExports.errdetail)(e,I),Module._TransactionIdDidCommit=e=>(Module._TransactionIdDidCommit=wasmExports.TransactionIdDidCommit)(e),Module._TransactionIdPrecedes=(e,I)=>(Module._TransactionIdPrecedes=wasmExports.TransactionIdPrecedes)(e,I),Module._XLogBeginInsert=()=>(Module._XLogBeginInsert=wasmExports.XLogBeginInsert)(),Module._XLogRegisterData=(e,I)=>(Module._XLogRegisterData=wasmExports.XLogRegisterData)(e,I),Module._XLogInsert=(e,I)=>(Module._XLogInsert=wasmExports.XLogInsert)(e,I),Module._ConditionVariableInit=e=>(Module._ConditionVariableInit=wasmExports.ConditionVariableInit)(e),Module._ConditionVariableCancelSleep=()=>(Module._ConditionVariableCancelSleep=wasmExports.ConditionVariableCancelSleep)(),Module._ConditionVariableSleep=(e,I)=>(Module._ConditionVariableSleep=wasmExports.ConditionVariableSleep)(e,I),Module.___wasm_setjmp=(e,I,Hn)=>(Module.___wasm_setjmp=wasmExports.__wasm_setjmp)(e,I,Hn),Module.___wasm_setjmp_test=(e,I)=>(Module.___wasm_setjmp_test=wasmExports.__wasm_setjmp_test)(e,I),Module._pg_re_throw=()=>(Module._pg_re_throw=wasmExports.pg_re_throw)(),Module._emscripten_longjmp=(e,I)=>(Module._emscripten_longjmp=wasmExports.emscripten_longjmp)(e,I),Module._procsignal_sigusr1_handler=e=>(Module._procsignal_sigusr1_handler=wasmExports.procsignal_sigusr1_handler)(e),Module._close=e=>(Module._close=wasmExports.close)(e),Module._ReleaseExternalFD=()=>(Module._ReleaseExternalFD=wasmExports.ReleaseExternalFD)(),Module._fcntl=(e,I,Hn)=>(Module._fcntl=wasmExports.fcntl)(e,I,Hn),Module._pqsignal=(e,I)=>(Module._pqsignal=wasmExports.pqsignal)(e,I),Module._write=(e,I,Hn)=>(Module._write=wasmExports.write)(e,I,Hn),Module._AddWaitEventToSet=(e,I,Hn,$n,qn)=>(Module._AddWaitEventToSet=wasmExports.AddWaitEventToSet)(e,I,Hn,$n,qn),Module._clock_gettime=(e,I)=>(Module._clock_gettime=wasmExports.clock_gettime)(e,I),Module._poll=(e,I,Hn)=>(Module._poll=wasmExports.poll)(e,I,Hn),Module._WaitLatchOrSocket=(e,I,Hn,$n,qn)=>(Module._WaitLatchOrSocket=wasmExports.WaitLatchOrSocket)(e,I,Hn,$n,qn),Module._GetNumRegisteredWaitEvents=e=>(Module._GetNumRegisteredWaitEvents=wasmExports.GetNumRegisteredWaitEvents)(e),Module._ShmemInitHash=(e,I,Hn,$n,qn)=>(Module._ShmemInitHash=wasmExports.ShmemInitHash)(e,I,Hn,$n,qn),Module._InitMaterializedSRF=(e,I)=>(Module._InitMaterializedSRF=wasmExports.InitMaterializedSRF)(e,I),Module._cstring_to_text=e=>(Module._cstring_to_text=wasmExports.cstring_to_text)(e),Module._Int64GetDatum=e=>(Module._Int64GetDatum=wasmExports.Int64GetDatum)(e),Module._tuplestore_putvalues=(e,I,Hn,$n)=>(Module._tuplestore_putvalues=wasmExports.tuplestore_putvalues)(e,I,Hn,$n),Module._shm_toc_allocate=(e,I)=>(Module._shm_toc_allocate=wasmExports.shm_toc_allocate)(e,I),Module._shm_toc_insert=(e,I,Hn)=>(Module._shm_toc_insert=wasmExports.shm_toc_insert)(e,I,Hn),Module._shm_toc_lookup=(e,I,Hn)=>(Module._shm_toc_lookup=wasmExports.shm_toc_lookup)(e,I,Hn),Module._superuser_arg=e=>(Module._superuser_arg=wasmExports.superuser_arg)(e),Module._superuser=()=>(Module._superuser=wasmExports.superuser)(),Module._GetUserId=()=>(Module._GetUserId=wasmExports.GetUserId)(),Module._has_privs_of_role=(e,I)=>(Module._has_privs_of_role=wasmExports.has_privs_of_role)(e,I),Module._errmsg_plural=(e,I,Hn,$n)=>(Module._errmsg_plural=wasmExports.errmsg_plural)(e,I,Hn,$n),Module._errhint=(e,I)=>(Module._errhint=wasmExports.errhint)(e,I),Module._fstat=(e,I)=>(Module._fstat=wasmExports.fstat)(e,I),Module._ftruncate=(e,I)=>(Module._ftruncate=wasmExports.ftruncate)(e,I),Module._RequestAddinShmemSpace=e=>(Module._RequestAddinShmemSpace=wasmExports.RequestAddinShmemSpace)(e),Module._hash_estimate_size=(e,I)=>(Module._hash_estimate_size=wasmExports.hash_estimate_size)(e,I),Module._pg_sprintf=(e,I,Hn)=>(Module._pg_sprintf=wasmExports.pg_sprintf)(e,I,Hn),Module._SetConfigOption=(e,I,Hn,$n)=>(Module._SetConfigOption=wasmExports.SetConfigOption)(e,I,Hn,$n),Module._pg_printf=(e,I)=>(Module._pg_printf=wasmExports.pg_printf)(e,I),Module._before_shmem_exit=(e,I)=>(Module._before_shmem_exit=wasmExports.before_shmem_exit)(e,I),Module._cancel_before_shmem_exit=(e,I)=>(Module._cancel_before_shmem_exit=wasmExports.cancel_before_shmem_exit)(e,I),Module._pg_qsort=(e,I,Hn,$n)=>(Module._pg_qsort=wasmExports.pg_qsort)(e,I,Hn,$n),Module._TransactionIdIsInProgress=e=>(Module._TransactionIdIsInProgress=wasmExports.TransactionIdIsInProgress)(e),Module._TransactionIdIsCurrentTransactionId=e=>(Module._TransactionIdIsCurrentTransactionId=wasmExports.TransactionIdIsCurrentTransactionId)(e),Module._RecoveryInProgress=()=>(Module._RecoveryInProgress=wasmExports.RecoveryInProgress)(),Module._GetOldestNonRemovableTransactionId=e=>(Module._GetOldestNonRemovableTransactionId=wasmExports.GetOldestNonRemovableTransactionId)(e),Module._GetCurrentCommandId=e=>(Module._GetCurrentCommandId=wasmExports.GetCurrentCommandId)(e),Module._BackendXidGetPid=e=>(Module._BackendXidGetPid=wasmExports.BackendXidGetPid)(e),Module._lappend_int=(e,I)=>(Module._lappend_int=wasmExports.lappend_int)(e,I),Module._index_close=(e,I)=>(Module._index_close=wasmExports.index_close)(e,I),Module._table_close=(e,I)=>(Module._table_close=wasmExports.table_close)(e,I),Module._CommandCounterIncrement=()=>(Module._CommandCounterIncrement=wasmExports.CommandCounterIncrement)(),Module._GetActiveSnapshot=()=>(Module._GetActiveSnapshot=wasmExports.GetActiveSnapshot)(),Module._ScanKeyInit=(e,I,Hn,$n,qn)=>(Module._ScanKeyInit=wasmExports.ScanKeyInit)(e,I,Hn,$n,qn),Module._table_open=(e,I)=>(Module._table_open=wasmExports.table_open)(e,I),Module._systable_beginscan=(e,I,Hn,$n,qn,Xn)=>(Module._systable_beginscan=wasmExports.systable_beginscan)(e,I,Hn,$n,qn,Xn),Module._systable_getnext=e=>(Module._systable_getnext=wasmExports.systable_getnext)(e),Module._systable_endscan=e=>(Module._systable_endscan=wasmExports.systable_endscan)(e),Module._index_open=(e,I)=>(Module._index_open=wasmExports.index_open)(e,I),Module._systable_beginscan_ordered=(e,I,Hn,$n,qn)=>(Module._systable_beginscan_ordered=wasmExports.systable_beginscan_ordered)(e,I,Hn,$n,qn),Module._systable_getnext_ordered=(e,I)=>(Module._systable_getnext_ordered=wasmExports.systable_getnext_ordered)(e,I),Module._systable_endscan_ordered=e=>(Module._systable_endscan_ordered=wasmExports.systable_endscan_ordered)(e),Module._heap_form_tuple=(e,I,Hn)=>(Module._heap_form_tuple=wasmExports.heap_form_tuple)(e,I,Hn),Module._heap_freetuple=e=>(Module._heap_freetuple=wasmExports.heap_freetuple)(e),Module._AllocSetContextCreateInternal=(e,I,Hn,$n,qn)=>(Module._AllocSetContextCreateInternal=wasmExports.AllocSetContextCreateInternal)(e,I,Hn,$n,qn),Module._list_free_deep=e=>(Module._list_free_deep=wasmExports.list_free_deep)(e),Module._lappend=(e,I)=>(Module._lappend=wasmExports.lappend)(e,I),Module._LockBuffer=(e,I)=>(Module._LockBuffer=wasmExports.LockBuffer)(e,I),Module._GetFreeIndexPage=e=>(Module._GetFreeIndexPage=wasmExports.GetFreeIndexPage)(e),Module._RecordFreeIndexPage=(e,I)=>(Module._RecordFreeIndexPage=wasmExports.RecordFreeIndexPage)(e,I),Module._IndexFreeSpaceMapVacuum=e=>(Module._IndexFreeSpaceMapVacuum=wasmExports.IndexFreeSpaceMapVacuum)(e),Module._UnlockReleaseBuffer=e=>(Module._UnlockReleaseBuffer=wasmExports.UnlockReleaseBuffer)(e),Module._smgropen=(e,I)=>(Module._smgropen=wasmExports.smgropen)(e,I),Module._smgrsetowner=(e,I)=>(Module._smgrsetowner=wasmExports.smgrsetowner)(e,I),Module._RelationGetNumberOfBlocksInFork=(e,I)=>(Module._RelationGetNumberOfBlocksInFork=wasmExports.RelationGetNumberOfBlocksInFork)(e,I),Module._ReleaseBuffer=e=>(Module._ReleaseBuffer=wasmExports.ReleaseBuffer)(e),Module._GetRecordedFreeSpace=(e,I)=>(Module._GetRecordedFreeSpace=wasmExports.GetRecordedFreeSpace)(e,I),Module._smgrexists=(e,I)=>(Module._smgrexists=wasmExports.smgrexists)(e,I),Module._ReadBufferExtended=(e,I,Hn,$n,qn)=>(Module._ReadBufferExtended=wasmExports.ReadBufferExtended)(e,I,Hn,$n,qn),Module._MarkBufferDirty=e=>(Module._MarkBufferDirty=wasmExports.MarkBufferDirty)(e),Module._log_newpage_buffer=(e,I)=>(Module._log_newpage_buffer=wasmExports.log_newpage_buffer)(e,I),Module._copy_file=(e,I)=>(Module._copy_file=wasmExports.copy_file)(e,I),Module._fd_fsync_fname=(e,I)=>(Module._fd_fsync_fname=wasmExports.fd_fsync_fname)(e,I),Module._OpenTransientFile=(e,I)=>(Module._OpenTransientFile=wasmExports.OpenTransientFile)(e,I),Module._CloseTransientFile=e=>(Module._CloseTransientFile=wasmExports.CloseTransientFile)(e),Module._hash_bytes=(e,I)=>(Module._hash_bytes=wasmExports.hash_bytes)(e,I),Module._pstrdup=e=>(Module._pstrdup=wasmExports.pstrdup)(e),Module._repalloc=(e,I)=>(Module._repalloc=wasmExports.repalloc)(e,I),Module._wasm_OpenPipeStream=(e,I)=>(Module._wasm_OpenPipeStream=wasmExports.wasm_OpenPipeStream)(e,I),Module._access=(e,I)=>(Module._access=wasmExports.access)(e,I),Module._fopen=(e,I)=>(Module._fopen=wasmExports.fopen)(e,I),Module._fiprintf=(e,I,Hn)=>(Module._fiprintf=wasmExports.fiprintf)(e,I,Hn),Module._fclose=e=>(Module._fclose=wasmExports.fclose)(e),Module._fsync_fname_ext=(e,I,Hn,$n)=>(Module._fsync_fname_ext=wasmExports.fsync_fname_ext)(e,I,Hn,$n),Module._fd_durable_rename=(e,I,Hn)=>(Module._fd_durable_rename=wasmExports.fd_durable_rename)(e,I,Hn),Module._rename=(e,I)=>(Module._rename=wasmExports.rename)(e,I),Module._strlcpy=(e,I,Hn)=>(Module._strlcpy=wasmExports.strlcpy)(e,I,Hn),Module._dup=e=>(Module._dup=wasmExports.dup)(e),Module._open=(e,I,Hn)=>(Module._open=wasmExports.open)(e,I,Hn),Module._AcquireExternalFD=()=>(Module._AcquireExternalFD=wasmExports.AcquireExternalFD)(),Module._realloc=(e,I)=>(Module._realloc=wasmExports.realloc)(e,I),Module._stat=(e,I)=>(Module._stat=wasmExports.stat)(e,I),Module._pwrite=(e,I,Hn,$n)=>(Module._pwrite=wasmExports.pwrite)(e,I,Hn,$n),Module._lseek=(e,I,Hn)=>(Module._lseek=wasmExports.lseek)(e,I,Hn),Module._AllocateFile=(e,I)=>(Module._AllocateFile=wasmExports.AllocateFile)(e,I),Module._GetCurrentSubTransactionId=()=>(Module._GetCurrentSubTransactionId=wasmExports.GetCurrentSubTransactionId)(),Module._FreeFile=e=>(Module._FreeFile=wasmExports.FreeFile)(e),Module._pclose=e=>(Module._pclose=wasmExports.pclose)(e),Module._ClosePipeStream=e=>(Module._ClosePipeStream=wasmExports.ClosePipeStream)(e),Module._pg_prng_uint64_range=(e,I,Hn)=>(Module._pg_prng_uint64_range=wasmExports.pg_prng_uint64_range)(e,I,Hn),Module._AtEOSubXact_Files=(e,I,Hn)=>(Module._AtEOSubXact_Files=wasmExports.AtEOSubXact_Files)(e,I,Hn),Module._pre_format_elog_string=(e,I)=>(Module._pre_format_elog_string=wasmExports.pre_format_elog_string)(e,I),Module._format_elog_string=(e,I)=>(Module._format_elog_string=wasmExports.format_elog_string)(e,I),Module._list_free=e=>(Module._list_free=wasmExports.list_free)(e),Module._guc_malloc=(e,I)=>(Module._guc_malloc=wasmExports.guc_malloc)(e,I),Module._MemoryContextDelete=e=>(Module._MemoryContextDelete=wasmExports.MemoryContextDelete)(e),Module._strtoul=(e,I,Hn)=>(Module._strtoul=wasmExports.strtoul)(e,I,Hn),Module._hash_get_num_entries=e=>(Module._hash_get_num_entries=wasmExports.hash_get_num_entries)(e),Module._LWLockInitialize=(e,I)=>(Module._LWLockInitialize=wasmExports.LWLockInitialize)(e,I),Module._PrefetchBuffer=(e,I,Hn,$n)=>(Module._PrefetchBuffer=wasmExports.PrefetchBuffer)(e,I,Hn,$n),Module._LockBufHdr=e=>(Module._LockBufHdr=wasmExports.LockBufHdr)(e),Module._ReadBuffer=(e,I)=>(Module._ReadBuffer=wasmExports.ReadBuffer)(e,I),Module._pgstat_assoc_relation=e=>(Module._pgstat_assoc_relation=wasmExports.pgstat_assoc_relation)(e),Module._ExtendBufferedRel=(e,I,Hn,$n)=>(Module._ExtendBufferedRel=wasmExports.ExtendBufferedRel)(e,I,Hn,$n),Module._LockBufferForCleanup=e=>(Module._LockBufferForCleanup=wasmExports.LockBufferForCleanup)(e),Module._smgrread=(e,I,Hn,$n)=>(Module._smgrread=wasmExports.smgrread)(e,I,Hn,$n),Module._LockRelationForExtension=(e,I)=>(Module._LockRelationForExtension=wasmExports.LockRelationForExtension)(e,I),Module._UnlockRelationForExtension=(e,I)=>(Module._UnlockRelationForExtension=wasmExports.UnlockRelationForExtension)(e,I),Module._BufferGetBlockNumber=e=>(Module._BufferGetBlockNumber=wasmExports.BufferGetBlockNumber)(e),Module._bsearch=(e,I,Hn,$n,qn)=>(Module._bsearch=wasmExports.bsearch)(e,I,Hn,$n,qn),Module._set_errcontext_domain=e=>(Module._set_errcontext_domain=wasmExports.set_errcontext_domain)(e),Module._errcontext_msg=(e,I)=>(Module._errcontext_msg=wasmExports.errcontext_msg)(e,I),Module._GetAccessStrategy=e=>(Module._GetAccessStrategy=wasmExports.GetAccessStrategy)(e),Module._FreeAccessStrategy=e=>(Module._FreeAccessStrategy=wasmExports.FreeAccessStrategy)(e),Module._ConditionalLockBuffer=e=>(Module._ConditionalLockBuffer=wasmExports.ConditionalLockBuffer)(e),Module._TestForOldSnapshot_impl=(e,I)=>(Module._TestForOldSnapshot_impl=wasmExports.TestForOldSnapshot_impl)(e,I);var _calloc=Module._calloc=(e,I)=>(_calloc=Module._calloc=wasmExports.calloc)(e,I);Module._have_free_buffer=()=>(Module._have_free_buffer=wasmExports.have_free_buffer)(),Module._palloc0=e=>(Module._palloc0=wasmExports.palloc0)(e),Module._resetStringInfo=e=>(Module._resetStringInfo=wasmExports.resetStringInfo)(e),Module._appendStringInfoChar=(e,I)=>(Module._appendStringInfoChar=wasmExports.appendStringInfoChar)(e,I),Module._appendBinaryStringInfo=(e,I,Hn)=>(Module._appendBinaryStringInfo=wasmExports.appendBinaryStringInfo)(e,I,Hn),Module._errdetail_internal=(e,I)=>(Module._errdetail_internal=wasmExports.errdetail_internal)(e,I),Module._strcpy=(e,I)=>(Module._strcpy=wasmExports.strcpy)(e,I),Module._LWLockRegisterTranche=(e,I)=>(Module._LWLockRegisterTranche=wasmExports.LWLockRegisterTranche)(e,I),Module._GetNamedLWLockTranche=e=>(Module._GetNamedLWLockTranche=wasmExports.GetNamedLWLockTranche)(e),Module._LWLockNewTrancheId=()=>(Module._LWLockNewTrancheId=wasmExports.LWLockNewTrancheId)(),Module._RequestNamedLWLockTranche=(e,I)=>(Module._RequestNamedLWLockTranche=wasmExports.RequestNamedLWLockTranche)(e,I),Module._pg_prng_double=e=>(Module._pg_prng_double=wasmExports.pg_prng_double)(e),Module._getpid=()=>(Module._getpid=wasmExports.getpid)(),Module._GetTransactionSnapshot=()=>(Module._GetTransactionSnapshot=wasmExports.GetTransactionSnapshot)(),Module._ConditionVariableSignal=e=>(Module._ConditionVariableSignal=wasmExports.ConditionVariableSignal)(e),Module._LockPage=(e,I,Hn)=>(Module._LockPage=wasmExports.LockPage)(e,I,Hn),Module._UnlockPage=(e,I,Hn)=>(Module._UnlockPage=wasmExports.UnlockPage)(e,I,Hn),Module._pgstat_progress_update_param=(e,I)=>(Module._pgstat_progress_update_param=wasmExports.pgstat_progress_update_param)(e,I),Module._list_make1_impl=(e,I)=>(Module._list_make1_impl=wasmExports.list_make1_impl)(e,I),Module._psprintf=(e,I)=>(Module._psprintf=wasmExports.psprintf)(e,I),Module._smgrtruncate=(e,I,Hn,$n)=>(Module._smgrtruncate=wasmExports.smgrtruncate)(e,I,Hn,$n),Module._log=e=>(Module._log=wasmExports.log)(e),Module._pairingheap_allocate=(e,I)=>(Module._pairingheap_allocate=wasmExports.pairingheap_allocate)(e,I),Module._pairingheap_add=(e,I)=>(Module._pairingheap_add=wasmExports.pairingheap_add)(e,I),Module._pairingheap_first=e=>(Module._pairingheap_first=wasmExports.pairingheap_first)(e),Module._pairingheap_remove_first=e=>(Module._pairingheap_remove_first=wasmExports.pairingheap_remove_first)(e),Module._bloom_create=(e,I,Hn)=>(Module._bloom_create=wasmExports.bloom_create)(e,I,Hn),Module._bloom_free=e=>(Module._bloom_free=wasmExports.bloom_free)(e),Module._bloom_add_element=(e,I,Hn)=>(Module._bloom_add_element=wasmExports.bloom_add_element)(e,I,Hn),Module._hash_bytes_extended=(e,I,Hn)=>(Module._hash_bytes_extended=wasmExports.hash_bytes_extended)(e,I,Hn),Module._bloom_lacks_element=(e,I,Hn)=>(Module._bloom_lacks_element=wasmExports.bloom_lacks_element)(e,I,Hn),Module._bloom_prop_bits_set=e=>(Module._bloom_prop_bits_set=wasmExports.bloom_prop_bits_set)(e),Module._pg_popcount=(e,I)=>(Module._pg_popcount=wasmExports.pg_popcount)(e,I),Module._memcmp=(e,I,Hn)=>(Module._memcmp=wasmExports.memcmp)(e,I,Hn),Module._bms_make_singleton=e=>(Module._bms_make_singleton=wasmExports.bms_make_singleton)(e),Module._bms_add_members=(e,I)=>(Module._bms_add_members=wasmExports.bms_add_members)(e,I),Module._bms_add_member=(e,I)=>(Module._bms_add_member=wasmExports.bms_add_member)(e,I),Module._bms_del_member=(e,I)=>(Module._bms_del_member=wasmExports.bms_del_member)(e,I),Module._check_stack_depth=()=>(Module._check_stack_depth=wasmExports.check_stack_depth)(),Module._parser_errposition=(e,I)=>(Module._parser_errposition=wasmExports.parser_errposition)(e,I),Module._makeVar=(e,I,Hn,$n,qn,Xn)=>(Module._makeVar=wasmExports.makeVar)(e,I,Hn,$n,qn,Xn),Module._bms_union=(e,I)=>(Module._bms_union=wasmExports.bms_union)(e,I),Module._varstr_levenshtein_less_equal=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn)=>(Module._varstr_levenshtein_less_equal=wasmExports.varstr_levenshtein_less_equal)(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn),Module._SearchSysCacheExists=(e,I,Hn,$n,qn)=>(Module._SearchSysCacheExists=wasmExports.SearchSysCacheExists)(e,I,Hn,$n,qn),Module._MemoryContextAllocZeroAligned=(e,I)=>(Module._MemoryContextAllocZeroAligned=wasmExports.MemoryContextAllocZeroAligned)(e,I),Module._makeString=e=>(Module._makeString=wasmExports.makeString)(e),Module._addRTEPermissionInfo=(e,I)=>(Module._addRTEPermissionInfo=wasmExports.addRTEPermissionInfo)(e,I),Module._copyObjectImpl=e=>(Module._copyObjectImpl=wasmExports.copyObjectImpl)(e),Module._exprType=e=>(Module._exprType=wasmExports.exprType)(e),Module._lappend_oid=(e,I)=>(Module._lappend_oid=wasmExports.lappend_oid)(e,I),Module._exprTypmod=e=>(Module._exprTypmod=wasmExports.exprTypmod)(e),Module._exprLocation=e=>(Module._exprLocation=wasmExports.exprLocation)(e),Module._CreateTemplateTupleDesc=e=>(Module._CreateTemplateTupleDesc=wasmExports.CreateTemplateTupleDesc)(e),Module._TupleDescInitEntry=(e,I,Hn,$n,qn,Xn)=>(Module._TupleDescInitEntry=wasmExports.TupleDescInitEntry)(e,I,Hn,$n,qn,Xn),Module._TupleDescInitEntryCollation=(e,I,Hn)=>(Module._TupleDescInitEntryCollation=wasmExports.TupleDescInitEntryCollation)(e,I,Hn),Module._typenameTypeIdAndMod=(e,I,Hn,$n)=>(Module._typenameTypeIdAndMod=wasmExports.typenameTypeIdAndMod)(e,I,Hn,$n),Module._format_type_be=e=>(Module._format_type_be=wasmExports.format_type_be)(e),Module._list_concat=(e,I)=>(Module._list_concat=wasmExports.list_concat)(e,I),Module._list_copy=e=>(Module._list_copy=wasmExports.list_copy)(e),Module._relation_open=(e,I)=>(Module._relation_open=wasmExports.relation_open)(e,I),Module._relation_close=(e,I)=>(Module._relation_close=wasmExports.relation_close)(e,I),Module._makeTargetEntry=(e,I,Hn,$n)=>(Module._makeTargetEntry=wasmExports.makeTargetEntry)(e,I,Hn,$n),Module._get_attname=(e,I,Hn)=>(Module._get_attname=wasmExports.get_attname)(e,I,Hn),Module._SearchSysCache2=(e,I,Hn)=>(Module._SearchSysCache2=wasmExports.SearchSysCache2)(e,I,Hn),Module._ReleaseSysCache=e=>(Module._ReleaseSysCache=wasmExports.ReleaseSysCache)(e),Module._RangeVarGetRelidExtended=(e,I,Hn,$n,qn)=>(Module._RangeVarGetRelidExtended=wasmExports.RangeVarGetRelidExtended)(e,I,Hn,$n,qn),Module._pg_mbstrlen_with_len=(e,I)=>(Module._pg_mbstrlen_with_len=wasmExports.pg_mbstrlen_with_len)(e,I),Module._errposition=e=>(Module._errposition=wasmExports.errposition)(e),Module._numeric_in=e=>(Module._numeric_in=wasmExports.numeric_in)(e),Module._DirectFunctionCall3Coll=(e,I,Hn,$n,qn)=>(Module._DirectFunctionCall3Coll=wasmExports.DirectFunctionCall3Coll)(e,I,Hn,$n,qn),Module._bit_in=e=>(Module._bit_in=wasmExports.bit_in)(e),Module._NameListToString=e=>(Module._NameListToString=wasmExports.NameListToString)(e),Module._appendStringInfoString=(e,I)=>(Module._appendStringInfoString=wasmExports.appendStringInfoString)(e,I),Module._lookup_type_cache=(e,I)=>(Module._lookup_type_cache=wasmExports.lookup_type_cache)(e,I),Module._CacheRegisterSyscacheCallback=(e,I,Hn)=>(Module._CacheRegisterSyscacheCallback=wasmExports.CacheRegisterSyscacheCallback)(e,I,Hn),Module._SearchSysCache1=(e,I)=>(Module._SearchSysCache1=wasmExports.SearchSysCache1)(e,I),Module._list_make2_impl=(e,I,Hn)=>(Module._list_make2_impl=wasmExports.list_make2_impl)(e,I,Hn),Module._get_base_element_type=e=>(Module._get_base_element_type=wasmExports.get_base_element_type)(e),Module._downcase_truncate_identifier=(e,I,Hn)=>(Module._downcase_truncate_identifier=wasmExports.downcase_truncate_identifier)(e,I,Hn),Module._pg_database_encoding_max_length=()=>(Module._pg_database_encoding_max_length=wasmExports.pg_database_encoding_max_length)(),Module._truncate_identifier=(e,I,Hn)=>(Module._truncate_identifier=wasmExports.truncate_identifier)(e,I,Hn),Module._scanner_isspace=e=>(Module._scanner_isspace=wasmExports.scanner_isspace)(e),Module._get_typcollation=e=>(Module._get_typcollation=wasmExports.get_typcollation)(e),Module._list_delete_cell=(e,I)=>(Module._list_delete_cell=wasmExports.list_delete_cell)(e,I),Module._makeTypeNameFromNameList=e=>(Module._makeTypeNameFromNameList=wasmExports.makeTypeNameFromNameList)(e),Module._SysCacheGetAttrNotNull=(e,I,Hn)=>(Module._SysCacheGetAttrNotNull=wasmExports.SysCacheGetAttrNotNull)(e,I,Hn),Module._text_to_cstring=e=>(Module._text_to_cstring=wasmExports.text_to_cstring)(e),Module._stringToNode=e=>(Module._stringToNode=wasmExports.stringToNode)(e),Module._bms_is_member=(e,I)=>(Module._bms_is_member=wasmExports.bms_is_member)(e,I),Module._bms_free=e=>(Module._bms_free=wasmExports.bms_free)(e),Module._core_yylex=(e,I,Hn)=>(Module._core_yylex=wasmExports.core_yylex)(e,I,Hn),Module._getc=e=>(Module._getc=wasmExports.getc)(e),Module._ferror=e=>(Module._ferror=wasmExports.ferror)(e),Module._fread=(e,I,Hn,$n)=>(Module._fread=wasmExports.fread)(e,I,Hn,$n),Module._clearerr=e=>(Module._clearerr=wasmExports.clearerr)(e),Module._scanner_init=(e,I,Hn,$n)=>(Module._scanner_init=wasmExports.scanner_init)(e,I,Hn,$n),Module._scanner_finish=e=>(Module._scanner_finish=wasmExports.scanner_finish)(e),Module._get_namespace_name=e=>(Module._get_namespace_name=wasmExports.get_namespace_name)(e),Module._lookup_rowtype_tupdesc=(e,I)=>(Module._lookup_rowtype_tupdesc=wasmExports.lookup_rowtype_tupdesc)(e,I),Module._DecrTupleDescRefCount=e=>(Module._DecrTupleDescRefCount=wasmExports.DecrTupleDescRefCount)(e),Module._relation_openrv=(e,I)=>(Module._relation_openrv=wasmExports.relation_openrv)(e,I),Module._errdetail_relkind_not_supported=e=>(Module._errdetail_relkind_not_supported=wasmExports.errdetail_relkind_not_supported)(e),Module._object_aclcheck=(e,I,Hn,$n)=>(Module._object_aclcheck=wasmExports.object_aclcheck)(e,I,Hn,$n),Module._aclcheck_error=(e,I,Hn)=>(Module._aclcheck_error=wasmExports.aclcheck_error)(e,I,Hn),Module._pg_class_aclcheck=(e,I,Hn)=>(Module._pg_class_aclcheck=wasmExports.pg_class_aclcheck)(e,I,Hn),Module._get_relkind_objtype=e=>(Module._get_relkind_objtype=wasmExports.get_relkind_objtype)(e),Module._list_make3_impl=(e,I,Hn,$n)=>(Module._list_make3_impl=wasmExports.list_make3_impl)(e,I,Hn,$n),Module._quote_qualified_identifier=(e,I)=>(Module._quote_qualified_identifier=wasmExports.quote_qualified_identifier)(e,I),Module._table_openrv=(e,I)=>(Module._table_openrv=wasmExports.table_openrv)(e,I),Module._equal=(e,I)=>(Module._equal=wasmExports.equal)(e,I),Module._RelationGetIndexList=e=>(Module._RelationGetIndexList=wasmExports.RelationGetIndexList)(e),Module._pg_detoast_datum=e=>(Module._pg_detoast_datum=wasmExports.pg_detoast_datum)(e),Module._SysCacheGetAttr=(e,I,Hn,$n)=>(Module._SysCacheGetAttr=wasmExports.SysCacheGetAttr)(e,I,Hn,$n),Module._deconstruct_array_builtin=(e,I,Hn,$n,qn)=>(Module._deconstruct_array_builtin=wasmExports.deconstruct_array_builtin)(e,I,Hn,$n,qn),Module._untransformRelOptions=e=>(Module._untransformRelOptions=wasmExports.untransformRelOptions)(e),Module._transformExpr=(e,I,Hn)=>(Module._transformExpr=wasmExports.transformExpr)(e,I,Hn),Module._get_rel_namespace=e=>(Module._get_rel_namespace=wasmExports.get_rel_namespace)(e),Module._get_rel_name=e=>(Module._get_rel_name=wasmExports.get_rel_name)(e),Module._makeRangeVar=(e,I,Hn)=>(Module._makeRangeVar=wasmExports.makeRangeVar)(e,I,Hn),Module._makeDefElem=(e,I,Hn)=>(Module._makeDefElem=wasmExports.makeDefElem)(e,I,Hn),Module._makeRangeVarFromNameList=e=>(Module._makeRangeVarFromNameList=wasmExports.makeRangeVarFromNameList)(e),Module._coerce_to_target_type=(e,I,Hn,$n,qn,Xn,Yn,Kn)=>(Module._coerce_to_target_type=wasmExports.coerce_to_target_type)(e,I,Hn,$n,qn,Xn,Yn,Kn),Module._LookupTypeName=(e,I,Hn,$n)=>(Module._LookupTypeName=wasmExports.LookupTypeName)(e,I,Hn,$n),Module._GetSysCacheOid=(e,I,Hn,$n,qn,Xn)=>(Module._GetSysCacheOid=wasmExports.GetSysCacheOid)(e,I,Hn,$n,qn,Xn),Module._construct_array_builtin=(e,I,Hn)=>(Module._construct_array_builtin=wasmExports.construct_array_builtin)(e,I,Hn),Module._get_collation_oid=(e,I)=>(Module._get_collation_oid=wasmExports.get_collation_oid)(e,I),Module._typeStringToTypeName=(e,I)=>(Module._typeStringToTypeName=wasmExports.typeStringToTypeName)(e,I),Module._raw_parser=(e,I)=>(Module._raw_parser=wasmExports.raw_parser)(e,I),Module._errsave_start=(e,I)=>(Module._errsave_start=wasmExports.errsave_start)(e,I),Module._errsave_finish=(e,I,Hn,$n)=>(Module._errsave_finish=wasmExports.errsave_finish)(e,I,Hn,$n),Module._defGetBoolean=e=>(Module._defGetBoolean=wasmExports.defGetBoolean)(e),Module._list_delete_last=e=>(Module._list_delete_last=wasmExports.list_delete_last)(e),Module._format_type_with_typemod=(e,I)=>(Module._format_type_with_typemod=wasmExports.format_type_with_typemod)(e,I),Module._list_member=(e,I)=>(Module._list_member=wasmExports.list_member)(e,I),Module._list_member_int=(e,I)=>(Module._list_member_int=wasmExports.list_member_int)(e,I),Module._list_sort=(e,I)=>(Module._list_sort=wasmExports.list_sort)(e,I),Module._get_element_type=e=>(Module._get_element_type=wasmExports.get_element_type)(e),Module._makeBoolean=e=>(Module._makeBoolean=wasmExports.makeBoolean)(e),Module._makeInteger=e=>(Module._makeInteger=wasmExports.makeInteger)(e),Module._makeTypeName=e=>(Module._makeTypeName=wasmExports.makeTypeName)(e),Module._list_make4_impl=(e,I,Hn,$n,qn)=>(Module._list_make4_impl=wasmExports.list_make4_impl)(e,I,Hn,$n,qn),Module._isxdigit=e=>(Module._isxdigit=wasmExports.isxdigit)(e),Module._strip_implicit_coercions=e=>(Module._strip_implicit_coercions=wasmExports.strip_implicit_coercions)(e),Module._SearchSysCacheList=(e,I,Hn,$n,qn)=>(Module._SearchSysCacheList=wasmExports.SearchSysCacheList)(e,I,Hn,$n,qn),Module._ReleaseCatCacheList=e=>(Module._ReleaseCatCacheList=wasmExports.ReleaseCatCacheList)(e),Module._get_sortgroupref_tle=(e,I)=>(Module._get_sortgroupref_tle=wasmExports.get_sortgroupref_tle)(e,I),Module._type_is_rowtype=e=>(Module._type_is_rowtype=wasmExports.type_is_rowtype)(e),Module._bms_next_member=(e,I)=>(Module._bms_next_member=wasmExports.bms_next_member)(e,I),Module._MemoryContextReset=e=>(Module._MemoryContextReset=wasmExports.MemoryContextReset)(e),Module._abort=()=>(Module._abort=wasmExports.abort)(),Module._heap_getnext=(e,I)=>(Module._heap_getnext=wasmExports.heap_getnext)(e,I),Module._OidOutputFunctionCall=(e,I)=>(Module._OidOutputFunctionCall=wasmExports.OidOutputFunctionCall)(e,I),Module._atoi=e=>(Module._atoi=wasmExports.atoi)(e),Module._GetConfigOption=(e,I,Hn)=>(Module._GetConfigOption=wasmExports.GetConfigOption)(e,I,Hn),Module._pg_strong_random=(e,I)=>(Module._pg_strong_random=wasmExports.pg_strong_random)(e,I),Module._pg_prng_seed_check=e=>(Module._pg_prng_seed_check=wasmExports.pg_prng_seed_check)(e),Module._pg_prng_seed=(e,I)=>(Module._pg_prng_seed=wasmExports.pg_prng_seed)(e,I),Module._fputc=(e,I)=>(Module._fputc=wasmExports.fputc)(e,I),Module._time=e=>(Module._time=wasmExports.time)(e),Module._TimestampDifferenceMilliseconds=(e,I)=>(Module._TimestampDifferenceMilliseconds=wasmExports.TimestampDifferenceMilliseconds)(e,I),Module._ProcessConfigFile=e=>(Module._ProcessConfigFile=wasmExports.ProcessConfigFile)(e),Module._send=(e,I,Hn,$n)=>(Module._send=wasmExports.send)(e,I,Hn,$n),Module._parse_bool=(e,I)=>(Module._parse_bool=wasmExports.parse_bool)(e,I),Module._enlargeStringInfo=(e,I)=>(Module._enlargeStringInfo=wasmExports.enlargeStringInfo)(e,I),Module._BackgroundWorkerInitializeConnectionByOid=(e,I,Hn)=>(Module._BackgroundWorkerInitializeConnectionByOid=wasmExports.BackgroundWorkerInitializeConnectionByOid)(e,I,Hn),Module._BackgroundWorkerUnblockSignals=()=>(Module._BackgroundWorkerUnblockSignals=wasmExports.BackgroundWorkerUnblockSignals)(),Module._pg_getnameinfo_all=(e,I,Hn,$n,qn,Xn,Yn)=>(Module._pg_getnameinfo_all=wasmExports.pg_getnameinfo_all)(e,I,Hn,$n,qn,Xn,Yn),Module._gai_strerror=e=>(Module._gai_strerror=wasmExports.gai_strerror)(e),Module._SignalHandlerForConfigReload=e=>(Module._SignalHandlerForConfigReload=wasmExports.SignalHandlerForConfigReload)(e),Module._fwrite=(e,I,Hn,$n)=>(Module._fwrite=wasmExports.fwrite)(e,I,Hn,$n),Module._SignalHandlerForShutdownRequest=e=>(Module._SignalHandlerForShutdownRequest=wasmExports.SignalHandlerForShutdownRequest)(e),Module._EmitErrorReport=()=>(Module._EmitErrorReport=wasmExports.EmitErrorReport)(),Module._FlushErrorState=()=>(Module._FlushErrorState=wasmExports.FlushErrorState)(),Module._die=e=>(Module._die=wasmExports.die)(e),Module._MultiXactIdPrecedes=(e,I)=>(Module._MultiXactIdPrecedes=wasmExports.MultiXactIdPrecedes)(e,I),Module._CreateTupleDescCopy=e=>(Module._CreateTupleDescCopy=wasmExports.CreateTupleDescCopy)(e),Module._pgstat_report_activity=(e,I)=>(Module._pgstat_report_activity=wasmExports.pgstat_report_activity)(e,I),Module._DirectFunctionCall2Coll=(e,I,Hn,$n)=>(Module._DirectFunctionCall2Coll=wasmExports.DirectFunctionCall2Coll)(e,I,Hn,$n),Module._RegisterBackgroundWorker=e=>(Module._RegisterBackgroundWorker=wasmExports.RegisterBackgroundWorker)(e),Module._RegisterDynamicBackgroundWorker=(e,I)=>(Module._RegisterDynamicBackgroundWorker=wasmExports.RegisterDynamicBackgroundWorker)(e,I),Module._WaitForBackgroundWorkerStartup=(e,I)=>(Module._WaitForBackgroundWorkerStartup=wasmExports.WaitForBackgroundWorkerStartup)(e,I),Module._WaitForBackgroundWorkerShutdown=e=>(Module._WaitForBackgroundWorkerShutdown=wasmExports.WaitForBackgroundWorkerShutdown)(e),Module._GetXLogReplayRecPtr=e=>(Module._GetXLogReplayRecPtr=wasmExports.GetXLogReplayRecPtr)(e),Module._gettimeofday=(e,I)=>(Module._gettimeofday=wasmExports.gettimeofday)(e,I),Module._sscanf=(e,I,Hn)=>(Module._sscanf=wasmExports.sscanf)(e,I,Hn),Module._get_call_result_type=(e,I,Hn)=>(Module._get_call_result_type=wasmExports.get_call_result_type)(e,I,Hn),Module._HeapTupleHeaderGetDatum=e=>(Module._HeapTupleHeaderGetDatum=wasmExports.HeapTupleHeaderGetDatum)(e),Module._wal_segment_close=e=>(Module._wal_segment_close=wasmExports.wal_segment_close)(e),Module._wal_segment_open=(e,I,Hn)=>(Module._wal_segment_open=wasmExports.wal_segment_open)(e,I,Hn),Module._GetFlushRecPtr=e=>(Module._GetFlushRecPtr=wasmExports.GetFlushRecPtr)(e),Module._XLogReadRecord=(e,I)=>(Module._XLogReadRecord=wasmExports.XLogReadRecord)(e,I),Module._RmgrNotFound=e=>(Module._RmgrNotFound=wasmExports.RmgrNotFound)(e),Module._CacheRegisterRelcacheCallback=(e,I)=>(Module._CacheRegisterRelcacheCallback=wasmExports.CacheRegisterRelcacheCallback)(e,I),Module._free_attrmap=e=>(Module._free_attrmap=wasmExports.free_attrmap)(e),Module._BuildIndexInfo=e=>(Module._BuildIndexInfo=wasmExports.BuildIndexInfo)(e),Module._hash_seq_term=e=>(Module._hash_seq_term=wasmExports.hash_seq_term)(e),Module._PushActiveSnapshot=e=>(Module._PushActiveSnapshot=wasmExports.PushActiveSnapshot)(e),Module._PopActiveSnapshot=()=>(Module._PopActiveSnapshot=wasmExports.PopActiveSnapshot)(),Module._MakePerTupleExprContext=e=>(Module._MakePerTupleExprContext=wasmExports.MakePerTupleExprContext)(e),Module._ExecInitExpr=(e,I)=>(Module._ExecInitExpr=wasmExports.ExecInitExpr)(e,I),Module._FreeExecutorState=e=>(Module._FreeExecutorState=wasmExports.FreeExecutorState)(e),Module._list_member_oid=(e,I)=>(Module._list_member_oid=wasmExports.list_member_oid)(e,I),Module._MemoryContextStrdup=(e,I)=>(Module._MemoryContextStrdup=wasmExports.MemoryContextStrdup)(e,I),Module._pq_getmsgint=(e,I)=>(Module._pq_getmsgint=wasmExports.pq_getmsgint)(e,I),Module._CreateExecutorState=()=>(Module._CreateExecutorState=wasmExports.CreateExecutorState)(),Module._ExecInitRangeTable=(e,I,Hn)=>(Module._ExecInitRangeTable=wasmExports.ExecInitRangeTable)(e,I,Hn),Module._getTypeInputInfo=(e,I,Hn)=>(Module._getTypeInputInfo=wasmExports.getTypeInputInfo)(e,I,Hn),Module._ExecStoreVirtualTuple=e=>(Module._ExecStoreVirtualTuple=wasmExports.ExecStoreVirtualTuple)(e),Module._execute_attr_map_slot=(e,I,Hn)=>(Module._execute_attr_map_slot=wasmExports.execute_attr_map_slot)(e,I,Hn),Module._slot_getsomeattrs_int=(e,I)=>(Module._slot_getsomeattrs_int=wasmExports.slot_getsomeattrs_int)(e,I),Module._GetUserNameFromId=(e,I)=>(Module._GetUserNameFromId=wasmExports.GetUserNameFromId)(e,I),Module._makeStringInfo=()=>(Module._makeStringInfo=wasmExports.makeStringInfo)(),Module._list_member_xid=(e,I)=>(Module._list_member_xid=wasmExports.list_member_xid)(e,I),Module._lappend_xid=(e,I)=>(Module._lappend_xid=wasmExports.lappend_xid)(e,I),Module._tuplestore_end=e=>(Module._tuplestore_end=wasmExports.tuplestore_end)(e),Module._quote_literal_cstr=e=>(Module._quote_literal_cstr=wasmExports.quote_literal_cstr)(e),Module._MakeSingleTupleTableSlot=(e,I)=>(Module._MakeSingleTupleTableSlot=wasmExports.MakeSingleTupleTableSlot)(e,I),Module._ExecDropSingleTupleTableSlot=e=>(Module._ExecDropSingleTupleTableSlot=wasmExports.ExecDropSingleTupleTableSlot)(e),Module._tuplestore_tuple_count=e=>(Module._tuplestore_tuple_count=wasmExports.tuplestore_tuple_count)(e),Module._quote_identifier=e=>(Module._quote_identifier=wasmExports.quote_identifier)(e),Module._BeginCopyFrom=(e,I,Hn,$n,qn,Xn,Yn,Kn)=>(Module._BeginCopyFrom=wasmExports.BeginCopyFrom)(e,I,Hn,$n,qn,Xn,Yn,Kn),Module._array_contains_nulls=e=>(Module._array_contains_nulls=wasmExports.array_contains_nulls)(e),Module._format_procedure=e=>(Module._format_procedure=wasmExports.format_procedure)(e),Module._pg_detoast_datum_packed=e=>(Module._pg_detoast_datum_packed=wasmExports.pg_detoast_datum_packed)(e),Module._cstring_to_text_with_len=(e,I)=>(Module._cstring_to_text_with_len=wasmExports.cstring_to_text_with_len)(e,I),Module._GenerationContextCreate=(e,I,Hn,$n,qn)=>(Module._GenerationContextCreate=wasmExports.GenerationContextCreate)(e,I,Hn,$n,qn),Module._BeginInternalSubTransaction=e=>(Module._BeginInternalSubTransaction=wasmExports.BeginInternalSubTransaction)(e),Module._RollbackAndReleaseCurrentSubTransaction=()=>(Module._RollbackAndReleaseCurrentSubTransaction=wasmExports.RollbackAndReleaseCurrentSubTransaction)(),Module._CopyErrorData=()=>(Module._CopyErrorData=wasmExports.CopyErrorData)(),Module._FreeErrorData=e=>(Module._FreeErrorData=wasmExports.FreeErrorData)(e),Module._RelidByRelfilenumber=(e,I)=>(Module._RelidByRelfilenumber=wasmExports.RelidByRelfilenumber)(e,I),Module._RelationIdGetRelation=e=>(Module._RelationIdGetRelation=wasmExports.RelationIdGetRelation)(e),Module._heap_deform_tuple=(e,I,Hn,$n)=>(Module._heap_deform_tuple=wasmExports.heap_deform_tuple)(e,I,Hn,$n),Module._RelationClose=e=>(Module._RelationClose=wasmExports.RelationClose)(e),Module._nocachegetattr=(e,I,Hn)=>(Module._nocachegetattr=wasmExports.nocachegetattr)(e,I,Hn),Module._XLogReaderAllocate=(e,I,Hn,$n)=>(Module._XLogReaderAllocate=wasmExports.XLogReaderAllocate)(e,I,Hn,$n),Module._XLogReaderFree=e=>(Module._XLogReaderFree=wasmExports.XLogReaderFree)(e),Module._OutputPluginPrepareWrite=(e,I)=>(Module._OutputPluginPrepareWrite=wasmExports.OutputPluginPrepareWrite)(e,I),Module._OutputPluginWrite=(e,I)=>(Module._OutputPluginWrite=wasmExports.OutputPluginWrite)(e,I),Module._OutputPluginUpdateProgress=(e,I)=>(Module._OutputPluginUpdateProgress=wasmExports.OutputPluginUpdateProgress)(e,I),Module._replorigin_by_oid=(e,I,Hn)=>(Module._replorigin_by_oid=wasmExports.replorigin_by_oid)(e,I,Hn),Module._logicalrep_write_begin=(e,I)=>(Module._logicalrep_write_begin=wasmExports.logicalrep_write_begin)(e,I),Module._logicalrep_write_commit=(e,I,Hn)=>(Module._logicalrep_write_commit=wasmExports.logicalrep_write_commit)(e,I,Hn),Module._logicalrep_write_begin_prepare=(e,I)=>(Module._logicalrep_write_begin_prepare=wasmExports.logicalrep_write_begin_prepare)(e,I),Module._logicalrep_write_prepare=(e,I,Hn)=>(Module._logicalrep_write_prepare=wasmExports.logicalrep_write_prepare)(e,I,Hn),Module._logicalrep_write_commit_prepared=(e,I,Hn)=>(Module._logicalrep_write_commit_prepared=wasmExports.logicalrep_write_commit_prepared)(e,I,Hn),Module._logicalrep_write_rollback_prepared=(e,I,Hn,$n)=>(Module._logicalrep_write_rollback_prepared=wasmExports.logicalrep_write_rollback_prepared)(e,I,Hn,$n),Module._logicalrep_write_stream_prepare=(e,I,Hn)=>(Module._logicalrep_write_stream_prepare=wasmExports.logicalrep_write_stream_prepare)(e,I,Hn),Module._logicalrep_write_origin=(e,I,Hn)=>(Module._logicalrep_write_origin=wasmExports.logicalrep_write_origin)(e,I,Hn),Module._logicalrep_write_insert=(e,I,Hn,$n,qn,Xn)=>(Module._logicalrep_write_insert=wasmExports.logicalrep_write_insert)(e,I,Hn,$n,qn,Xn),Module._logicalrep_write_update=(e,I,Hn,$n,qn,Xn,Yn)=>(Module._logicalrep_write_update=wasmExports.logicalrep_write_update)(e,I,Hn,$n,qn,Xn,Yn),Module._logicalrep_write_delete=(e,I,Hn,$n,qn,Xn)=>(Module._logicalrep_write_delete=wasmExports.logicalrep_write_delete)(e,I,Hn,$n,qn,Xn),Module._logicalrep_write_truncate=(e,I,Hn,$n,qn,Xn)=>(Module._logicalrep_write_truncate=wasmExports.logicalrep_write_truncate)(e,I,Hn,$n,qn,Xn),Module._logicalrep_write_message=(e,I,Hn,$n,qn,Xn,Yn)=>(Module._logicalrep_write_message=wasmExports.logicalrep_write_message)(e,I,Hn,$n,qn,Xn,Yn),Module._logicalrep_write_rel=(e,I,Hn,$n)=>(Module._logicalrep_write_rel=wasmExports.logicalrep_write_rel)(e,I,Hn,$n),Module._logicalrep_write_typ=(e,I,Hn)=>(Module._logicalrep_write_typ=wasmExports.logicalrep_write_typ)(e,I,Hn),Module._logicalrep_write_stream_start=(e,I,Hn)=>(Module._logicalrep_write_stream_start=wasmExports.logicalrep_write_stream_start)(e,I,Hn),Module._logicalrep_write_stream_stop=e=>(Module._logicalrep_write_stream_stop=wasmExports.logicalrep_write_stream_stop)(e),Module._logicalrep_write_stream_commit=(e,I,Hn)=>(Module._logicalrep_write_stream_commit=wasmExports.logicalrep_write_stream_commit)(e,I,Hn),Module._logicalrep_write_stream_abort=(e,I,Hn,$n,qn,Xn)=>(Module._logicalrep_write_stream_abort=wasmExports.logicalrep_write_stream_abort)(e,I,Hn,$n,qn,Xn),Module._ProcessWalRcvInterrupts=()=>(Module._ProcessWalRcvInterrupts=wasmExports.ProcessWalRcvInterrupts)(),Module._timestamptz_to_str=e=>(Module._timestamptz_to_str=wasmExports.timestamptz_to_str)(e),Module._GetDatabaseEncodingName=()=>(Module._GetDatabaseEncodingName=wasmExports.GetDatabaseEncodingName)(),Module._PQconnectStartParams=(e,I,Hn)=>(Module._PQconnectStartParams=wasmExports.PQconnectStartParams)(e,I,Hn),Module._PQstatus=e=>(Module._PQstatus=wasmExports.PQstatus)(e),Module._PQsocket=e=>(Module._PQsocket=wasmExports.PQsocket)(e),Module._PQconnectPoll=e=>(Module._PQconnectPoll=wasmExports.PQconnectPoll)(e),Module._PQconnectionUsedPassword=e=>(Module._PQconnectionUsedPassword=wasmExports.PQconnectionUsedPassword)(e),Module._PQfinish=e=>(Module._PQfinish=wasmExports.PQfinish)(e),Module._PQresultStatus=e=>(Module._PQresultStatus=wasmExports.PQresultStatus)(e),Module._PQclear=e=>(Module._PQclear=wasmExports.PQclear)(e),Module._PQerrorMessage=e=>(Module._PQerrorMessage=wasmExports.PQerrorMessage)(e),Module._pchomp=e=>(Module._pchomp=wasmExports.pchomp)(e),Module._PQnfields=e=>(Module._PQnfields=wasmExports.PQnfields)(e),Module._PQntuples=e=>(Module._PQntuples=wasmExports.PQntuples)(e),Module._PQgetvalue=(e,I,Hn)=>(Module._PQgetvalue=wasmExports.PQgetvalue)(e,I,Hn),Module._pg_strtoint32=e=>(Module._pg_strtoint32=wasmExports.pg_strtoint32)(e),Module._PQconsumeInput=e=>(Module._PQconsumeInput=wasmExports.PQconsumeInput)(e),Module._pg_lsn_in=e=>(Module._pg_lsn_in=wasmExports.pg_lsn_in)(e),Module._DirectFunctionCall1Coll=(e,I,Hn)=>(Module._DirectFunctionCall1Coll=wasmExports.DirectFunctionCall1Coll)(e,I,Hn),Module._PQgetisnull=(e,I,Hn)=>(Module._PQgetisnull=wasmExports.PQgetisnull)(e,I,Hn),Module._tuplestore_begin_heap=(e,I,Hn)=>(Module._tuplestore_begin_heap=wasmExports.tuplestore_begin_heap)(e,I,Hn),Module._TupleDescGetAttInMetadata=e=>(Module._TupleDescGetAttInMetadata=wasmExports.TupleDescGetAttInMetadata)(e),Module._BuildTupleFromCStrings=(e,I)=>(Module._BuildTupleFromCStrings=wasmExports.BuildTupleFromCStrings)(e,I),Module._tuplestore_puttuple=(e,I)=>(Module._tuplestore_puttuple=wasmExports.tuplestore_puttuple)(e,I),Module._PQresultErrorField=(e,I)=>(Module._PQresultErrorField=wasmExports.PQresultErrorField)(e,I),Module._PQsendQuery=(e,I)=>(Module._PQsendQuery=wasmExports.PQsendQuery)(e,I),Module._PQisBusy=e=>(Module._PQisBusy=wasmExports.PQisBusy)(e),Module._PQgetResult=e=>(Module._PQgetResult=wasmExports.PQgetResult)(e),Module._ResourceOwnerDelete=e=>(Module._ResourceOwnerDelete=wasmExports.ResourceOwnerDelete)(e),Module._CreateDestReceiver=e=>(Module._CreateDestReceiver=wasmExports.CreateDestReceiver)(e),Module._defGetString=e=>(Module._defGetString=wasmExports.defGetString)(e),Module._pg_md5_encrypt=(e,I,Hn,$n,qn)=>(Module._pg_md5_encrypt=wasmExports.pg_md5_encrypt)(e,I,Hn,$n,qn),Module._plain_crypt_verify=(e,I,Hn,$n)=>(Module._plain_crypt_verify=wasmExports.plain_crypt_verify)(e,I,Hn,$n),Module._pg_b64_enc_len=e=>(Module._pg_b64_enc_len=wasmExports.pg_b64_enc_len)(e),Module._pg_b64_encode=(e,I,Hn,$n)=>(Module._pg_b64_encode=wasmExports.pg_b64_encode)(e,I,Hn,$n),Module._pg_b64_dec_len=e=>(Module._pg_b64_dec_len=wasmExports.pg_b64_dec_len)(e),Module._pg_b64_decode=(e,I,Hn,$n)=>(Module._pg_b64_decode=wasmExports.pg_b64_decode)(e,I,Hn,$n),Module._pg_hmac_create=e=>(Module._pg_hmac_create=wasmExports.pg_hmac_create)(e),Module._pg_hmac_init=(e,I,Hn)=>(Module._pg_hmac_init=wasmExports.pg_hmac_init)(e,I,Hn),Module._pg_hmac_update=(e,I,Hn)=>(Module._pg_hmac_update=wasmExports.pg_hmac_update)(e,I,Hn),Module._pg_hmac_final=(e,I,Hn)=>(Module._pg_hmac_final=wasmExports.pg_hmac_final)(e,I,Hn),Module._pg_hmac_error=e=>(Module._pg_hmac_error=wasmExports.pg_hmac_error)(e),Module._pg_hmac_free=e=>(Module._pg_hmac_free=wasmExports.pg_hmac_free)(e),Module._scram_H=(e,I,Hn,$n,qn)=>(Module._scram_H=wasmExports.scram_H)(e,I,Hn,$n,qn),Module._pg_saslprep=(e,I)=>(Module._pg_saslprep=wasmExports.pg_saslprep)(e,I),Module._scram_build_secret=(e,I,Hn,$n,qn,Xn,Yn)=>(Module._scram_build_secret=wasmExports.scram_build_secret)(e,I,Hn,$n,qn,Xn,Yn),Module._scram_SaltedPassword=(e,I,Hn,$n,qn,Xn,Yn,Kn)=>(Module._scram_SaltedPassword=wasmExports.scram_SaltedPassword)(e,I,Hn,$n,qn,Xn,Yn,Kn),Module._scram_ServerKey=(e,I,Hn,$n,qn)=>(Module._scram_ServerKey=wasmExports.scram_ServerKey)(e,I,Hn,$n,qn),Module._strtol=(e,I,Hn)=>(Module._strtol=wasmExports.strtol)(e,I,Hn),Module._replace_percent_placeholders=(e,I,Hn,$n)=>(Module._replace_percent_placeholders=wasmExports.replace_percent_placeholders)(e,I,Hn,$n),Module._fgets=(e,I,Hn)=>(Module._fgets=wasmExports.fgets)(e,I,Hn),Module._explicit_bzero=(e,I)=>(Module._explicit_bzero=wasmExports.explicit_bzero)(e,I),Module._wait_result_to_str=e=>(Module._wait_result_to_str=wasmExports.wait_result_to_str)(e),Module._pg_strip_crlf=e=>(Module._pg_strip_crlf=wasmExports.pg_strip_crlf)(e),Module._geteuid=()=>(Module._geteuid=wasmExports.geteuid)(),Module._getpeereid=(e,I,Hn)=>(Module._getpeereid=wasmExports.getpeereid)(e,I,Hn),Module._pg_getaddrinfo_all=(e,I,Hn,$n)=>(Module._pg_getaddrinfo_all=wasmExports.pg_getaddrinfo_all)(e,I,Hn,$n),Module._socket=(e,I,Hn)=>(Module._socket=wasmExports.socket)(e,I,Hn),Module._connect=(e,I,Hn)=>(Module._connect=wasmExports.connect)(e,I,Hn),Module._recv=(e,I,Hn,$n)=>(Module._recv=wasmExports.recv)(e,I,Hn,$n),Module._pg_freeaddrinfo_all=(e,I)=>(Module._pg_freeaddrinfo_all=wasmExports.pg_freeaddrinfo_all)(e,I),Module._pq_sendtext=(e,I,Hn)=>(Module._pq_sendtext=wasmExports.pq_sendtext)(e,I,Hn),Module._pq_sendfloat4=(e,I)=>(Module._pq_sendfloat4=wasmExports.pq_sendfloat4)(e,I),Module._pq_sendfloat8=(e,I)=>(Module._pq_sendfloat8=wasmExports.pq_sendfloat8)(e,I),Module._pq_begintypsend=e=>(Module._pq_begintypsend=wasmExports.pq_begintypsend)(e),Module._pq_endtypsend=e=>(Module._pq_endtypsend=wasmExports.pq_endtypsend)(e),Module._pq_getmsgfloat4=e=>(Module._pq_getmsgfloat4=wasmExports.pq_getmsgfloat4)(e),Module._pq_getmsgfloat8=e=>(Module._pq_getmsgfloat8=wasmExports.pq_getmsgfloat8)(e),Module._pq_getmsgtext=(e,I,Hn)=>(Module._pq_getmsgtext=wasmExports.pq_getmsgtext)(e,I,Hn),Module._feof=e=>(Module._feof=wasmExports.feof)(e),Module._pg_mb2wchar_with_len=(e,I,Hn)=>(Module._pg_mb2wchar_with_len=wasmExports.pg_mb2wchar_with_len)(e,I,Hn),Module._pg_regcomp=(e,I,Hn,$n,qn)=>(Module._pg_regcomp=wasmExports.pg_regcomp)(e,I,Hn,$n,qn),Module._pg_regerror=(e,I,Hn,$n)=>(Module._pg_regerror=wasmExports.pg_regerror)(e,I,Hn,$n),Module._get_role_oid=(e,I)=>(Module._get_role_oid=wasmExports.get_role_oid)(e,I),Module._strcat=(e,I)=>(Module._strcat=wasmExports.strcat)(e,I),Module._sigemptyset=e=>(Module._sigemptyset=wasmExports.sigemptyset)(e),Module._be_lo_unlink=e=>(Module._be_lo_unlink=wasmExports.be_lo_unlink)(e),Module._object_ownercheck=(e,I,Hn)=>(Module._object_ownercheck=wasmExports.object_ownercheck)(e,I,Hn),Module._text_to_cstring_buffer=(e,I,Hn)=>(Module._text_to_cstring_buffer=wasmExports.text_to_cstring_buffer)(e,I,Hn),Module._setsockopt=(e,I,Hn,$n,qn)=>(Module._setsockopt=wasmExports.setsockopt)(e,I,Hn,$n,qn),Module._getsockname=(e,I,Hn)=>(Module._getsockname=wasmExports.getsockname)(e,I,Hn),Module._pq_recvbuf_fill=(e,I)=>(Module._pq_recvbuf_fill=wasmExports.pq_recvbuf_fill)(e,I),Module._getsockopt=(e,I,Hn,$n,qn)=>(Module._getsockopt=wasmExports.getsockopt)(e,I,Hn,$n,qn),Module._getmissingattr=(e,I,Hn)=>(Module._getmissingattr=wasmExports.getmissingattr)(e,I,Hn),Module._get_rel_relkind=e=>(Module._get_rel_relkind=wasmExports.get_rel_relkind)(e),Module._MemoryContextSetIdentifier=(e,I)=>(Module._MemoryContextSetIdentifier=wasmExports.MemoryContextSetIdentifier)(e,I),Module._MemoryContextSetParent=(e,I)=>(Module._MemoryContextSetParent=wasmExports.MemoryContextSetParent)(e,I),Module._find_base_rel=(e,I)=>(Module._find_base_rel=wasmExports.find_base_rel)(e,I),Module._bms_equal=(e,I)=>(Module._bms_equal=wasmExports.bms_equal)(e,I),Module._bms_num_members=e=>(Module._bms_num_members=wasmExports.bms_num_members)(e),Module._fmgr_info_copy=(e,I,Hn)=>(Module._fmgr_info_copy=wasmExports.fmgr_info_copy)(e,I,Hn),Module._fmgr_info_cxt=(e,I,Hn)=>(Module._fmgr_info_cxt=wasmExports.fmgr_info_cxt)(e,I,Hn),Module._get_typlenbyvalalign=(e,I,Hn,$n)=>(Module._get_typlenbyvalalign=wasmExports.get_typlenbyvalalign)(e,I,Hn,$n),Module._deconstruct_array=(e,I,Hn,$n,qn,Xn,Yn,Kn)=>(Module._deconstruct_array=wasmExports.deconstruct_array)(e,I,Hn,$n,qn,Xn,Yn,Kn),Module._datumCopy=(e,I,Hn)=>(Module._datumCopy=wasmExports.datumCopy)(e,I,Hn),Module._qsort_arg=(e,I,Hn,$n,qn)=>(Module._qsort_arg=wasmExports.qsort_arg)(e,I,Hn,$n,qn),Module._FunctionCall2Coll=(e,I,Hn,$n)=>(Module._FunctionCall2Coll=wasmExports.FunctionCall2Coll)(e,I,Hn,$n),Module._datumIsEqual=(e,I,Hn,$n)=>(Module._datumIsEqual=wasmExports.datumIsEqual)(e,I,Hn,$n),Module._bms_overlap=(e,I)=>(Module._bms_overlap=wasmExports.bms_overlap)(e,I),Module._ExecPrepareExpr=(e,I)=>(Module._ExecPrepareExpr=wasmExports.ExecPrepareExpr)(e,I),Module._RegisterSnapshot=e=>(Module._RegisterSnapshot=wasmExports.RegisterSnapshot)(e),Module._UnregisterSnapshot=e=>(Module._UnregisterSnapshot=wasmExports.UnregisterSnapshot)(e),Module._get_fn_expr_argtype=(e,I)=>(Module._get_fn_expr_argtype=wasmExports.get_fn_expr_argtype)(e,I),Module._get_opfamily_member=(e,I,Hn,$n)=>(Module._get_opfamily_member=wasmExports.get_opfamily_member)(e,I,Hn,$n),Module._init_MultiFuncCall=e=>(Module._init_MultiFuncCall=wasmExports.init_MultiFuncCall)(e),Module._per_MultiFuncCall=e=>(Module._per_MultiFuncCall=wasmExports.per_MultiFuncCall)(e),Module._end_MultiFuncCall=(e,I)=>(Module._end_MultiFuncCall=wasmExports.end_MultiFuncCall)(e,I),Module._textToQualifiedNameList=e=>(Module._textToQualifiedNameList=wasmExports.textToQualifiedNameList)(e),Module._FunctionCall1Coll=(e,I,Hn)=>(Module._FunctionCall1Coll=wasmExports.FunctionCall1Coll)(e,I,Hn),Module._DirectFunctionCall4Coll=(e,I,Hn,$n,qn,Xn)=>(Module._DirectFunctionCall4Coll=wasmExports.DirectFunctionCall4Coll)(e,I,Hn,$n,qn,Xn),Module._pg_mblen=e=>(Module._pg_mblen=wasmExports.pg_mblen)(e),Module._tsearch_readline_begin=(e,I)=>(Module._tsearch_readline_begin=wasmExports.tsearch_readline_begin)(e,I),Module._tsearch_readline=e=>(Module._tsearch_readline=wasmExports.tsearch_readline)(e),Module._t_isspace=e=>(Module._t_isspace=wasmExports.t_isspace)(e),Module._lowerstr=e=>(Module._lowerstr=wasmExports.lowerstr)(e),Module._tsearch_readline_end=e=>(Module._tsearch_readline_end=wasmExports.tsearch_readline_end)(e),Module._t_isdigit=e=>(Module._t_isdigit=wasmExports.t_isdigit)(e),Module._pnstrdup=(e,I)=>(Module._pnstrdup=wasmExports.pnstrdup)(e,I),Module._get_tsearch_config_filename=(e,I)=>(Module._get_tsearch_config_filename=wasmExports.get_tsearch_config_filename)(e,I),Module._lookup_ts_dictionary_cache=e=>(Module._lookup_ts_dictionary_cache=wasmExports.lookup_ts_dictionary_cache)(e),Module._FunctionCall4Coll=(e,I,Hn,$n,qn,Xn)=>(Module._FunctionCall4Coll=wasmExports.FunctionCall4Coll)(e,I,Hn,$n,qn,Xn),Module._t_isalnum=e=>(Module._t_isalnum=wasmExports.t_isalnum)(e),Module._isalnum=e=>(Module._isalnum=wasmExports.isalnum)(e),Module._pg_any_to_server=(e,I,Hn)=>(Module._pg_any_to_server=wasmExports.pg_any_to_server)(e,I,Hn),Module._lowerstr_with_len=(e,I)=>(Module._lowerstr_with_len=wasmExports.lowerstr_with_len)(e,I),Module._tolower=e=>(Module._tolower=wasmExports.tolower)(e),Module._readstoplist=(e,I,Hn)=>(Module._readstoplist=wasmExports.readstoplist)(e,I,Hn),Module._searchstoplist=(e,I)=>(Module._searchstoplist=wasmExports.searchstoplist)(e,I),Module._GetDatabaseEncoding=()=>(Module._GetDatabaseEncoding=wasmExports.GetDatabaseEncoding)(),Module._vacuum_delay_point=()=>(Module._vacuum_delay_point=wasmExports.vacuum_delay_point)(),Module._get_restriction_variable=(e,I,Hn,$n,qn,Xn)=>(Module._get_restriction_variable=wasmExports.get_restriction_variable)(e,I,Hn,$n,qn,Xn),Module._get_attstatsslot=(e,I,Hn,$n,qn)=>(Module._get_attstatsslot=wasmExports.get_attstatsslot)(e,I,Hn,$n,qn),Module._free_attstatsslot=e=>(Module._free_attstatsslot=wasmExports.free_attstatsslot)(e),Module._Float8GetDatum=e=>(Module._Float8GetDatum=wasmExports.Float8GetDatum)(e),Module._ExecReScan=e=>(Module._ExecReScan=wasmExports.ExecReScan)(e),Module._ExecAsyncResponse=e=>(Module._ExecAsyncResponse=wasmExports.ExecAsyncResponse)(e),Module._ExecAsyncRequestDone=(e,I)=>(Module._ExecAsyncRequestDone=wasmExports.ExecAsyncRequestDone)(e,I),Module._ExecAsyncRequestPending=e=>(Module._ExecAsyncRequestPending=wasmExports.ExecAsyncRequestPending)(e),Module._tuplesort_end=e=>(Module._tuplesort_end=wasmExports.tuplesort_end)(e),Module._ExecInitExprList=(e,I)=>(Module._ExecInitExprList=wasmExports.ExecInitExprList)(e,I),Module._fmgr_info=(e,I)=>(Module._fmgr_info=wasmExports.fmgr_info)(e,I),Module._get_typlenbyval=(e,I,Hn)=>(Module._get_typlenbyval=wasmExports.get_typlenbyval)(e,I,Hn),Module._ExecForceStoreHeapTuple=(e,I,Hn)=>(Module._ExecForceStoreHeapTuple=wasmExports.ExecForceStoreHeapTuple)(e,I,Hn),Module._tuplesort_performsort=e=>(Module._tuplesort_performsort=wasmExports.tuplesort_performsort)(e),Module._tuplesort_begin_heap=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn)=>(Module._tuplesort_begin_heap=wasmExports.tuplesort_begin_heap)(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn),Module._MemoryContextMemAllocated=(e,I)=>(Module._MemoryContextMemAllocated=wasmExports.MemoryContextMemAllocated)(e,I),Module._tuplesort_gettupleslot=(e,I,Hn,$n,qn)=>(Module._tuplesort_gettupleslot=wasmExports.tuplesort_gettupleslot)(e,I,Hn,$n,qn),Module._tuplesort_puttupleslot=(e,I)=>(Module._tuplesort_puttupleslot=wasmExports.tuplesort_puttupleslot)(e,I),Module._ExecStoreAllNullTuple=e=>(Module._ExecStoreAllNullTuple=wasmExports.ExecStoreAllNullTuple)(e),Module._MakeExpandedObjectReadOnlyInternal=e=>(Module._MakeExpandedObjectReadOnlyInternal=wasmExports.MakeExpandedObjectReadOnlyInternal)(e),Module._BlessTupleDesc=e=>(Module._BlessTupleDesc=wasmExports.BlessTupleDesc)(e),Module._pg_detoast_datum_copy=e=>(Module._pg_detoast_datum_copy=wasmExports.pg_detoast_datum_copy)(e),Module._construct_md_array=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn)=>(Module._construct_md_array=wasmExports.construct_md_array)(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn),Module._ArrayGetNItems=(e,I)=>(Module._ArrayGetNItems=wasmExports.ArrayGetNItems)(e,I),Module._construct_empty_array=e=>(Module._construct_empty_array=wasmExports.construct_empty_array)(e),Module._DatumGetEOHP=e=>(Module._DatumGetEOHP=wasmExports.DatumGetEOHP)(e),Module._expanded_record_fetch_tupdesc=e=>(Module._expanded_record_fetch_tupdesc=wasmExports.expanded_record_fetch_tupdesc)(e),Module._expanded_record_fetch_field=(e,I,Hn)=>(Module._expanded_record_fetch_field=wasmExports.expanded_record_fetch_field)(e,I,Hn),Module._execute_attr_map_tuple=(e,I)=>(Module._execute_attr_map_tuple=wasmExports.execute_attr_map_tuple)(e,I),Module._MemoryContextAllocExtended=(e,I,Hn)=>(Module._MemoryContextAllocExtended=wasmExports.MemoryContextAllocExtended)(e,I,Hn),Module._lookup_rowtype_tupdesc_domain=(e,I,Hn)=>(Module._lookup_rowtype_tupdesc_domain=wasmExports.lookup_rowtype_tupdesc_domain)(e,I,Hn),Module._MemoryContextGetParent=e=>(Module._MemoryContextGetParent=wasmExports.MemoryContextGetParent)(e),Module._DeleteExpandedObject=e=>(Module._DeleteExpandedObject=wasmExports.DeleteExpandedObject)(e),Module._InstrAlloc=(e,I,Hn)=>(Module._InstrAlloc=wasmExports.InstrAlloc)(e,I,Hn),Module._ExprEvalPushStep=(e,I)=>(Module._ExprEvalPushStep=wasmExports.ExprEvalPushStep)(e,I),Module._getTypeOutputInfo=(e,I,Hn)=>(Module._getTypeOutputInfo=wasmExports.getTypeOutputInfo)(e,I,Hn),Module._ExecInitExprWithParams=(e,I)=>(Module._ExecInitExprWithParams=wasmExports.ExecInitExprWithParams)(e,I),Module._ExecOpenScanRelation=(e,I,Hn)=>(Module._ExecOpenScanRelation=wasmExports.ExecOpenScanRelation)(e,I,Hn),Module._FreeExprContext=(e,I)=>(Module._FreeExprContext=wasmExports.FreeExprContext)(e,I),Module._CreateExprContext=e=>(Module._CreateExprContext=wasmExports.CreateExprContext)(e),Module._ExecGetReturningSlot=(e,I)=>(Module._ExecGetReturningSlot=wasmExports.ExecGetReturningSlot)(e,I),Module._build_attrmap_by_name_if_req=(e,I,Hn)=>(Module._build_attrmap_by_name_if_req=wasmExports.build_attrmap_by_name_if_req)(e,I,Hn),Module._ExecGetResultRelCheckAsUser=(e,I)=>(Module._ExecGetResultRelCheckAsUser=wasmExports.ExecGetResultRelCheckAsUser)(e,I),Module._InstrEndLoop=e=>(Module._InstrEndLoop=wasmExports.InstrEndLoop)(e),Module._ExecStoreHeapTuple=(e,I,Hn)=>(Module._ExecStoreHeapTuple=wasmExports.ExecStoreHeapTuple)(e,I,Hn),Module._get_partition_ancestors=e=>(Module._get_partition_ancestors=wasmExports.get_partition_ancestors)(e),Module._pull_varattnos=(e,I,Hn)=>(Module._pull_varattnos=wasmExports.pull_varattnos)(e,I,Hn),Module._ExecFindJunkAttributeInTlist=(e,I)=>(Module._ExecFindJunkAttributeInTlist=wasmExports.ExecFindJunkAttributeInTlist)(e,I),Module._visibilitymap_get_status=(e,I,Hn)=>(Module._visibilitymap_get_status=wasmExports.visibilitymap_get_status)(e,I,Hn),Module._index_deform_tuple=(e,I,Hn,$n)=>(Module._index_deform_tuple=wasmExports.index_deform_tuple)(e,I,Hn,$n),Module._LaunchParallelWorkers=e=>(Module._LaunchParallelWorkers=wasmExports.LaunchParallelWorkers)(e),Module._standard_ExecutorStart=(e,I)=>(Module._standard_ExecutorStart=wasmExports.standard_ExecutorStart)(e,I),Module._GetCommandTagName=e=>(Module._GetCommandTagName=wasmExports.GetCommandTagName)(e),Module._standard_ExecutorRun=(e,I,Hn,$n)=>(Module._standard_ExecutorRun=wasmExports.standard_ExecutorRun)(e,I,Hn,$n),Module._EnterParallelMode=()=>(Module._EnterParallelMode=wasmExports.EnterParallelMode)(),Module._ExitParallelMode=()=>(Module._ExitParallelMode=wasmExports.ExitParallelMode)(),Module._standard_ExecutorFinish=e=>(Module._standard_ExecutorFinish=wasmExports.standard_ExecutorFinish)(e),Module._standard_ExecutorEnd=e=>(Module._standard_ExecutorEnd=wasmExports.standard_ExecutorEnd)(e),Module._MakeTupleTableSlot=(e,I)=>(Module._MakeTupleTableSlot=wasmExports.MakeTupleTableSlot)(e,I),Module._CreateParallelContext=(e,I,Hn)=>(Module._CreateParallelContext=wasmExports.CreateParallelContext)(e,I,Hn),Module._InitializeParallelDSM=e=>(Module._InitializeParallelDSM=wasmExports.InitializeParallelDSM)(e),Module._WaitForParallelWorkersToFinish=e=>(Module._WaitForParallelWorkersToFinish=wasmExports.WaitForParallelWorkersToFinish)(e),Module._DestroyParallelContext=e=>(Module._DestroyParallelContext=wasmExports.DestroyParallelContext)(e),Module._SPI_connect=()=>(Module._SPI_connect=wasmExports.SPI_connect)(),Module._SPI_connect_ext=e=>(Module._SPI_connect_ext=wasmExports.SPI_connect_ext)(e),Module._SPI_finish=()=>(Module._SPI_finish=wasmExports.SPI_finish)(),Module._SPI_commit=()=>(Module._SPI_commit=wasmExports.SPI_commit)(),Module._ReThrowError=e=>(Module._ReThrowError=wasmExports.ReThrowError)(e),Module._SPI_commit_and_chain=()=>(Module._SPI_commit_and_chain=wasmExports.SPI_commit_and_chain)(),Module._SPI_rollback=()=>(Module._SPI_rollback=wasmExports.SPI_rollback)(),Module._SPI_rollback_and_chain=()=>(Module._SPI_rollback_and_chain=wasmExports.SPI_rollback_and_chain)(),Module._SPI_execute=(e,I,Hn)=>(Module._SPI_execute=wasmExports.SPI_execute)(e,I,Hn),Module._EnsurePortalSnapshotExists=()=>(Module._EnsurePortalSnapshotExists=wasmExports.EnsurePortalSnapshotExists)(),Module._SPI_freetuptable=e=>(Module._SPI_freetuptable=wasmExports.SPI_freetuptable)(e),Module._ReleaseCachedPlan=(e,I)=>(Module._ReleaseCachedPlan=wasmExports.ReleaseCachedPlan)(e,I),Module._SPI_exec=(e,I)=>(Module._SPI_exec=wasmExports.SPI_exec)(e,I),Module._SPI_execute_extended=(e,I)=>(Module._SPI_execute_extended=wasmExports.SPI_execute_extended)(e,I),Module._makeParamList=e=>(Module._makeParamList=wasmExports.makeParamList)(e),Module._SPI_execp=(e,I,Hn,$n)=>(Module._SPI_execp=wasmExports.SPI_execp)(e,I,Hn,$n),Module._SPI_execute_plan_extended=(e,I)=>(Module._SPI_execute_plan_extended=wasmExports.SPI_execute_plan_extended)(e,I),Module._SPI_execute_plan_with_paramlist=(e,I,Hn,$n)=>(Module._SPI_execute_plan_with_paramlist=wasmExports.SPI_execute_plan_with_paramlist)(e,I,Hn,$n),Module._SPI_prepare=(e,I,Hn)=>(Module._SPI_prepare=wasmExports.SPI_prepare)(e,I,Hn),Module._SPI_prepare_extended=(e,I)=>(Module._SPI_prepare_extended=wasmExports.SPI_prepare_extended)(e,I),Module._SPI_keepplan=e=>(Module._SPI_keepplan=wasmExports.SPI_keepplan)(e),Module._SPI_freeplan=e=>(Module._SPI_freeplan=wasmExports.SPI_freeplan)(e),Module._SPI_copytuple=e=>(Module._SPI_copytuple=wasmExports.SPI_copytuple)(e),Module._SPI_returntuple=(e,I)=>(Module._SPI_returntuple=wasmExports.SPI_returntuple)(e,I),Module._SPI_fnumber=(e,I)=>(Module._SPI_fnumber=wasmExports.SPI_fnumber)(e,I),Module._SPI_fname=(e,I)=>(Module._SPI_fname=wasmExports.SPI_fname)(e,I),Module._SPI_getvalue=(e,I,Hn)=>(Module._SPI_getvalue=wasmExports.SPI_getvalue)(e,I,Hn),Module._SPI_getbinval=(e,I,Hn,$n)=>(Module._SPI_getbinval=wasmExports.SPI_getbinval)(e,I,Hn,$n),Module._SPI_gettype=(e,I)=>(Module._SPI_gettype=wasmExports.SPI_gettype)(e,I),Module._SPI_gettypeid=(e,I)=>(Module._SPI_gettypeid=wasmExports.SPI_gettypeid)(e,I),Module._SPI_getrelname=e=>(Module._SPI_getrelname=wasmExports.SPI_getrelname)(e),Module._SPI_palloc=e=>(Module._SPI_palloc=wasmExports.SPI_palloc)(e),Module._SPI_datumTransfer=(e,I,Hn)=>(Module._SPI_datumTransfer=wasmExports.SPI_datumTransfer)(e,I,Hn),Module._datumTransfer=(e,I,Hn)=>(Module._datumTransfer=wasmExports.datumTransfer)(e,I,Hn),Module._SPI_cursor_open_with_paramlist=(e,I,Hn,$n)=>(Module._SPI_cursor_open_with_paramlist=wasmExports.SPI_cursor_open_with_paramlist)(e,I,Hn,$n),Module._SPI_cursor_parse_open=(e,I,Hn)=>(Module._SPI_cursor_parse_open=wasmExports.SPI_cursor_parse_open)(e,I,Hn),Module._SPI_cursor_find=e=>(Module._SPI_cursor_find=wasmExports.SPI_cursor_find)(e),Module._SPI_cursor_fetch=(e,I,Hn)=>(Module._SPI_cursor_fetch=wasmExports.SPI_cursor_fetch)(e,I,Hn),Module._SPI_scroll_cursor_fetch=(e,I,Hn)=>(Module._SPI_scroll_cursor_fetch=wasmExports.SPI_scroll_cursor_fetch)(e,I,Hn),Module._SPI_scroll_cursor_move=(e,I,Hn)=>(Module._SPI_scroll_cursor_move=wasmExports.SPI_scroll_cursor_move)(e,I,Hn),Module._SPI_cursor_close=e=>(Module._SPI_cursor_close=wasmExports.SPI_cursor_close)(e),Module._SPI_result_code_string=e=>(Module._SPI_result_code_string=wasmExports.SPI_result_code_string)(e),Module._SPI_plan_get_plan_sources=e=>(Module._SPI_plan_get_plan_sources=wasmExports.SPI_plan_get_plan_sources)(e),Module._SPI_plan_get_cached_plan=e=>(Module._SPI_plan_get_cached_plan=wasmExports.SPI_plan_get_cached_plan)(e),Module._geterrposition=()=>(Module._geterrposition=wasmExports.geterrposition)(),Module._internalerrposition=e=>(Module._internalerrposition=wasmExports.internalerrposition)(e),Module._internalerrquery=e=>(Module._internalerrquery=wasmExports.internalerrquery)(e),Module._SPI_register_trigger_data=e=>(Module._SPI_register_trigger_data=wasmExports.SPI_register_trigger_data)(e),Module._EOH_get_flat_size=e=>(Module._EOH_get_flat_size=wasmExports.EOH_get_flat_size)(e),Module._EOH_flatten_into=(e,I,Hn)=>(Module._EOH_flatten_into=wasmExports.EOH_flatten_into)(e,I,Hn),Module._ExecFetchSlotHeapTuple=(e,I,Hn)=>(Module._ExecFetchSlotHeapTuple=wasmExports.ExecFetchSlotHeapTuple)(e,I,Hn),Module._InputFunctionCall=(e,I,Hn,$n)=>(Module._InputFunctionCall=wasmExports.InputFunctionCall)(e,I,Hn,$n),Module._convert_tuples_by_position=(e,I,Hn)=>(Module._convert_tuples_by_position=wasmExports.convert_tuples_by_position)(e,I,Hn),Module._SetTuplestoreDestReceiverParams=(e,I,Hn,$n,qn,Xn)=>(Module._SetTuplestoreDestReceiverParams=wasmExports.SetTuplestoreDestReceiverParams)(e,I,Hn,$n,qn,Xn),Module._detoast_external_attr=e=>(Module._detoast_external_attr=wasmExports.detoast_external_attr)(e),Module._bms_nonempty_difference=(e,I)=>(Module._bms_nonempty_difference=wasmExports.bms_nonempty_difference)(e,I),Module._table_parallelscan_estimate=(e,I)=>(Module._table_parallelscan_estimate=wasmExports.table_parallelscan_estimate)(e,I),Module._table_parallelscan_initialize=(e,I,Hn)=>(Module._table_parallelscan_initialize=wasmExports.table_parallelscan_initialize)(e,I,Hn),Module._table_beginscan_parallel=(e,I)=>(Module._table_beginscan_parallel=wasmExports.table_beginscan_parallel)(e,I),Module._BufferUsageAccumDiff=(e,I,Hn)=>(Module._BufferUsageAccumDiff=wasmExports.BufferUsageAccumDiff)(e,I,Hn),Module._WalUsageAccumDiff=(e,I,Hn)=>(Module._WalUsageAccumDiff=wasmExports.WalUsageAccumDiff)(e,I,Hn),Module._InstrUpdateTupleCount=(e,I)=>(Module._InstrUpdateTupleCount=wasmExports.InstrUpdateTupleCount)(e,I),Module._tuplesort_reset=e=>(Module._tuplesort_reset=wasmExports.tuplesort_reset)(e),Module._get_call_expr_argtype=(e,I)=>(Module._get_call_expr_argtype=wasmExports.get_call_expr_argtype)(e,I),Module._get_typtype=e=>(Module._get_typtype=wasmExports.get_typtype)(e),Module._pull_var_clause=(e,I)=>(Module._pull_var_clause=wasmExports.pull_var_clause)(e,I),Module._bms_is_subset=(e,I)=>(Module._bms_is_subset=wasmExports.bms_is_subset)(e,I),Module._bms_membership=e=>(Module._bms_membership=wasmExports.bms_membership)(e),Module._make_restrictinfo=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn)=>(Module._make_restrictinfo=wasmExports.make_restrictinfo)(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn),Module._GetSysCacheHashValue=(e,I,Hn,$n,qn)=>(Module._GetSysCacheHashValue=wasmExports.GetSysCacheHashValue)(e,I,Hn,$n,qn),Module._tlist_member=(e,I)=>(Module._tlist_member=wasmExports.tlist_member)(e,I),Module._add_path=(e,I)=>(Module._add_path=wasmExports.add_path)(e,I),Module._contain_mutable_functions=e=>(Module._contain_mutable_functions=wasmExports.contain_mutable_functions)(e),Module._make_orclause=e=>(Module._make_orclause=wasmExports.make_orclause)(e),Module._extract_actual_clauses=(e,I)=>(Module._extract_actual_clauses=wasmExports.extract_actual_clauses)(e,I),Module._cost_sort=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn)=>(Module._cost_sort=wasmExports.cost_sort)(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn),Module._pathkeys_contained_in=(e,I)=>(Module._pathkeys_contained_in=wasmExports.pathkeys_contained_in)(e,I),Module._change_plan_targetlist=(e,I,Hn)=>(Module._change_plan_targetlist=wasmExports.change_plan_targetlist)(e,I,Hn),Module._make_foreignscan=(e,I,Hn,$n,qn,Xn,Yn,Kn)=>(Module._make_foreignscan=wasmExports.make_foreignscan)(e,I,Hn,$n,qn,Xn,Yn,Kn),Module._list_member_ptr=(e,I)=>(Module._list_member_ptr=wasmExports.list_member_ptr)(e,I),Module._clamp_row_est=e=>(Module._clamp_row_est=wasmExports.clamp_row_est)(e),Module._standard_planner=(e,I,Hn,$n)=>(Module._standard_planner=wasmExports.standard_planner)(e,I,Hn,$n),Module._estimate_expression_value=(e,I)=>(Module._estimate_expression_value=wasmExports.estimate_expression_value)(e,I),Module._add_new_columns_to_pathtarget=(e,I)=>(Module._add_new_columns_to_pathtarget=wasmExports.add_new_columns_to_pathtarget)(e,I),Module._get_sortgroupref_clause_noerr=(e,I)=>(Module._get_sortgroupref_clause_noerr=wasmExports.get_sortgroupref_clause_noerr)(e,I),Module._get_agg_clause_costs=(e,I,Hn)=>(Module._get_agg_clause_costs=wasmExports.get_agg_clause_costs)(e,I,Hn),Module._grouping_is_sortable=e=>(Module._grouping_is_sortable=wasmExports.grouping_is_sortable)(e),Module._create_sort_path=(e,I,Hn,$n,qn)=>(Module._create_sort_path=wasmExports.create_sort_path)(e,I,Hn,$n,qn),Module._copy_pathtarget=e=>(Module._copy_pathtarget=wasmExports.copy_pathtarget)(e),Module._get_sortgrouplist_exprs=(e,I)=>(Module._get_sortgrouplist_exprs=wasmExports.get_sortgrouplist_exprs)(e,I),Module._estimate_num_groups=(e,I,Hn,$n,qn)=>(Module._estimate_num_groups=wasmExports.estimate_num_groups)(e,I,Hn,$n,qn),Module._cost_qual_eval=(e,I,Hn)=>(Module._cost_qual_eval=wasmExports.cost_qual_eval)(e,I,Hn),Module._plan_create_index_workers=(e,I)=>(Module._plan_create_index_workers=wasmExports.plan_create_index_workers)(e,I),Module._create_projection_path=(e,I,Hn,$n)=>(Module._create_projection_path=wasmExports.create_projection_path)(e,I,Hn,$n),Module._get_plan_rowmark=(e,I)=>(Module._get_plan_rowmark=wasmExports.get_plan_rowmark)(e,I),Module._find_join_rel=(e,I)=>(Module._find_join_rel=wasmExports.find_join_rel)(e,I),Module._make_canonical_pathkey=(e,I,Hn,$n,qn)=>(Module._make_canonical_pathkey=wasmExports.make_canonical_pathkey)(e,I,Hn,$n,qn),Module._eclass_useful_for_merging=(e,I,Hn)=>(Module._eclass_useful_for_merging=wasmExports.eclass_useful_for_merging)(e,I,Hn),Module._update_mergeclause_eclasses=(e,I)=>(Module._update_mergeclause_eclasses=wasmExports.update_mergeclause_eclasses)(e,I),Module._clauselist_selectivity=(e,I,Hn,$n,qn)=>(Module._clauselist_selectivity=wasmExports.clauselist_selectivity)(e,I,Hn,$n,qn),Module._join_clause_is_movable_to=(e,I)=>(Module._join_clause_is_movable_to=wasmExports.join_clause_is_movable_to)(e,I),Module._generate_implied_equalities_for_column=(e,I,Hn,$n,qn)=>(Module._generate_implied_equalities_for_column=wasmExports.generate_implied_equalities_for_column)(e,I,Hn,$n,qn),Module._get_tablespace_page_costs=(e,I,Hn)=>(Module._get_tablespace_page_costs=wasmExports.get_tablespace_page_costs)(e,I,Hn),Module._set_baserel_size_estimates=(e,I)=>(Module._set_baserel_size_estimates=wasmExports.set_baserel_size_estimates)(e,I),Module._add_to_flat_tlist=(e,I)=>(Module._add_to_flat_tlist=wasmExports.add_to_flat_tlist)(e,I),Module._get_baserel_parampathinfo=(e,I,Hn)=>(Module._get_baserel_parampathinfo=wasmExports.get_baserel_parampathinfo)(e,I,Hn),Module._create_foreignscan_path=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn)=>(Module._create_foreignscan_path=wasmExports.create_foreignscan_path)(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn),Module._create_foreign_join_path=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn)=>(Module._create_foreign_join_path=wasmExports.create_foreign_join_path)(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn),Module._create_foreign_upper_path=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn)=>(Module._create_foreign_upper_path=wasmExports.create_foreign_upper_path)(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn),Module._adjust_limit_rows_costs=(e,I,Hn,$n,qn)=>(Module._adjust_limit_rows_costs=wasmExports.adjust_limit_rows_costs)(e,I,Hn,$n,qn),Module._SearchSysCacheAttName=(e,I)=>(Module._SearchSysCacheAttName=wasmExports.SearchSysCacheAttName)(e,I),Module._get_translated_update_targetlist=(e,I,Hn,$n)=>(Module._get_translated_update_targetlist=wasmExports.get_translated_update_targetlist)(e,I,Hn,$n),Module._add_row_identity_var=(e,I,Hn,$n)=>(Module._add_row_identity_var=wasmExports.add_row_identity_var)(e,I,Hn,$n),Module._get_rel_all_updated_cols=(e,I)=>(Module._get_rel_all_updated_cols=wasmExports.get_rel_all_updated_cols)(e,I),Module._list_append_unique_ptr=(e,I)=>(Module._list_append_unique_ptr=wasmExports.list_append_unique_ptr)(e,I),Module._palloc_extended=(e,I)=>(Module._palloc_extended=wasmExports.palloc_extended)(e,I),Module._pg_reg_getinitialstate=e=>(Module._pg_reg_getinitialstate=wasmExports.pg_reg_getinitialstate)(e),Module._pg_reg_getfinalstate=e=>(Module._pg_reg_getfinalstate=wasmExports.pg_reg_getfinalstate)(e),Module._pg_reg_getnumoutarcs=(e,I)=>(Module._pg_reg_getnumoutarcs=wasmExports.pg_reg_getnumoutarcs)(e,I),Module._pg_reg_getoutarcs=(e,I,Hn,$n)=>(Module._pg_reg_getoutarcs=wasmExports.pg_reg_getoutarcs)(e,I,Hn,$n),Module._pg_reg_getnumcolors=e=>(Module._pg_reg_getnumcolors=wasmExports.pg_reg_getnumcolors)(e),Module._pg_reg_colorisbegin=(e,I)=>(Module._pg_reg_colorisbegin=wasmExports.pg_reg_colorisbegin)(e,I),Module._pg_reg_colorisend=(e,I)=>(Module._pg_reg_colorisend=wasmExports.pg_reg_colorisend)(e,I),Module._pg_reg_getnumcharacters=(e,I)=>(Module._pg_reg_getnumcharacters=wasmExports.pg_reg_getnumcharacters)(e,I),Module._pg_reg_getcharacters=(e,I,Hn,$n)=>(Module._pg_reg_getcharacters=wasmExports.pg_reg_getcharacters)(e,I,Hn,$n),Module._toupper=e=>(Module._toupper=wasmExports.toupper)(e),Module._pg_initdb=()=>(Module._pg_initdb=wasmExports.pg_initdb)(),Module._pg_initdb_main=()=>(Module._pg_initdb_main=wasmExports.pg_initdb_main)(),Module.___cxa_throw=(e,I,Hn)=>(Module.___cxa_throw=wasmExports.__cxa_throw)(e,I,Hn),Module._main_repl=()=>(Module._main_repl=wasmExports.main_repl)(),Module._main=(e,I)=>(Module._main=wasmExports.__main_argc_argv)(e,I),Module._setenv=(e,I,Hn)=>(Module._setenv=wasmExports.setenv)(e,I,Hn),Module._pg_repl_raf=()=>(Module._pg_repl_raf=wasmExports.pg_repl_raf)(),Module._GetForeignDataWrapper=e=>(Module._GetForeignDataWrapper=wasmExports.GetForeignDataWrapper)(e),Module._GetForeignServer=e=>(Module._GetForeignServer=wasmExports.GetForeignServer)(e),Module._GetForeignServerExtended=(e,I)=>(Module._GetForeignServerExtended=wasmExports.GetForeignServerExtended)(e,I),Module._GetForeignServerByName=(e,I)=>(Module._GetForeignServerByName=wasmExports.GetForeignServerByName)(e,I),Module._GetUserMapping=(e,I)=>(Module._GetUserMapping=wasmExports.GetUserMapping)(e,I),Module._GetForeignTable=e=>(Module._GetForeignTable=wasmExports.GetForeignTable)(e),Module._GetForeignColumnOptions=(e,I)=>(Module._GetForeignColumnOptions=wasmExports.GetForeignColumnOptions)(e,I),Module._initClosestMatch=(e,I,Hn)=>(Module._initClosestMatch=wasmExports.initClosestMatch)(e,I,Hn),Module._updateClosestMatch=(e,I)=>(Module._updateClosestMatch=wasmExports.updateClosestMatch)(e,I),Module._getClosestMatch=e=>(Module._getClosestMatch=wasmExports.getClosestMatch)(e),Module._GetExistingLocalJoinPath=e=>(Module._GetExistingLocalJoinPath=wasmExports.GetExistingLocalJoinPath)(e),Module._BaseBackupAddTarget=(e,I,Hn)=>(Module._BaseBackupAddTarget=wasmExports.BaseBackupAddTarget)(e,I,Hn),Module._bbsink_forward_begin_backup=e=>(Module._bbsink_forward_begin_backup=wasmExports.bbsink_forward_begin_backup)(e),Module._bbsink_forward_archive_contents=(e,I)=>(Module._bbsink_forward_archive_contents=wasmExports.bbsink_forward_archive_contents)(e,I),Module._bbsink_forward_end_archive=e=>(Module._bbsink_forward_end_archive=wasmExports.bbsink_forward_end_archive)(e),Module._bbsink_forward_begin_archive=(e,I)=>(Module._bbsink_forward_begin_archive=wasmExports.bbsink_forward_begin_archive)(e,I),Module._bbsink_forward_begin_manifest=e=>(Module._bbsink_forward_begin_manifest=wasmExports.bbsink_forward_begin_manifest)(e),Module._bbsink_forward_manifest_contents=(e,I)=>(Module._bbsink_forward_manifest_contents=wasmExports.bbsink_forward_manifest_contents)(e,I),Module._bbsink_forward_end_manifest=e=>(Module._bbsink_forward_end_manifest=wasmExports.bbsink_forward_end_manifest)(e),Module._bbsink_forward_end_backup=(e,I,Hn)=>(Module._bbsink_forward_end_backup=wasmExports.bbsink_forward_end_backup)(e,I,Hn),Module._bbsink_forward_cleanup=e=>(Module._bbsink_forward_cleanup=wasmExports.bbsink_forward_cleanup)(e),Module._ResourceOwnerCreate=(e,I)=>(Module._ResourceOwnerCreate=wasmExports.ResourceOwnerCreate)(e,I),Module._escape_json=(e,I)=>(Module._escape_json=wasmExports.escape_json)(e,I),Module._exprIsLengthCoercion=(e,I)=>(Module._exprIsLengthCoercion=wasmExports.exprIsLengthCoercion)(e,I),Module._tbm_add_tuples=(e,I,Hn,$n)=>(Module._tbm_add_tuples=wasmExports.tbm_add_tuples)(e,I,Hn,$n),Module._appendStringInfoStringQuoted=(e,I,Hn)=>(Module._appendStringInfoStringQuoted=wasmExports.appendStringInfoStringQuoted)(e,I,Hn),Module._list_make5_impl=(e,I,Hn,$n,qn,Xn)=>(Module._list_make5_impl=wasmExports.list_make5_impl)(e,I,Hn,$n,qn,Xn),Module._list_delete=(e,I)=>(Module._list_delete=wasmExports.list_delete)(e,I),Module._CleanQuerytext=(e,I,Hn)=>(Module._CleanQuerytext=wasmExports.CleanQuerytext)(e,I,Hn),Module._EnableQueryId=()=>(Module._EnableQueryId=wasmExports.EnableQueryId)(),Module._get_rel_type_id=e=>(Module._get_rel_type_id=wasmExports.get_rel_type_id)(e),Module._set_config_option=(e,I,Hn,$n,qn,Xn,Yn,Kn)=>(Module._set_config_option=wasmExports.set_config_option)(e,I,Hn,$n,qn,Xn,Yn,Kn),Module._NewGUCNestLevel=()=>(Module._NewGUCNestLevel=wasmExports.NewGUCNestLevel)(),Module._AtEOXact_GUC=(e,I)=>(Module._AtEOXact_GUC=wasmExports.AtEOXact_GUC)(e,I),Module._parse_int=(e,I,Hn,$n)=>(Module._parse_int=wasmExports.parse_int)(e,I,Hn,$n),Module._strtod=(e,I)=>(Module._strtod=wasmExports.strtod)(e,I),Module._parse_real=(e,I,Hn,$n)=>(Module._parse_real=wasmExports.parse_real)(e,I,Hn,$n),Module._DefineCustomBoolVariable=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn)=>(Module._DefineCustomBoolVariable=wasmExports.DefineCustomBoolVariable)(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn),Module._DefineCustomIntVariable=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn,ea,aa)=>(Module._DefineCustomIntVariable=wasmExports.DefineCustomIntVariable)(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn,ea,aa),Module._DefineCustomRealVariable=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn,ea,aa)=>(Module._DefineCustomRealVariable=wasmExports.DefineCustomRealVariable)(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn,ea,aa),Module._DefineCustomStringVariable=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn)=>(Module._DefineCustomStringVariable=wasmExports.DefineCustomStringVariable)(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn),Module._DefineCustomEnumVariable=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn,ea)=>(Module._DefineCustomEnumVariable=wasmExports.DefineCustomEnumVariable)(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn,ea),Module._MarkGUCPrefixReserved=e=>(Module._MarkGUCPrefixReserved=wasmExports.MarkGUCPrefixReserved)(e),Module._strcspn=(e,I)=>(Module._strcspn=wasmExports.strcspn)(e,I),Module._BlockSampler_Init=(e,I,Hn,$n)=>(Module._BlockSampler_Init=wasmExports.BlockSampler_Init)(e,I,Hn,$n),Module._sampler_random_init_state=(e,I)=>(Module._sampler_random_init_state=wasmExports.sampler_random_init_state)(e,I),Module._BlockSampler_HasMore=e=>(Module._BlockSampler_HasMore=wasmExports.BlockSampler_HasMore)(e),Module._BlockSampler_Next=e=>(Module._BlockSampler_Next=wasmExports.BlockSampler_Next)(e),Module._sampler_random_fract=e=>(Module._sampler_random_fract=wasmExports.sampler_random_fract)(e),Module._reservoir_init_selection_state=(e,I)=>(Module._reservoir_init_selection_state=wasmExports.reservoir_init_selection_state)(e,I),Module._reservoir_get_next_S=(e,I,Hn)=>(Module._reservoir_get_next_S=wasmExports.reservoir_get_next_S)(e,I,Hn),Module._canonicalize_path=e=>(Module._canonicalize_path=wasmExports.canonicalize_path)(e),Module.__bt_mkscankey=(e,I)=>(Module.__bt_mkscankey=wasmExports._bt_mkscankey)(e,I),Module._nocache_index_getattr=(e,I,Hn)=>(Module._nocache_index_getattr=wasmExports.nocache_index_getattr)(e,I,Hn),Module._tuplesort_estimate_shared=e=>(Module._tuplesort_estimate_shared=wasmExports.tuplesort_estimate_shared)(e),Module._tuplesort_initialize_shared=(e,I,Hn)=>(Module._tuplesort_initialize_shared=wasmExports.tuplesort_initialize_shared)(e,I,Hn),Module._tuplesort_attach_shared=(e,I)=>(Module._tuplesort_attach_shared=wasmExports.tuplesort_attach_shared)(e,I),Module._GetCurrentTransactionNestLevel=()=>(Module._GetCurrentTransactionNestLevel=wasmExports.GetCurrentTransactionNestLevel)(),Module._in_error_recursion_trouble=()=>(Module._in_error_recursion_trouble=wasmExports.in_error_recursion_trouble)(),Module._strrchr=(e,I)=>(Module._strrchr=wasmExports.strrchr)(e,I),Module._errhidestmt=e=>(Module._errhidestmt=wasmExports.errhidestmt)(e),Module._err_generic_string=(e,I)=>(Module._err_generic_string=wasmExports.err_generic_string)(e,I),Module._getinternalerrposition=()=>(Module._getinternalerrposition=wasmExports.getinternalerrposition)(),Module._GetErrorContextStack=()=>(Module._GetErrorContextStack=wasmExports.GetErrorContextStack)(),Module._SplitIdentifierString=(e,I,Hn)=>(Module._SplitIdentifierString=wasmExports.SplitIdentifierString)(e,I,Hn),Module._appendStringInfoSpaces=(e,I)=>(Module._appendStringInfoSpaces=wasmExports.appendStringInfoSpaces)(e,I),Module._unpack_sql_state=e=>(Module._unpack_sql_state=wasmExports.unpack_sql_state)(e),Module._CreateTupleDescCopyConstr=e=>(Module._CreateTupleDescCopyConstr=wasmExports.CreateTupleDescCopyConstr)(e),Module._CachedPlanAllowsSimpleValidityCheck=(e,I,Hn)=>(Module._CachedPlanAllowsSimpleValidityCheck=wasmExports.CachedPlanAllowsSimpleValidityCheck)(e,I,Hn),Module._CachedPlanIsSimplyValid=(e,I,Hn)=>(Module._CachedPlanIsSimplyValid=wasmExports.CachedPlanIsSimplyValid)(e,I,Hn),Module._GetCachedExpression=e=>(Module._GetCachedExpression=wasmExports.GetCachedExpression)(e),Module._FreeCachedExpression=e=>(Module._FreeCachedExpression=wasmExports.FreeCachedExpression)(e),Module._MemoryContextDeleteChildren=e=>(Module._MemoryContextDeleteChildren=wasmExports.MemoryContextDeleteChildren)(e),Module._is_publishable_relation=e=>(Module._is_publishable_relation=wasmExports.is_publishable_relation)(e),Module._GetRelationPublications=e=>(Module._GetRelationPublications=wasmExports.GetRelationPublications)(e),Module._GetSchemaPublications=e=>(Module._GetSchemaPublications=wasmExports.GetSchemaPublications)(e),Module._index_getprocid=(e,I,Hn)=>(Module._index_getprocid=wasmExports.index_getprocid)(e,I,Hn),Module._get_rel_relispartition=e=>(Module._get_rel_relispartition=wasmExports.get_rel_relispartition)(e),Module._get_func_namespace=e=>(Module._get_func_namespace=wasmExports.get_func_namespace)(e),Module._get_typsubscript=(e,I)=>(Module._get_typsubscript=wasmExports.get_typsubscript)(e,I),Module._get_namespace_name_or_temp=e=>(Module._get_namespace_name_or_temp=wasmExports.get_namespace_name_or_temp)(e),Module._texteq=e=>(Module._texteq=wasmExports.texteq)(e),Module._GetUserIdAndSecContext=(e,I)=>(Module._GetUserIdAndSecContext=wasmExports.GetUserIdAndSecContext)(e,I),Module._SetUserIdAndSecContext=(e,I)=>(Module._SetUserIdAndSecContext=wasmExports.SetUserIdAndSecContext)(e,I),Module._DirectFunctionCall5Coll=(e,I,Hn,$n,qn,Xn,Yn)=>(Module._DirectFunctionCall5Coll=wasmExports.DirectFunctionCall5Coll)(e,I,Hn,$n,qn,Xn,Yn),Module._CallerFInfoFunctionCall2=(e,I,Hn,$n,qn)=>(Module._CallerFInfoFunctionCall2=wasmExports.CallerFInfoFunctionCall2)(e,I,Hn,$n,qn),Module._FunctionCall0Coll=(e,I)=>(Module._FunctionCall0Coll=wasmExports.FunctionCall0Coll)(e,I),Module._OutputFunctionCall=(e,I)=>(Module._OutputFunctionCall=wasmExports.OutputFunctionCall)(e,I),Module._get_fn_expr_rettype=e=>(Module._get_fn_expr_rettype=wasmExports.get_fn_expr_rettype)(e),Module._has_fn_opclass_options=e=>(Module._has_fn_opclass_options=wasmExports.has_fn_opclass_options)(e),Module._get_fn_opclass_options=e=>(Module._get_fn_opclass_options=wasmExports.get_fn_opclass_options)(e),Module._CheckFunctionValidatorAccess=(e,I)=>(Module._CheckFunctionValidatorAccess=wasmExports.CheckFunctionValidatorAccess)(e,I),Module._resolve_polymorphic_argtypes=(e,I,Hn,$n)=>(Module._resolve_polymorphic_argtypes=wasmExports.resolve_polymorphic_argtypes)(e,I,Hn,$n),Module._get_func_arg_info=(e,I,Hn,$n)=>(Module._get_func_arg_info=wasmExports.get_func_arg_info)(e,I,Hn,$n),Module._dlsym=(e,I)=>(Module._dlsym=wasmExports.dlsym)(e,I),Module._dlopen=(e,I)=>(Module._dlopen=wasmExports.dlopen)(e,I),Module._dlerror=()=>(Module._dlerror=wasmExports.dlerror)(),Module._dlclose=e=>(Module._dlclose=wasmExports.dlclose)(e),Module._find_rendezvous_variable=e=>(Module._find_rendezvous_variable=wasmExports.find_rendezvous_variable)(e),Module._fscanf=(e,I,Hn)=>(Module._fscanf=wasmExports.fscanf)(e,I,Hn),Module._strlcat=(e,I,Hn)=>(Module._strlcat=wasmExports.strlcat)(e,I,Hn),Module._pg_bindtextdomain=e=>(Module._pg_bindtextdomain=wasmExports.pg_bindtextdomain)(e),Module._pg_do_encoding_conversion=(e,I,Hn,$n)=>(Module._pg_do_encoding_conversion=wasmExports.pg_do_encoding_conversion)(e,I,Hn,$n),Module._report_invalid_encoding=(e,I,Hn)=>(Module._report_invalid_encoding=wasmExports.report_invalid_encoding)(e,I,Hn),Module._pg_encoding_to_char_private=e=>(Module._pg_encoding_to_char_private=wasmExports.pg_encoding_to_char_private)(e),Module._MemoryContextAllocHuge=(e,I)=>(Module._MemoryContextAllocHuge=wasmExports.MemoryContextAllocHuge)(e,I),Module._namein=e=>(Module._namein=wasmExports.namein)(e),Module._pg_char_to_encoding_private=e=>(Module._pg_char_to_encoding_private=wasmExports.pg_char_to_encoding_private)(e),Module._pg_encoding_max_length=e=>(Module._pg_encoding_max_length=wasmExports.pg_encoding_max_length)(e),Module._pg_server_to_any=(e,I,Hn)=>(Module._pg_server_to_any=wasmExports.pg_server_to_any)(e,I,Hn),Module._pg_utf_mblen=e=>(Module._pg_utf_mblen=wasmExports.pg_utf_mblen)(e),Module._pg_wchar2mb_with_len=(e,I,Hn)=>(Module._pg_wchar2mb_with_len=wasmExports.pg_wchar2mb_with_len)(e,I,Hn),Module._pg_encoding_mblen=(e,I)=>(Module._pg_encoding_mblen=wasmExports.pg_encoding_mblen)(e,I),Module._check_encoding_conversion_args=(e,I,Hn,$n,qn)=>(Module._check_encoding_conversion_args=wasmExports.check_encoding_conversion_args)(e,I,Hn,$n,qn),Module._report_untranslatable_char=(e,I,Hn,$n)=>(Module._report_untranslatable_char=wasmExports.report_untranslatable_char)(e,I,Hn,$n),Module._local2local=(e,I,Hn,$n,qn,Xn,Yn)=>(Module._local2local=wasmExports.local2local)(e,I,Hn,$n,qn,Xn,Yn),Module._latin2mic=(e,I,Hn,$n,qn,Xn)=>(Module._latin2mic=wasmExports.latin2mic)(e,I,Hn,$n,qn,Xn),Module._mic2latin=(e,I,Hn,$n,qn,Xn)=>(Module._mic2latin=wasmExports.mic2latin)(e,I,Hn,$n,qn,Xn),Module._latin2mic_with_table=(e,I,Hn,$n,qn,Xn,Yn)=>(Module._latin2mic_with_table=wasmExports.latin2mic_with_table)(e,I,Hn,$n,qn,Xn,Yn),Module._mic2latin_with_table=(e,I,Hn,$n,qn,Xn,Yn)=>(Module._mic2latin_with_table=wasmExports.mic2latin_with_table)(e,I,Hn,$n,qn,Xn,Yn),Module._pg_encoding_verifymbchar=(e,I,Hn)=>(Module._pg_encoding_verifymbchar=wasmExports.pg_encoding_verifymbchar)(e,I,Hn),Module._float_overflow_error=()=>(Module._float_overflow_error=wasmExports.float_overflow_error)(),Module._float_underflow_error=()=>(Module._float_underflow_error=wasmExports.float_underflow_error)(),Module._float4in_internal=(e,I,Hn,$n,qn)=>(Module._float4in_internal=wasmExports.float4in_internal)(e,I,Hn,$n,qn),Module._strtof=(e,I)=>(Module._strtof=wasmExports.strtof)(e,I),Module._float_to_shortest_decimal_buf=(e,I)=>(Module._float_to_shortest_decimal_buf=wasmExports.float_to_shortest_decimal_buf)(e,I),Module._float8in_internal=(e,I,Hn,$n,qn)=>(Module._float8in_internal=wasmExports.float8in_internal)(e,I,Hn,$n,qn),Module._float8out_internal=e=>(Module._float8out_internal=wasmExports.float8out_internal)(e),Module._btfloat4cmp=e=>(Module._btfloat4cmp=wasmExports.btfloat4cmp)(e),Module._btfloat8cmp=e=>(Module._btfloat8cmp=wasmExports.btfloat8cmp)(e),Module._pow=(e,I)=>(Module._pow=wasmExports.pow)(e,I),Module._log10=e=>(Module._log10=wasmExports.log10)(e),Module._acos=e=>(Module._acos=wasmExports.acos)(e),Module._asin=e=>(Module._asin=wasmExports.asin)(e),Module._cos=e=>(Module._cos=wasmExports.cos)(e),Module._sin=e=>(Module._sin=wasmExports.sin)(e),Module._fmod=(e,I)=>(Module._fmod=wasmExports.fmod)(e,I),Module._construct_array=(e,I,Hn,$n,qn,Xn)=>(Module._construct_array=wasmExports.construct_array)(e,I,Hn,$n,qn,Xn),Module._try_relation_open=(e,I)=>(Module._try_relation_open=wasmExports.try_relation_open)(e,I),Module._forkname_to_number=e=>(Module._forkname_to_number=wasmExports.forkname_to_number)(e),Module._numeric_lt=e=>(Module._numeric_lt=wasmExports.numeric_lt)(e),Module._int64_to_numeric=e=>(Module._int64_to_numeric=wasmExports.int64_to_numeric)(e),Module._numeric_sub=e=>(Module._numeric_sub=wasmExports.numeric_sub)(e),Module._numeric_ge=e=>(Module._numeric_ge=wasmExports.numeric_ge)(e),Module._inet_in=e=>(Module._inet_in=wasmExports.inet_in)(e),Module._format_operator=e=>(Module._format_operator=wasmExports.format_operator)(e),Module._RelationIsVisible=e=>(Module._RelationIsVisible=wasmExports.RelationIsVisible)(e),Module._pg_get_indexdef_columns_extended=(e,I)=>(Module._pg_get_indexdef_columns_extended=wasmExports.pg_get_indexdef_columns_extended)(e,I),Module._accumArrayResult=(e,I,Hn,$n,qn)=>(Module._accumArrayResult=wasmExports.accumArrayResult)(e,I,Hn,$n,qn),Module._makeArrayResult=(e,I)=>(Module._makeArrayResult=wasmExports.makeArrayResult)(e,I),Module._init_local_reloptions=(e,I)=>(Module._init_local_reloptions=wasmExports.init_local_reloptions)(e,I),Module._add_local_int_reloption=(e,I,Hn,$n,qn,Xn,Yn)=>(Module._add_local_int_reloption=wasmExports.add_local_int_reloption)(e,I,Hn,$n,qn,Xn,Yn),Module._pg_inet_net_ntop=(e,I,Hn,$n,qn)=>(Module._pg_inet_net_ntop=wasmExports.pg_inet_net_ntop)(e,I,Hn,$n,qn),Module._network_cmp=e=>(Module._network_cmp=wasmExports.network_cmp)(e),Module._convert_network_to_scalar=(e,I,Hn)=>(Module._convert_network_to_scalar=wasmExports.convert_network_to_scalar)(e,I,Hn),Module._JsonbValueToJsonb=e=>(Module._JsonbValueToJsonb=wasmExports.JsonbValueToJsonb)(e),Module._pushJsonbValue=(e,I,Hn)=>(Module._pushJsonbValue=wasmExports.pushJsonbValue)(e,I,Hn),Module._numeric_cmp=e=>(Module._numeric_cmp=wasmExports.numeric_cmp)(e),Module._timetz_cmp=e=>(Module._timetz_cmp=wasmExports.timetz_cmp)(e),Module._date_cmp=e=>(Module._date_cmp=wasmExports.date_cmp)(e),Module._time_cmp=e=>(Module._time_cmp=wasmExports.time_cmp)(e),Module._timestamp_cmp=e=>(Module._timestamp_cmp=wasmExports.timestamp_cmp)(e),Module._domain_check=(e,I,Hn,$n,qn)=>(Module._domain_check=wasmExports.domain_check)(e,I,Hn,$n,qn),Module._initArrayResult=(e,I,Hn)=>(Module._initArrayResult=wasmExports.initArrayResult)(e,I,Hn),Module._path_is_prefix_of_path=(e,I)=>(Module._path_is_prefix_of_path=wasmExports.path_is_prefix_of_path)(e,I),Module._path_is_relative_and_below_cwd=e=>(Module._path_is_relative_and_below_cwd=wasmExports.path_is_relative_and_below_cwd)(e),Module._ArrayGetIntegerTypmods=(e,I)=>(Module._ArrayGetIntegerTypmods=wasmExports.ArrayGetIntegerTypmods)(e,I),Module._bpchareq=e=>(Module._bpchareq=wasmExports.bpchareq)(e),Module._varstr_cmp=(e,I,Hn,$n,qn)=>(Module._varstr_cmp=wasmExports.varstr_cmp)(e,I,Hn,$n,qn),Module._bpcharlt=e=>(Module._bpcharlt=wasmExports.bpcharlt)(e),Module._bpcharle=e=>(Module._bpcharle=wasmExports.bpcharle)(e),Module._bpchargt=e=>(Module._bpchargt=wasmExports.bpchargt)(e),Module._bpcharge=e=>(Module._bpcharge=wasmExports.bpcharge)(e),Module._bpcharcmp=e=>(Module._bpcharcmp=wasmExports.bpcharcmp)(e),Module._current_query=e=>(Module._current_query=wasmExports.current_query)(e),Module._str_tolower=(e,I,Hn)=>(Module._str_tolower=wasmExports.str_tolower)(e,I,Hn),Module._TransferExpandedObject=(e,I)=>(Module._TransferExpandedObject=wasmExports.TransferExpandedObject)(e,I),Module._macaddr_cmp=e=>(Module._macaddr_cmp=wasmExports.macaddr_cmp)(e),Module._macaddr_lt=e=>(Module._macaddr_lt=wasmExports.macaddr_lt)(e),Module._macaddr_le=e=>(Module._macaddr_le=wasmExports.macaddr_le)(e),Module._macaddr_eq=e=>(Module._macaddr_eq=wasmExports.macaddr_eq)(e),Module._macaddr_ge=e=>(Module._macaddr_ge=wasmExports.macaddr_ge)(e),Module._macaddr_gt=e=>(Module._macaddr_gt=wasmExports.macaddr_gt)(e),Module._quote_ident=e=>(Module._quote_ident=wasmExports.quote_ident)(e),Module._timestamp_in=e=>(Module._timestamp_in=wasmExports.timestamp_in)(e),Module._ParseDateTime=(e,I,Hn,$n,qn,Xn,Yn)=>(Module._ParseDateTime=wasmExports.ParseDateTime)(e,I,Hn,$n,qn,Xn,Yn),Module._DecodeDateTime=(e,I,Hn,$n,qn,Xn,Yn,Kn)=>(Module._DecodeDateTime=wasmExports.DecodeDateTime)(e,I,Hn,$n,qn,Xn,Yn,Kn),Module.___multi3=(e,I,Hn,$n,qn)=>(Module.___multi3=wasmExports.__multi3)(e,I,Hn,$n,qn),Module._timestamptz_in=e=>(Module._timestamptz_in=wasmExports.timestamptz_in)(e),Module._timestamp_eq=e=>(Module._timestamp_eq=wasmExports.timestamp_eq)(e),Module._timestamp_lt=e=>(Module._timestamp_lt=wasmExports.timestamp_lt)(e),Module._timestamp_gt=e=>(Module._timestamp_gt=wasmExports.timestamp_gt)(e),Module._timestamp_le=e=>(Module._timestamp_le=wasmExports.timestamp_le)(e),Module._timestamp_ge=e=>(Module._timestamp_ge=wasmExports.timestamp_ge)(e),Module._interval_eq=e=>(Module._interval_eq=wasmExports.interval_eq)(e),Module._interval_lt=e=>(Module._interval_lt=wasmExports.interval_lt)(e),Module._interval_gt=e=>(Module._interval_gt=wasmExports.interval_gt)(e),Module._interval_le=e=>(Module._interval_le=wasmExports.interval_le)(e),Module._interval_ge=e=>(Module._interval_ge=wasmExports.interval_ge)(e),Module._interval_cmp=e=>(Module._interval_cmp=wasmExports.interval_cmp)(e),Module._timestamp_mi=e=>(Module._timestamp_mi=wasmExports.timestamp_mi)(e),Module._interval_um=e=>(Module._interval_um=wasmExports.interval_um)(e),Module._interval_mi=e=>(Module._interval_mi=wasmExports.interval_mi)(e),Module._IsValidJsonNumber=(e,I)=>(Module._IsValidJsonNumber=wasmExports.IsValidJsonNumber)(e,I),Module._btnamecmp=e=>(Module._btnamecmp=wasmExports.btnamecmp)(e),Module._strncpy=(e,I,Hn)=>(Module._strncpy=wasmExports.strncpy)(e,I,Hn),Module._expand_array=(e,I,Hn)=>(Module._expand_array=wasmExports.expand_array)(e,I,Hn),Module._pg_get_encoding_from_locale=(e,I)=>(Module._pg_get_encoding_from_locale=wasmExports.pg_get_encoding_from_locale)(e,I),Module._localtime=e=>(Module._localtime=wasmExports.localtime)(e),Module._strftime=(e,I,Hn,$n)=>(Module._strftime=wasmExports.strftime)(e,I,Hn,$n),Module._numeric_is_nan=e=>(Module._numeric_is_nan=wasmExports.numeric_is_nan)(e),Module._numeric_eq=e=>(Module._numeric_eq=wasmExports.numeric_eq)(e),Module._numeric_gt=e=>(Module._numeric_gt=wasmExports.numeric_gt)(e),Module._numeric_le=e=>(Module._numeric_le=wasmExports.numeric_le)(e),Module._numeric_div=e=>(Module._numeric_div=wasmExports.numeric_div)(e),Module._numeric_float8_no_overflow=e=>(Module._numeric_float8_no_overflow=wasmExports.numeric_float8_no_overflow)(e),Module._numeric_float4=e=>(Module._numeric_float4=wasmExports.numeric_float4)(e),Module._date_eq=e=>(Module._date_eq=wasmExports.date_eq)(e),Module._date_lt=e=>(Module._date_lt=wasmExports.date_lt)(e),Module._date_le=e=>(Module._date_le=wasmExports.date_le)(e),Module._date_gt=e=>(Module._date_gt=wasmExports.date_gt)(e),Module._date_ge=e=>(Module._date_ge=wasmExports.date_ge)(e),Module._date_mi=e=>(Module._date_mi=wasmExports.date_mi)(e),Module._time_eq=e=>(Module._time_eq=wasmExports.time_eq)(e),Module._time_lt=e=>(Module._time_lt=wasmExports.time_lt)(e),Module._time_le=e=>(Module._time_le=wasmExports.time_le)(e),Module._time_gt=e=>(Module._time_gt=wasmExports.time_gt)(e),Module._time_ge=e=>(Module._time_ge=wasmExports.time_ge)(e),Module._time_mi_time=e=>(Module._time_mi_time=wasmExports.time_mi_time)(e),Module._get_extension_oid=(e,I)=>(Module._get_extension_oid=wasmExports.get_extension_oid)(e,I),Module._pg_ltoa=(e,I)=>(Module._pg_ltoa=wasmExports.pg_ltoa)(e,I),Module._varbit_in=e=>(Module._varbit_in=wasmExports.varbit_in)(e),Module._biteq=e=>(Module._biteq=wasmExports.biteq)(e),Module._bitlt=e=>(Module._bitlt=wasmExports.bitlt)(e),Module._bitle=e=>(Module._bitle=wasmExports.bitle)(e),Module._bitgt=e=>(Module._bitgt=wasmExports.bitgt)(e),Module._bitge=e=>(Module._bitge=wasmExports.bitge)(e),Module._bitcmp=e=>(Module._bitcmp=wasmExports.bitcmp)(e),Module._tidin=e=>(Module._tidin=wasmExports.tidin)(e),Module._tidout=e=>(Module._tidout=wasmExports.tidout)(e),Module._cash_cmp=e=>(Module._cash_cmp=wasmExports.cash_cmp)(e),Module._arraycontsel=e=>(Module._arraycontsel=wasmExports.arraycontsel)(e),Module._arraycontjoinsel=e=>(Module._arraycontjoinsel=wasmExports.arraycontjoinsel)(e),Module._text_lt=e=>(Module._text_lt=wasmExports.text_lt)(e),Module._text_le=e=>(Module._text_le=wasmExports.text_le)(e),Module._text_gt=e=>(Module._text_gt=wasmExports.text_gt)(e),Module._text_ge=e=>(Module._text_ge=wasmExports.text_ge)(e),Module._bttextcmp=e=>(Module._bttextcmp=wasmExports.bttextcmp)(e),Module._byteaeq=e=>(Module._byteaeq=wasmExports.byteaeq)(e),Module._bytealt=e=>(Module._bytealt=wasmExports.bytealt)(e),Module._byteale=e=>(Module._byteale=wasmExports.byteale)(e),Module._byteagt=e=>(Module._byteagt=wasmExports.byteagt)(e),Module._byteage=e=>(Module._byteage=wasmExports.byteage)(e),Module._byteacmp=e=>(Module._byteacmp=wasmExports.byteacmp)(e),Module._to_hex32=e=>(Module._to_hex32=wasmExports.to_hex32)(e),Module._varstr_levenshtein=(e,I,Hn,$n,qn,Xn,Yn,Kn)=>(Module._varstr_levenshtein=wasmExports.varstr_levenshtein)(e,I,Hn,$n,qn,Xn,Yn,Kn),Module._utf8_to_unicode=e=>(Module._utf8_to_unicode=wasmExports.utf8_to_unicode)(e),Module._format_type_extended=(e,I,Hn)=>(Module._format_type_extended=wasmExports.format_type_extended)(e,I,Hn),Module._array_create_iterator=(e,I,Hn)=>(Module._array_create_iterator=wasmExports.array_create_iterator)(e,I,Hn),Module._array_iterate=(e,I,Hn)=>(Module._array_iterate=wasmExports.array_iterate)(e,I,Hn),Module._make_expanded_record_from_typeid=(e,I,Hn)=>(Module._make_expanded_record_from_typeid=wasmExports.make_expanded_record_from_typeid)(e,I,Hn),Module._make_expanded_record_from_tupdesc=(e,I)=>(Module._make_expanded_record_from_tupdesc=wasmExports.make_expanded_record_from_tupdesc)(e,I),Module._make_expanded_record_from_exprecord=(e,I)=>(Module._make_expanded_record_from_exprecord=wasmExports.make_expanded_record_from_exprecord)(e,I),Module._expanded_record_set_tuple=(e,I,Hn,$n)=>(Module._expanded_record_set_tuple=wasmExports.expanded_record_set_tuple)(e,I,Hn,$n),Module._expanded_record_get_tuple=e=>(Module._expanded_record_get_tuple=wasmExports.expanded_record_get_tuple)(e),Module._deconstruct_expanded_record=e=>(Module._deconstruct_expanded_record=wasmExports.deconstruct_expanded_record)(e),Module._expanded_record_lookup_field=(e,I,Hn)=>(Module._expanded_record_lookup_field=wasmExports.expanded_record_lookup_field)(e,I,Hn),Module._expanded_record_set_field_internal=(e,I,Hn,$n,qn,Xn)=>(Module._expanded_record_set_field_internal=wasmExports.expanded_record_set_field_internal)(e,I,Hn,$n,qn,Xn),Module._expanded_record_set_fields=(e,I,Hn,$n)=>(Module._expanded_record_set_fields=wasmExports.expanded_record_set_fields)(e,I,Hn,$n),Module._macaddr8_cmp=e=>(Module._macaddr8_cmp=wasmExports.macaddr8_cmp)(e),Module._macaddr8_lt=e=>(Module._macaddr8_lt=wasmExports.macaddr8_lt)(e),Module._macaddr8_le=e=>(Module._macaddr8_le=wasmExports.macaddr8_le)(e),Module._macaddr8_eq=e=>(Module._macaddr8_eq=wasmExports.macaddr8_eq)(e),Module._macaddr8_ge=e=>(Module._macaddr8_ge=wasmExports.macaddr8_ge)(e),Module._macaddr8_gt=e=>(Module._macaddr8_gt=wasmExports.macaddr8_gt)(e),Module._enum_lt=e=>(Module._enum_lt=wasmExports.enum_lt)(e),Module._enum_le=e=>(Module._enum_le=wasmExports.enum_le)(e),Module._enum_ge=e=>(Module._enum_ge=wasmExports.enum_ge)(e),Module._enum_gt=e=>(Module._enum_gt=wasmExports.enum_gt)(e),Module._enum_cmp=e=>(Module._enum_cmp=wasmExports.enum_cmp)(e),Module._uuid_in=e=>(Module._uuid_in=wasmExports.uuid_in)(e),Module._uuid_out=e=>(Module._uuid_out=wasmExports.uuid_out)(e),Module._uuid_cmp=e=>(Module._uuid_cmp=wasmExports.uuid_cmp)(e),Module._gen_random_uuid=e=>(Module._gen_random_uuid=wasmExports.gen_random_uuid)(e),Module._generic_restriction_selectivity=(e,I,Hn,$n,qn,Xn)=>(Module._generic_restriction_selectivity=wasmExports.generic_restriction_selectivity)(e,I,Hn,$n,qn,Xn),Module._genericcostestimate=(e,I,Hn,$n)=>(Module._genericcostestimate=wasmExports.genericcostestimate)(e,I,Hn,$n),Module._pg_xml_init=e=>(Module._pg_xml_init=wasmExports.pg_xml_init)(e),Module._xmlInitParser=()=>(Module._xmlInitParser=wasmExports.xmlInitParser)(),Module._xml_ereport=(e,I,Hn,$n)=>(Module._xml_ereport=wasmExports.xml_ereport)(e,I,Hn,$n),Module._pg_xml_done=(e,I)=>(Module._pg_xml_done=wasmExports.pg_xml_done)(e,I),Module._xmlXPathNewContext=e=>(Module._xmlXPathNewContext=wasmExports.xmlXPathNewContext)(e),Module._xmlXPathFreeContext=e=>(Module._xmlXPathFreeContext=wasmExports.xmlXPathFreeContext)(e),Module._xmlFreeDoc=e=>(Module._xmlFreeDoc=wasmExports.xmlFreeDoc)(e),Module._xmlXPathCompile=e=>(Module._xmlXPathCompile=wasmExports.xmlXPathCompile)(e),Module._xmlXPathCompiledEval=(e,I)=>(Module._xmlXPathCompiledEval=wasmExports.xmlXPathCompiledEval)(e,I),Module._xmlXPathFreeCompExpr=e=>(Module._xmlXPathFreeCompExpr=wasmExports.xmlXPathFreeCompExpr)(e),Module._xmlStrdup=e=>(Module._xmlStrdup=wasmExports.xmlStrdup)(e),Module._strnlen=(e,I)=>(Module._strnlen=wasmExports.strnlen)(e,I),Module._xmlXPathCastNodeToString=e=>(Module._xmlXPathCastNodeToString=wasmExports.xmlXPathCastNodeToString)(e),Module._heap_modify_tuple_by_cols=(e,I,Hn,$n,qn,Xn)=>(Module._heap_modify_tuple_by_cols=wasmExports.heap_modify_tuple_by_cols)(e,I,Hn,$n,qn,Xn),Module._ResourceOwnerReleaseAllPlanCacheRefs=e=>(Module._ResourceOwnerReleaseAllPlanCacheRefs=wasmExports.ResourceOwnerReleaseAllPlanCacheRefs)(e),Module._RegisterResourceReleaseCallback=(e,I)=>(Module._RegisterResourceReleaseCallback=wasmExports.RegisterResourceReleaseCallback)(e,I),Module._PinPortal=e=>(Module._PinPortal=wasmExports.PinPortal)(e),Module._UnpinPortal=e=>(Module._UnpinPortal=wasmExports.UnpinPortal)(e),Module._btint2cmp=e=>(Module._btint2cmp=wasmExports.btint2cmp)(e),Module._btint4cmp=e=>(Module._btint4cmp=wasmExports.btint4cmp)(e),Module._btoidcmp=e=>(Module._btoidcmp=wasmExports.btoidcmp)(e),Module._btcharcmp=e=>(Module._btcharcmp=wasmExports.btcharcmp)(e),Module._btint8cmp=e=>(Module._btint8cmp=wasmExports.btint8cmp)(e),Module._btboolcmp=e=>(Module._btboolcmp=wasmExports.btboolcmp)(e),Module._GetPublicationByName=(e,I)=>(Module._GetPublicationByName=wasmExports.GetPublicationByName)(e,I),Module._GetTopMostAncestorInPublication=(e,I,Hn)=>(Module._GetTopMostAncestorInPublication=wasmExports.GetTopMostAncestorInPublication)(e,I,Hn),Module._pub_collist_to_bitmapset=(e,I,Hn)=>(Module._pub_collist_to_bitmapset=wasmExports.pub_collist_to_bitmapset)(e,I,Hn),Module._getExtensionOfObject=(e,I)=>(Module._getExtensionOfObject=wasmExports.getExtensionOfObject)(e,I),Module._visibilitymap_prepare_truncate=(e,I)=>(Module._visibilitymap_prepare_truncate=wasmExports.visibilitymap_prepare_truncate)(e,I),Module._log_newpage_range=(e,I,Hn,$n,qn)=>(Module._log_newpage_range=wasmExports.log_newpage_range)(e,I,Hn,$n,qn),Module._function_parse_error_transpose=e=>(Module._function_parse_error_transpose=wasmExports.function_parse_error_transpose)(e),Module._IndexGetRelation=(e,I)=>(Module._IndexGetRelation=wasmExports.IndexGetRelation)(e,I),Module._RelnameGetRelid=e=>(Module._RelnameGetRelid=wasmExports.RelnameGetRelid)(e),Module._standard_ProcessUtility=(e,I,Hn,$n,qn,Xn,Yn,Kn)=>(Module._standard_ProcessUtility=wasmExports.standard_ProcessUtility)(e,I,Hn,$n,qn,Xn,Yn,Kn),Module._Async_Notify=(e,I)=>(Module._Async_Notify=wasmExports.Async_Notify)(e,I),Module._sigaddset=(e,I)=>(Module._sigaddset=wasmExports.sigaddset)(e,I),Module._fsync_pgdata=(e,I)=>(Module._fsync_pgdata=wasmExports.fsync_pgdata)(e,I),Module._get_restricted_token=()=>(Module._get_restricted_token=wasmExports.get_restricted_token)(),Module._pg_malloc=e=>(Module._pg_malloc=wasmExports.pg_malloc)(e),Module._pg_realloc=(e,I)=>(Module._pg_realloc=wasmExports.pg_realloc)(e,I),Module._pg_strdup=e=>(Module._pg_strdup=wasmExports.pg_strdup)(e),Module._simple_prompt=(e,I)=>(Module._simple_prompt=wasmExports.simple_prompt)(e,I),Module._interactive_file=()=>(Module._interactive_file=wasmExports.interactive_file)(),Module._interactive_one=()=>(Module._interactive_one=wasmExports.interactive_one)(),Module._pg_shutdown=()=>(Module._pg_shutdown=wasmExports.pg_shutdown)(),Module._interactive_write=e=>(Module._interactive_write=wasmExports.interactive_write)(e),Module._interactive_read=()=>(Module._interactive_read=wasmExports.interactive_read)(),Module._visibilitymap_pin=(e,I,Hn)=>(Module._visibilitymap_pin=wasmExports.visibilitymap_pin)(e,I,Hn),Module._HeapTupleSatisfiesVacuum=(e,I,Hn)=>(Module._HeapTupleSatisfiesVacuum=wasmExports.HeapTupleSatisfiesVacuum)(e,I,Hn),Module._visibilitymap_clear=(e,I,Hn,$n)=>(Module._visibilitymap_clear=wasmExports.visibilitymap_clear)(e,I,Hn,$n),Module._vac_estimate_reltuples=(e,I,Hn,$n)=>(Module._vac_estimate_reltuples=wasmExports.vac_estimate_reltuples)(e,I,Hn,$n),Module._heap_tuple_needs_eventual_freeze=e=>(Module._heap_tuple_needs_eventual_freeze=wasmExports.heap_tuple_needs_eventual_freeze)(e),Module._HeapTupleSatisfiesUpdate=(e,I,Hn)=>(Module._HeapTupleSatisfiesUpdate=wasmExports.HeapTupleSatisfiesUpdate)(e,I,Hn),Module._HeapTupleGetUpdateXid=e=>(Module._HeapTupleGetUpdateXid=wasmExports.HeapTupleGetUpdateXid)(e),Module._HeapTupleSatisfiesVisibility=(e,I,Hn)=>(Module._HeapTupleSatisfiesVisibility=wasmExports.HeapTupleSatisfiesVisibility)(e,I,Hn),Module._GetMultiXactIdMembers=(e,I,Hn,$n)=>(Module._GetMultiXactIdMembers=wasmExports.GetMultiXactIdMembers)(e,I,Hn,$n),Module._XLogRecGetBlockTagExtended=(e,I,Hn,$n,qn,Xn)=>(Module._XLogRecGetBlockTagExtended=wasmExports.XLogRecGetBlockTagExtended)(e,I,Hn,$n,qn,Xn),Module._toast_open_indexes=(e,I,Hn,$n)=>(Module._toast_open_indexes=wasmExports.toast_open_indexes)(e,I,Hn,$n),Module._init_toast_snapshot=e=>(Module._init_toast_snapshot=wasmExports.init_toast_snapshot)(e),Module._toast_close_indexes=(e,I,Hn)=>(Module._toast_close_indexes=wasmExports.toast_close_indexes)(e,I,Hn),Module._index_getprocinfo=(e,I,Hn)=>(Module._index_getprocinfo=wasmExports.index_getprocinfo)(e,I,Hn),Module._identify_opfamily_groups=(e,I)=>(Module._identify_opfamily_groups=wasmExports.identify_opfamily_groups)(e,I),Module._check_amproc_signature=(e,I,Hn,$n,qn,Xn)=>(Module._check_amproc_signature=wasmExports.check_amproc_signature)(e,I,Hn,$n,qn,Xn),Module._check_amoptsproc_signature=e=>(Module._check_amoptsproc_signature=wasmExports.check_amoptsproc_signature)(e),Module._check_amop_signature=(e,I,Hn,$n)=>(Module._check_amop_signature=wasmExports.check_amop_signature)(e,I,Hn,$n),Module._RelationGetIndexScan=(e,I,Hn)=>(Module._RelationGetIndexScan=wasmExports.RelationGetIndexScan)(e,I,Hn),Module.__hash_get_indextuple_hashkey=e=>(Module.__hash_get_indextuple_hashkey=wasmExports._hash_get_indextuple_hashkey)(e),Module.__hash_getbuf=(e,I,Hn,$n)=>(Module.__hash_getbuf=wasmExports._hash_getbuf)(e,I,Hn,$n),Module.__hash_relbuf=(e,I)=>(Module.__hash_relbuf=wasmExports._hash_relbuf)(e,I),Module.__hash_getbuf_with_strategy=(e,I,Hn,$n,qn)=>(Module.__hash_getbuf_with_strategy=wasmExports._hash_getbuf_with_strategy)(e,I,Hn,$n,qn),Module._build_reloptions=(e,I,Hn,$n,qn,Xn)=>(Module._build_reloptions=wasmExports.build_reloptions)(e,I,Hn,$n,qn,Xn),Module._index_form_tuple=(e,I,Hn)=>(Module._index_form_tuple=wasmExports.index_form_tuple)(e,I,Hn),Module.__hash_ovflblkno_to_bitno=(e,I)=>(Module.__hash_ovflblkno_to_bitno=wasmExports._hash_ovflblkno_to_bitno)(e,I),Module._brin_build_desc=e=>(Module._brin_build_desc=wasmExports.brin_build_desc)(e),Module._brin_deform_tuple=(e,I,Hn)=>(Module._brin_deform_tuple=wasmExports.brin_deform_tuple)(e,I,Hn),Module._brin_free_desc=e=>(Module._brin_free_desc=wasmExports.brin_free_desc)(e),Module._XLogRecGetBlockRefInfo=(e,I,Hn,$n,qn)=>(Module._XLogRecGetBlockRefInfo=wasmExports.XLogRecGetBlockRefInfo)(e,I,Hn,$n,qn),Module._ginPostingListDecode=(e,I)=>(Module._ginPostingListDecode=wasmExports.ginPostingListDecode)(e,I),Module._add_reloption_kind=()=>(Module._add_reloption_kind=wasmExports.add_reloption_kind)(),Module._register_reloptions_validator=(e,I)=>(Module._register_reloptions_validator=wasmExports.register_reloptions_validator)(e,I),Module._add_int_reloption=(e,I,Hn,$n,qn,Xn,Yn)=>(Module._add_int_reloption=wasmExports.add_int_reloption)(e,I,Hn,$n,qn,Xn,Yn),Module._XLogFindNextRecord=(e,I)=>(Module._XLogFindNextRecord=wasmExports.XLogFindNextRecord)(e,I),Module._RestoreBlockImage=(e,I,Hn)=>(Module._RestoreBlockImage=wasmExports.RestoreBlockImage)(e,I,Hn),Module._GenericXLogStart=e=>(Module._GenericXLogStart=wasmExports.GenericXLogStart)(e),Module._GenericXLogRegisterBuffer=(e,I,Hn)=>(Module._GenericXLogRegisterBuffer=wasmExports.GenericXLogRegisterBuffer)(e,I,Hn),Module._GenericXLogFinish=e=>(Module._GenericXLogFinish=wasmExports.GenericXLogFinish)(e),Module._GenericXLogAbort=e=>(Module._GenericXLogAbort=wasmExports.GenericXLogAbort)(e),Module._read_local_xlog_page_no_wait=(e,I,Hn,$n,qn)=>(Module._read_local_xlog_page_no_wait=wasmExports.read_local_xlog_page_no_wait)(e,I,Hn,$n,qn),Module._XLogRecStoreStats=(e,I)=>(Module._XLogRecStoreStats=wasmExports.XLogRecStoreStats)(e,I),Module._ReadMultiXactIdRange=(e,I)=>(Module._ReadMultiXactIdRange=wasmExports.ReadMultiXactIdRange)(e,I),Module._MultiXactIdPrecedesOrEquals=(e,I)=>(Module._MultiXactIdPrecedesOrEquals=wasmExports.MultiXactIdPrecedesOrEquals)(e,I),Module._RegisterXactCallback=(e,I)=>(Module._RegisterXactCallback=wasmExports.RegisterXactCallback)(e,I),Module._RegisterSubXactCallback=(e,I)=>(Module._RegisterSubXactCallback=wasmExports.RegisterSubXactCallback)(e,I),Module._ReleaseCurrentSubTransaction=()=>(Module._ReleaseCurrentSubTransaction=wasmExports.ReleaseCurrentSubTransaction)(),Module._WaitForParallelWorkersToAttach=e=>(Module._WaitForParallelWorkersToAttach=wasmExports.WaitForParallelWorkersToAttach)(e),Module.__bt_allequalimage=(e,I)=>(Module.__bt_allequalimage=wasmExports._bt_allequalimage)(e,I),Module.__bt_checkpage=(e,I)=>(Module.__bt_checkpage=wasmExports._bt_checkpage)(e,I),Module.__bt_relbuf=(e,I)=>(Module.__bt_relbuf=wasmExports._bt_relbuf)(e,I),Module.__bt_metaversion=(e,I,Hn)=>(Module.__bt_metaversion=wasmExports._bt_metaversion)(e,I,Hn),Module.__bt_search=(e,I,Hn,$n,qn,Xn)=>(Module.__bt_search=wasmExports._bt_search)(e,I,Hn,$n,qn,Xn),Module.__bt_compare=(e,I,Hn,$n)=>(Module.__bt_compare=wasmExports._bt_compare)(e,I,Hn,$n),Module.__bt_binsrch_insert=(e,I)=>(Module.__bt_binsrch_insert=wasmExports._bt_binsrch_insert)(e,I),Module.__bt_freestack=e=>(Module.__bt_freestack=wasmExports._bt_freestack)(e),Module.__bt_form_posting=(e,I,Hn)=>(Module.__bt_form_posting=wasmExports._bt_form_posting)(e,I,Hn),Module.__bt_check_natts=(e,I,Hn,$n)=>(Module.__bt_check_natts=wasmExports._bt_check_natts)(e,I,Hn,$n),Module._gistcheckpage=(e,I)=>(Module._gistcheckpage=wasmExports.gistcheckpage)(e,I),Module._EndCopyFrom=e=>(Module._EndCopyFrom=wasmExports.EndCopyFrom)(e),Module._ProcessCopyOptions=(e,I,Hn,$n)=>(Module._ProcessCopyOptions=wasmExports.ProcessCopyOptions)(e,I,Hn,$n),Module._CopyFromErrorCallback=e=>(Module._CopyFromErrorCallback=wasmExports.CopyFromErrorCallback)(e),Module._NextCopyFrom=(e,I,Hn,$n)=>(Module._NextCopyFrom=wasmExports.NextCopyFrom)(e,I,Hn,$n),Module._nextval=e=>(Module._nextval=wasmExports.nextval)(e),Module._defGetStreamingMode=e=>(Module._defGetStreamingMode=wasmExports.defGetStreamingMode)(e),Module._ExplainBeginOutput=e=>(Module._ExplainBeginOutput=wasmExports.ExplainBeginOutput)(e),Module._NewExplainState=()=>(Module._NewExplainState=wasmExports.NewExplainState)(),Module._ExplainEndOutput=e=>(Module._ExplainEndOutput=wasmExports.ExplainEndOutput)(e),Module._ExplainPrintPlan=(e,I)=>(Module._ExplainPrintPlan=wasmExports.ExplainPrintPlan)(e,I),Module._ExplainPrintTriggers=(e,I)=>(Module._ExplainPrintTriggers=wasmExports.ExplainPrintTriggers)(e,I),Module._ExplainPrintJITSummary=(e,I)=>(Module._ExplainPrintJITSummary=wasmExports.ExplainPrintJITSummary)(e,I),Module._ExplainPropertyInteger=(e,I,Hn,$n)=>(Module._ExplainPropertyInteger=wasmExports.ExplainPropertyInteger)(e,I,Hn,$n),Module._ExplainQueryText=(e,I)=>(Module._ExplainQueryText=wasmExports.ExplainQueryText)(e,I),Module._ExplainPropertyText=(e,I,Hn)=>(Module._ExplainPropertyText=wasmExports.ExplainPropertyText)(e,I,Hn),Module._ExplainQueryParameters=(e,I,Hn)=>(Module._ExplainQueryParameters=wasmExports.ExplainQueryParameters)(e,I,Hn),Module._pg_is_ascii=e=>(Module._pg_is_ascii=wasmExports.pg_is_ascii)(e),Module._fputs=(e,I)=>(Module._fputs=wasmExports.fputs)(e,I),Module._popen=(e,I)=>(Module._popen=wasmExports.popen)(e,I),Module._float_to_shortest_decimal_bufn=(e,I)=>(Module._float_to_shortest_decimal_bufn=wasmExports.float_to_shortest_decimal_bufn)(e,I),Module._pg_prng_uint64=e=>(Module._pg_prng_uint64=wasmExports.pg_prng_uint64)(e),Module._scram_ClientKey=(e,I,Hn,$n,qn)=>(Module._scram_ClientKey=wasmExports.scram_ClientKey)(e,I,Hn,$n,qn),Module._pg_encoding_dsplen=(e,I)=>(Module._pg_encoding_dsplen=wasmExports.pg_encoding_dsplen)(e,I),Module._getcwd=(e,I)=>(Module._getcwd=wasmExports.getcwd)(e,I),Module._pg_get_user_home_dir=(e,I,Hn)=>(Module._pg_get_user_home_dir=wasmExports.pg_get_user_home_dir)(e,I,Hn),Module._nanosleep=(e,I)=>(Module._nanosleep=wasmExports.nanosleep)(e,I),Module._snprintf=(e,I,Hn,$n)=>(Module._snprintf=wasmExports.snprintf)(e,I,Hn,$n),Module._pg_strerror_r=(e,I,Hn)=>(Module._pg_strerror_r=wasmExports.pg_strerror_r)(e,I,Hn),Module._pthread_mutex_lock=e=>(Module._pthread_mutex_lock=wasmExports.pthread_mutex_lock)(e),Module._pthread_mutex_unlock=e=>(Module._pthread_mutex_unlock=wasmExports.pthread_mutex_unlock)(e),Module._strncat=(e,I,Hn)=>(Module._strncat=wasmExports.strncat)(e,I,Hn),Module._PQexec=(e,I)=>(Module._PQexec=wasmExports.PQexec)(e,I),Module._PQsetSingleRowMode=e=>(Module._PQsetSingleRowMode=wasmExports.PQsetSingleRowMode)(e),Module._PQcmdStatus=e=>(Module._PQcmdStatus=wasmExports.PQcmdStatus)(e),Module._pthread_sigmask=(e,I,Hn)=>(Module._pthread_sigmask=wasmExports.pthread_sigmask)(e,I,Hn),Module._sigismember=(e,I)=>(Module._sigismember=wasmExports.sigismember)(e,I),Module._sigpending=e=>(Module._sigpending=wasmExports.sigpending)(e),Module._sigwait=(e,I)=>(Module._sigwait=wasmExports.sigwait)(e,I),Module._isolat1ToUTF8=(e,I,Hn,$n)=>(Module._isolat1ToUTF8=wasmExports.isolat1ToUTF8)(e,I,Hn,$n),Module._UTF8Toisolat1=(e,I,Hn,$n)=>(Module._UTF8Toisolat1=wasmExports.UTF8Toisolat1)(e,I,Hn,$n),Module._vfprintf=(e,I,Hn)=>(Module._vfprintf=wasmExports.vfprintf)(e,I,Hn),Module._vsnprintf=(e,I,Hn,$n)=>(Module._vsnprintf=wasmExports.vsnprintf)(e,I,Hn,$n),Module._xmlParserValidityWarning=(e,I,Hn)=>(Module._xmlParserValidityWarning=wasmExports.xmlParserValidityWarning)(e,I,Hn),Module._xmlParserValidityError=(e,I,Hn)=>(Module._xmlParserValidityError=wasmExports.xmlParserValidityError)(e,I,Hn),Module._xmlParserError=(e,I,Hn)=>(Module._xmlParserError=wasmExports.xmlParserError)(e,I,Hn),Module._xmlParserWarning=(e,I,Hn)=>(Module._xmlParserWarning=wasmExports.xmlParserWarning)(e,I,Hn),Module._fprintf=(e,I,Hn)=>(Module._fprintf=wasmExports.fprintf)(e,I,Hn),Module.___xmlParserInputBufferCreateFilename=(e,I)=>(Module.___xmlParserInputBufferCreateFilename=wasmExports.__xmlParserInputBufferCreateFilename)(e,I),Module.___xmlOutputBufferCreateFilename=(e,I,Hn)=>(Module.___xmlOutputBufferCreateFilename=wasmExports.__xmlOutputBufferCreateFilename)(e,I,Hn),Module._xmlSAX2InternalSubset=(e,I,Hn,$n)=>(Module._xmlSAX2InternalSubset=wasmExports.xmlSAX2InternalSubset)(e,I,Hn,$n),Module._xmlSAX2IsStandalone=e=>(Module._xmlSAX2IsStandalone=wasmExports.xmlSAX2IsStandalone)(e),Module._xmlSAX2HasInternalSubset=e=>(Module._xmlSAX2HasInternalSubset=wasmExports.xmlSAX2HasInternalSubset)(e),Module._xmlSAX2HasExternalSubset=e=>(Module._xmlSAX2HasExternalSubset=wasmExports.xmlSAX2HasExternalSubset)(e),Module._xmlSAX2ResolveEntity=(e,I,Hn)=>(Module._xmlSAX2ResolveEntity=wasmExports.xmlSAX2ResolveEntity)(e,I,Hn),Module._xmlSAX2GetEntity=(e,I)=>(Module._xmlSAX2GetEntity=wasmExports.xmlSAX2GetEntity)(e,I),Module._xmlSAX2EntityDecl=(e,I,Hn,$n,qn,Xn)=>(Module._xmlSAX2EntityDecl=wasmExports.xmlSAX2EntityDecl)(e,I,Hn,$n,qn,Xn),Module._xmlSAX2NotationDecl=(e,I,Hn,$n)=>(Module._xmlSAX2NotationDecl=wasmExports.xmlSAX2NotationDecl)(e,I,Hn,$n),Module._xmlSAX2AttributeDecl=(e,I,Hn,$n,qn,Xn,Yn)=>(Module._xmlSAX2AttributeDecl=wasmExports.xmlSAX2AttributeDecl)(e,I,Hn,$n,qn,Xn,Yn),Module._xmlSAX2ElementDecl=(e,I,Hn,$n)=>(Module._xmlSAX2ElementDecl=wasmExports.xmlSAX2ElementDecl)(e,I,Hn,$n),Module._xmlSAX2UnparsedEntityDecl=(e,I,Hn,$n,qn)=>(Module._xmlSAX2UnparsedEntityDecl=wasmExports.xmlSAX2UnparsedEntityDecl)(e,I,Hn,$n,qn),Module._xmlSAX2SetDocumentLocator=(e,I)=>(Module._xmlSAX2SetDocumentLocator=wasmExports.xmlSAX2SetDocumentLocator)(e,I),Module._xmlSAX2StartDocument=e=>(Module._xmlSAX2StartDocument=wasmExports.xmlSAX2StartDocument)(e),Module._xmlSAX2EndDocument=e=>(Module._xmlSAX2EndDocument=wasmExports.xmlSAX2EndDocument)(e),Module._xmlSAX2StartElement=(e,I,Hn)=>(Module._xmlSAX2StartElement=wasmExports.xmlSAX2StartElement)(e,I,Hn),Module._xmlSAX2EndElement=(e,I)=>(Module._xmlSAX2EndElement=wasmExports.xmlSAX2EndElement)(e,I),Module._xmlSAX2Reference=(e,I)=>(Module._xmlSAX2Reference=wasmExports.xmlSAX2Reference)(e,I),Module._xmlSAX2Characters=(e,I,Hn)=>(Module._xmlSAX2Characters=wasmExports.xmlSAX2Characters)(e,I,Hn),Module._xmlSAX2ProcessingInstruction=(e,I,Hn)=>(Module._xmlSAX2ProcessingInstruction=wasmExports.xmlSAX2ProcessingInstruction)(e,I,Hn),Module._xmlSAX2Comment=(e,I)=>(Module._xmlSAX2Comment=wasmExports.xmlSAX2Comment)(e,I),Module._xmlSAX2GetParameterEntity=(e,I)=>(Module._xmlSAX2GetParameterEntity=wasmExports.xmlSAX2GetParameterEntity)(e,I),Module._xmlSAX2CDataBlock=(e,I,Hn)=>(Module._xmlSAX2CDataBlock=wasmExports.xmlSAX2CDataBlock)(e,I,Hn),Module._xmlSAX2ExternalSubset=(e,I,Hn,$n)=>(Module._xmlSAX2ExternalSubset=wasmExports.xmlSAX2ExternalSubset)(e,I,Hn,$n),Module._xmlSAX2GetPublicId=e=>(Module._xmlSAX2GetPublicId=wasmExports.xmlSAX2GetPublicId)(e),Module._xmlSAX2GetSystemId=e=>(Module._xmlSAX2GetSystemId=wasmExports.xmlSAX2GetSystemId)(e),Module._xmlSAX2GetLineNumber=e=>(Module._xmlSAX2GetLineNumber=wasmExports.xmlSAX2GetLineNumber)(e),Module._xmlSAX2GetColumnNumber=e=>(Module._xmlSAX2GetColumnNumber=wasmExports.xmlSAX2GetColumnNumber)(e),Module._xmlSAX2IgnorableWhitespace=(e,I,Hn)=>(Module._xmlSAX2IgnorableWhitespace=wasmExports.xmlSAX2IgnorableWhitespace)(e,I,Hn),Module._xmlHashDefaultDeallocator=(e,I)=>(Module._xmlHashDefaultDeallocator=wasmExports.xmlHashDefaultDeallocator)(e,I),Module._iconv_open=(e,I)=>(Module._iconv_open=wasmExports.iconv_open)(e,I),Module._iconv_close=e=>(Module._iconv_close=wasmExports.iconv_close)(e),Module._iconv=(e,I,Hn,$n,qn)=>(Module._iconv=wasmExports.iconv)(e,I,Hn,$n,qn),Module._UTF8ToHtml=(e,I,Hn,$n)=>(Module._UTF8ToHtml=wasmExports.UTF8ToHtml)(e,I,Hn,$n),Module._xmlReadMemory=(e,I,Hn,$n,qn)=>(Module._xmlReadMemory=wasmExports.xmlReadMemory)(e,I,Hn,$n,qn),Module._xmlSAX2StartElementNs=(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn)=>(Module._xmlSAX2StartElementNs=wasmExports.xmlSAX2StartElementNs)(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn),Module._xmlSAX2EndElementNs=(e,I,Hn,$n)=>(Module._xmlSAX2EndElementNs=wasmExports.xmlSAX2EndElementNs)(e,I,Hn,$n),Module.___cxa_atexit=(e,I,Hn)=>(Module.___cxa_atexit=wasmExports.__cxa_atexit)(e,I,Hn),Module._xmlDocGetRootElement=e=>(Module._xmlDocGetRootElement=wasmExports.xmlDocGetRootElement)(e),Module._xmlFileMatch=e=>(Module._xmlFileMatch=wasmExports.xmlFileMatch)(e),Module._xmlFileOpen=e=>(Module._xmlFileOpen=wasmExports.xmlFileOpen)(e),Module._xmlFileRead=(e,I,Hn)=>(Module._xmlFileRead=wasmExports.xmlFileRead)(e,I,Hn),Module._xmlFileClose=e=>(Module._xmlFileClose=wasmExports.xmlFileClose)(e),Module._gzread=(e,I,Hn)=>(Module._gzread=wasmExports.gzread)(e,I,Hn),Module._gzclose=e=>(Module._gzclose=wasmExports.gzclose)(e),Module._gzdirect=e=>(Module._gzdirect=wasmExports.gzdirect)(e),Module._gzdopen=(e,I)=>(Module._gzdopen=wasmExports.gzdopen)(e,I),Module._gzopen=(e,I)=>(Module._gzopen=wasmExports.gzopen)(e,I),Module._gzwrite=(e,I,Hn)=>(Module._gzwrite=wasmExports.gzwrite)(e,I,Hn),Module._xmlUCSIsCatNd=e=>(Module._xmlUCSIsCatNd=wasmExports.xmlUCSIsCatNd)(e),Module._xmlUCSIsCatP=e=>(Module._xmlUCSIsCatP=wasmExports.xmlUCSIsCatP)(e),Module._xmlUCSIsCatZ=e=>(Module._xmlUCSIsCatZ=wasmExports.xmlUCSIsCatZ)(e),Module._xmlUCSIsCatC=e=>(Module._xmlUCSIsCatC=wasmExports.xmlUCSIsCatC)(e),Module._xmlUCSIsCatL=e=>(Module._xmlUCSIsCatL=wasmExports.xmlUCSIsCatL)(e),Module._xmlUCSIsCatLu=e=>(Module._xmlUCSIsCatLu=wasmExports.xmlUCSIsCatLu)(e),Module._xmlUCSIsCatLl=e=>(Module._xmlUCSIsCatLl=wasmExports.xmlUCSIsCatLl)(e),Module._xmlUCSIsCatLt=e=>(Module._xmlUCSIsCatLt=wasmExports.xmlUCSIsCatLt)(e),Module._xmlUCSIsCatLm=e=>(Module._xmlUCSIsCatLm=wasmExports.xmlUCSIsCatLm)(e),Module._xmlUCSIsCatLo=e=>(Module._xmlUCSIsCatLo=wasmExports.xmlUCSIsCatLo)(e),Module._xmlUCSIsCatM=e=>(Module._xmlUCSIsCatM=wasmExports.xmlUCSIsCatM)(e),Module._xmlUCSIsCatMn=e=>(Module._xmlUCSIsCatMn=wasmExports.xmlUCSIsCatMn)(e),Module._xmlUCSIsCatMc=e=>(Module._xmlUCSIsCatMc=wasmExports.xmlUCSIsCatMc)(e),Module._xmlUCSIsCatMe=e=>(Module._xmlUCSIsCatMe=wasmExports.xmlUCSIsCatMe)(e),Module._xmlUCSIsCatN=e=>(Module._xmlUCSIsCatN=wasmExports.xmlUCSIsCatN)(e),Module._xmlUCSIsCatNl=e=>(Module._xmlUCSIsCatNl=wasmExports.xmlUCSIsCatNl)(e),Module._xmlUCSIsCatNo=e=>(Module._xmlUCSIsCatNo=wasmExports.xmlUCSIsCatNo)(e),Module._xmlUCSIsCatPc=e=>(Module._xmlUCSIsCatPc=wasmExports.xmlUCSIsCatPc)(e),Module._xmlUCSIsCatPd=e=>(Module._xmlUCSIsCatPd=wasmExports.xmlUCSIsCatPd)(e),Module._xmlUCSIsCatPs=e=>(Module._xmlUCSIsCatPs=wasmExports.xmlUCSIsCatPs)(e),Module._xmlUCSIsCatPe=e=>(Module._xmlUCSIsCatPe=wasmExports.xmlUCSIsCatPe)(e),Module._xmlUCSIsCatPi=e=>(Module._xmlUCSIsCatPi=wasmExports.xmlUCSIsCatPi)(e),Module._xmlUCSIsCatPf=e=>(Module._xmlUCSIsCatPf=wasmExports.xmlUCSIsCatPf)(e),Module._xmlUCSIsCatPo=e=>(Module._xmlUCSIsCatPo=wasmExports.xmlUCSIsCatPo)(e),Module._xmlUCSIsCatZs=e=>(Module._xmlUCSIsCatZs=wasmExports.xmlUCSIsCatZs)(e),Module._xmlUCSIsCatZl=e=>(Module._xmlUCSIsCatZl=wasmExports.xmlUCSIsCatZl)(e),Module._xmlUCSIsCatZp=e=>(Module._xmlUCSIsCatZp=wasmExports.xmlUCSIsCatZp)(e),Module._xmlUCSIsCatS=e=>(Module._xmlUCSIsCatS=wasmExports.xmlUCSIsCatS)(e),Module._xmlUCSIsCatSm=e=>(Module._xmlUCSIsCatSm=wasmExports.xmlUCSIsCatSm)(e),Module._xmlUCSIsCatSc=e=>(Module._xmlUCSIsCatSc=wasmExports.xmlUCSIsCatSc)(e),Module._xmlUCSIsCatSk=e=>(Module._xmlUCSIsCatSk=wasmExports.xmlUCSIsCatSk)(e),Module._xmlUCSIsCatSo=e=>(Module._xmlUCSIsCatSo=wasmExports.xmlUCSIsCatSo)(e),Module._xmlUCSIsCatCc=e=>(Module._xmlUCSIsCatCc=wasmExports.xmlUCSIsCatCc)(e),Module._xmlUCSIsCatCf=e=>(Module._xmlUCSIsCatCf=wasmExports.xmlUCSIsCatCf)(e),Module._xmlUCSIsCatCo=e=>(Module._xmlUCSIsCatCo=wasmExports.xmlUCSIsCatCo)(e),Module._xmlUCSIsAegeanNumbers=e=>(Module._xmlUCSIsAegeanNumbers=wasmExports.xmlUCSIsAegeanNumbers)(e),Module._xmlUCSIsAlphabeticPresentationForms=e=>(Module._xmlUCSIsAlphabeticPresentationForms=wasmExports.xmlUCSIsAlphabeticPresentationForms)(e),Module._xmlUCSIsArabic=e=>(Module._xmlUCSIsArabic=wasmExports.xmlUCSIsArabic)(e),Module._xmlUCSIsArabicPresentationFormsA=e=>(Module._xmlUCSIsArabicPresentationFormsA=wasmExports.xmlUCSIsArabicPresentationFormsA)(e),Module._xmlUCSIsArabicPresentationFormsB=e=>(Module._xmlUCSIsArabicPresentationFormsB=wasmExports.xmlUCSIsArabicPresentationFormsB)(e),Module._xmlUCSIsArmenian=e=>(Module._xmlUCSIsArmenian=wasmExports.xmlUCSIsArmenian)(e),Module._xmlUCSIsArrows=e=>(Module._xmlUCSIsArrows=wasmExports.xmlUCSIsArrows)(e),Module._xmlUCSIsBasicLatin=e=>(Module._xmlUCSIsBasicLatin=wasmExports.xmlUCSIsBasicLatin)(e),Module._xmlUCSIsBengali=e=>(Module._xmlUCSIsBengali=wasmExports.xmlUCSIsBengali)(e),Module._xmlUCSIsBlockElements=e=>(Module._xmlUCSIsBlockElements=wasmExports.xmlUCSIsBlockElements)(e),Module._xmlUCSIsBopomofo=e=>(Module._xmlUCSIsBopomofo=wasmExports.xmlUCSIsBopomofo)(e),Module._xmlUCSIsBopomofoExtended=e=>(Module._xmlUCSIsBopomofoExtended=wasmExports.xmlUCSIsBopomofoExtended)(e),Module._xmlUCSIsBoxDrawing=e=>(Module._xmlUCSIsBoxDrawing=wasmExports.xmlUCSIsBoxDrawing)(e),Module._xmlUCSIsBraillePatterns=e=>(Module._xmlUCSIsBraillePatterns=wasmExports.xmlUCSIsBraillePatterns)(e),Module._xmlUCSIsBuhid=e=>(Module._xmlUCSIsBuhid=wasmExports.xmlUCSIsBuhid)(e),Module._xmlUCSIsByzantineMusicalSymbols=e=>(Module._xmlUCSIsByzantineMusicalSymbols=wasmExports.xmlUCSIsByzantineMusicalSymbols)(e),Module._xmlUCSIsCJKCompatibility=e=>(Module._xmlUCSIsCJKCompatibility=wasmExports.xmlUCSIsCJKCompatibility)(e),Module._xmlUCSIsCJKCompatibilityForms=e=>(Module._xmlUCSIsCJKCompatibilityForms=wasmExports.xmlUCSIsCJKCompatibilityForms)(e),Module._xmlUCSIsCJKCompatibilityIdeographs=e=>(Module._xmlUCSIsCJKCompatibilityIdeographs=wasmExports.xmlUCSIsCJKCompatibilityIdeographs)(e),Module._xmlUCSIsCJKCompatibilityIdeographsSupplement=e=>(Module._xmlUCSIsCJKCompatibilityIdeographsSupplement=wasmExports.xmlUCSIsCJKCompatibilityIdeographsSupplement)(e),Module._xmlUCSIsCJKRadicalsSupplement=e=>(Module._xmlUCSIsCJKRadicalsSupplement=wasmExports.xmlUCSIsCJKRadicalsSupplement)(e),Module._xmlUCSIsCJKSymbolsandPunctuation=e=>(Module._xmlUCSIsCJKSymbolsandPunctuation=wasmExports.xmlUCSIsCJKSymbolsandPunctuation)(e),Module._xmlUCSIsCJKUnifiedIdeographs=e=>(Module._xmlUCSIsCJKUnifiedIdeographs=wasmExports.xmlUCSIsCJKUnifiedIdeographs)(e),Module._xmlUCSIsCJKUnifiedIdeographsExtensionA=e=>(Module._xmlUCSIsCJKUnifiedIdeographsExtensionA=wasmExports.xmlUCSIsCJKUnifiedIdeographsExtensionA)(e),Module._xmlUCSIsCJKUnifiedIdeographsExtensionB=e=>(Module._xmlUCSIsCJKUnifiedIdeographsExtensionB=wasmExports.xmlUCSIsCJKUnifiedIdeographsExtensionB)(e),Module._xmlUCSIsCherokee=e=>(Module._xmlUCSIsCherokee=wasmExports.xmlUCSIsCherokee)(e),Module._xmlUCSIsCombiningDiacriticalMarks=e=>(Module._xmlUCSIsCombiningDiacriticalMarks=wasmExports.xmlUCSIsCombiningDiacriticalMarks)(e),Module._xmlUCSIsCombiningDiacriticalMarksforSymbols=e=>(Module._xmlUCSIsCombiningDiacriticalMarksforSymbols=wasmExports.xmlUCSIsCombiningDiacriticalMarksforSymbols)(e),Module._xmlUCSIsCombiningHalfMarks=e=>(Module._xmlUCSIsCombiningHalfMarks=wasmExports.xmlUCSIsCombiningHalfMarks)(e),Module._xmlUCSIsCombiningMarksforSymbols=e=>(Module._xmlUCSIsCombiningMarksforSymbols=wasmExports.xmlUCSIsCombiningMarksforSymbols)(e),Module._xmlUCSIsControlPictures=e=>(Module._xmlUCSIsControlPictures=wasmExports.xmlUCSIsControlPictures)(e),Module._xmlUCSIsCurrencySymbols=e=>(Module._xmlUCSIsCurrencySymbols=wasmExports.xmlUCSIsCurrencySymbols)(e),Module._xmlUCSIsCypriotSyllabary=e=>(Module._xmlUCSIsCypriotSyllabary=wasmExports.xmlUCSIsCypriotSyllabary)(e),Module._xmlUCSIsCyrillic=e=>(Module._xmlUCSIsCyrillic=wasmExports.xmlUCSIsCyrillic)(e),Module._xmlUCSIsCyrillicSupplement=e=>(Module._xmlUCSIsCyrillicSupplement=wasmExports.xmlUCSIsCyrillicSupplement)(e),Module._xmlUCSIsDeseret=e=>(Module._xmlUCSIsDeseret=wasmExports.xmlUCSIsDeseret)(e),Module._xmlUCSIsDevanagari=e=>(Module._xmlUCSIsDevanagari=wasmExports.xmlUCSIsDevanagari)(e),Module._xmlUCSIsDingbats=e=>(Module._xmlUCSIsDingbats=wasmExports.xmlUCSIsDingbats)(e),Module._xmlUCSIsEnclosedAlphanumerics=e=>(Module._xmlUCSIsEnclosedAlphanumerics=wasmExports.xmlUCSIsEnclosedAlphanumerics)(e),Module._xmlUCSIsEnclosedCJKLettersandMonths=e=>(Module._xmlUCSIsEnclosedCJKLettersandMonths=wasmExports.xmlUCSIsEnclosedCJKLettersandMonths)(e),Module._xmlUCSIsEthiopic=e=>(Module._xmlUCSIsEthiopic=wasmExports.xmlUCSIsEthiopic)(e),Module._xmlUCSIsGeneralPunctuation=e=>(Module._xmlUCSIsGeneralPunctuation=wasmExports.xmlUCSIsGeneralPunctuation)(e),Module._xmlUCSIsGeometricShapes=e=>(Module._xmlUCSIsGeometricShapes=wasmExports.xmlUCSIsGeometricShapes)(e),Module._xmlUCSIsGeorgian=e=>(Module._xmlUCSIsGeorgian=wasmExports.xmlUCSIsGeorgian)(e),Module._xmlUCSIsGothic=e=>(Module._xmlUCSIsGothic=wasmExports.xmlUCSIsGothic)(e),Module._xmlUCSIsGreek=e=>(Module._xmlUCSIsGreek=wasmExports.xmlUCSIsGreek)(e),Module._xmlUCSIsGreekExtended=e=>(Module._xmlUCSIsGreekExtended=wasmExports.xmlUCSIsGreekExtended)(e),Module._xmlUCSIsGreekandCoptic=e=>(Module._xmlUCSIsGreekandCoptic=wasmExports.xmlUCSIsGreekandCoptic)(e),Module._xmlUCSIsGujarati=e=>(Module._xmlUCSIsGujarati=wasmExports.xmlUCSIsGujarati)(e),Module._xmlUCSIsGurmukhi=e=>(Module._xmlUCSIsGurmukhi=wasmExports.xmlUCSIsGurmukhi)(e),Module._xmlUCSIsHalfwidthandFullwidthForms=e=>(Module._xmlUCSIsHalfwidthandFullwidthForms=wasmExports.xmlUCSIsHalfwidthandFullwidthForms)(e),Module._xmlUCSIsHangulCompatibilityJamo=e=>(Module._xmlUCSIsHangulCompatibilityJamo=wasmExports.xmlUCSIsHangulCompatibilityJamo)(e),Module._xmlUCSIsHangulJamo=e=>(Module._xmlUCSIsHangulJamo=wasmExports.xmlUCSIsHangulJamo)(e),Module._xmlUCSIsHangulSyllables=e=>(Module._xmlUCSIsHangulSyllables=wasmExports.xmlUCSIsHangulSyllables)(e),Module._xmlUCSIsHanunoo=e=>(Module._xmlUCSIsHanunoo=wasmExports.xmlUCSIsHanunoo)(e),Module._xmlUCSIsHebrew=e=>(Module._xmlUCSIsHebrew=wasmExports.xmlUCSIsHebrew)(e),Module._xmlUCSIsHighPrivateUseSurrogates=e=>(Module._xmlUCSIsHighPrivateUseSurrogates=wasmExports.xmlUCSIsHighPrivateUseSurrogates)(e),Module._xmlUCSIsHighSurrogates=e=>(Module._xmlUCSIsHighSurrogates=wasmExports.xmlUCSIsHighSurrogates)(e),Module._xmlUCSIsHiragana=e=>(Module._xmlUCSIsHiragana=wasmExports.xmlUCSIsHiragana)(e),Module._xmlUCSIsIPAExtensions=e=>(Module._xmlUCSIsIPAExtensions=wasmExports.xmlUCSIsIPAExtensions)(e),Module._xmlUCSIsIdeographicDescriptionCharacters=e=>(Module._xmlUCSIsIdeographicDescriptionCharacters=wasmExports.xmlUCSIsIdeographicDescriptionCharacters)(e),Module._xmlUCSIsKanbun=e=>(Module._xmlUCSIsKanbun=wasmExports.xmlUCSIsKanbun)(e),Module._xmlUCSIsKangxiRadicals=e=>(Module._xmlUCSIsKangxiRadicals=wasmExports.xmlUCSIsKangxiRadicals)(e),Module._xmlUCSIsKannada=e=>(Module._xmlUCSIsKannada=wasmExports.xmlUCSIsKannada)(e),Module._xmlUCSIsKatakana=e=>(Module._xmlUCSIsKatakana=wasmExports.xmlUCSIsKatakana)(e),Module._xmlUCSIsKatakanaPhoneticExtensions=e=>(Module._xmlUCSIsKatakanaPhoneticExtensions=wasmExports.xmlUCSIsKatakanaPhoneticExtensions)(e),Module._xmlUCSIsKhmer=e=>(Module._xmlUCSIsKhmer=wasmExports.xmlUCSIsKhmer)(e),Module._xmlUCSIsKhmerSymbols=e=>(Module._xmlUCSIsKhmerSymbols=wasmExports.xmlUCSIsKhmerSymbols)(e),Module._xmlUCSIsLao=e=>(Module._xmlUCSIsLao=wasmExports.xmlUCSIsLao)(e),Module._xmlUCSIsLatin1Supplement=e=>(Module._xmlUCSIsLatin1Supplement=wasmExports.xmlUCSIsLatin1Supplement)(e),Module._xmlUCSIsLatinExtendedA=e=>(Module._xmlUCSIsLatinExtendedA=wasmExports.xmlUCSIsLatinExtendedA)(e),Module._xmlUCSIsLatinExtendedB=e=>(Module._xmlUCSIsLatinExtendedB=wasmExports.xmlUCSIsLatinExtendedB)(e),Module._xmlUCSIsLatinExtendedAdditional=e=>(Module._xmlUCSIsLatinExtendedAdditional=wasmExports.xmlUCSIsLatinExtendedAdditional)(e),Module._xmlUCSIsLetterlikeSymbols=e=>(Module._xmlUCSIsLetterlikeSymbols=wasmExports.xmlUCSIsLetterlikeSymbols)(e),Module._xmlUCSIsLimbu=e=>(Module._xmlUCSIsLimbu=wasmExports.xmlUCSIsLimbu)(e),Module._xmlUCSIsLinearBIdeograms=e=>(Module._xmlUCSIsLinearBIdeograms=wasmExports.xmlUCSIsLinearBIdeograms)(e),Module._xmlUCSIsLinearBSyllabary=e=>(Module._xmlUCSIsLinearBSyllabary=wasmExports.xmlUCSIsLinearBSyllabary)(e),Module._xmlUCSIsLowSurrogates=e=>(Module._xmlUCSIsLowSurrogates=wasmExports.xmlUCSIsLowSurrogates)(e),Module._xmlUCSIsMalayalam=e=>(Module._xmlUCSIsMalayalam=wasmExports.xmlUCSIsMalayalam)(e),Module._xmlUCSIsMathematicalAlphanumericSymbols=e=>(Module._xmlUCSIsMathematicalAlphanumericSymbols=wasmExports.xmlUCSIsMathematicalAlphanumericSymbols)(e),Module._xmlUCSIsMathematicalOperators=e=>(Module._xmlUCSIsMathematicalOperators=wasmExports.xmlUCSIsMathematicalOperators)(e),Module._xmlUCSIsMiscellaneousMathematicalSymbolsA=e=>(Module._xmlUCSIsMiscellaneousMathematicalSymbolsA=wasmExports.xmlUCSIsMiscellaneousMathematicalSymbolsA)(e),Module._xmlUCSIsMiscellaneousMathematicalSymbolsB=e=>(Module._xmlUCSIsMiscellaneousMathematicalSymbolsB=wasmExports.xmlUCSIsMiscellaneousMathematicalSymbolsB)(e),Module._xmlUCSIsMiscellaneousSymbols=e=>(Module._xmlUCSIsMiscellaneousSymbols=wasmExports.xmlUCSIsMiscellaneousSymbols)(e),Module._xmlUCSIsMiscellaneousSymbolsandArrows=e=>(Module._xmlUCSIsMiscellaneousSymbolsandArrows=wasmExports.xmlUCSIsMiscellaneousSymbolsandArrows)(e),Module._xmlUCSIsMiscellaneousTechnical=e=>(Module._xmlUCSIsMiscellaneousTechnical=wasmExports.xmlUCSIsMiscellaneousTechnical)(e),Module._xmlUCSIsMongolian=e=>(Module._xmlUCSIsMongolian=wasmExports.xmlUCSIsMongolian)(e),Module._xmlUCSIsMusicalSymbols=e=>(Module._xmlUCSIsMusicalSymbols=wasmExports.xmlUCSIsMusicalSymbols)(e),Module._xmlUCSIsMyanmar=e=>(Module._xmlUCSIsMyanmar=wasmExports.xmlUCSIsMyanmar)(e),Module._xmlUCSIsNumberForms=e=>(Module._xmlUCSIsNumberForms=wasmExports.xmlUCSIsNumberForms)(e),Module._xmlUCSIsOgham=e=>(Module._xmlUCSIsOgham=wasmExports.xmlUCSIsOgham)(e),Module._xmlUCSIsOldItalic=e=>(Module._xmlUCSIsOldItalic=wasmExports.xmlUCSIsOldItalic)(e),Module._xmlUCSIsOpticalCharacterRecognition=e=>(Module._xmlUCSIsOpticalCharacterRecognition=wasmExports.xmlUCSIsOpticalCharacterRecognition)(e),Module._xmlUCSIsOriya=e=>(Module._xmlUCSIsOriya=wasmExports.xmlUCSIsOriya)(e),Module._xmlUCSIsOsmanya=e=>(Module._xmlUCSIsOsmanya=wasmExports.xmlUCSIsOsmanya)(e),Module._xmlUCSIsPhoneticExtensions=e=>(Module._xmlUCSIsPhoneticExtensions=wasmExports.xmlUCSIsPhoneticExtensions)(e),Module._xmlUCSIsPrivateUse=e=>(Module._xmlUCSIsPrivateUse=wasmExports.xmlUCSIsPrivateUse)(e),Module._xmlUCSIsPrivateUseArea=e=>(Module._xmlUCSIsPrivateUseArea=wasmExports.xmlUCSIsPrivateUseArea)(e),Module._xmlUCSIsRunic=e=>(Module._xmlUCSIsRunic=wasmExports.xmlUCSIsRunic)(e),Module._xmlUCSIsShavian=e=>(Module._xmlUCSIsShavian=wasmExports.xmlUCSIsShavian)(e),Module._xmlUCSIsSinhala=e=>(Module._xmlUCSIsSinhala=wasmExports.xmlUCSIsSinhala)(e),Module._xmlUCSIsSmallFormVariants=e=>(Module._xmlUCSIsSmallFormVariants=wasmExports.xmlUCSIsSmallFormVariants)(e),Module._xmlUCSIsSpacingModifierLetters=e=>(Module._xmlUCSIsSpacingModifierLetters=wasmExports.xmlUCSIsSpacingModifierLetters)(e),Module._xmlUCSIsSpecials=e=>(Module._xmlUCSIsSpecials=wasmExports.xmlUCSIsSpecials)(e),Module._xmlUCSIsSuperscriptsandSubscripts=e=>(Module._xmlUCSIsSuperscriptsandSubscripts=wasmExports.xmlUCSIsSuperscriptsandSubscripts)(e),Module._xmlUCSIsSupplementalArrowsA=e=>(Module._xmlUCSIsSupplementalArrowsA=wasmExports.xmlUCSIsSupplementalArrowsA)(e),Module._xmlUCSIsSupplementalArrowsB=e=>(Module._xmlUCSIsSupplementalArrowsB=wasmExports.xmlUCSIsSupplementalArrowsB)(e),Module._xmlUCSIsSupplementalMathematicalOperators=e=>(Module._xmlUCSIsSupplementalMathematicalOperators=wasmExports.xmlUCSIsSupplementalMathematicalOperators)(e),Module._xmlUCSIsSupplementaryPrivateUseAreaA=e=>(Module._xmlUCSIsSupplementaryPrivateUseAreaA=wasmExports.xmlUCSIsSupplementaryPrivateUseAreaA)(e),Module._xmlUCSIsSupplementaryPrivateUseAreaB=e=>(Module._xmlUCSIsSupplementaryPrivateUseAreaB=wasmExports.xmlUCSIsSupplementaryPrivateUseAreaB)(e),Module._xmlUCSIsSyriac=e=>(Module._xmlUCSIsSyriac=wasmExports.xmlUCSIsSyriac)(e),Module._xmlUCSIsTagalog=e=>(Module._xmlUCSIsTagalog=wasmExports.xmlUCSIsTagalog)(e),Module._xmlUCSIsTagbanwa=e=>(Module._xmlUCSIsTagbanwa=wasmExports.xmlUCSIsTagbanwa)(e),Module._xmlUCSIsTags=e=>(Module._xmlUCSIsTags=wasmExports.xmlUCSIsTags)(e),Module._xmlUCSIsTaiLe=e=>(Module._xmlUCSIsTaiLe=wasmExports.xmlUCSIsTaiLe)(e),Module._xmlUCSIsTaiXuanJingSymbols=e=>(Module._xmlUCSIsTaiXuanJingSymbols=wasmExports.xmlUCSIsTaiXuanJingSymbols)(e),Module._xmlUCSIsTamil=e=>(Module._xmlUCSIsTamil=wasmExports.xmlUCSIsTamil)(e),Module._xmlUCSIsTelugu=e=>(Module._xmlUCSIsTelugu=wasmExports.xmlUCSIsTelugu)(e),Module._xmlUCSIsThaana=e=>(Module._xmlUCSIsThaana=wasmExports.xmlUCSIsThaana)(e),Module._xmlUCSIsThai=e=>(Module._xmlUCSIsThai=wasmExports.xmlUCSIsThai)(e),Module._xmlUCSIsTibetan=e=>(Module._xmlUCSIsTibetan=wasmExports.xmlUCSIsTibetan)(e),Module._xmlUCSIsUgaritic=e=>(Module._xmlUCSIsUgaritic=wasmExports.xmlUCSIsUgaritic)(e),Module._xmlUCSIsUnifiedCanadianAboriginalSyllabics=e=>(Module._xmlUCSIsUnifiedCanadianAboriginalSyllabics=wasmExports.xmlUCSIsUnifiedCanadianAboriginalSyllabics)(e),Module._xmlUCSIsVariationSelectors=e=>(Module._xmlUCSIsVariationSelectors=wasmExports.xmlUCSIsVariationSelectors)(e),Module._xmlUCSIsVariationSelectorsSupplement=e=>(Module._xmlUCSIsVariationSelectorsSupplement=wasmExports.xmlUCSIsVariationSelectorsSupplement)(e),Module._xmlUCSIsYiRadicals=e=>(Module._xmlUCSIsYiRadicals=wasmExports.xmlUCSIsYiRadicals)(e),Module._xmlUCSIsYiSyllables=e=>(Module._xmlUCSIsYiSyllables=wasmExports.xmlUCSIsYiSyllables)(e),Module._xmlUCSIsYijingHexagramSymbols=e=>(Module._xmlUCSIsYijingHexagramSymbols=wasmExports.xmlUCSIsYijingHexagramSymbols)(e),Module._xmlUCSIsCatCs=e=>(Module._xmlUCSIsCatCs=wasmExports.xmlUCSIsCatCs)(e),Module.___small_fprintf=(e,I,Hn)=>(Module.___small_fprintf=wasmExports.__small_fprintf)(e,I,Hn),Module._xmlXPathBooleanFunction=(e,I)=>(Module._xmlXPathBooleanFunction=wasmExports.xmlXPathBooleanFunction)(e,I),Module._xmlXPathCeilingFunction=(e,I)=>(Module._xmlXPathCeilingFunction=wasmExports.xmlXPathCeilingFunction)(e,I),Module._xmlXPathCountFunction=(e,I)=>(Module._xmlXPathCountFunction=wasmExports.xmlXPathCountFunction)(e,I),Module._xmlXPathConcatFunction=(e,I)=>(Module._xmlXPathConcatFunction=wasmExports.xmlXPathConcatFunction)(e,I),Module._xmlXPathContainsFunction=(e,I)=>(Module._xmlXPathContainsFunction=wasmExports.xmlXPathContainsFunction)(e,I),Module._xmlXPathIdFunction=(e,I)=>(Module._xmlXPathIdFunction=wasmExports.xmlXPathIdFunction)(e,I),Module._xmlXPathFalseFunction=(e,I)=>(Module._xmlXPathFalseFunction=wasmExports.xmlXPathFalseFunction)(e,I),Module._xmlXPathFloorFunction=(e,I)=>(Module._xmlXPathFloorFunction=wasmExports.xmlXPathFloorFunction)(e,I),Module._xmlXPathLastFunction=(e,I)=>(Module._xmlXPathLastFunction=wasmExports.xmlXPathLastFunction)(e,I),Module._xmlXPathLangFunction=(e,I)=>(Module._xmlXPathLangFunction=wasmExports.xmlXPathLangFunction)(e,I),Module._xmlXPathLocalNameFunction=(e,I)=>(Module._xmlXPathLocalNameFunction=wasmExports.xmlXPathLocalNameFunction)(e,I),Module._xmlXPathNotFunction=(e,I)=>(Module._xmlXPathNotFunction=wasmExports.xmlXPathNotFunction)(e,I),Module._xmlXPathNamespaceURIFunction=(e,I)=>(Module._xmlXPathNamespaceURIFunction=wasmExports.xmlXPathNamespaceURIFunction)(e,I),Module._xmlXPathNormalizeFunction=(e,I)=>(Module._xmlXPathNormalizeFunction=wasmExports.xmlXPathNormalizeFunction)(e,I),Module._xmlXPathNumberFunction=(e,I)=>(Module._xmlXPathNumberFunction=wasmExports.xmlXPathNumberFunction)(e,I),Module._xmlXPathPositionFunction=(e,I)=>(Module._xmlXPathPositionFunction=wasmExports.xmlXPathPositionFunction)(e,I),Module._xmlXPathRoundFunction=(e,I)=>(Module._xmlXPathRoundFunction=wasmExports.xmlXPathRoundFunction)(e,I),Module._xmlXPathStringFunction=(e,I)=>(Module._xmlXPathStringFunction=wasmExports.xmlXPathStringFunction)(e,I),Module._xmlXPathStringLengthFunction=(e,I)=>(Module._xmlXPathStringLengthFunction=wasmExports.xmlXPathStringLengthFunction)(e,I),Module._xmlXPathStartsWithFunction=(e,I)=>(Module._xmlXPathStartsWithFunction=wasmExports.xmlXPathStartsWithFunction)(e,I),Module._xmlXPathSubstringFunction=(e,I)=>(Module._xmlXPathSubstringFunction=wasmExports.xmlXPathSubstringFunction)(e,I),Module._xmlXPathSubstringBeforeFunction=(e,I)=>(Module._xmlXPathSubstringBeforeFunction=wasmExports.xmlXPathSubstringBeforeFunction)(e,I),Module._xmlXPathSubstringAfterFunction=(e,I)=>(Module._xmlXPathSubstringAfterFunction=wasmExports.xmlXPathSubstringAfterFunction)(e,I),Module._xmlXPathSumFunction=(e,I)=>(Module._xmlXPathSumFunction=wasmExports.xmlXPathSumFunction)(e,I),Module._xmlXPathTrueFunction=(e,I)=>(Module._xmlXPathTrueFunction=wasmExports.xmlXPathTrueFunction)(e,I),Module._xmlXPathTranslateFunction=(e,I)=>(Module._xmlXPathTranslateFunction=wasmExports.xmlXPathTranslateFunction)(e,I),Module._xmlXPathNextSelf=(e,I)=>(Module._xmlXPathNextSelf=wasmExports.xmlXPathNextSelf)(e,I),Module._xmlXPathNextChild=(e,I)=>(Module._xmlXPathNextChild=wasmExports.xmlXPathNextChild)(e,I),Module._xmlXPathNextDescendant=(e,I)=>(Module._xmlXPathNextDescendant=wasmExports.xmlXPathNextDescendant)(e,I),Module._xmlXPathNextDescendantOrSelf=(e,I)=>(Module._xmlXPathNextDescendantOrSelf=wasmExports.xmlXPathNextDescendantOrSelf)(e,I),Module._xmlXPathNextParent=(e,I)=>(Module._xmlXPathNextParent=wasmExports.xmlXPathNextParent)(e,I),Module._xmlXPathNextAncestor=(e,I)=>(Module._xmlXPathNextAncestor=wasmExports.xmlXPathNextAncestor)(e,I),Module._xmlXPathNextAncestorOrSelf=(e,I)=>(Module._xmlXPathNextAncestorOrSelf=wasmExports.xmlXPathNextAncestorOrSelf)(e,I),Module._xmlXPathNextFollowingSibling=(e,I)=>(Module._xmlXPathNextFollowingSibling=wasmExports.xmlXPathNextFollowingSibling)(e,I),Module._xmlXPathNextPrecedingSibling=(e,I)=>(Module._xmlXPathNextPrecedingSibling=wasmExports.xmlXPathNextPrecedingSibling)(e,I),Module._xmlXPathNextFollowing=(e,I)=>(Module._xmlXPathNextFollowing=wasmExports.xmlXPathNextFollowing)(e,I),Module._xmlXPathNextNamespace=(e,I)=>(Module._xmlXPathNextNamespace=wasmExports.xmlXPathNextNamespace)(e,I),Module._xmlXPathNextAttribute=(e,I)=>(Module._xmlXPathNextAttribute=wasmExports.xmlXPathNextAttribute)(e,I),Module._zcalloc=(e,I,Hn)=>(Module._zcalloc=wasmExports.zcalloc)(e,I,Hn),Module._zcfree=(e,I)=>(Module._zcfree=wasmExports.zcfree)(e,I),Module._strerror=e=>(Module._strerror=wasmExports.strerror)(e);var ___dl_seterr=(e,I)=>(___dl_seterr=wasmExports.__dl_seterr)(e,I);Module._putc=(e,I)=>(Module._putc=wasmExports.putc)(e,I),Module._gmtime=e=>(Module._gmtime=wasmExports.gmtime)(e);var _htonl=e=>(_htonl=wasmExports.htonl)(e),_htons=e=>(_htons=wasmExports.htons)(e);Module._ioctl=(e,I,Hn)=>(Module._ioctl=wasmExports.ioctl)(e,I,Hn);var _emscripten_builtin_memalign=(e,I)=>(_emscripten_builtin_memalign=wasmExports.emscripten_builtin_memalign)(e,I),_ntohs=e=>(_ntohs=wasmExports.ntohs)(e);Module._srand=e=>(Module._srand=wasmExports.srand)(e),Module._rand=()=>(Module._rand=wasmExports.rand)();var __emscripten_timeout=(e,I)=>(__emscripten_timeout=wasmExports._emscripten_timeout)(e,I);Module.___floatsitf=(e,I)=>(Module.___floatsitf=wasmExports.__floatsitf)(e,I),Module.___multf3=(e,I,Hn,$n,qn)=>(Module.___multf3=wasmExports.__multf3)(e,I,Hn,$n,qn),Module.___extenddftf2=(e,I)=>(Module.___extenddftf2=wasmExports.__extenddftf2)(e,I),Module.___getf2=(e,I,Hn,$n)=>(Module.___getf2=wasmExports.__getf2)(e,I,Hn,$n),Module.___subtf3=(e,I,Hn,$n,qn)=>(Module.___subtf3=wasmExports.__subtf3)(e,I,Hn,$n,qn),Module.___letf2=(e,I,Hn,$n)=>(Module.___letf2=wasmExports.__letf2)(e,I,Hn,$n),Module.___lttf2=(e,I,Hn,$n)=>(Module.___lttf2=wasmExports.__lttf2)(e,I,Hn,$n);var _setThrew=(e,I)=>(_setThrew=wasmExports.setThrew)(e,I),__emscripten_tempret_set=e=>(__emscripten_tempret_set=wasmExports._emscripten_tempret_set)(e),__emscripten_tempret_get=()=>(__emscripten_tempret_get=wasmExports._emscripten_tempret_get)();Module.___fixtfsi=(e,I)=>(Module.___fixtfsi=wasmExports.__fixtfsi)(e,I);var __emscripten_stack_restore=e=>(__emscripten_stack_restore=wasmExports._emscripten_stack_restore)(e),__emscripten_stack_alloc=e=>(__emscripten_stack_alloc=wasmExports._emscripten_stack_alloc)(e),_emscripten_stack_get_current=()=>(_emscripten_stack_get_current=wasmExports.emscripten_stack_get_current)();Module._ScanKeywords=18770052,Module._stderr=18792480,Module._stdout=18792784,Module._TopMemoryContext=18830716,Module._MainLWLockArray=18800668,Module._MyProc=18802328,Module._MyProcPid=18824228,Module._MyLatch=18824260,Module._CurrentMemoryContext=18830712,Module._InterruptPending=18824092,Module._pg_global_prng_state=18936304,Module._CurrentResourceOwner=18830692,Module._InterruptHoldoffCount=18824132,Module._IsUnderPostmaster=18824165,Module._wal_level=18758340,Module._MyDatabaseId=18824148,Module._error_context_stack=18816816,Module._PG_exception_stack=18816820,Module.___THREW__=18950052,Module.___threwValue=18950056,Module._ShmemVariableCache=18849760,Module._shmem_startup_hook=18794508,Module._debug_query_string=18848300,Module._CritSectionCount=18824140,Module._old_snapshot_threshold=18823756,Module._TopTransactionResourceOwner=18830700,Module._LocalBufferBlockPointers=18800556,Module._BufferBlocks=18795304,Module._pgBufferUsage=18813728,Module._GUC_check_errdetail_string=18814680,Module._NBuffers=18690456,Module._BufferDescriptors=18795300,Module._ParallelWorkerNumber=18767008,Module._stdin=18792632,Module._ScanKeywordTokens=17487664,Module._post_parse_analyze_hook=18802584,Module._progname=18848060,Module._DataDir=18824144,Module._MyStartTime=18824232,Module._MyProcPort=18824248,Module._Log_directory=18803120,Module._Log_filename=18803124,Module._ConfigReloadPending=18803272,Module._ShutdownRequestPending=18803276,Module._process_shared_preload_libraries_in_progress=18824080,Module._wal_segment_size=18758360,Module._application_name=18815988,Module._XactIsoLevel=18758700,Module._RmgrTable=18758816,Module._CacheMemoryContext=18830728,Module._TopTransactionContext=18830736,Module._TTSOpsVirtual=18638668,Module._WalReceiverFunctions=18803712,Module._TTSOpsMinimalTuple=18638764,Module._cluster_name=18640444,Module._work_mem=18690432,Module._ClientAuthentication_hook=18804032,Module._cma_rsize=18848108,Module._SOCKET_DATA=18854312,Module._SOCKET_FILE=18854308,Module._TTSOpsHeapTuple=18638716,Module._SnapshotAnyData=18690240,Module._ExecutorStart_hook=18813600,Module._ExecutorRun_hook=18813604,Module._ExecutorFinish_hook=18813608,Module._ExecutorEnd_hook=18813612,Module._SPI_processed=18813624,Module._SPI_tuptable=18813632,Module._SPI_result=18813636,Module._pgWalUsage=18813840,Module._cpu_operator_cost=18638912,Module._planner_hook=18813876,Module._maintenance_work_mem=18690448,Module._max_parallel_maintenance_workers=18690452,Module._cpu_tuple_cost=18638896,Module._seq_page_cost=18638880,Module._check_function_bodies=18640389,Module._quote_all_identifiers=18848065,Module._extra_float_digits=18692128,Module._IntervalStyle=18824172,Module._pg_crc32_table=18115504,Module._oldSnapshotControl=18823760,Module._shmem_request_hook=18824084,Module._DateStyle=18690420,Module._pg_number_of_ones=18433360,Module._xmlStructuredError=18936668,Module._xmlStructuredErrorContext=18936676,Module._xmlGenericErrorContext=18936672,Module._xmlGenericError=18774356,Module._xmlIsBaseCharGroup=18774120,Module._xmlIsDigitGroup=18774152,Module._xmlIsCombiningGroup=18774136,Module._xmlIsExtenderGroup=18774168,Module._xmlFree=18774320,Module._ProcessUtility_hook=18848012,Module._single_mode_feed=18848076,Module._cma_wsize=18848116,Module._check_password_hook=18850784,Module._IDB_STAGE=18854320,Module._IDB_PIPE_FP=18854316,Module._pg_scram_mech=18774064,Module._pg_g_threadlock=18772168,Module._pgresStatus=18773856,Module._xmlIsPubidChar_tab=18433648,Module._xmlGetWarningsDefaultValue=18774348,Module._xmlMalloc=18774324,Module._xmlRealloc=18774332,Module._xmlLastError=18936688,Module._xmlMallocAtomic=18774328,Module._xmlMemStrdup=18774336,Module._xmlBufferAllocScheme=18774340,Module._xmlDefaultBufferSize=18774344,Module._xmlParserDebugEntities=18936628,Module._xmlDoValidityCheckingDefaultValue=18936632,Module._xmlLoadExtDtdDefaultValue=18936636,Module._xmlPedanticParserDefaultValue=18936640,Module._xmlLineNumbersDefaultValue=18936644,Module._xmlKeepBlanksDefaultValue=18774352,Module._xmlSubstituteEntitiesDefaultValue=18936648,Module._xmlRegisterNodeDefaultValue=18936652,Module._xmlDeregisterNodeDefaultValue=18936656,Module._xmlParserInputBufferCreateFilenameValue=18936660,Module._xmlOutputBufferCreateFilenameValue=18936664,Module._xmlIndentTreeOutput=18774360,Module._xmlTreeIndentString=18774364,Module._xmlSaveNoEmptyTags=18936680,Module._xmlDefaultSAXHandler=18774368,Module._xmlDefaultSAXLocator=18774480,Module._xmlParserMaxDepth=18775140,Module._xmlStringText=18435456,Module._xmlStringComment=18435471,Module._xmlStringTextNoenc=18435461,Module._xmlXPathNAN=18937352,Module._xmlXPathNINF=18937368,Module._xmlXPathPINF=18937360,Module._z_errmsg=18791696,Module.__length_code=18455120,Module.__dist_code=18454608;function invoke_i(e){var I=stackSave();try{return getWasmTableEntry(e)()}catch(Hn){if(stackRestore(I),Hn!==Hn+0)throw Hn;_setThrew(1,0)}}function invoke_v(e){var I=stackSave();try{getWasmTableEntry(e)()}catch(Hn){if(stackRestore(I),Hn!==Hn+0)throw Hn;_setThrew(1,0)}}function invoke_vi(e,I){var Hn=stackSave();try{getWasmTableEntry(e)(I)}catch($n){if(stackRestore(Hn),$n!==$n+0)throw $n;_setThrew(1,0)}}function invoke_iii(e,I,Hn){var $n=stackSave();try{return getWasmTableEntry(e)(I,Hn)}catch(qn){if(stackRestore($n),qn!==qn+0)throw qn;_setThrew(1,0)}}function invoke_iiiiii(e,I,Hn,$n,qn,Xn){var Yn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn,Xn)}catch(Kn){if(stackRestore(Yn),Kn!==Kn+0)throw Kn;_setThrew(1,0)}}function invoke_viii(e,I,Hn,$n){var qn=stackSave();try{getWasmTableEntry(e)(I,Hn,$n)}catch(Xn){if(stackRestore(qn),Xn!==Xn+0)throw Xn;_setThrew(1,0)}}function invoke_viiiiiii(e,I,Hn,$n,qn,Xn,Yn,Kn){var Jn=stackSave();try{getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn,Kn)}catch(Zn){if(stackRestore(Jn),Zn!==Zn+0)throw Zn;_setThrew(1,0)}}function invoke_iiii(e,I,Hn,$n){var qn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n)}catch(Xn){if(stackRestore(qn),Xn!==Xn+0)throw Xn;_setThrew(1,0)}}function invoke_viiii(e,I,Hn,$n,qn){var Xn=stackSave();try{getWasmTableEntry(e)(I,Hn,$n,qn)}catch(Yn){if(stackRestore(Xn),Yn!==Yn+0)throw Yn;_setThrew(1,0)}}function invoke_iiiii(e,I,Hn,$n,qn){var Xn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn)}catch(Yn){if(stackRestore(Xn),Yn!==Yn+0)throw Yn;_setThrew(1,0)}}function invoke_vii(e,I,Hn){var $n=stackSave();try{getWasmTableEntry(e)(I,Hn)}catch(qn){if(stackRestore($n),qn!==qn+0)throw qn;_setThrew(1,0)}}function invoke_ii(e,I){var Hn=stackSave();try{return getWasmTableEntry(e)(I)}catch($n){if(stackRestore(Hn),$n!==$n+0)throw $n;_setThrew(1,0)}}function invoke_viiiiiiii(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn){var Zn=stackSave();try{getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn,Kn,Jn)}catch(ea){if(stackRestore(Zn),ea!==ea+0)throw ea;_setThrew(1,0)}}function invoke_viiiii(e,I,Hn,$n,qn,Xn){var Yn=stackSave();try{getWasmTableEntry(e)(I,Hn,$n,qn,Xn)}catch(Kn){if(stackRestore(Yn),Kn!==Kn+0)throw Kn;_setThrew(1,0)}}function invoke_ij(e,I){var Hn=stackSave();try{return getWasmTableEntry(e)(I)}catch($n){if(stackRestore(Hn),$n!==$n+0)throw $n;_setThrew(1,0)}}function invoke_ji(e,I){var Hn=stackSave();try{return getWasmTableEntry(e)(I)}catch($n){if(stackRestore(Hn),$n!==$n+0)throw $n;return _setThrew(1,0),0n}}function invoke_ijiiiiii(e,I,Hn,$n,qn,Xn,Yn,Kn){var Jn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn,Kn)}catch(Zn){if(stackRestore(Jn),Zn!==Zn+0)throw Zn;_setThrew(1,0)}}function invoke_vij(e,I,Hn){var $n=stackSave();try{getWasmTableEntry(e)(I,Hn)}catch(qn){if(stackRestore($n),qn!==qn+0)throw qn;_setThrew(1,0)}}function invoke_vj(e,I){var Hn=stackSave();try{getWasmTableEntry(e)(I)}catch($n){if(stackRestore(Hn),$n!==$n+0)throw $n;_setThrew(1,0)}}function invoke_viijii(e,I,Hn,$n,qn,Xn){var Yn=stackSave();try{getWasmTableEntry(e)(I,Hn,$n,qn,Xn)}catch(Kn){if(stackRestore(Yn),Kn!==Kn+0)throw Kn;_setThrew(1,0)}}function invoke_iiiiiji(e,I,Hn,$n,qn,Xn,Yn){var Kn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn)}catch(Jn){if(stackRestore(Kn),Jn!==Jn+0)throw Jn;_setThrew(1,0)}}function invoke_viijiiii(e,I,Hn,$n,qn,Xn,Yn,Kn){var Jn=stackSave();try{getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn,Kn)}catch(Zn){if(stackRestore(Jn),Zn!==Zn+0)throw Zn;_setThrew(1,0)}}function invoke_viij(e,I,Hn,$n){var qn=stackSave();try{getWasmTableEntry(e)(I,Hn,$n)}catch(Xn){if(stackRestore(qn),Xn!==Xn+0)throw Xn;_setThrew(1,0)}}function invoke_jiiiiiiii(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn){var Zn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn,Kn,Jn)}catch(ea){if(stackRestore(Zn),ea!==ea+0)throw ea;return _setThrew(1,0),0n}}function invoke_jiiiii(e,I,Hn,$n,qn,Xn){var Yn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn,Xn)}catch(Kn){if(stackRestore(Yn),Kn!==Kn+0)throw Kn;return _setThrew(1,0),0n}}function invoke_iiiiiiiii(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn){var Zn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn,Kn,Jn)}catch(ea){if(stackRestore(Zn),ea!==ea+0)throw ea;_setThrew(1,0)}}function invoke_vji(e,I,Hn){var $n=stackSave();try{getWasmTableEntry(e)(I,Hn)}catch(qn){if(stackRestore($n),qn!==qn+0)throw qn;_setThrew(1,0)}}function invoke_iiiijii(e,I,Hn,$n,qn,Xn,Yn){var Kn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn)}catch(Jn){if(stackRestore(Kn),Jn!==Jn+0)throw Jn;_setThrew(1,0)}}function invoke_vijiji(e,I,Hn,$n,qn,Xn){var Yn=stackSave();try{getWasmTableEntry(e)(I,Hn,$n,qn,Xn)}catch(Kn){if(stackRestore(Yn),Kn!==Kn+0)throw Kn;_setThrew(1,0)}}function invoke_viji(e,I,Hn,$n){var qn=stackSave();try{getWasmTableEntry(e)(I,Hn,$n)}catch(Xn){if(stackRestore(qn),Xn!==Xn+0)throw Xn;_setThrew(1,0)}}function invoke_iiij(e,I,Hn,$n){var qn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n)}catch(Xn){if(stackRestore(qn),Xn!==Xn+0)throw Xn;_setThrew(1,0)}}function invoke_iiiiiiii(e,I,Hn,$n,qn,Xn,Yn,Kn){var Jn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn,Kn)}catch(Zn){if(stackRestore(Jn),Zn!==Zn+0)throw Zn;_setThrew(1,0)}}function invoke_iiiiiii(e,I,Hn,$n,qn,Xn,Yn){var Kn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn)}catch(Jn){if(stackRestore(Kn),Jn!==Jn+0)throw Jn;_setThrew(1,0)}}function invoke_di(e,I){var Hn=stackSave();try{return getWasmTableEntry(e)(I)}catch($n){if(stackRestore(Hn),$n!==$n+0)throw $n;_setThrew(1,0)}}function invoke_id(e,I){var Hn=stackSave();try{return getWasmTableEntry(e)(I)}catch($n){if(stackRestore(Hn),$n!==$n+0)throw $n;_setThrew(1,0)}}function invoke_ijiiiii(e,I,Hn,$n,qn,Xn,Yn){var Kn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn)}catch(Jn){if(stackRestore(Kn),Jn!==Jn+0)throw Jn;_setThrew(1,0)}}function invoke_jiiii(e,I,Hn,$n,qn){var Xn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn)}catch(Yn){if(stackRestore(Xn),Yn!==Yn+0)throw Yn;return _setThrew(1,0),0n}}function invoke_viiiiii(e,I,Hn,$n,qn,Xn,Yn){var Kn=stackSave();try{getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn)}catch(Jn){if(stackRestore(Kn),Jn!==Jn+0)throw Jn;_setThrew(1,0)}}function invoke_viiiiiiiiiiii(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn,ea,aa,oa){var la=stackSave();try{getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn,ea,aa,oa)}catch(ra){if(stackRestore(la),ra!==ra+0)throw ra;_setThrew(1,0)}}function invoke_jii(e,I,Hn){var $n=stackSave();try{return getWasmTableEntry(e)(I,Hn)}catch(qn){if(stackRestore($n),qn!==qn+0)throw qn;return _setThrew(1,0),0n}}function invoke_iiiij(e,I,Hn,$n,qn){var Xn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn)}catch(Yn){if(stackRestore(Xn),Yn!==Yn+0)throw Yn;_setThrew(1,0)}}function invoke_iiiiiiiiii(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn){var ea=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn)}catch(aa){if(stackRestore(ea),aa!==aa+0)throw aa;_setThrew(1,0)}}function invoke_viiji(e,I,Hn,$n,qn){var Xn=stackSave();try{getWasmTableEntry(e)(I,Hn,$n,qn)}catch(Yn){if(stackRestore(Xn),Yn!==Yn+0)throw Yn;_setThrew(1,0)}}function invoke_iiji(e,I,Hn,$n){var qn=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n)}catch(Xn){if(stackRestore(qn),Xn!==Xn+0)throw Xn;_setThrew(1,0)}}function invoke_vid(e,I,Hn){var $n=stackSave();try{getWasmTableEntry(e)(I,Hn)}catch(qn){if(stackRestore($n),qn!==qn+0)throw qn;_setThrew(1,0)}}function invoke_viiiiiiiii(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn){var ea=stackSave();try{getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn)}catch(aa){if(stackRestore(ea),aa!==aa+0)throw aa;_setThrew(1,0)}}function invoke_viiij(e,I,Hn,$n,qn){var Xn=stackSave();try{getWasmTableEntry(e)(I,Hn,$n,qn)}catch(Yn){if(stackRestore(Xn),Yn!==Yn+0)throw Yn;_setThrew(1,0)}}function invoke_iiiiiiiiiiiiiiiii(e,I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn,ea,aa,oa,la,ra,ia,da){var Ea=stackSave();try{return getWasmTableEntry(e)(I,Hn,$n,qn,Xn,Yn,Kn,Jn,Zn,ea,aa,oa,la,ra,ia,da)}catch(na){if(stackRestore(Ea),na!==na+0)throw na;_setThrew(1,0)}}Module.addRunDependency=addRunDependency,Module.removeRunDependency=removeRunDependency,Module.callMain=callMain,Module.ccall=ccall,Module.cwrap=cwrap,Module.setValue=setValue,Module.getValue=getValue,Module.UTF8ToString=UTF8ToString,Module.stringToNewUTF8=stringToNewUTF8,Module.stringToUTF8OnStack=stringToUTF8OnStack,Module.FS_createPreloadedFile=FS_createPreloadedFile,Module.FS_unlink=FS_unlink,Module.FS_createPath=FS_createPath,Module.FS_createDevice=FS_createDevice,Module.FS=FS,Module.FS_createDataFile=FS_createDataFile,Module.FS_createLazyFile=FS_createLazyFile;var calledRun;dependenciesFulfilled=function e(){calledRun||run(),calledRun||(dependenciesFulfilled=e)};function callMain(e=[]){var I=resolveGlobalSymbol("main").sym;if(I){e.unshift(thisProgram);var Hn=e.length,$n=stackAlloc((Hn+1)*4),qn=$n;e.forEach(Yn=>{HEAPU32[qn>>2]=stringToUTF8OnStack(Yn),qn+=4}),HEAPU32[qn>>2]=0;try{var Xn=I(Hn,$n);return exitJS(Xn,!0),Xn}catch(Yn){return handleException(Yn)}}}function run(e=arguments_){if(runDependencies>0||(preRun(),runDependencies>0))return;function I(){calledRun||(calledRun=!0,Module.calledRun=!0,!ABORT&&(initRuntime(),preMain(),readyPromiseResolve(Module),Module.onRuntimeInitialized?.(),shouldRunNow&&callMain(e),postRun()))}Module.setStatus?(Module.setStatus("Running..."),setTimeout(()=>{setTimeout(()=>Module.setStatus(""),1),I()},1)):I()}if(Module.preInit)for(typeof Module.preInit=="function"&&(Module.preInit=[Module.preInit]);Module.preInit.length>0;)Module.preInit.pop()();var shouldRunNow=!0;return Module.noInitialRun&&(shouldRunNow=!1),run(),moduleRtn=readyPromise,moduleRtn}})(),ke=Qe,Te=ke,Y,W$1,j$2,J,$,_e,ie,me,Z,ae,oe,se,V$1,G$1,k,K$1,O,qe,re,pe=class ha extends z{constructor(I={},Hn={}){super(),R$2(this,O),R$2(this,Y,!1),R$2(this,W$1,!1),R$2(this,j$2,!1),R$2(this,J,!1),R$2(this,$,!1),R$2(this,_e,new H$1),R$2(this,ie,new H$1),R$2(this,me,new H$1),R$2(this,Z,!1),this.debug=0,R$2(this,ae),R$2(this,oe,[]),R$2(this,se,new ye),R$2(this,V$1),R$2(this,G$1),R$2(this,k,new Map),R$2(this,K$1,new Set),typeof I=="string"?Hn={dataDir:I,...Hn}:Hn=I,this.dataDir=Hn.dataDir,Hn.parsers!==void 0&&(this.parsers={...this.parsers,...Hn.parsers}),Hn.serializers!==void 0&&(this.serializers={...this.serializers,...Hn.serializers}),Hn?.debug!==void 0&&(this.debug=Hn.debug),Hn?.relaxedDurability!==void 0&&x$2(this,$,Hn.relaxedDurability),x$2(this,ae,Hn.extensions??{}),this.waitReady=T(this,O,qe).call(this,Hn??{})}static async create(I,Hn){let $n=typeof I=="string"?{dataDir:I,...Hn??{}}:I??{},qn=new ha($n);return await qn.waitReady,qn}get Module(){return this.mod}get ready(){return h$1(this,Y)&&!h$1(this,W$1)&&!h$1(this,j$2)}get closed(){return h$1(this,j$2)}async close(){await this._checkReady(),x$2(this,W$1,!0);for(let I of h$1(this,oe))await I();try{await this.execProtocol(O$1.end()),this.mod._pg_shutdown()}catch(I){let Hn=I;if(!(Hn.name==="ExitStatus"&&Hn.status===0))throw I}await this.fs.closeFs(),x$2(this,j$2,!0),x$2(this,W$1,!1)}async[Symbol.asyncDispose](){await this.close()}async _handleBlob(I){x$2(this,V$1,I?await I.arrayBuffer():void 0)}async _cleanupBlob(){x$2(this,V$1,void 0)}async _getWrittenBlob(){if(!h$1(this,G$1))return;let I=new Blob(h$1(this,G$1));return x$2(this,G$1,void 0),I}async _checkReady(){if(h$1(this,W$1))throw new Error("PGlite is closing");if(h$1(this,j$2))throw new Error("PGlite is closed");h$1(this,Y)||await this.waitReady}execProtocolRawSync(I){let Hn=I.length,$n=this.mod;$n._interactive_write(Hn),$n.HEAPU8.set(I,1),$n._interactive_one();let qn=Hn+2,Xn=qn+$n._interactive_read();return $n.HEAPU8.subarray(qn,Xn)}async execProtocolRaw(I,{syncToFs:Hn=!0}={}){let $n=I.length,qn=this.mod;qn._interactive_write($n),qn.HEAPU8.set(I,1),qn._interactive_one();let Xn=$n+2,Yn=Xn+qn._interactive_read(),Kn=qn.HEAPU8.subarray(Xn,Yn);return Hn&&await this.syncToFs(),Kn}async execProtocol(I,{syncToFs:Hn=!0,throwOnError:$n=!0,onNotice:qn}={}){let Xn=await this.execProtocolRaw(I,{syncToFs:Hn}),Yn=[];return h$1(this,se).parse(Xn,Kn=>{if(Kn instanceof E){if(x$2(this,se,new ye),$n)throw Kn}else if(Kn instanceof ne)this.debug>0&&console.warn(Kn),qn&&qn(Kn);else if(Kn instanceof ee$2)switch(Kn.text){case"BEGIN":x$2(this,J,!0);break;case"COMMIT":case"ROLLBACK":x$2(this,J,!1);break}else if(Kn instanceof X$1){let Jn=h$1(this,k).get(Kn.channel);Jn&&Jn.forEach(Zn=>{queueMicrotask(()=>Zn(Kn.payload))}),h$1(this,K$1).forEach(Zn=>{queueMicrotask(()=>Zn(Kn.channel,Kn.payload))})}Yn.push(Kn)}),{messages:Yn,data:Xn}}isInTransaction(){return h$1(this,J)}async syncToFs(){if(h$1(this,Z))return;x$2(this,Z,!0);let I=async()=>{await h$1(this,me).runExclusive(async()=>{x$2(this,Z,!1),await this.fs.syncToFs(h$1(this,$))})};h$1(this,$)?I():await I()}async listen(I,Hn){let $n=Nr(I);h$1(this,k).has($n)||h$1(this,k).set($n,new Set),h$1(this,k).get($n).add(Hn);try{await this.exec(`LISTEN ${I}`)}catch(qn){throw h$1(this,k).get($n).delete(Hn),h$1(this,k).get($n)?.size===0&&h$1(this,k).delete($n),qn}return async()=>{await this.unlisten($n,Hn)}}async unlisten(I,Hn){let $n=Nr(I);Hn?(h$1(this,k).get($n)?.delete(Hn),h$1(this,k).get($n)?.size===0&&(await this.exec(`UNLISTEN ${I}`),h$1(this,k).delete($n))):(await this.exec(`UNLISTEN ${I}`),h$1(this,k).delete($n))}onNotification(I){return h$1(this,K$1).add(I),()=>{h$1(this,K$1).delete(I)}}offNotification(I){h$1(this,K$1).delete(I)}async dumpDataDir(I){let Hn=this.dataDir?.split("/").pop()??"pgdata";return this.fs.dumpTar(Hn,I)}_runExclusiveQuery(I){return h$1(this,_e).runExclusive(I)}_runExclusiveTransaction(I){return h$1(this,ie).runExclusive(I)}async clone(){let I=await this.dumpDataDir("none");return new ha({loadDataDir:I})}};Y=new WeakMap,W$1=new WeakMap,j$2=new WeakMap,J=new WeakMap,$=new WeakMap,_e=new WeakMap,ie=new WeakMap,me=new WeakMap,Z=new WeakMap,ae=new WeakMap,oe=new WeakMap,se=new WeakMap,V$1=new WeakMap,G$1=new WeakMap,k=new WeakMap,K$1=new WeakMap,O=new WeakSet,qe=async function(e){if(e.fs)this.fs=e.fs;else{let{dataDir:Zn,fsType:ea}=Fe(e.dataDir);this.fs=await Ae(Zn,ea)}let I={},Hn=[],$n=[`PGDATA=${C}`,`PREFIX=${Vr}`,`PGUSER=${e.username??"postgres"}`,`PGDATABASE=${e.database??"template1"}`,"MODE=REACT","REPL=N",...this.debug?["-d",this.debug.toString()]:[]];e.wasmModule||Rr();let qn=e.fsBundle?e.fsBundle.arrayBuffer():Er(),Xn;qn.then(Zn=>{Xn=Zn});let Yn={WASM_PREFIX:Vr,arguments:$n,INITIAL_MEMORY:e.initialMemory,noExitRuntime:!0,...this.debug>0?{print:console.info,printErr:console.error}:{print:()=>{},printErr:()=>{}},instantiateWasm:(Zn,ea)=>(Tr(Zn,e.wasmModule).then(({instance:aa,module:oa})=>{ea(aa,oa)}),{}),getPreloadedPackage:(Zn,ea)=>{if(Zn==="postgres.data"){if(Xn.byteLength!==ea)throw new Error(`Invalid FS bundle size: ${Xn.byteLength} !== ${ea}`);return Xn}throw new Error(`Unknown package: ${Zn}`)},preRun:[Zn=>{let ea=Zn.FS.makedev(64,0),aa={open:oa=>{},close:oa=>{},read:(oa,la,ra,ia,da)=>{let Ea=h$1(this,V$1);if(!Ea)throw new Error("No /dev/blob File or Blob provided to read from");let na=new Uint8Array(Ea);if(da>=na.length)return 0;let ta=Math.min(na.length-da,ia);for(let sa=0;sa<ta;sa++)la[ra+sa]=na[da+sa];return ta},write:(oa,la,ra,ia,da)=>(h$1(this,G$1)??x$2(this,G$1,[]),h$1(this,G$1).push(la.slice(ra,ra+ia)),ia),llseek:(oa,la,ra)=>{let ia=h$1(this,V$1);if(!ia)throw new Error("No /dev/blob File or Blob provided to llseek");let da=la;if(ra===1?da+=oa.position:ra===2&&(da=new Uint8Array(ia).length),da<0)throw new Zn.FS.ErrnoError(28);return da}};Zn.FS.registerDevice(ea,aa),Zn.FS.mkdev("/dev/blob",ea)}]},{emscriptenOpts:Kn}=await this.fs.init(this,Yn);Yn=Kn;for(let[Zn,ea]of Object.entries(h$1(this,ae)))if(ea instanceof URL)I[Zn]=ge(ea);else{let aa=await ea.setup(this,Yn);if(aa.emscriptenOpts&&(Yn=aa.emscriptenOpts),aa.namespaceObj){let oa=this;oa[Zn]=aa.namespaceObj}aa.bundlePath&&(I[Zn]=ge(aa.bundlePath)),aa.init&&Hn.push(aa.init),aa.close&&h$1(this,oe).push(aa.close)}if(Yn.pg_extensions=I,await qn,this.mod=await Te(Yn),await this.fs.initialSyncFs(),e.loadDataDir){if(this.mod.FS.analyzePath(C+"/PG_VERSION").exists)throw new Error("Database already exists, cannot load from tarball");T(this,O,re).call(this,"pglite: loading data from tarball"),await ce$1(this.mod.FS,e.loadDataDir,C)}this.mod.FS.analyzePath(C+"/PG_VERSION").exists?T(this,O,re).call(this,"pglite: found DB, resuming"):T(this,O,re).call(this,"pglite: no db"),await Pe(this.mod,(...Zn)=>T(this,O,re).call(this,...Zn));let Jn=this.mod._pg_initdb();if(!Jn)throw new Error("INITDB failed to return value");if(Jn&1)throw new Error("INITDB failed");if(Jn&2){let Zn=e.username??"postgres",ea=e.database??"template1";if(Jn&4){if(!(Jn&12))throw new Error("Invalid db/user combination")}else if(ea!=="template1"&&Zn!=="postgres")throw new Error("INITDB created a new datadir, but an alternative db/user was requested")}await this.syncToFs(),x$2(this,Y,!0),await this.exec("SET search_path TO public;"),await this._initArrayTypes();for(let Zn of Hn)await Zn()},re=function(...e){this.debug>0&&console.log(...e)};var Ue=pe;u$1();var __defProp$1=Object.defineProperty,__defProps$1=Object.defineProperties,__getOwnPropDescs$1=Object.getOwnPropertyDescriptors,__getOwnPropSymbols$1=Object.getOwnPropertySymbols,__hasOwnProp$1=Object.prototype.hasOwnProperty,__propIsEnum$1=Object.prototype.propertyIsEnumerable,__typeError$1=e=>{throw TypeError(e)},__defNormalProp$1=(e,I,Hn)=>I in e?__defProp$1(e,I,{enumerable:!0,configurable:!0,writable:!0,value:Hn}):e[I]=Hn,__spreadValues$1=(e,I)=>{for(var Hn in I||(I={}))__hasOwnProp$1.call(I,Hn)&&__defNormalProp$1(e,Hn,I[Hn]);if(__getOwnPropSymbols$1)for(var Hn of __getOwnPropSymbols$1(I))__propIsEnum$1.call(I,Hn)&&__defNormalProp$1(e,Hn,I[Hn]);return e},__spreadProps$1=(e,I)=>__defProps$1(e,__getOwnPropDescs$1(I)),__objRest=(e,I)=>{var Hn={};for(var $n in e)__hasOwnProp$1.call(e,$n)&&I.indexOf($n)<0&&(Hn[$n]=e[$n]);if(e!=null&&__getOwnPropSymbols$1)for(var $n of __getOwnPropSymbols$1(e))I.indexOf($n)<0&&__propIsEnum$1.call(e,$n)&&(Hn[$n]=e[$n]);return Hn},__accessCheck$1=(e,I,Hn)=>I.has(e)||__typeError$1("Cannot "+Hn),__privateGet$1=(e,I,Hn)=>(__accessCheck$1(e,I,"read from private field"),Hn?Hn.call(e):I.get(e)),__privateAdd$1=(e,I,Hn)=>I.has(e)?__typeError$1("Cannot add the same private member more than once"):I instanceof WeakSet?I.add(e):I.set(e,Hn),__privateSet$1=(e,I,Hn,$n)=>(__accessCheck$1(e,I,"write to private field"),I.set(e,Hn),Hn),__privateMethod$1=(e,I,Hn)=>(__accessCheck$1(e,I,"access private method"),Hn),__async$1=(e,I,Hn)=>new Promise(($n,qn)=>{var Xn=Jn=>{try{Kn(Hn.next(Jn))}catch(Zn){qn(Zn)}},Yn=Jn=>{try{Kn(Hn.throw(Jn))}catch(Zn){qn(Zn)}},Kn=Jn=>Jn.done?$n(Jn.value):Promise.resolve(Jn.value).then(Xn,Yn);Kn((Hn=Hn.apply(e,I)).next())}),FetchError=class fa extends Error{constructor(I,Hn,$n,qn,Xn,Yn){super(Yn||`HTTP Error ${I} at ${Xn}: ${Hn??JSON.stringify($n)}`),this.url=Xn,this.name="FetchError",this.status=I,this.text=Hn,this.json=$n,this.headers=qn}static fromResponse(I,Hn){return __async$1(this,null,function*(){const $n=I.status,qn=Object.fromEntries([...I.headers.entries()]);let Xn,Yn;const Kn=I.headers.get("content-type");return Kn&&Kn.includes("application/json")?Yn=yield I.json():Xn=yield I.text(),new fa($n,Xn,Yn,qn,Hn)})}},FetchBackoffAbortError=class extends Error{constructor(){super("Fetch with backoff aborted"),this.name="FetchBackoffAbortError"}},MissingShapeUrlError=class extends Error{constructor(){super("Invalid shape options: missing required url parameter"),this.name="MissingShapeUrlError"}},InvalidSignalError=class extends Error{constructor(){super("Invalid signal option. It must be an instance of AbortSignal."),this.name="InvalidSignalError"}},MissingShapeHandleError=class extends Error{constructor(){super("shapeHandle is required if this isn't an initial fetch (i.e. offset > -1)"),this.name="MissingShapeHandleError"}},ReservedParamError=class extends Error{constructor(e){super(`Cannot use reserved Electric parameter names in custom params: ${e.join(", ")}`),this.name="ReservedParamError"}},ParserNullValueError=class extends Error{constructor(e){super(`Column "${e??"unknown"}" does not allow NULL values`),this.name="ParserNullValueError"}},MissingHeadersError=class extends Error{constructor(e,I){let Hn=`The response for the shape request to ${e} didn't include the following required headers:
`;I.forEach($n=>{Hn+=`- ${$n}
`}),Hn+=`
This is often due to a proxy not setting CORS correctly so that all Electric headers can be read by the client.`,Hn+=`
For more information visit the troubleshooting guide: /docs/guides/troubleshooting/missing-headers`,super(Hn)}},parseNumber=e=>Number(e),parseBool=e=>e==="true"||e==="t",parseBigInt=e=>BigInt(e),parseJson=e=>JSON.parse(e),identityParser=e=>e,defaultParser={int2:parseNumber,int4:parseNumber,int8:parseBigInt,bool:parseBool,float4:parseNumber,float8:parseNumber,json:parseJson,jsonb:parseJson};function pgArrayParser(e,I){let Hn=0,$n=null,qn="",Xn=!1,Yn=0,Kn;function Jn(Zn){const ea=[];for(;Hn<Zn.length;Hn++){if($n=Zn[Hn],Xn)$n==="\\"?qn+=Zn[++Hn]:$n==='"'?(ea.push(I?I(qn):qn),qn="",Xn=Zn[Hn+1]==='"',Yn=Hn+2):qn+=$n;else if($n==='"')Xn=!0;else if($n==="{")Yn=++Hn,ea.push(Jn(Zn));else if($n==="}"){Xn=!1,Yn<Hn&&ea.push(I?I(Zn.slice(Yn,Hn)):Zn.slice(Yn,Hn)),Yn=Hn+1;break}else $n===","&&Kn!=="}"&&Kn!=='"'&&(ea.push(I?I(Zn.slice(Yn,Hn)):Zn.slice(Yn,Hn)),Yn=Hn+1);Kn=$n}return Yn<Hn&&ea.push(I?I(Zn.slice(Yn,Hn+1)):Zn.slice(Yn,Hn+1)),ea}return Jn(e)[0]}var MessageParser=class{constructor(e){this.parser=__spreadValues$1(__spreadValues$1({},defaultParser),e)}parse(e,I){return JSON.parse(e,(Hn,$n)=>{if((Hn==="value"||Hn==="old_value")&&typeof $n=="object"&&$n!==null){const qn=$n;Object.keys(qn).forEach(Xn=>{qn[Xn]=this.parseRow(Xn,qn[Xn],I)})}return $n})}parseRow(e,I,Hn){var $n;const qn=Hn[e];if(!qn)return I;const Xn=qn,{type:Yn,dims:Kn}=Xn,Jn=__objRest(Xn,["type","dims"]),Zn=($n=this.parser[Yn])!=null?$n:identityParser,ea=makeNullableParser(Zn,qn,e);return Kn&&Kn>0?makeNullableParser((oa,la)=>pgArrayParser(oa,ea),qn,e)(I):ea(I,Jn)}};function makeNullableParser(e,I,Hn){var $n;const qn=!(($n=I.not_null)!=null&&$n);return Xn=>{if(isPgNull(Xn)){if(!qn)throw new ParserNullValueError(Hn??"unknown");return null}return e(Xn,I)}}function isPgNull(e){return e===null||e==="NULL"}function isChangeMessage(e){return"key"in e}function isControlMessage(e){return!isChangeMessage(e)}function isUpToDateMessage(e){return isControlMessage(e)&&e.headers.control==="up-to-date"}var LIVE_CACHE_BUSTER_HEADER="electric-cursor",SHAPE_HANDLE_HEADER="electric-handle",CHUNK_LAST_OFFSET_HEADER="electric-offset",SHAPE_SCHEMA_HEADER="electric-schema",CHUNK_UP_TO_DATE_HEADER="electric-up-to-date",COLUMNS_QUERY_PARAM="columns",LIVE_CACHE_BUSTER_QUERY_PARAM="cursor",SHAPE_HANDLE_QUERY_PARAM="handle",LIVE_QUERY_PARAM="live",OFFSET_QUERY_PARAM="offset",TABLE_QUERY_PARAM="table",WHERE_QUERY_PARAM="where",REPLICA_PARAM="replica",WHERE_PARAMS_PARAM="params",FORCE_DISCONNECT_AND_REFRESH="force-disconnect-and-refresh",HTTP_RETRY_STATUS_CODES=[429],BackoffDefaults={initialDelay:100,maxDelay:1e4,multiplier:1.3};function createFetchWithBackoff(e,I=BackoffDefaults){const{initialDelay:Hn,maxDelay:$n,multiplier:qn,debug:Xn=!1,onFailedAttempt:Yn}=I;return(...Kn)=>__async$1(this,null,function*(){var Jn;const Zn=Kn[0],ea=Kn[1];let aa=Hn,oa=0;for(;;)try{const la=yield e(...Kn);if(la.ok)return la;throw yield FetchError.fromResponse(la,Zn.toString())}catch(la){if(Yn?.(),(Jn=ea?.signal)!=null&&Jn.aborted)throw new FetchBackoffAbortError;if(la instanceof FetchError&&!HTTP_RETRY_STATUS_CODES.includes(la.status)&&la.status>=400&&la.status<500)throw la;yield new Promise(ra=>setTimeout(ra,aa)),aa=Math.min(aa*qn,$n),Xn&&(oa++,console.log(`Retry attempt #${oa} after ${aa}ms`))}})}var ChunkPrefetchDefaults={maxChunksToPrefetch:2};function createFetchWithChunkBuffer(e,I=ChunkPrefetchDefaults){const{maxChunksToPrefetch:Hn}=I;let $n;return(...Xn)=>__async$1(this,null,function*(){const Yn=Xn[0].toString(),Kn=$n?.consume(...Xn);if(Kn)return Kn;$n?.abort();const Jn=yield e(...Xn),Zn=getNextChunkUrl(Yn,Jn);return Zn&&($n=new PrefetchQueue({fetchClient:e,maxPrefetchedRequests:Hn,url:Zn,requestInit:Xn[1]})),Jn})}var requiredElectricResponseHeaders=["electric-offset","electric-handle"],requiredLiveResponseHeaders=["electric-cursor"],requiredNonLiveResponseHeaders=["electric-schema"];function createFetchWithResponseHeadersCheck(e){return(...I)=>__async$1(this,null,function*(){const Hn=yield e(...I);if(Hn.ok){const $n=Hn.headers,qn=[],Xn=Zn=>qn.push(...Zn.filter(ea=>!$n.has(ea)));Xn(requiredElectricResponseHeaders);const Kn=I[0].toString(),Jn=new URL(Kn);if(Jn.searchParams.get(LIVE_QUERY_PARAM)==="true"&&Xn(requiredLiveResponseHeaders),(!Jn.searchParams.has(LIVE_QUERY_PARAM)||Jn.searchParams.get(LIVE_QUERY_PARAM)==="false")&&Xn(requiredNonLiveResponseHeaders),qn.length>0)throw new MissingHeadersError(Kn,qn)}return Hn})}var _fetchClient,_maxPrefetchedRequests,_prefetchQueue,_queueHeadUrl,_queueTailUrl,_PrefetchQueue_instances,prefetch_fn,PrefetchQueue=class{constructor(e){__privateAdd$1(this,_PrefetchQueue_instances),__privateAdd$1(this,_fetchClient),__privateAdd$1(this,_maxPrefetchedRequests),__privateAdd$1(this,_prefetchQueue,new Map),__privateAdd$1(this,_queueHeadUrl),__privateAdd$1(this,_queueTailUrl);var I;__privateSet$1(this,_fetchClient,(I=e.fetchClient)!=null?I:(...Hn)=>fetch(...Hn)),__privateSet$1(this,_maxPrefetchedRequests,e.maxPrefetchedRequests),__privateSet$1(this,_queueHeadUrl,e.url.toString()),__privateSet$1(this,_queueTailUrl,__privateGet$1(this,_queueHeadUrl)),__privateMethod$1(this,_PrefetchQueue_instances,prefetch_fn).call(this,e.url,e.requestInit)}abort(){__privateGet$1(this,_prefetchQueue).forEach(([e,I])=>I.abort())}consume(...e){var I;const Hn=e[0].toString(),$n=(I=__privateGet$1(this,_prefetchQueue).get(Hn))==null?void 0:I[0];if(!(!$n||Hn!==__privateGet$1(this,_queueHeadUrl)))return __privateGet$1(this,_prefetchQueue).delete(Hn),$n.then(qn=>{const Xn=getNextChunkUrl(Hn,qn);__privateSet$1(this,_queueHeadUrl,Xn),__privateGet$1(this,_queueTailUrl)&&!__privateGet$1(this,_prefetchQueue).has(__privateGet$1(this,_queueTailUrl))&&__privateMethod$1(this,_PrefetchQueue_instances,prefetch_fn).call(this,__privateGet$1(this,_queueTailUrl),e[1])}).catch(()=>{}),$n}};_fetchClient=new WeakMap;_maxPrefetchedRequests=new WeakMap;_prefetchQueue=new WeakMap;_queueHeadUrl=new WeakMap;_queueTailUrl=new WeakMap;_PrefetchQueue_instances=new WeakSet;prefetch_fn=function(...e){var I,Hn;const $n=e[0].toString();if(__privateGet$1(this,_prefetchQueue).size>=__privateGet$1(this,_maxPrefetchedRequests))return;const qn=new AbortController;try{const{signal:Xn,cleanup:Yn}=chainAborter(qn,(I=e[1])==null?void 0:I.signal),Kn=__privateGet$1(this,_fetchClient).call(this,$n,__spreadProps$1(__spreadValues$1({},(Hn=e[1])!=null?Hn:{}),{signal:Xn}));__privateGet$1(this,_prefetchQueue).set($n,[Kn,qn]),Kn.then(Jn=>{if(!Jn.ok||qn.signal.aborted)return;const Zn=getNextChunkUrl($n,Jn);if(!Zn||Zn===$n){__privateSet$1(this,_queueTailUrl,void 0);return}return __privateSet$1(this,_queueTailUrl,Zn),__privateMethod$1(this,_PrefetchQueue_instances,prefetch_fn).call(this,Zn,e[1])}).catch(()=>{}).finally(Yn)}catch{}};function getNextChunkUrl(e,I){const Hn=I.headers.get(SHAPE_HANDLE_HEADER),$n=I.headers.get(CHUNK_LAST_OFFSET_HEADER),qn=I.headers.has(CHUNK_UP_TO_DATE_HEADER);if(!Hn||!$n||qn)return;const Xn=new URL(e);if(!Xn.searchParams.has(LIVE_QUERY_PARAM))return Xn.searchParams.set(SHAPE_HANDLE_QUERY_PARAM,Hn),Xn.searchParams.set(OFFSET_QUERY_PARAM,$n),Xn.searchParams.sort(),Xn.toString()}function chainAborter(e,I){let Hn=noop;if(I)if(I.aborted)e.abort();else{const $n=()=>e.abort();I.addEventListener("abort",$n,{once:!0,signal:e.signal}),Hn=()=>I.removeEventListener("abort",$n)}return{signal:e.signal,cleanup:Hn}}function noop(){}var RESERVED_PARAMS=new Set([LIVE_CACHE_BUSTER_QUERY_PARAM,SHAPE_HANDLE_QUERY_PARAM,LIVE_QUERY_PARAM,OFFSET_QUERY_PARAM]);function resolveValue(e){return __async$1(this,null,function*(){return typeof e=="function"?e():e})}function toInternalParams(e){return __async$1(this,null,function*(){const I=Object.entries(e),Hn=yield Promise.all(I.map($n=>__async$1(this,[$n],function*([qn,Xn]){if(Xn===void 0)return[qn,void 0];const Yn=yield resolveValue(Xn);return[qn,Array.isArray(Yn)?Yn.join(","):Yn]})));return Object.fromEntries(Hn.filter(([$n,qn])=>qn!==void 0))})}function resolveHeaders(e){return __async$1(this,null,function*(){if(!e)return{};const I=Object.entries(e),Hn=yield Promise.all(I.map($n=>__async$1(this,[$n],function*([qn,Xn]){return[qn,yield resolveValue(Xn)]})));return Object.fromEntries(Hn)})}var _error,_fetchClient2,_messageParser,_subscribers$1,_started$1,_lastOffset,_liveCacheBuster,_lastSyncedAt,_isUpToDate,_connected,_shapeHandle,_schema,_onError,_requestAbortController,_isRefreshing,_tickPromise,_tickPromiseResolver,_tickPromiseRejecter,_ShapeStream_instances,start_fn$1,nextTick_fn,publish_fn,sendErrorToSubscribers_fn,reset_fn,ShapeStream=class{constructor(e){__privateAdd$1(this,_ShapeStream_instances),__privateAdd$1(this,_error,null),__privateAdd$1(this,_fetchClient2),__privateAdd$1(this,_messageParser),__privateAdd$1(this,_subscribers$1,new Map),__privateAdd$1(this,_started$1,!1),__privateAdd$1(this,_lastOffset),__privateAdd$1(this,_liveCacheBuster),__privateAdd$1(this,_lastSyncedAt),__privateAdd$1(this,_isUpToDate,!1),__privateAdd$1(this,_connected,!1),__privateAdd$1(this,_shapeHandle),__privateAdd$1(this,_schema),__privateAdd$1(this,_onError),__privateAdd$1(this,_requestAbortController),__privateAdd$1(this,_isRefreshing,!1),__privateAdd$1(this,_tickPromise),__privateAdd$1(this,_tickPromiseResolver),__privateAdd$1(this,_tickPromiseRejecter);var I,Hn,$n;this.options=__spreadValues$1({subscribe:!0},e),validateOptions(this.options),__privateSet$1(this,_lastOffset,(I=this.options.offset)!=null?I:"-1"),__privateSet$1(this,_liveCacheBuster,""),__privateSet$1(this,_shapeHandle,this.options.handle),__privateSet$1(this,_messageParser,new MessageParser(e.parser)),__privateSet$1(this,_onError,this.options.onError);const qn=(Hn=e.fetchClient)!=null?Hn:(...Yn)=>fetch(...Yn),Xn=createFetchWithBackoff(qn,__spreadProps$1(__spreadValues$1({},($n=e.backoffOptions)!=null?$n:BackoffDefaults),{onFailedAttempt:()=>{var Yn,Kn;__privateSet$1(this,_connected,!1),(Kn=(Yn=e.backoffOptions)==null?void 0:Yn.onFailedAttempt)==null||Kn.call(Yn)}}));__privateSet$1(this,_fetchClient2,createFetchWithResponseHeadersCheck(createFetchWithChunkBuffer(Xn)))}get shapeHandle(){return __privateGet$1(this,_shapeHandle)}get error(){return __privateGet$1(this,_error)}get isUpToDate(){return __privateGet$1(this,_isUpToDate)}get lastOffset(){return __privateGet$1(this,_lastOffset)}subscribe(e,I=()=>{}){const Hn=Math.random();return __privateGet$1(this,_subscribers$1).set(Hn,[e,I]),__privateGet$1(this,_started$1)||__privateMethod$1(this,_ShapeStream_instances,start_fn$1).call(this),()=>{__privateGet$1(this,_subscribers$1).delete(Hn)}}unsubscribeAll(){__privateGet$1(this,_subscribers$1).clear()}lastSyncedAt(){return __privateGet$1(this,_lastSyncedAt)}lastSynced(){return __privateGet$1(this,_lastSyncedAt)===void 0?1/0:Date.now()-__privateGet$1(this,_lastSyncedAt)}isConnected(){return __privateGet$1(this,_connected)}isLoading(){return!__privateGet$1(this,_isUpToDate)}hasStarted(){return __privateGet$1(this,_started$1)}forceDisconnectAndRefresh(){return __async$1(this,null,function*(){var e,I;__privateSet$1(this,_isRefreshing,!0),__privateGet$1(this,_isUpToDate)&&!((e=__privateGet$1(this,_requestAbortController))!=null&&e.signal.aborted)&&((I=__privateGet$1(this,_requestAbortController))==null||I.abort(FORCE_DISCONNECT_AND_REFRESH)),yield __privateMethod$1(this,_ShapeStream_instances,nextTick_fn).call(this),__privateSet$1(this,_isRefreshing,!1)})}};_error=new WeakMap;_fetchClient2=new WeakMap;_messageParser=new WeakMap;_subscribers$1=new WeakMap;_started$1=new WeakMap;_lastOffset=new WeakMap;_liveCacheBuster=new WeakMap;_lastSyncedAt=new WeakMap;_isUpToDate=new WeakMap;_connected=new WeakMap;_shapeHandle=new WeakMap;_schema=new WeakMap;_onError=new WeakMap;_requestAbortController=new WeakMap;_isRefreshing=new WeakMap;_tickPromise=new WeakMap;_tickPromiseResolver=new WeakMap;_tickPromiseRejecter=new WeakMap;_ShapeStream_instances=new WeakSet;start_fn$1=function(){return __async$1(this,null,function*(){var e,I,Hn,$n,qn;if(__privateGet$1(this,_started$1))throw new Error("Cannot start stream twice");__privateSet$1(this,_started$1,!0);try{for(;!((e=this.options.signal)!=null&&e.aborted)&&!__privateGet$1(this,_isUpToDate)||this.options.subscribe;){const{url:Xn,signal:Yn}=this.options,[Kn,Jn]=yield Promise.all([resolveHeaders(this.options.headers),this.options.params?toInternalParams(convertWhereParamsToObj(this.options.params)):void 0]);Jn&&validateParams(Jn);const Zn=new URL(Xn);if(Jn){Jn.table&&setQueryParam(Zn,TABLE_QUERY_PARAM,Jn.table),Jn.where&&setQueryParam(Zn,WHERE_QUERY_PARAM,Jn.where),Jn.columns&&setQueryParam(Zn,COLUMNS_QUERY_PARAM,Jn.columns),Jn.replica&&setQueryParam(Zn,REPLICA_PARAM,Jn.replica),Jn.params&&setQueryParam(Zn,WHERE_PARAMS_PARAM,Jn.params);const sa=__spreadValues$1({},Jn);delete sa.table,delete sa.where,delete sa.columns,delete sa.replica,delete sa.params;for(const[ca,_a]of Object.entries(sa))setQueryParam(Zn,ca,_a)}Zn.searchParams.set(OFFSET_QUERY_PARAM,__privateGet$1(this,_lastOffset)),__privateGet$1(this,_isUpToDate)&&(__privateGet$1(this,_isRefreshing)||Zn.searchParams.set(LIVE_QUERY_PARAM,"true"),Zn.searchParams.set(LIVE_CACHE_BUSTER_QUERY_PARAM,__privateGet$1(this,_liveCacheBuster))),__privateGet$1(this,_shapeHandle)&&Zn.searchParams.set(SHAPE_HANDLE_QUERY_PARAM,__privateGet$1(this,_shapeHandle)),Zn.searchParams.sort(),__privateSet$1(this,_requestAbortController,new AbortController);let ea;Yn&&(ea=()=>{var sa;(sa=__privateGet$1(this,_requestAbortController))==null||sa.abort(Yn.reason)},Yn.addEventListener("abort",ea,{once:!0}),Yn.aborted&&((I=__privateGet$1(this,_requestAbortController))==null||I.abort(Yn.reason)));let aa;try{aa=yield __privateGet$1(this,_fetchClient2).call(this,Zn.toString(),{signal:__privateGet$1(this,_requestAbortController).signal,headers:Kn}),__privateSet$1(this,_connected,!0)}catch(sa){if((sa instanceof FetchError||sa instanceof FetchBackoffAbortError)&&__privateGet$1(this,_requestAbortController).signal.aborted&&__privateGet$1(this,_requestAbortController).signal.reason===FORCE_DISCONNECT_AND_REFRESH)continue;if(sa instanceof FetchBackoffAbortError)break;if(!(sa instanceof FetchError))throw sa;if(sa.status==409){const ca=sa.headers[SHAPE_HANDLE_HEADER];__privateMethod$1(this,_ShapeStream_instances,reset_fn).call(this,ca),yield __privateMethod$1(this,_ShapeStream_instances,publish_fn).call(this,sa.json);continue}else if(sa.status>=400&&sa.status<500)throw __privateMethod$1(this,_ShapeStream_instances,sendErrorToSubscribers_fn).call(this,sa),sa}finally{ea&&Yn&&Yn.removeEventListener("abort",ea),__privateSet$1(this,_requestAbortController,void 0)}const{headers:oa,status:la}=aa,ra=oa.get(SHAPE_HANDLE_HEADER);ra&&__privateSet$1(this,_shapeHandle,ra);const ia=oa.get(CHUNK_LAST_OFFSET_HEADER);ia&&__privateSet$1(this,_lastOffset,ia);const da=oa.get(LIVE_CACHE_BUSTER_HEADER);da&&__privateSet$1(this,_liveCacheBuster,da);const Ea=()=>{const sa=oa.get(SHAPE_SCHEMA_HEADER);return sa?JSON.parse(sa):{}};__privateSet$1(this,_schema,(Hn=__privateGet$1(this,_schema))!=null?Hn:Ea());const na=la===204?"[]":yield aa.text();la===204&&__privateSet$1(this,_lastSyncedAt,Date.now());const ta=__privateGet$1(this,_messageParser).parse(na,__privateGet$1(this,_schema));if(ta.length>0){const sa=ta[ta.length-1];isUpToDateMessage(sa)&&(__privateSet$1(this,_lastSyncedAt,Date.now()),__privateSet$1(this,_isUpToDate,!0)),yield __privateMethod$1(this,_ShapeStream_instances,publish_fn).call(this,ta)}($n=__privateGet$1(this,_tickPromiseResolver))==null||$n.call(this)}}catch(Xn){if(__privateSet$1(this,_error,Xn),__privateGet$1(this,_onError)){const Yn=yield __privateGet$1(this,_onError).call(this,Xn);typeof Yn=="object"&&(__privateMethod$1(this,_ShapeStream_instances,reset_fn).call(this),"params"in Yn&&(this.options.params=Yn.params),"headers"in Yn&&(this.options.headers=Yn.headers),__privateSet$1(this,_started$1,!1),__privateMethod$1(this,_ShapeStream_instances,start_fn$1).call(this));return}throw Xn}finally{__privateSet$1(this,_connected,!1),(qn=__privateGet$1(this,_tickPromiseRejecter))==null||qn.call(this)}})};nextTick_fn=function(){return __async$1(this,null,function*(){return __privateGet$1(this,_tickPromise)?__privateGet$1(this,_tickPromise):(__privateSet$1(this,_tickPromise,new Promise((e,I)=>{__privateSet$1(this,_tickPromiseResolver,e),__privateSet$1(this,_tickPromiseRejecter,I)})),__privateGet$1(this,_tickPromise).finally(()=>{__privateSet$1(this,_tickPromise,void 0),__privateSet$1(this,_tickPromiseResolver,void 0),__privateSet$1(this,_tickPromiseRejecter,void 0)}),__privateGet$1(this,_tickPromise))})};publish_fn=function(e){return __async$1(this,null,function*(){yield Promise.all(Array.from(__privateGet$1(this,_subscribers$1).values()).map(I=>__async$1(this,[I],function*([Hn,$n]){try{yield Hn(e)}catch(qn){queueMicrotask(()=>{throw qn})}})))})};sendErrorToSubscribers_fn=function(e){__privateGet$1(this,_subscribers$1).forEach(([I,Hn])=>{Hn?.(e)})};reset_fn=function(e){__privateSet$1(this,_lastOffset,"-1"),__privateSet$1(this,_liveCacheBuster,""),__privateSet$1(this,_shapeHandle,e),__privateSet$1(this,_isUpToDate,!1),__privateSet$1(this,_connected,!1),__privateSet$1(this,_schema,void 0)};ShapeStream.Replica={FULL:"full",DEFAULT:"default"};function validateParams(e){if(!e)return;const I=Object.keys(e).filter(Hn=>RESERVED_PARAMS.has(Hn));if(I.length>0)throw new ReservedParamError(I)}function validateOptions(e){if(!e.url)throw new MissingShapeUrlError;if(e.signal&&!(e.signal instanceof AbortSignal))throw new InvalidSignalError;if(e.offset!==void 0&&e.offset!=="-1"&&!e.handle)throw new MissingShapeHandleError;validateParams(e.params)}function setQueryParam(e,I,Hn){if(!(Hn===void 0||Hn==null))if(typeof Hn=="string")e.searchParams.set(I,Hn);else if(typeof Hn=="object")for(const[$n,qn]of Object.entries(Hn))e.searchParams.set(`${I}[${$n}]`,qn);else e.searchParams.set(I,Hn.toString())}function convertWhereParamsToObj(e){return Array.isArray(e.params)?__spreadProps$1(__spreadValues$1({},e),{params:Object.fromEntries(e.params.map((I,Hn)=>[Hn+1,I]))}):e}var __defProp=Object.defineProperty,__defProps=Object.defineProperties,__getOwnPropDescs=Object.getOwnPropertyDescriptors,__getOwnPropSymbols=Object.getOwnPropertySymbols,__hasOwnProp=Object.prototype.hasOwnProperty,__propIsEnum=Object.prototype.propertyIsEnumerable,__typeError=e=>{throw TypeError(e)},__defNormalProp=(e,I,Hn)=>I in e?__defProp(e,I,{enumerable:!0,configurable:!0,writable:!0,value:Hn}):e[I]=Hn,__spreadValues=(e,I)=>{for(var Hn in I||(I={}))__hasOwnProp.call(I,Hn)&&__defNormalProp(e,Hn,I[Hn]);if(__getOwnPropSymbols)for(var Hn of __getOwnPropSymbols(I))__propIsEnum.call(I,Hn)&&__defNormalProp(e,Hn,I[Hn]);return e},__spreadProps=(e,I)=>__defProps(e,__getOwnPropDescs(I)),__accessCheck=(e,I,Hn)=>I.has(e)||__typeError("Cannot "+Hn),__privateGet=(e,I,Hn)=>(__accessCheck(e,I,"read from private field"),Hn?Hn.call(e):I.get(e)),__privateAdd=(e,I,Hn)=>I.has(e)?__typeError("Cannot add the same private member more than once"):I instanceof WeakSet?I.add(e):I.set(e,Hn),__privateSet=(e,I,Hn,$n)=>(__accessCheck(e,I,"write to private field"),I.set(e,Hn),Hn),__privateMethod=(e,I,Hn)=>(__accessCheck(e,I,"access private method"),Hn),__async=(e,I,Hn)=>new Promise(($n,qn)=>{var Xn=Jn=>{try{Kn(Hn.next(Jn))}catch(Zn){qn(Zn)}},Yn=Jn=>{try{Kn(Hn.throw(Jn))}catch(Zn){qn(Zn)}},Kn=Jn=>Jn.done?$n(Jn.value):Promise.resolve(Jn.value).then(Xn,Yn);Kn((Hn=Hn.apply(e,I)).next())});function bigIntMax(...e){return BigInt(e.reduce((I,Hn)=>Hn>I?Hn:I))}var _shapes,_started,_checkForUpdatesTimeout,_lastDataLsns,_lastUpToDateLsns,_subscribers,_MultiShapeStream_instances,start_fn,scheduleCheckForUpdates_fn,checkForUpdates_fn,onError_fn,shapeEntries_fn,MultiShapeStream=class{constructor(e){__privateAdd(this,_MultiShapeStream_instances),__privateAdd(this,_shapes),__privateAdd(this,_started,!1),__privateAdd(this,_checkForUpdatesTimeout),__privateAdd(this,_lastDataLsns),__privateAdd(this,_lastUpToDateLsns),__privateAdd(this,_subscribers,new Map);const{start:I=!0,checkForUpdatesAfterMs:Hn=100,shapes:$n}=e;this.checkForUpdatesAfterMs=Hn,__privateSet(this,_shapes,Object.fromEntries(Object.entries($n).map(([qn,Xn])=>[qn,Xn instanceof ShapeStream?Xn:new ShapeStream(__spreadProps(__spreadValues({},Xn),{start:!1}))]))),__privateSet(this,_lastDataLsns,Object.fromEntries(Object.entries($n).map(([qn])=>[qn,BigInt(-1)]))),__privateSet(this,_lastUpToDateLsns,Object.fromEntries(Object.entries($n).map(([qn])=>[qn,BigInt(-1)]))),I&&__privateMethod(this,_MultiShapeStream_instances,start_fn).call(this)}_publish(e){return __async(this,null,function*(){yield Promise.all(Array.from(__privateGet(this,_subscribers).values()).map(I=>__async(this,[I],function*([Hn,$n]){try{yield Hn(e)}catch(qn){queueMicrotask(()=>{throw qn})}})))})}get shapes(){return __privateGet(this,_shapes)}subscribe(e,I){const Hn=Math.random();return __privateGet(this,_subscribers).set(Hn,[e,I]),__privateGet(this,_started)||__privateMethod(this,_MultiShapeStream_instances,start_fn).call(this),()=>{__privateGet(this,_subscribers).delete(Hn)}}unsubscribeAll(){__privateGet(this,_subscribers).clear()}lastSyncedAt(){return Math.min(...__privateMethod(this,_MultiShapeStream_instances,shapeEntries_fn).call(this).map(([e,I])=>{var Hn;return(Hn=I.lastSyncedAt())!=null?Hn:1/0}))}lastSynced(){const e=this.lastSyncedAt();return e===void 0?1/0:Date.now()-e}isConnected(){return __privateMethod(this,_MultiShapeStream_instances,shapeEntries_fn).call(this).every(([e,I])=>I.isConnected())}isLoading(){return __privateMethod(this,_MultiShapeStream_instances,shapeEntries_fn).call(this).some(([e,I])=>I.isLoading())}get isUpToDate(){return __privateMethod(this,_MultiShapeStream_instances,shapeEntries_fn).call(this).every(([e,I])=>I.isUpToDate)}};_shapes=new WeakMap;_started=new WeakMap;_checkForUpdatesTimeout=new WeakMap;_lastDataLsns=new WeakMap;_lastUpToDateLsns=new WeakMap;_subscribers=new WeakMap;_MultiShapeStream_instances=new WeakSet;start_fn=function(){if(__privateGet(this,_started))throw new Error("Cannot start multi-shape stream twice");for(const[e,I]of __privateMethod(this,_MultiShapeStream_instances,shapeEntries_fn).call(this)){if(I.hasStarted())throw new Error(`Shape ${e} already started`);I.subscribe(Hn=>__async(this,null,function*(){const $n=Hn.filter(isControlMessage).map(({headers:Yn})=>typeof Yn.global_last_seen_lsn=="string"?BigInt(Yn.global_last_seen_lsn):BigInt(0));if($n.length>0){const Yn=bigIntMax(...$n),Kn=__privateGet(this,_lastUpToDateLsns)[e];Yn>Kn&&(__privateGet(this,_lastUpToDateLsns)[e]=Yn)}const qn=Hn.filter(isChangeMessage).map(({headers:Yn})=>typeof Yn.lsn=="string"?BigInt(Yn.lsn):BigInt(0));if(qn.length>0){const Yn=bigIntMax(...qn),Kn=__privateGet(this,_lastDataLsns)[e];Yn>Kn&&(__privateGet(this,_lastDataLsns)[e]=Yn),__privateMethod(this,_MultiShapeStream_instances,scheduleCheckForUpdates_fn).call(this)}const Xn=Hn.map(Yn=>__spreadProps(__spreadValues({},Yn),{shape:e}));yield this._publish(Xn)}),Hn=>__privateMethod(this,_MultiShapeStream_instances,onError_fn).call(this,Hn))}__privateSet(this,_started,!0)};scheduleCheckForUpdates_fn=function(){var e;(e=__privateGet(this,_checkForUpdatesTimeout))!=null||__privateSet(this,_checkForUpdatesTimeout,setTimeout(()=>{__privateMethod(this,_MultiShapeStream_instances,checkForUpdates_fn).call(this),__privateSet(this,_checkForUpdatesTimeout,void 0)},this.checkForUpdatesAfterMs))};checkForUpdates_fn=function(){return __async(this,null,function*(){const e=bigIntMax(...Object.values(__privateGet(this,_lastDataLsns))),I=__privateMethod(this,_MultiShapeStream_instances,shapeEntries_fn).call(this).filter(([Hn])=>__privateGet(this,_lastUpToDateLsns)[Hn]<e).map(([Hn,$n])=>$n.forceDisconnectAndRefresh());yield Promise.all(I)})};onError_fn=function(e){__privateGet(this,_subscribers).forEach(([I,Hn])=>{Hn?.(e)})};shapeEntries_fn=function(){return Object.entries(__privateGet(this,_shapes))};var V="subscriptions_metadata";async function B({pg:e,metadataSchema:I,subscriptionKey:Hn}){let $n=await e.query(`
      SELECT key, shape_metadata, last_lsn
      FROM ${j$1(I)}
      WHERE key = $1
    `,[Hn]);if($n.rows.length===0)return null;if($n.rows.length>1)throw new Error(`Multiple subscriptions found for key: ${Hn}`);let qn=$n.rows[0];if(typeof qn.last_lsn=="string")return{...qn,last_lsn:BigInt(qn.last_lsn)};throw new Error(`Invalid last_lsn type: ${typeof qn.last_lsn}`)}async function G({pg:e,metadataSchema:I,subscriptionKey:Hn,shapeMetadata:$n,lastLsn:qn,debug:Xn}){await e.query(`
      INSERT INTO ${j$1(I)}
        (key, shape_metadata, last_lsn)
      VALUES
        ($1, $2, $3)
      ON CONFLICT(key)
      DO UPDATE SET
        shape_metadata = EXCLUDED.shape_metadata,
        last_lsn = EXCLUDED.last_lsn;
    `,[Hn,$n,qn.toString()])}async function K({pg:e,metadataSchema:I,subscriptionKey:Hn}){await e.query(`DELETE FROM ${j$1(I)} WHERE key = $1`,[Hn])}async function q$1({pg:e,metadataSchema:I}){await e.exec(`
      SET ${I}.syncing = false;
      CREATE SCHEMA IF NOT EXISTS "${I}";
      CREATE TABLE IF NOT EXISTS ${j$1(I)} (
        key TEXT PRIMARY KEY,
        shape_metadata JSONB NOT NULL,
        last_lsn TEXT NOT NULL
      );
    `)}function j$1(e){return`"${e}"."${V}"`}async function F$1({pg:e,table:I,schema:Hn="public",message:$n,mapColumns:qn,primaryKey:Xn,debug:Yn}){let Kn=qn?P(qn,$n):$n.value;switch($n.headers.operation){case"insert":{let Jn=Object.keys(Kn);return await e.query(`
            INSERT INTO "${Hn}"."${I}"
            (${Jn.map(Zn=>'"'+Zn+'"').join(", ")})
            VALUES
            (${Jn.map((Zn,ea)=>"$"+(ea+1)).join(", ")})
          `,Jn.map(Zn=>Kn[Zn]))}case"update":{let Jn=Object.keys(Kn).filter(Zn=>!Xn.includes(Zn));return Jn.length===0?void 0:await e.query(`
            UPDATE "${Hn}"."${I}"
            SET ${Jn.map((Zn,ea)=>'"'+Zn+'" = $'+(ea+1)).join(", ")}
            WHERE ${Xn.map((Zn,ea)=>'"'+Zn+'" = $'+(Jn.length+ea+1)).join(" AND ")}
          `,[...Jn.map(Zn=>Kn[Zn]),...Xn.map(Zn=>Kn[Zn])])}case"delete":return await e.query(`
            DELETE FROM "${Hn}"."${I}"
            WHERE ${Xn.map((Jn,Zn)=>'"'+Jn+'" = $'+(Zn+1)).join(" AND ")}
          `,[...Xn.map(Jn=>Kn[Jn])])}}async function W({pg:e,table:I,schema:Hn="public",messages:$n,mapColumns:qn,debug:Xn}){Xn&&console.log("applying messages with json_to_recordset");let Yn=$n.map(Zn=>qn?P(qn,Zn):Zn.value),Kn=(await e.query(`
        SELECT column_name, udt_name, data_type
        FROM information_schema.columns
        WHERE table_name = $1 AND table_schema = $2
      `,[I,Hn])).rows.filter(Zn=>Object.prototype.hasOwnProperty.call(Yn[0],Zn.column_name)),Jn=1e4;for(let Zn=0;Zn<Yn.length;Zn+=Jn){let ea=Yn.slice(Zn,Zn+Jn);await e.query(`
        INSERT INTO "${Hn}"."${I}"
        SELECT x.* from json_to_recordset($1) as x(${Kn.map(aa=>`${aa.column_name} ${aa.udt_name.replace(/^_/,"")}`+(aa.data_type==="ARRAY"?"[]":"")).join(", ")})
      `,[ea])}Xn&&console.log(`Inserted ${$n.length} rows using json_to_recordset`)}async function H({pg:e,table:I,schema:Hn="public",messages:$n,mapColumns:qn,debug:Xn}){Xn&&console.log("applying messages with COPY");let Yn=$n.map(ea=>qn?P(qn,ea):ea.value),Kn=Object.keys(Yn[0]),Jn=Yn.map(ea=>Kn.map(aa=>{let oa=ea[aa];return typeof oa=="string"&&(oa.includes(",")||oa.includes('"')||oa.includes(`
`))?`"${oa.replace(/"/g,'""')}"`:oa===null?"\\N":oa}).join(",")).join(`
`),Zn=new Blob([Jn],{type:"text/csv"});await e.query(`
      COPY "${Hn}"."${I}" (${Kn.map(ea=>`"${ea}"`).join(", ")})
      FROM '/dev/blob'
      WITH (FORMAT csv, NULL '\\N')
    `,[],{blob:Zn}),Xn&&console.log(`Inserted ${$n.length} rows using COPY`)}function P(e,I){if(typeof e=="function")return e(I);let Hn={};for(let[$n,qn]of Object.entries(e))Hn[$n]=I.value[qn];return Hn}async function ee(e,I){let Hn=I?.debug,$n=I?.metadataSchema??"electric",qn=[],Xn=new Map,Yn=!1,Kn=async()=>{Yn||(Yn=!0,await q$1({pg:e,metadataSchema:$n}))},Jn=async({key:Zn,shapes:ea,useCopy:aa=!1,initialInsertMethod:oa="insert",onInitialSync:la})=>{let ra=!1;await Kn(),Object.values(ea).filter(ma=>!ma.onMustRefetch).forEach(ma=>{if(Xn.has(ma.table))throw new Error("Already syncing shape for table "+ma.table);Xn.set(ma.table)});let ia=null;Zn!==null&&(ia=await B({pg:e,metadataSchema:$n,subscriptionKey:Zn}));let da=ia===null;aa&&oa==="insert"&&(oa="csv",console.warn("The useCopy option is deprecated and will be removed in a future version. Use initialInsertMethod instead."));let Ea=!da||oa==="insert",na=!1,ta=new Map(Object.keys(ea).map(ma=>[ma,new Map])),sa=new Map(Object.keys(ea).map(ma=>[ma,BigInt(-1)])),ca=new Set,_a=ia?.last_lsn??BigInt(-1),pa=new AbortController;Object.values(ea).filter(ma=>!!ma.shape.signal).forEach(ma=>{ma.shape.signal.addEventListener("abort",()=>pa.abort(),{once:!0})});let Sa=new MultiShapeStream({shapes:Object.fromEntries(Object.entries(ea).map(([ma,Ia])=>{let ua=ia?.shape_metadata[ma];return[ma,{...Ia.shape,...ua?{offset:ua.offset,handle:ua.handle}:{},signal:pa.signal}]}))}),Na=async ma=>{let Ia=new Map(Object.keys(ea).map(ua=>[ua,[]]));for(let[ua,Aa]of ta.entries()){let Ta=Ia.get(ua);for(let Ra of Aa.keys())if(Ra<=ma){for(let ya of Aa.get(Ra))Ta.push(ya);Aa.delete(Ra)}}await e.transaction(async ua=>{await ua.exec(`SET LOCAL ${$n}.syncing = true;`);for(let[Aa,Ta]of Ia.entries()){let Ra=ea[Aa],ya=Ta;if(ca.has(Aa)&&(Ra.onMustRefetch?await Ra.onMustRefetch(ua):await ua.exec(`DELETE FROM ${Ra.table};`),ca.delete(Aa)),!Ea){let ga=[],Ca=[],La=!1;for(let Oa of ya)!La&&Oa.headers.operation==="insert"?ga.push(Oa):(La=!0,Ca.push(Oa));ga.length>0&&oa==="csv"&&Ca.unshift(ga.pop()),ya=Ca,ga.length>0&&(await(oa==="json"?W:H)({pg:ua,table:Ra.table,schema:Ra.schema,messages:ga,mapColumns:Ra.mapColumns,primaryKey:Ra.primaryKey,debug:Hn}),Ea=!0)}for(let ga of ya)await F$1({pg:ua,table:Ra.table,schema:Ra.schema,message:ga,mapColumns:Ra.mapColumns,primaryKey:Ra.primaryKey,debug:Hn})}Zn&&await G({pg:ua,metadataSchema:$n,subscriptionKey:Zn,shapeMetadata:Object.fromEntries(Object.keys(ea).map(Aa=>[Aa,{handle:Sa.shapes[Aa].shapeHandle,offset:Sa.shapes[Aa].lastOffset}])),lastLsn:ma,debug:Hn}),ra&&await ua.rollback()}),la&&!na&&Sa.isUpToDate&&(la(),na=!0)};return Sa.subscribe(async ma=>{if(ra)return;ma.forEach(Ta=>{let Ra=sa.get(Ta.shape)??BigInt(-1);if(isChangeMessage(Ta)){let ya=ta.get(Ta.shape),ga=typeof Ta.headers.lsn=="string"?BigInt(Ta.headers.lsn):BigInt(0);if(ga<=Ra)return;let Ca=Ta.headers.last??!1;ya.has(ga)||ya.set(ga,[]),ya.get(ga).push(Ta),Ca&&sa.set(Ta.shape,ga)}else if(isControlMessage(Ta))switch(Ta.headers.control){case"up-to-date":{if(typeof Ta.headers.global_last_seen_lsn!="string")throw new Error("global_last_seen_lsn is not a string");let ya=BigInt(Ta.headers.global_last_seen_lsn);if(ya<=Ra)return;sa.set(Ta.shape,ya);break}case"must-refetch":{ta.get(Ta.shape).clear(),sa.set(Ta.shape,BigInt(-1)),ca.add(Ta.shape);break}}});let Ia=Array.from(sa.values()).reduce((Ta,Ra)=>Ra<Ta?Ra:Ta),ua=Ia>_a,Aa=Ia>=_a&&ca.size>0;(ua||Aa)&&(Na(Ia),await new Promise(Ta=>setTimeout(Ta)))}),qn.push({stream:Sa,aborter:pa}),{unsubscribe:()=>{ra=!0,Sa.unsubscribeAll(),pa.abort();for(let ma of Object.values(ea))Xn.delete(ma.table)},get isUpToDate(){return Sa.isUpToDate},streams:Object.fromEntries(Object.keys(ea).map(ma=>[ma,Sa.shapes[ma]]))}};return{namespaceObj:{initMetadataTables:Kn,syncShapesToTables:Jn,syncShapeToTable:async Zn=>{let ea=await Jn({shapes:{shape:{shape:Zn.shape,table:Zn.table,schema:Zn.schema,mapColumns:Zn.mapColumns,primaryKey:Zn.primaryKey,onMustRefetch:Zn.onMustRefetch}},key:Zn.shapeKey,useCopy:Zn.useCopy,initialInsertMethod:Zn.initialInsertMethod,onInitialSync:Zn.onInitialSync});return{unsubscribe:ea.unsubscribe,get isUpToDate(){return ea.isUpToDate},stream:ea.streams.shape}},deleteSubscription:async Zn=>{await K({pg:e,metadataSchema:$n,subscriptionKey:Zn})}},close:async()=>{for(let{stream:Zn,aborter:ea}of qn)Zn.unsubscribeAll(),ea.abort()}}}function ue(e){return{name:"ElectricSQL Sync",setup:async I=>{let{namespaceObj:Hn,close:$n}=await ee(I,e);return{namespaceObj:Hn,close:$n}}}}u$1();var t=async(e,I)=>({bundlePath:new URL("/_build/assets/pg_trgm.tar-CUnu0XkG.gz",import.meta.url)}),p={name:"pg_trgm",setup:t};u$1();var M=5,U=async(e,I)=>{let Hn=new Set,$n={async query(qn,Xn,Yn){let Kn,Jn,Zn;if(typeof qn!="string"&&(Kn=qn.signal,Xn=qn.params,Yn=qn.callback,Jn=qn.offset,Zn=qn.limit,qn=qn.query),Jn===void 0!=(Zn===void 0))throw new Error("offset and limit must be provided together");let ea=Jn!==void 0&&Zn!==void 0,aa;if(ea&&(typeof Jn!="number"||isNaN(Jn)||typeof Zn!="number"||isNaN(Zn)))throw new Error("offset and limit must be numbers");let oa=Yn?[Yn]:[],la=Cr().replace(/-/g,""),ra=!1,ia,da,Ea=async()=>{await e.transaction(async _a=>{let pa=Xn&&Xn.length>0?await Pr(e,qn,Xn,_a):qn;await _a.exec(`CREATE OR REPLACE TEMP VIEW live_query_${la}_view AS ${pa}`),da=await q(_a,`live_query_${la}_view`),await F(_a,da,Hn),ea?(await _a.exec(`
              PREPARE live_query_${la}_get(int, int) AS
              SELECT * FROM live_query_${la}_view
              LIMIT $1 OFFSET $2;
            `),await _a.exec(`
              PREPARE live_query_${la}_get_total_count AS
              SELECT COUNT(*) FROM live_query_${la}_view;
            `),aa=(await _a.query(`EXECUTE live_query_${la}_get_total_count;`)).rows[0].count,ia={...await _a.query(`EXECUTE live_query_${la}_get(${Zn}, ${Jn});`),offset:Jn,limit:Zn,totalCount:aa}):(await _a.exec(`
              PREPARE live_query_${la}_get AS
              SELECT * FROM live_query_${la}_view;
            `),ia=await _a.query(`EXECUTE live_query_${la}_get;`))})};await Ea();let na=Ur(async({offset:_a,limit:pa}={})=>{if(!ea&&(_a!==void 0||pa!==void 0))throw new Error("offset and limit cannot be provided for non-windowed queries");if(_a&&(typeof _a!="number"||isNaN(_a))||pa&&(typeof pa!="number"||isNaN(pa)))throw new Error("offset and limit must be numbers");Jn=_a??Jn,Zn=pa??Zn;let Sa=async(Na=0)=>{if(oa.length!==0){try{ea?ia={...await e.query(`EXECUTE live_query_${la}_get(${Zn}, ${Jn});`),offset:Jn,limit:Zn,totalCount:aa}:ia=await e.query(`EXECUTE live_query_${la}_get;`)}catch(ma){let Ia=ma.message;if(Ia.startsWith(`prepared statement "live_query_${la}`)&&Ia.endsWith("does not exist")){if(Na>M)throw ma;await Ea(),Sa(Na+1)}else throw ma}if(S(oa,ia),ea){let ma=(await e.query(`EXECUTE live_query_${la}_get_total_count;`)).rows[0].count;ma!==aa&&(aa=ma,na())}}};await Sa()}),ta=await Promise.all(da.map(_a=>e.listen(`table_change__${_a.schema_name}__${_a.table_name}`,async()=>{na()}))),sa=_a=>{if(ra)throw new Error("Live query is no longer active and cannot be subscribed to");oa.push(_a)},ca=async _a=>{_a?oa=oa.filter(pa=>pa!==pa):oa=[],oa.length===0&&(ra=!0,await Promise.all(ta.map(pa=>pa())),await e.exec(`
            DROP VIEW IF EXISTS live_query_${la}_view;
            DEALLOCATE live_query_${la}_get;
          `))};return Kn?.aborted?await ca():Kn?.addEventListener("abort",()=>{ca()},{once:!0}),S(oa,ia),{initialResults:ia,subscribe:sa,unsubscribe:ca,refresh:na}},async changes(qn,Xn,Yn,Kn){let Jn;if(typeof qn!="string"&&(Jn=qn.signal,Xn=qn.params,Yn=qn.key,Kn=qn.callback,qn=qn.query),!Yn)throw new Error("key is required for changes queries");let Zn=Kn?[Kn]:[],ea=Cr().replace(/-/g,""),aa=!1,oa,la=1,ra,ia=async()=>{await e.transaction(async sa=>{let ca=await Pr(e,qn,Xn,sa);await sa.query(`CREATE OR REPLACE TEMP VIEW live_query_${ea}_view AS ${ca}`),oa=await q(sa,`live_query_${ea}_view`),await F(sa,oa,Hn);let _a=[...(await sa.query(`
                SELECT column_name, data_type, udt_name
                FROM information_schema.columns 
                WHERE table_name = 'live_query_${ea}_view'
              `)).rows,{column_name:"__after__",data_type:"integer"}];await sa.exec(`
            CREATE TEMP TABLE live_query_${ea}_state1 (LIKE live_query_${ea}_view INCLUDING ALL);
            CREATE TEMP TABLE live_query_${ea}_state2 (LIKE live_query_${ea}_view INCLUDING ALL);
          `);for(let pa of[1,2]){let Sa=pa===1?2:1;await sa.exec(`
              PREPARE live_query_${ea}_diff${pa} AS
              WITH
                prev AS (SELECT LAG("${Yn}") OVER () as __after__, * FROM live_query_${ea}_state${Sa}),
                curr AS (SELECT LAG("${Yn}") OVER () as __after__, * FROM live_query_${ea}_state${pa}),
                data_diff AS (
                  -- INSERT operations: Include all columns
                  SELECT 
                    'INSERT' AS __op__,
                    ${_a.map(({column_name:Na})=>`curr."${Na}" AS "${Na}"`).join(`,
`)},
                    ARRAY[]::text[] AS __changed_columns__
                  FROM curr
                  LEFT JOIN prev ON curr.${Yn} = prev.${Yn}
                  WHERE prev.${Yn} IS NULL
                UNION ALL
                  -- DELETE operations: Include only the primary key
                  SELECT 
                    'DELETE' AS __op__,
                    ${_a.map(({column_name:Na,data_type:ma,udt_name:Ia})=>Na===Yn?`prev."${Na}" AS "${Na}"`:`NULL${ma==="USER-DEFINED"?`::${Ia}`:""} AS "${Na}"`).join(`,
`)},
                      ARRAY[]::text[] AS __changed_columns__
                  FROM prev
                  LEFT JOIN curr ON prev.${Yn} = curr.${Yn}
                  WHERE curr.${Yn} IS NULL
                UNION ALL
                  -- UPDATE operations: Include only changed columns
                  SELECT 
                    'UPDATE' AS __op__,
                    ${_a.map(({column_name:Na,data_type:ma,udt_name:Ia})=>Na===Yn?`curr."${Na}" AS "${Na}"`:`CASE 
                              WHEN curr."${Na}" IS DISTINCT FROM prev."${Na}" 
                              THEN curr."${Na}"
                              ELSE NULL${ma==="USER-DEFINED"?`::${Ia}`:""}
                              END AS "${Na}"`).join(`,
`)},
                      ARRAY(SELECT unnest FROM unnest(ARRAY[${_a.filter(({column_name:Na})=>Na!==Yn).map(({column_name:Na})=>`CASE
                              WHEN curr."${Na}" IS DISTINCT FROM prev."${Na}" 
                              THEN '${Na}' 
                              ELSE NULL 
                              END`).join(", ")}]) WHERE unnest IS NOT NULL) AS __changed_columns__
                  FROM curr
                  INNER JOIN prev ON curr.${Yn} = prev.${Yn}
                  WHERE NOT (curr IS NOT DISTINCT FROM prev)
                )
              SELECT * FROM data_diff;
            `)}})};await ia();let da=Ur(async()=>{if(Zn.length===0&&ra)return;let sa=!1;for(let ca=0;ca<5;ca++)try{await e.transaction(async _a=>{await _a.exec(`
                INSERT INTO live_query_${ea}_state${la} 
                  SELECT * FROM live_query_${ea}_view;
              `),ra=await _a.query(`EXECUTE live_query_${ea}_diff${la};`),la=la===1?2:1,await _a.exec(`
                TRUNCATE live_query_${ea}_state${la};
              `)});break}catch(_a){if(_a.message===`relation "live_query_${ea}_state${la}" does not exist`){sa=!0,await ia();continue}else throw _a}D(Zn,[...sa?[{__op__:"RESET"}]:[],...ra.rows])}),Ea=await Promise.all(oa.map(sa=>e.listen(`table_change__${sa.schema_name}__${sa.table_name}`,async()=>da()))),na=sa=>{if(aa)throw new Error("Live query is no longer active and cannot be subscribed to");Zn.push(sa)},ta=async sa=>{sa?Zn=Zn.filter(ca=>ca!==ca):Zn=[],Zn.length===0&&(aa=!0,await Promise.all(Ea.map(ca=>ca())),await e.exec(`
            DROP VIEW IF EXISTS live_query_${ea}_view;
            DROP TABLE IF EXISTS live_query_${ea}_state1;
            DROP TABLE IF EXISTS live_query_${ea}_state2;
            DEALLOCATE live_query_${ea}_diff1;
            DEALLOCATE live_query_${ea}_diff2;
          `))};return Jn?.aborted?await ta():Jn?.addEventListener("abort",()=>{ta()},{once:!0}),await da(),{fields:ra.fields.filter(sa=>!["__after__","__op__","__changed_columns__"].includes(sa.name)),initialChanges:ra.rows,subscribe:na,unsubscribe:ta,refresh:da}},async incrementalQuery(qn,Xn,Yn,Kn){let Jn;if(typeof qn!="string"&&(Jn=qn.signal,Xn=qn.params,Yn=qn.key,Kn=qn.callback,qn=qn.query),!Yn)throw new Error("key is required for incremental queries");let Zn=Kn?[Kn]:[],ea=new Map,aa=new Map,oa=[],la=!0,{fields:ra,unsubscribe:ia,refresh:da}=await $n.changes(qn,Xn,Yn,ta=>{for(let _a of ta){let{__op__:pa,__changed_columns__:Sa,...Na}=_a;switch(pa){case"RESET":ea.clear(),aa.clear();break;case"INSERT":ea.set(Na[Yn],Na),aa.set(Na.__after__,Na[Yn]);break;case"DELETE":{let ma=ea.get(Na[Yn]);ea.delete(Na[Yn]),ma.__after__!==null&&aa.delete(ma.__after__);break}case"UPDATE":{let ma={...ea.get(Na[Yn])??{}};for(let Ia of Sa)ma[Ia]=Na[Ia],Ia==="__after__"&&aa.set(Na.__after__,Na[Yn]);ea.set(Na[Yn],ma);break}}}let sa=[],ca=null;for(let _a=0;_a<ea.size;_a++){let pa=aa.get(ca),Sa=ea.get(pa);if(!Sa)break;let Na={...Sa};delete Na.__after__,sa.push(Na),ca=pa}oa=sa,la||S(Zn,{rows:sa,fields:ra})});la=!1,S(Zn,{rows:oa,fields:ra});let Ea=ta=>{Zn.push(ta)},na=async ta=>{ta?Zn=Zn.filter(sa=>sa!==sa):Zn=[],Zn.length===0&&await ia()};return Jn?.aborted?await na():Jn?.addEventListener("abort",()=>{na()},{once:!0}),{initialResults:{rows:oa,fields:ra},subscribe:Ea,unsubscribe:na,refresh:da}}};return{namespaceObj:$n}},j={name:"Live Queries",setup:U};async function q(e,I){return(await e.query(`
      WITH RECURSIVE view_dependencies AS (
        -- Base case: Get the initial view's dependencies
        SELECT DISTINCT
          cl.relname AS dependent_name,
          n.nspname AS schema_name,
          cl.relkind = 'v' AS is_view
        FROM pg_rewrite r
        JOIN pg_depend d ON r.oid = d.objid
        JOIN pg_class cl ON d.refobjid = cl.oid
        JOIN pg_namespace n ON cl.relnamespace = n.oid
        WHERE
          r.ev_class = (
              SELECT oid FROM pg_class WHERE relname = $1 AND relkind = 'v'
          )
          AND d.deptype = 'n'

        UNION ALL

        -- Recursive case: Traverse dependencies for views
        SELECT DISTINCT
          cl.relname AS dependent_name,
          n.nspname AS schema_name,
          cl.relkind = 'v' AS is_view
        FROM view_dependencies vd
        JOIN pg_rewrite r ON vd.dependent_name = (
          SELECT relname FROM pg_class WHERE oid = r.ev_class AND relkind = 'v'
        )
        JOIN pg_depend d ON r.oid = d.objid
        JOIN pg_class cl ON d.refobjid = cl.oid
        JOIN pg_namespace n ON cl.relnamespace = n.oid
        WHERE d.deptype = 'n'
      )
      SELECT DISTINCT
        dependent_name AS table_name,
        schema_name
      FROM view_dependencies
      WHERE NOT is_view; -- Exclude intermediate views
    `,[I])).rows.map(Hn=>({table_name:Hn.table_name,schema_name:Hn.schema_name}))}async function F(e,I,Hn){let $n=I.filter(qn=>!Hn.has(`${qn.schema_name}_${qn.table_name}`)).map(qn=>`
      CREATE OR REPLACE FUNCTION "_notify_${qn.schema_name}_${qn.table_name}"() RETURNS TRIGGER AS $$
      BEGIN
        PERFORM pg_notify('table_change__${qn.schema_name}__${qn.table_name}', '');
        RETURN NULL;
      END;
      $$ LANGUAGE plpgsql;
      CREATE OR REPLACE TRIGGER "_notify_trigger_${qn.schema_name}_${qn.table_name}"
      AFTER INSERT OR UPDATE OR DELETE ON "${qn.schema_name}"."${qn.table_name}"
      FOR EACH STATEMENT EXECUTE FUNCTION "_notify_${qn.schema_name}_${qn.table_name}"();
      `).join(`
`);$n.trim()!==""&&await e.exec($n),I.map(qn=>Hn.add(`${qn.schema_name}_${qn.table_name}`))}var S=(e,I)=>{for(let Hn of e)Hn(I)},D=(e,I)=>{for(let Hn of e)Hn(I)},ddl=`-- CreateEnum
CREATE TYPE "AccountType" AS ENUM ('User', 'Admin');
-- CreateEnum
CREATE TYPE "AddressType" AS ENUM ('Normal', 'Limited');
-- CreateEnum
CREATE TYPE "AvatarType" AS ENUM ('Decoration', 'Top', 'Bottom');
-- CreateEnum
CREATE TYPE "BossPartBreakRewardType" AS ENUM ('None', 'CanDrop', 'DropUp');
-- CreateEnum
CREATE TYPE "BossPartType" AS ENUM ('A', 'B', 'C');
-- CreateEnum
CREATE TYPE "CharacterPersonalityType" AS ENUM ('None', 'Luk', 'Cri', 'Tec', 'Men');
-- CreateEnum
CREATE TYPE "ComboStepType" AS ENUM ('None', 'Start', 'Rengeki', 'ThirdEye', 'Filling', 'Quick', 'HardHit', 'Tenacity', 'Invincible', 'BloodSucking', 'Tough', 'AMomentaryWalk', 'Reflection', 'Illusion', 'Max');
-- CreateEnum
CREATE TYPE "ConsumableType" AS ENUM ('MaxHp', 'MaxMp', 'pAtk', 'mAtk', 'Aspd', 'Cspd', 'Hit', 'Flee', 'EleStro', 'EleRes', 'pRes', 'mRes');
-- CreateEnum
CREATE TYPE "CrystalType" AS ENUM ('NormalCrystal', 'WeaponCrystal', 'ArmorCrystal', 'OptEquipCrystal', 'SpecialCrystal');
-- CreateEnum
CREATE TYPE "ElementType" AS ENUM ('Normal', 'Light', 'Dark', 'Water', 'Fire', 'Earth', 'Wind');
-- CreateEnum
CREATE TYPE "ItemType" AS ENUM ('Weapon', 'Armor', 'Option', 'Special', 'Crystal', 'Consumable', 'Material');
-- CreateEnum
CREATE TYPE "MainWeaponType" AS ENUM ('OneHandSword', 'TwoHandSword', 'Bow', 'Bowgun', 'Rod', 'Magictool', 'Knuckle', 'Halberd', 'Katana');
-- CreateEnum
CREATE TYPE "MaterialType" AS ENUM ('Metal', 'Cloth', 'Beast', 'Wood', 'Drug', 'Magic');
-- CreateEnum
CREATE TYPE "MercenaryType" AS ENUM ('Tank', 'Dps');
-- CreateEnum
CREATE TYPE "MobDifficultyFlag" AS ENUM ('Easy', 'Normal', 'Hard', 'Lunatic', 'Ultimate');
-- CreateEnum
CREATE TYPE "MobType" AS ENUM ('Mob', 'MiniBoss', 'Boss');
-- CreateEnum
CREATE TYPE "PartnerSkillType" AS ENUM ('Passive', 'Active');
-- CreateEnum
CREATE TYPE "PetPersonaType" AS ENUM ('Fervent', 'Intelligent', 'Mild', 'Swift', 'Justice', 'Devoted', 'Impulsive', 'Calm', 'Sly', 'Timid', 'Brave', 'Active', 'Sturdy', 'Steady', 'Max');
-- CreateEnum
CREATE TYPE "PetType" AS ENUM ('AllTrades', 'PhysicalAttack', 'MagicAttack', 'PhysicalDefense', 'MagicDefensem', 'Avoidance', 'Hit', 'SkillsEnhancement', 'Genius');
-- CreateEnum
CREATE TYPE "PlayerArmorAbilityType" AS ENUM ('Normal', 'Light', 'Heavy');
-- CreateEnum
CREATE TYPE "RecipeIngredientType" AS ENUM ('Gold', 'Metal', 'Cloth', 'Beast', 'Wood', 'Drug', 'Magic', 'Item');
-- CreateEnum
CREATE TYPE "SkillChargingType" AS ENUM ('Chanting', 'Reservoir');
-- CreateEnum
CREATE TYPE "SkillDistanceType" AS ENUM ('None', 'Long', 'Short', 'Both');
-- CreateEnum
CREATE TYPE "SkillTargetType" AS ENUM ('None', 'Self', 'Player', 'Enemy');
-- CreateEnum
CREATE TYPE "SkillTreeType" AS ENUM ('BladeSkill', 'ShootSkill', 'MagicSkill', 'MarshallSkill', 'DualSwordSkill', 'HalberdSkill', 'MononofuSkill', 'CrusherSkill', 'FeatheringSkill', 'GuardSkill', 'ShieldSkill', 'KnifeSkill', 'KnightSkill', 'HunterSkill', 'PriestSkill', 'AssassinSkill', 'WizardSkill', 'SupportSkill', 'BattleSkill', 'SurvivalSkill', 'SmithSkill', 'AlchemySkill', 'TamerSkill', 'DarkPowerSkill', 'MagicBladeSkill', 'DancerSkill', 'MinstrelSkill', 'BareHandSkill', 'NinjaSkill', 'PartisanSkill', 'LuckSkill', 'MerchantSkill', 'PetSkill');
-- CreateEnum
CREATE TYPE "TaskRewardType" AS ENUM ('Exp', 'Money', 'Item');
-- CreateEnum
CREATE TYPE "TaskType" AS ENUM ('Collect', 'Defeat', 'Both', 'Other');
-- CreateEnum
CREATE TYPE "WeaponType" AS ENUM ('OneHandSword', 'TwoHandSword', 'Bow', 'Bowgun', 'Rod', 'Magictool', 'Knuckle', 'Halberd', 'Katana', 'Arrow', 'ShortSword', 'NinjutsuScroll', 'Shield');
-- CreateTable
-- _BackRelation
CREATE TABLE IF NOT EXISTS "_BackRelation_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_BackRelation_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_BackRelation_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_BackRelation_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_BackRelation" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_BackRelation_synced" AS synced
  FULL OUTER JOIN "_BackRelation_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _BackRelation_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_BackRelation_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_BackRelation',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _BackRelation_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_BackRelation_synced"%ROWTYPE;
    local "_BackRelation_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_BackRelation_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_BackRelation_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_BackRelation_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_BackRelation_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_BackRelation',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _BackRelation_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_BackRelation_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_BackRelation_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_BackRelation_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_BackRelation',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _BackRelation_insert
INSTEAD OF INSERT ON "_BackRelation"
FOR EACH ROW EXECUTE FUNCTION _BackRelation_insert_trigger();

CREATE OR REPLACE TRIGGER _BackRelation_update
INSTEAD OF UPDATE ON "_BackRelation"
FOR EACH ROW EXECUTE FUNCTION _BackRelation_update_trigger();

CREATE OR REPLACE TRIGGER _BackRelation_delete
INSTEAD OF DELETE ON "_BackRelation"
FOR EACH ROW EXECUTE FUNCTION _BackRelation_delete_trigger();


CREATE OR REPLACE FUNCTION _BackRelation_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_BackRelation_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _BackRelation_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_BackRelation_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_BackRelation_synced"
FOR EACH ROW EXECUTE FUNCTION _BackRelation_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_BackRelation_synced"
FOR EACH ROW EXECUTE FUNCTION _BackRelation_delete_local_on_synced_delete_trigger();

-- CreateTable
-- _FrontRelation
CREATE TABLE IF NOT EXISTS "_FrontRelation_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_FrontRelation_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_FrontRelation_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_FrontRelation_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_FrontRelation" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_FrontRelation_synced" AS synced
  FULL OUTER JOIN "_FrontRelation_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _FrontRelation_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_FrontRelation_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_FrontRelation',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _FrontRelation_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_FrontRelation_synced"%ROWTYPE;
    local "_FrontRelation_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_FrontRelation_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_FrontRelation_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_FrontRelation_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_FrontRelation_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_FrontRelation',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _FrontRelation_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_FrontRelation_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_FrontRelation_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_FrontRelation_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_FrontRelation',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _FrontRelation_insert
INSTEAD OF INSERT ON "_FrontRelation"
FOR EACH ROW EXECUTE FUNCTION _FrontRelation_insert_trigger();

CREATE OR REPLACE TRIGGER _FrontRelation_update
INSTEAD OF UPDATE ON "_FrontRelation"
FOR EACH ROW EXECUTE FUNCTION _FrontRelation_update_trigger();

CREATE OR REPLACE TRIGGER _FrontRelation_delete
INSTEAD OF DELETE ON "_FrontRelation"
FOR EACH ROW EXECUTE FUNCTION _FrontRelation_delete_trigger();


CREATE OR REPLACE FUNCTION _FrontRelation_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_FrontRelation_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _FrontRelation_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_FrontRelation_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_FrontRelation_synced"
FOR EACH ROW EXECUTE FUNCTION _FrontRelation_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_FrontRelation_synced"
FOR EACH ROW EXECUTE FUNCTION _FrontRelation_delete_local_on_synced_delete_trigger();

-- CreateTable
-- _armorTocrystal
CREATE TABLE IF NOT EXISTS "_armorTocrystal_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_armorTocrystal_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_armorTocrystal_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_armorTocrystal_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_armorTocrystal" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_armorTocrystal_synced" AS synced
  FULL OUTER JOIN "_armorTocrystal_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _armorTocrystal_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_armorTocrystal_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_armorTocrystal',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _armorTocrystal_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_armorTocrystal_synced"%ROWTYPE;
    local "_armorTocrystal_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_armorTocrystal_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_armorTocrystal_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_armorTocrystal_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_armorTocrystal_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_armorTocrystal',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _armorTocrystal_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_armorTocrystal_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_armorTocrystal_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_armorTocrystal_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_armorTocrystal',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _armorTocrystal_insert
INSTEAD OF INSERT ON "_armorTocrystal"
FOR EACH ROW EXECUTE FUNCTION _armorTocrystal_insert_trigger();

CREATE OR REPLACE TRIGGER _armorTocrystal_update
INSTEAD OF UPDATE ON "_armorTocrystal"
FOR EACH ROW EXECUTE FUNCTION _armorTocrystal_update_trigger();

CREATE OR REPLACE TRIGGER _armorTocrystal_delete
INSTEAD OF DELETE ON "_armorTocrystal"
FOR EACH ROW EXECUTE FUNCTION _armorTocrystal_delete_trigger();


CREATE OR REPLACE FUNCTION _armorTocrystal_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_armorTocrystal_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _armorTocrystal_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_armorTocrystal_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_armorTocrystal_synced"
FOR EACH ROW EXECUTE FUNCTION _armorTocrystal_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_armorTocrystal_synced"
FOR EACH ROW EXECUTE FUNCTION _armorTocrystal_delete_local_on_synced_delete_trigger();

-- CreateTable
-- _avatarTocharacter
CREATE TABLE IF NOT EXISTS "_avatarTocharacter_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_avatarTocharacter_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_avatarTocharacter_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_avatarTocharacter_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_avatarTocharacter" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_avatarTocharacter_synced" AS synced
  FULL OUTER JOIN "_avatarTocharacter_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _avatarTocharacter_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_avatarTocharacter_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_avatarTocharacter',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _avatarTocharacter_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_avatarTocharacter_synced"%ROWTYPE;
    local "_avatarTocharacter_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_avatarTocharacter_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_avatarTocharacter_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_avatarTocharacter_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_avatarTocharacter_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_avatarTocharacter',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _avatarTocharacter_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_avatarTocharacter_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_avatarTocharacter_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_avatarTocharacter_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_avatarTocharacter',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _avatarTocharacter_insert
INSTEAD OF INSERT ON "_avatarTocharacter"
FOR EACH ROW EXECUTE FUNCTION _avatarTocharacter_insert_trigger();

CREATE OR REPLACE TRIGGER _avatarTocharacter_update
INSTEAD OF UPDATE ON "_avatarTocharacter"
FOR EACH ROW EXECUTE FUNCTION _avatarTocharacter_update_trigger();

CREATE OR REPLACE TRIGGER _avatarTocharacter_delete
INSTEAD OF DELETE ON "_avatarTocharacter"
FOR EACH ROW EXECUTE FUNCTION _avatarTocharacter_delete_trigger();


CREATE OR REPLACE FUNCTION _avatarTocharacter_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_avatarTocharacter_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _avatarTocharacter_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_avatarTocharacter_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_avatarTocharacter_synced"
FOR EACH ROW EXECUTE FUNCTION _avatarTocharacter_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_avatarTocharacter_synced"
FOR EACH ROW EXECUTE FUNCTION _avatarTocharacter_delete_local_on_synced_delete_trigger();

-- CreateTable
-- _campA
CREATE TABLE IF NOT EXISTS "_campA_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_campA_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_campA_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_campA_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_campA" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_campA_synced" AS synced
  FULL OUTER JOIN "_campA_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _campA_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_campA_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_campA',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _campA_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_campA_synced"%ROWTYPE;
    local "_campA_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_campA_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_campA_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_campA_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_campA_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_campA',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _campA_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_campA_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_campA_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_campA_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_campA',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _campA_insert
INSTEAD OF INSERT ON "_campA"
FOR EACH ROW EXECUTE FUNCTION _campA_insert_trigger();

CREATE OR REPLACE TRIGGER _campA_update
INSTEAD OF UPDATE ON "_campA"
FOR EACH ROW EXECUTE FUNCTION _campA_update_trigger();

CREATE OR REPLACE TRIGGER _campA_delete
INSTEAD OF DELETE ON "_campA"
FOR EACH ROW EXECUTE FUNCTION _campA_delete_trigger();


CREATE OR REPLACE FUNCTION _campA_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_campA_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _campA_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_campA_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_campA_synced"
FOR EACH ROW EXECUTE FUNCTION _campA_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_campA_synced"
FOR EACH ROW EXECUTE FUNCTION _campA_delete_local_on_synced_delete_trigger();

-- CreateTable
-- _campB
CREATE TABLE IF NOT EXISTS "_campB_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_campB_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_campB_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_campB_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_campB" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_campB_synced" AS synced
  FULL OUTER JOIN "_campB_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _campB_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_campB_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_campB',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _campB_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_campB_synced"%ROWTYPE;
    local "_campB_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_campB_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_campB_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_campB_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_campB_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_campB',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _campB_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_campB_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_campB_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_campB_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_campB',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _campB_insert
INSTEAD OF INSERT ON "_campB"
FOR EACH ROW EXECUTE FUNCTION _campB_insert_trigger();

CREATE OR REPLACE TRIGGER _campB_update
INSTEAD OF UPDATE ON "_campB"
FOR EACH ROW EXECUTE FUNCTION _campB_update_trigger();

CREATE OR REPLACE TRIGGER _campB_delete
INSTEAD OF DELETE ON "_campB"
FOR EACH ROW EXECUTE FUNCTION _campB_delete_trigger();


CREATE OR REPLACE FUNCTION _campB_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_campB_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _campB_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_campB_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_campB_synced"
FOR EACH ROW EXECUTE FUNCTION _campB_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_campB_synced"
FOR EACH ROW EXECUTE FUNCTION _campB_delete_local_on_synced_delete_trigger();

-- CreateTable
-- _characterToconsumable
CREATE TABLE IF NOT EXISTS "_characterToconsumable_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_characterToconsumable_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_characterToconsumable_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_characterToconsumable_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_characterToconsumable" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_characterToconsumable_synced" AS synced
  FULL OUTER JOIN "_characterToconsumable_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _characterToconsumable_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_characterToconsumable_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_characterToconsumable',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _characterToconsumable_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_characterToconsumable_synced"%ROWTYPE;
    local "_characterToconsumable_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_characterToconsumable_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_characterToconsumable_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_characterToconsumable_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_characterToconsumable_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_characterToconsumable',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _characterToconsumable_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_characterToconsumable_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_characterToconsumable_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_characterToconsumable_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_characterToconsumable',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _characterToconsumable_insert
INSTEAD OF INSERT ON "_characterToconsumable"
FOR EACH ROW EXECUTE FUNCTION _characterToconsumable_insert_trigger();

CREATE OR REPLACE TRIGGER _characterToconsumable_update
INSTEAD OF UPDATE ON "_characterToconsumable"
FOR EACH ROW EXECUTE FUNCTION _characterToconsumable_update_trigger();

CREATE OR REPLACE TRIGGER _characterToconsumable_delete
INSTEAD OF DELETE ON "_characterToconsumable"
FOR EACH ROW EXECUTE FUNCTION _characterToconsumable_delete_trigger();


CREATE OR REPLACE FUNCTION _characterToconsumable_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_characterToconsumable_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _characterToconsumable_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_characterToconsumable_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_characterToconsumable_synced"
FOR EACH ROW EXECUTE FUNCTION _characterToconsumable_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_characterToconsumable_synced"
FOR EACH ROW EXECUTE FUNCTION _characterToconsumable_delete_local_on_synced_delete_trigger();

-- CreateTable
-- _crystalTooption
CREATE TABLE IF NOT EXISTS "_crystalTooption_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_crystalTooption_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_crystalTooption_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_crystalTooption_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_crystalTooption" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_crystalTooption_synced" AS synced
  FULL OUTER JOIN "_crystalTooption_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _crystalTooption_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_crystalTooption_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalTooption',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _crystalTooption_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_crystalTooption_synced"%ROWTYPE;
    local "_crystalTooption_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_crystalTooption_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_crystalTooption_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_crystalTooption_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_crystalTooption_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalTooption',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _crystalTooption_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_crystalTooption_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_crystalTooption_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_crystalTooption_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalTooption',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _crystalTooption_insert
INSTEAD OF INSERT ON "_crystalTooption"
FOR EACH ROW EXECUTE FUNCTION _crystalTooption_insert_trigger();

CREATE OR REPLACE TRIGGER _crystalTooption_update
INSTEAD OF UPDATE ON "_crystalTooption"
FOR EACH ROW EXECUTE FUNCTION _crystalTooption_update_trigger();

CREATE OR REPLACE TRIGGER _crystalTooption_delete
INSTEAD OF DELETE ON "_crystalTooption"
FOR EACH ROW EXECUTE FUNCTION _crystalTooption_delete_trigger();


CREATE OR REPLACE FUNCTION _crystalTooption_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_crystalTooption_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _crystalTooption_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_crystalTooption_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_crystalTooption_synced"
FOR EACH ROW EXECUTE FUNCTION _crystalTooption_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_crystalTooption_synced"
FOR EACH ROW EXECUTE FUNCTION _crystalTooption_delete_local_on_synced_delete_trigger();

-- CreateTable
-- _crystalToplayer_armor
CREATE TABLE IF NOT EXISTS "_crystalToplayer_armor_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_crystalToplayer_armor_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_crystalToplayer_armor_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_crystalToplayer_armor_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_crystalToplayer_armor" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_crystalToplayer_armor_synced" AS synced
  FULL OUTER JOIN "_crystalToplayer_armor_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _crystalToplayer_armor_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_crystalToplayer_armor_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToplayer_armor',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _crystalToplayer_armor_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_crystalToplayer_armor_synced"%ROWTYPE;
    local "_crystalToplayer_armor_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_crystalToplayer_armor_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_crystalToplayer_armor_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_crystalToplayer_armor_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_crystalToplayer_armor_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToplayer_armor',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _crystalToplayer_armor_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_crystalToplayer_armor_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_crystalToplayer_armor_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_crystalToplayer_armor_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToplayer_armor',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _crystalToplayer_armor_insert
INSTEAD OF INSERT ON "_crystalToplayer_armor"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_armor_insert_trigger();

CREATE OR REPLACE TRIGGER _crystalToplayer_armor_update
INSTEAD OF UPDATE ON "_crystalToplayer_armor"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_armor_update_trigger();

CREATE OR REPLACE TRIGGER _crystalToplayer_armor_delete
INSTEAD OF DELETE ON "_crystalToplayer_armor"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_armor_delete_trigger();


CREATE OR REPLACE FUNCTION _crystalToplayer_armor_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_crystalToplayer_armor_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _crystalToplayer_armor_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_crystalToplayer_armor_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_crystalToplayer_armor_synced"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_armor_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_crystalToplayer_armor_synced"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_armor_delete_local_on_synced_delete_trigger();

-- CreateTable
-- _crystalToplayer_option
CREATE TABLE IF NOT EXISTS "_crystalToplayer_option_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_crystalToplayer_option_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_crystalToplayer_option_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_crystalToplayer_option_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_crystalToplayer_option" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_crystalToplayer_option_synced" AS synced
  FULL OUTER JOIN "_crystalToplayer_option_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _crystalToplayer_option_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_crystalToplayer_option_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToplayer_option',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _crystalToplayer_option_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_crystalToplayer_option_synced"%ROWTYPE;
    local "_crystalToplayer_option_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_crystalToplayer_option_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_crystalToplayer_option_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_crystalToplayer_option_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_crystalToplayer_option_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToplayer_option',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _crystalToplayer_option_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_crystalToplayer_option_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_crystalToplayer_option_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_crystalToplayer_option_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToplayer_option',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _crystalToplayer_option_insert
INSTEAD OF INSERT ON "_crystalToplayer_option"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_option_insert_trigger();

CREATE OR REPLACE TRIGGER _crystalToplayer_option_update
INSTEAD OF UPDATE ON "_crystalToplayer_option"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_option_update_trigger();

CREATE OR REPLACE TRIGGER _crystalToplayer_option_delete
INSTEAD OF DELETE ON "_crystalToplayer_option"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_option_delete_trigger();


CREATE OR REPLACE FUNCTION _crystalToplayer_option_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_crystalToplayer_option_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _crystalToplayer_option_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_crystalToplayer_option_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_crystalToplayer_option_synced"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_option_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_crystalToplayer_option_synced"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_option_delete_local_on_synced_delete_trigger();

-- CreateTable
-- _crystalToplayer_special
CREATE TABLE IF NOT EXISTS "_crystalToplayer_special_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_crystalToplayer_special_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_crystalToplayer_special_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_crystalToplayer_special_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_crystalToplayer_special" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_crystalToplayer_special_synced" AS synced
  FULL OUTER JOIN "_crystalToplayer_special_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _crystalToplayer_special_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_crystalToplayer_special_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToplayer_special',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _crystalToplayer_special_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_crystalToplayer_special_synced"%ROWTYPE;
    local "_crystalToplayer_special_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_crystalToplayer_special_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_crystalToplayer_special_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_crystalToplayer_special_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_crystalToplayer_special_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToplayer_special',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _crystalToplayer_special_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_crystalToplayer_special_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_crystalToplayer_special_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_crystalToplayer_special_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToplayer_special',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _crystalToplayer_special_insert
INSTEAD OF INSERT ON "_crystalToplayer_special"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_special_insert_trigger();

CREATE OR REPLACE TRIGGER _crystalToplayer_special_update
INSTEAD OF UPDATE ON "_crystalToplayer_special"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_special_update_trigger();

CREATE OR REPLACE TRIGGER _crystalToplayer_special_delete
INSTEAD OF DELETE ON "_crystalToplayer_special"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_special_delete_trigger();


CREATE OR REPLACE FUNCTION _crystalToplayer_special_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_crystalToplayer_special_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _crystalToplayer_special_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_crystalToplayer_special_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_crystalToplayer_special_synced"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_special_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_crystalToplayer_special_synced"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_special_delete_local_on_synced_delete_trigger();

-- CreateTable
-- _crystalToplayer_weapon
CREATE TABLE IF NOT EXISTS "_crystalToplayer_weapon_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_crystalToplayer_weapon_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_crystalToplayer_weapon_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_crystalToplayer_weapon_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_crystalToplayer_weapon" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_crystalToplayer_weapon_synced" AS synced
  FULL OUTER JOIN "_crystalToplayer_weapon_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _crystalToplayer_weapon_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_crystalToplayer_weapon_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToplayer_weapon',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _crystalToplayer_weapon_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_crystalToplayer_weapon_synced"%ROWTYPE;
    local "_crystalToplayer_weapon_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_crystalToplayer_weapon_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_crystalToplayer_weapon_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_crystalToplayer_weapon_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_crystalToplayer_weapon_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToplayer_weapon',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _crystalToplayer_weapon_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_crystalToplayer_weapon_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_crystalToplayer_weapon_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_crystalToplayer_weapon_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToplayer_weapon',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _crystalToplayer_weapon_insert
INSTEAD OF INSERT ON "_crystalToplayer_weapon"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_weapon_insert_trigger();

CREATE OR REPLACE TRIGGER _crystalToplayer_weapon_update
INSTEAD OF UPDATE ON "_crystalToplayer_weapon"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_weapon_update_trigger();

CREATE OR REPLACE TRIGGER _crystalToplayer_weapon_delete
INSTEAD OF DELETE ON "_crystalToplayer_weapon"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_weapon_delete_trigger();


CREATE OR REPLACE FUNCTION _crystalToplayer_weapon_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_crystalToplayer_weapon_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _crystalToplayer_weapon_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_crystalToplayer_weapon_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_crystalToplayer_weapon_synced"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_weapon_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_crystalToplayer_weapon_synced"
FOR EACH ROW EXECUTE FUNCTION _crystalToplayer_weapon_delete_local_on_synced_delete_trigger();

-- CreateTable
-- _crystalTospecial
CREATE TABLE IF NOT EXISTS "_crystalTospecial_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_crystalTospecial_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_crystalTospecial_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_crystalTospecial_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_crystalTospecial" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_crystalTospecial_synced" AS synced
  FULL OUTER JOIN "_crystalTospecial_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _crystalTospecial_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_crystalTospecial_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalTospecial',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _crystalTospecial_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_crystalTospecial_synced"%ROWTYPE;
    local "_crystalTospecial_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_crystalTospecial_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_crystalTospecial_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_crystalTospecial_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_crystalTospecial_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalTospecial',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _crystalTospecial_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_crystalTospecial_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_crystalTospecial_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_crystalTospecial_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalTospecial',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _crystalTospecial_insert
INSTEAD OF INSERT ON "_crystalTospecial"
FOR EACH ROW EXECUTE FUNCTION _crystalTospecial_insert_trigger();

CREATE OR REPLACE TRIGGER _crystalTospecial_update
INSTEAD OF UPDATE ON "_crystalTospecial"
FOR EACH ROW EXECUTE FUNCTION _crystalTospecial_update_trigger();

CREATE OR REPLACE TRIGGER _crystalTospecial_delete
INSTEAD OF DELETE ON "_crystalTospecial"
FOR EACH ROW EXECUTE FUNCTION _crystalTospecial_delete_trigger();


CREATE OR REPLACE FUNCTION _crystalTospecial_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_crystalTospecial_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _crystalTospecial_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_crystalTospecial_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_crystalTospecial_synced"
FOR EACH ROW EXECUTE FUNCTION _crystalTospecial_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_crystalTospecial_synced"
FOR EACH ROW EXECUTE FUNCTION _crystalTospecial_delete_local_on_synced_delete_trigger();

-- CreateTable
-- _crystalToweapon
CREATE TABLE IF NOT EXISTS "_crystalToweapon_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_crystalToweapon_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_crystalToweapon_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_crystalToweapon_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_crystalToweapon" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_crystalToweapon_synced" AS synced
  FULL OUTER JOIN "_crystalToweapon_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _crystalToweapon_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_crystalToweapon_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToweapon',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _crystalToweapon_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_crystalToweapon_synced"%ROWTYPE;
    local "_crystalToweapon_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_crystalToweapon_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_crystalToweapon_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_crystalToweapon_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_crystalToweapon_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToweapon',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _crystalToweapon_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_crystalToweapon_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_crystalToweapon_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_crystalToweapon_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_crystalToweapon',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _crystalToweapon_insert
INSTEAD OF INSERT ON "_crystalToweapon"
FOR EACH ROW EXECUTE FUNCTION _crystalToweapon_insert_trigger();

CREATE OR REPLACE TRIGGER _crystalToweapon_update
INSTEAD OF UPDATE ON "_crystalToweapon"
FOR EACH ROW EXECUTE FUNCTION _crystalToweapon_update_trigger();

CREATE OR REPLACE TRIGGER _crystalToweapon_delete
INSTEAD OF DELETE ON "_crystalToweapon"
FOR EACH ROW EXECUTE FUNCTION _crystalToweapon_delete_trigger();


CREATE OR REPLACE FUNCTION _crystalToweapon_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_crystalToweapon_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _crystalToweapon_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_crystalToweapon_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_crystalToweapon_synced"
FOR EACH ROW EXECUTE FUNCTION _crystalToweapon_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_crystalToweapon_synced"
FOR EACH ROW EXECUTE FUNCTION _crystalToweapon_delete_local_on_synced_delete_trigger();

-- CreateTable
-- _mobTozone
CREATE TABLE IF NOT EXISTS "_mobTozone_synced" (
  "A" TEXT NOT NULL,
  "B" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "_mobTozone_synced_pkey" PRIMARY KEY ("A","B")
);
CREATE TABLE IF NOT EXISTS "_mobTozone_local" (
  "A" TEXT,
  "B" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "_mobTozone_local_pkey" PRIMARY KEY ("A","B")
);

CREATE OR REPLACE VIEW "_mobTozone" AS
  SELECT
     COALESCE(local."A", synced."A") AS "A",
   COALESCE(local."B", synced."B") AS "B"
  FROM "_mobTozone_synced" AS synced
  FULL OUTER JOIN "_mobTozone_local" AS local
  ON synced."A" = local."A" AND synced."B" = local."B"
  WHERE (local."A" IS NULL OR local."B" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION _mobTozone_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "_mobTozone_local" (
    "A", "B",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."A", NEW."B",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_mobTozone',
    'insert',
    jsonb_build_object(
        'A', NEW."A",
      'B', NEW."B"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _mobTozone_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "_mobTozone_synced"%ROWTYPE;
    local "_mobTozone_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "_mobTozone_synced" WHERE "A" = NEW."A" AND "B" = NEW."B";
    SELECT * INTO local FROM "_mobTozone_local" WHERE "A" = NEW."A" AND "B" = NEW."B";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "_mobTozone_local" (
        "A", "B",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."A", NEW."B",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "_mobTozone_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "A" = NEW."A" AND "B" = NEW."B";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_mobTozone',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'A', COALESCE(NEW."A", local."A"),
      'B', COALESCE(NEW."B", local."B")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION _mobTozone_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "_mobTozone_local" WHERE "A" = OLD."A" AND "B" = OLD."B") THEN
    UPDATE "_mobTozone_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "A" = OLD."A" AND "B" = OLD."B";
    ELSE
    INSERT INTO "_mobTozone_local" (
        A, B,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."A", OLD."B",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    '_mobTozone',
    'delete',
    jsonb_build_object('A', OLD."A", 'B', OLD."B"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER _mobTozone_insert
INSTEAD OF INSERT ON "_mobTozone"
FOR EACH ROW EXECUTE FUNCTION _mobTozone_insert_trigger();

CREATE OR REPLACE TRIGGER _mobTozone_update
INSTEAD OF UPDATE ON "_mobTozone"
FOR EACH ROW EXECUTE FUNCTION _mobTozone_update_trigger();

CREATE OR REPLACE TRIGGER _mobTozone_delete
INSTEAD OF DELETE ON "_mobTozone"
FOR EACH ROW EXECUTE FUNCTION _mobTozone_delete_trigger();


CREATE OR REPLACE FUNCTION _mobTozone_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_mobTozone_local"
  WHERE "A" = NEW."A" AND "B" = NEW."B"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION _mobTozone_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "_mobTozone_local"
  WHERE "A" = OLD."A" AND "B" = OLD."B";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "_mobTozone_synced"
FOR EACH ROW EXECUTE FUNCTION _mobTozone_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "_mobTozone_synced"
FOR EACH ROW EXECUTE FUNCTION _mobTozone_delete_local_on_synced_delete_trigger();

-- CreateTable
-- account
CREATE TABLE IF NOT EXISTS "account_synced" (
  "id" TEXT NOT NULL,
  "type" "AccountType" NOT NULL,
  "provider" TEXT NOT NULL,
  "providerAccountId" TEXT NOT NULL,
  "refresh_token" TEXT,
  "access_token" TEXT,
  "expires_at" INTEGER,
  "token_type" TEXT,
  "scope" TEXT,
  "id_token" TEXT,
  "session_state" TEXT,
  "userId" TEXT,
  "write_id" UUID,
  CONSTRAINT "account_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "account_local" (
  "id" TEXT,
  "type" "AccountType",
  "provider" TEXT,
  "providerAccountId" TEXT,
  "refresh_token" TEXT,
  "access_token" TEXT,
  "expires_at" INTEGER,
  "token_type" TEXT,
  "scope" TEXT,
  "id_token" TEXT,
  "session_state" TEXT,
  "userId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "account_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "account" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   CASE
    WHEN 'provider' = ANY(local.changed_columns)
      THEN local."provider"
      ELSE synced."provider"
    END AS "provider",
   CASE
    WHEN 'providerAccountId' = ANY(local.changed_columns)
      THEN local."providerAccountId"
      ELSE synced."providerAccountId"
    END AS "providerAccountId",
   CASE
    WHEN 'refresh_token' = ANY(local.changed_columns)
      THEN local."refresh_token"
      ELSE synced."refresh_token"
    END AS "refresh_token",
   CASE
    WHEN 'access_token' = ANY(local.changed_columns)
      THEN local."access_token"
      ELSE synced."access_token"
    END AS "access_token",
   CASE
    WHEN 'expires_at' = ANY(local.changed_columns)
      THEN local."expires_at"
      ELSE synced."expires_at"
    END AS "expires_at",
   CASE
    WHEN 'token_type' = ANY(local.changed_columns)
      THEN local."token_type"
      ELSE synced."token_type"
    END AS "token_type",
   CASE
    WHEN 'scope' = ANY(local.changed_columns)
      THEN local."scope"
      ELSE synced."scope"
    END AS "scope",
   CASE
    WHEN 'id_token' = ANY(local.changed_columns)
      THEN local."id_token"
      ELSE synced."id_token"
    END AS "id_token",
   CASE
    WHEN 'session_state' = ANY(local.changed_columns)
      THEN local."session_state"
      ELSE synced."session_state"
    END AS "session_state",
   CASE
    WHEN 'userId' = ANY(local.changed_columns)
      THEN local."userId"
      ELSE synced."userId"
    END AS "userId"
  FROM "account_synced" AS synced
  FULL OUTER JOIN "account_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION account_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "account_local" (
    "id", "type", "provider", "providerAccountId", "refresh_token", "access_token", "expires_at", "token_type", "scope", "id_token", "session_state", "userId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."type", NEW."provider", NEW."providerAccountId", NEW."refresh_token", NEW."access_token", NEW."expires_at", NEW."token_type", NEW."scope", NEW."id_token", NEW."session_state", NEW."userId",
    ARRAY['type', 'provider', 'providerAccountId', 'refresh_token', 'access_token', 'expires_at', 'token_type', 'scope', 'id_token', 'session_state', 'userId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'account',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'type', NEW."type",
      'provider', NEW."provider",
      'providerAccountId', NEW."providerAccountId",
      'refresh_token', NEW."refresh_token",
      'access_token', NEW."access_token",
      'expires_at', NEW."expires_at",
      'token_type', NEW."token_type",
      'scope', NEW."scope",
      'id_token', NEW."id_token",
      'session_state', NEW."session_state",
      'userId', NEW."userId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION account_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "account_synced"%ROWTYPE;
    local "account_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "account_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "account_local" WHERE "id" = NEW."id";
    
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."provider" IS DISTINCT FROM synced."provider" THEN
      changed_cols := array_append(changed_cols, 'provider');
    END IF;
    IF NEW."providerAccountId" IS DISTINCT FROM synced."providerAccountId" THEN
      changed_cols := array_append(changed_cols, 'providerAccountId');
    END IF;
    IF NEW."refresh_token" IS DISTINCT FROM synced."refresh_token" THEN
      changed_cols := array_append(changed_cols, 'refresh_token');
    END IF;
    IF NEW."access_token" IS DISTINCT FROM synced."access_token" THEN
      changed_cols := array_append(changed_cols, 'access_token');
    END IF;
    IF NEW."expires_at" IS DISTINCT FROM synced."expires_at" THEN
      changed_cols := array_append(changed_cols, 'expires_at');
    END IF;
    IF NEW."token_type" IS DISTINCT FROM synced."token_type" THEN
      changed_cols := array_append(changed_cols, 'token_type');
    END IF;
    IF NEW."scope" IS DISTINCT FROM synced."scope" THEN
      changed_cols := array_append(changed_cols, 'scope');
    END IF;
    IF NEW."id_token" IS DISTINCT FROM synced."id_token" THEN
      changed_cols := array_append(changed_cols, 'id_token');
    END IF;
    IF NEW."session_state" IS DISTINCT FROM synced."session_state" THEN
      changed_cols := array_append(changed_cols, 'session_state');
    END IF;
    IF NEW."userId" IS DISTINCT FROM synced."userId" THEN
      changed_cols := array_append(changed_cols, 'userId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "account_local" (
        "id", "type", "provider", "providerAccountId", "refresh_token", "access_token", "expires_at", "token_type", "scope", "id_token", "session_state", "userId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."type", NEW."provider", NEW."providerAccountId", NEW."refresh_token", NEW."access_token", NEW."expires_at", NEW."token_type", NEW."scope", NEW."id_token", NEW."session_state", NEW."userId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "account_local"
    SET
        
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "provider" = CASE WHEN NEW."provider" IS DISTINCT FROM synced."provider" THEN NEW."provider" ELSE local."provider" END,
    "providerAccountId" = CASE WHEN NEW."providerAccountId" IS DISTINCT FROM synced."providerAccountId" THEN NEW."providerAccountId" ELSE local."providerAccountId" END,
    "refresh_token" = CASE WHEN NEW."refresh_token" IS DISTINCT FROM synced."refresh_token" THEN NEW."refresh_token" ELSE local."refresh_token" END,
    "access_token" = CASE WHEN NEW."access_token" IS DISTINCT FROM synced."access_token" THEN NEW."access_token" ELSE local."access_token" END,
    "expires_at" = CASE WHEN NEW."expires_at" IS DISTINCT FROM synced."expires_at" THEN NEW."expires_at" ELSE local."expires_at" END,
    "token_type" = CASE WHEN NEW."token_type" IS DISTINCT FROM synced."token_type" THEN NEW."token_type" ELSE local."token_type" END,
    "scope" = CASE WHEN NEW."scope" IS DISTINCT FROM synced."scope" THEN NEW."scope" ELSE local."scope" END,
    "id_token" = CASE WHEN NEW."id_token" IS DISTINCT FROM synced."id_token" THEN NEW."id_token" ELSE local."id_token" END,
    "session_state" = CASE WHEN NEW."session_state" IS DISTINCT FROM synced."session_state" THEN NEW."session_state" ELSE local."session_state" END,
    "userId" = CASE WHEN NEW."userId" IS DISTINCT FROM synced."userId" THEN NEW."userId" ELSE local."userId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'account',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'type', COALESCE(NEW."type", local."type"),
      'provider', COALESCE(NEW."provider", local."provider"),
      'providerAccountId', COALESCE(NEW."providerAccountId", local."providerAccountId"),
      'refresh_token', COALESCE(NEW."refresh_token", local."refresh_token"),
      'access_token', COALESCE(NEW."access_token", local."access_token"),
      'expires_at', COALESCE(NEW."expires_at", local."expires_at"),
      'token_type', COALESCE(NEW."token_type", local."token_type"),
      'scope', COALESCE(NEW."scope", local."scope"),
      'id_token', COALESCE(NEW."id_token", local."id_token"),
      'session_state', COALESCE(NEW."session_state", local."session_state"),
      'userId', COALESCE(NEW."userId", local."userId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION account_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "account_local" WHERE "id" = OLD."id") THEN
    UPDATE "account_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "account_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'account',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER account_insert
INSTEAD OF INSERT ON "account"
FOR EACH ROW EXECUTE FUNCTION account_insert_trigger();

CREATE OR REPLACE TRIGGER account_update
INSTEAD OF UPDATE ON "account"
FOR EACH ROW EXECUTE FUNCTION account_update_trigger();

CREATE OR REPLACE TRIGGER account_delete
INSTEAD OF DELETE ON "account"
FOR EACH ROW EXECUTE FUNCTION account_delete_trigger();


CREATE OR REPLACE FUNCTION account_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "account_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION account_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "account_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "account_synced"
FOR EACH ROW EXECUTE FUNCTION account_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "account_synced"
FOR EACH ROW EXECUTE FUNCTION account_delete_local_on_synced_delete_trigger();

-- CreateTable
-- account_create_data
CREATE TABLE IF NOT EXISTS "account_create_data_synced" (
  "accountId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "account_create_data_synced_pkey" PRIMARY KEY ("accountId")
);
CREATE TABLE IF NOT EXISTS "account_create_data_local" (
  "accountId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "account_create_data_local_pkey" PRIMARY KEY ("accountId")
);

CREATE OR REPLACE VIEW "account_create_data" AS
  SELECT
     COALESCE(local."accountId", synced."accountId") AS "accountId"
  FROM "account_create_data_synced" AS synced
  FULL OUTER JOIN "account_create_data_local" AS local
  ON synced."accountId" = local."accountId"
  WHERE (local."accountId" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION account_create_data_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "account_create_data_local" (
    "accountId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."accountId",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'account_create_data',
    'insert',
    jsonb_build_object(
        'accountId', NEW."accountId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION account_create_data_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "account_create_data_synced"%ROWTYPE;
    local "account_create_data_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "account_create_data_synced" WHERE "accountId" = NEW."accountId";
    SELECT * INTO local FROM "account_create_data_local" WHERE "accountId" = NEW."accountId";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "account_create_data_local" (
        "accountId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."accountId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "account_create_data_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "accountId" = NEW."accountId";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'account_create_data',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'accountId', COALESCE(NEW."accountId", local."accountId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION account_create_data_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "account_create_data_local" WHERE "accountId" = OLD."accountId") THEN
    UPDATE "account_create_data_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "accountId" = OLD."accountId";
    ELSE
    INSERT INTO "account_create_data_local" (
        accountId,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."accountId",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'account_create_data',
    'delete',
    jsonb_build_object('accountId', OLD."accountId"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER account_create_data_insert
INSTEAD OF INSERT ON "account_create_data"
FOR EACH ROW EXECUTE FUNCTION account_create_data_insert_trigger();

CREATE OR REPLACE TRIGGER account_create_data_update
INSTEAD OF UPDATE ON "account_create_data"
FOR EACH ROW EXECUTE FUNCTION account_create_data_update_trigger();

CREATE OR REPLACE TRIGGER account_create_data_delete
INSTEAD OF DELETE ON "account_create_data"
FOR EACH ROW EXECUTE FUNCTION account_create_data_delete_trigger();


CREATE OR REPLACE FUNCTION account_create_data_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "account_create_data_local"
  WHERE "accountId" = NEW."accountId"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION account_create_data_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "account_create_data_local"
  WHERE "accountId" = OLD."accountId";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "account_create_data_synced"
FOR EACH ROW EXECUTE FUNCTION account_create_data_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "account_create_data_synced"
FOR EACH ROW EXECUTE FUNCTION account_create_data_delete_local_on_synced_delete_trigger();

-- CreateTable
-- account_update_data
CREATE TABLE IF NOT EXISTS "account_update_data_synced" (
  "accountId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "account_update_data_synced_pkey" PRIMARY KEY ("accountId")
);
CREATE TABLE IF NOT EXISTS "account_update_data_local" (
  "accountId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "account_update_data_local_pkey" PRIMARY KEY ("accountId")
);

CREATE OR REPLACE VIEW "account_update_data" AS
  SELECT
     COALESCE(local."accountId", synced."accountId") AS "accountId"
  FROM "account_update_data_synced" AS synced
  FULL OUTER JOIN "account_update_data_local" AS local
  ON synced."accountId" = local."accountId"
  WHERE (local."accountId" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION account_update_data_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "account_update_data_local" (
    "accountId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."accountId",
    ARRAY[],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'account_update_data',
    'insert',
    jsonb_build_object(
        'accountId', NEW."accountId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION account_update_data_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "account_update_data_synced"%ROWTYPE;
    local "account_update_data_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "account_update_data_synced" WHERE "accountId" = NEW."accountId";
    SELECT * INTO local FROM "account_update_data_local" WHERE "accountId" = NEW."accountId";
    -- no non-pk fields to track
    IF NOT FOUND THEN
    INSERT INTO "account_update_data_local" (
        "accountId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."accountId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "account_update_data_local"
    SET
        -- no non-pk fields,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "accountId" = NEW."accountId";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'account_update_data',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'accountId', COALESCE(NEW."accountId", local."accountId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION account_update_data_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "account_update_data_local" WHERE "accountId" = OLD."accountId") THEN
    UPDATE "account_update_data_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "accountId" = OLD."accountId";
    ELSE
    INSERT INTO "account_update_data_local" (
        accountId,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."accountId",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'account_update_data',
    'delete',
    jsonb_build_object('accountId', OLD."accountId"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER account_update_data_insert
INSTEAD OF INSERT ON "account_update_data"
FOR EACH ROW EXECUTE FUNCTION account_update_data_insert_trigger();

CREATE OR REPLACE TRIGGER account_update_data_update
INSTEAD OF UPDATE ON "account_update_data"
FOR EACH ROW EXECUTE FUNCTION account_update_data_update_trigger();

CREATE OR REPLACE TRIGGER account_update_data_delete
INSTEAD OF DELETE ON "account_update_data"
FOR EACH ROW EXECUTE FUNCTION account_update_data_delete_trigger();


CREATE OR REPLACE FUNCTION account_update_data_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "account_update_data_local"
  WHERE "accountId" = NEW."accountId"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION account_update_data_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "account_update_data_local"
  WHERE "accountId" = OLD."accountId";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "account_update_data_synced"
FOR EACH ROW EXECUTE FUNCTION account_update_data_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "account_update_data_synced"
FOR EACH ROW EXECUTE FUNCTION account_update_data_delete_local_on_synced_delete_trigger();

-- CreateTable
-- activity
CREATE TABLE IF NOT EXISTS "activity_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "activity_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "activity_local" (
  "id" TEXT,
  "name" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "activity_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "activity" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name"
  FROM "activity_synced" AS synced
  FULL OUTER JOIN "activity_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION activity_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "activity_local" (
    "id", "name",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name",
    ARRAY['name'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'activity',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION activity_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "activity_synced"%ROWTYPE;
    local "activity_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "activity_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "activity_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "activity_local" (
        "id", "name",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "activity_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'activity',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION activity_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "activity_local" WHERE "id" = OLD."id") THEN
    UPDATE "activity_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "activity_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'activity',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER activity_insert
INSTEAD OF INSERT ON "activity"
FOR EACH ROW EXECUTE FUNCTION activity_insert_trigger();

CREATE OR REPLACE TRIGGER activity_update
INSTEAD OF UPDATE ON "activity"
FOR EACH ROW EXECUTE FUNCTION activity_update_trigger();

CREATE OR REPLACE TRIGGER activity_delete
INSTEAD OF DELETE ON "activity"
FOR EACH ROW EXECUTE FUNCTION activity_delete_trigger();


CREATE OR REPLACE FUNCTION activity_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "activity_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION activity_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "activity_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "activity_synced"
FOR EACH ROW EXECUTE FUNCTION activity_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "activity_synced"
FOR EACH ROW EXECUTE FUNCTION activity_delete_local_on_synced_delete_trigger();

-- CreateTable
-- address
CREATE TABLE IF NOT EXISTS "address_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "type" "AddressType" NOT NULL,
  "posX" INTEGER NOT NULL,
  "posY" INTEGER NOT NULL,
  "worldId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "address_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "address_local" (
  "id" TEXT,
  "name" TEXT,
  "type" "AddressType",
  "posX" INTEGER,
  "posY" INTEGER,
  "worldId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "address_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "address" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   CASE
    WHEN 'posX' = ANY(local.changed_columns)
      THEN local."posX"
      ELSE synced."posX"
    END AS "posX",
   CASE
    WHEN 'posY' = ANY(local.changed_columns)
      THEN local."posY"
      ELSE synced."posY"
    END AS "posY",
   CASE
    WHEN 'worldId' = ANY(local.changed_columns)
      THEN local."worldId"
      ELSE synced."worldId"
    END AS "worldId"
  FROM "address_synced" AS synced
  FULL OUTER JOIN "address_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION address_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "address_local" (
    "id", "name", "type", "posX", "posY", "worldId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."type", NEW."posX", NEW."posY", NEW."worldId",
    ARRAY['name', 'type', 'posX', 'posY', 'worldId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'address',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'type', NEW."type",
      'posX', NEW."posX",
      'posY', NEW."posY",
      'worldId', NEW."worldId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION address_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "address_synced"%ROWTYPE;
    local "address_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "address_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "address_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."posX" IS DISTINCT FROM synced."posX" THEN
      changed_cols := array_append(changed_cols, 'posX');
    END IF;
    IF NEW."posY" IS DISTINCT FROM synced."posY" THEN
      changed_cols := array_append(changed_cols, 'posY');
    END IF;
    IF NEW."worldId" IS DISTINCT FROM synced."worldId" THEN
      changed_cols := array_append(changed_cols, 'worldId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "address_local" (
        "id", "name", "type", "posX", "posY", "worldId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."type", NEW."posX", NEW."posY", NEW."worldId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "address_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "posX" = CASE WHEN NEW."posX" IS DISTINCT FROM synced."posX" THEN NEW."posX" ELSE local."posX" END,
    "posY" = CASE WHEN NEW."posY" IS DISTINCT FROM synced."posY" THEN NEW."posY" ELSE local."posY" END,
    "worldId" = CASE WHEN NEW."worldId" IS DISTINCT FROM synced."worldId" THEN NEW."worldId" ELSE local."worldId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'address',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'type', COALESCE(NEW."type", local."type"),
      'posX', COALESCE(NEW."posX", local."posX"),
      'posY', COALESCE(NEW."posY", local."posY"),
      'worldId', COALESCE(NEW."worldId", local."worldId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION address_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "address_local" WHERE "id" = OLD."id") THEN
    UPDATE "address_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "address_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'address',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER address_insert
INSTEAD OF INSERT ON "address"
FOR EACH ROW EXECUTE FUNCTION address_insert_trigger();

CREATE OR REPLACE TRIGGER address_update
INSTEAD OF UPDATE ON "address"
FOR EACH ROW EXECUTE FUNCTION address_update_trigger();

CREATE OR REPLACE TRIGGER address_delete
INSTEAD OF DELETE ON "address"
FOR EACH ROW EXECUTE FUNCTION address_delete_trigger();


CREATE OR REPLACE FUNCTION address_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "address_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION address_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "address_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "address_synced"
FOR EACH ROW EXECUTE FUNCTION address_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "address_synced"
FOR EACH ROW EXECUTE FUNCTION address_delete_local_on_synced_delete_trigger();

-- CreateTable
-- armor
CREATE TABLE IF NOT EXISTS "armor_synced" (
  "baseDef" INTEGER NOT NULL,
  "modifiers" TEXT[],
  "colorA" INTEGER NOT NULL,
  "colorB" INTEGER NOT NULL,
  "colorC" INTEGER NOT NULL,
  "itemId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "armor_synced_pkey" PRIMARY KEY ("itemId")
);
CREATE TABLE IF NOT EXISTS "armor_local" (
  "baseDef" INTEGER,
  "modifiers" TEXT[],
  "colorA" INTEGER,
  "colorB" INTEGER,
  "colorC" INTEGER,
  "itemId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "armor_local_pkey" PRIMARY KEY ("itemId")
);

CREATE OR REPLACE VIEW "armor" AS
  SELECT
     CASE
    WHEN 'baseDef' = ANY(local.changed_columns)
      THEN local."baseDef"
      ELSE synced."baseDef"
    END AS "baseDef",
   CASE
    WHEN 'modifiers' = ANY(local.changed_columns)
      THEN local."modifiers"
      ELSE synced."modifiers"
    END AS "modifiers",
   CASE
    WHEN 'colorA' = ANY(local.changed_columns)
      THEN local."colorA"
      ELSE synced."colorA"
    END AS "colorA",
   CASE
    WHEN 'colorB' = ANY(local.changed_columns)
      THEN local."colorB"
      ELSE synced."colorB"
    END AS "colorB",
   CASE
    WHEN 'colorC' = ANY(local.changed_columns)
      THEN local."colorC"
      ELSE synced."colorC"
    END AS "colorC",
   COALESCE(local."itemId", synced."itemId") AS "itemId"
  FROM "armor_synced" AS synced
  FULL OUTER JOIN "armor_local" AS local
  ON synced."itemId" = local."itemId"
  WHERE (local."itemId" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION armor_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "armor_local" (
    "baseDef", "modifiers", "colorA", "colorB", "colorC", "itemId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."baseDef", NEW."modifiers", NEW."colorA", NEW."colorB", NEW."colorC", NEW."itemId",
    ARRAY['baseDef', 'modifiers', 'colorA', 'colorB', 'colorC'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'armor',
    'insert',
    jsonb_build_object(
        'baseDef', NEW."baseDef",
      'modifiers', NEW."modifiers",
      'colorA', NEW."colorA",
      'colorB', NEW."colorB",
      'colorC', NEW."colorC",
      'itemId', NEW."itemId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION armor_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "armor_synced"%ROWTYPE;
    local "armor_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "armor_synced" WHERE "itemId" = NEW."itemId";
    SELECT * INTO local FROM "armor_local" WHERE "itemId" = NEW."itemId";
    
    IF NEW."baseDef" IS DISTINCT FROM synced."baseDef" THEN
      changed_cols := array_append(changed_cols, 'baseDef');
    END IF;
    IF NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN
      changed_cols := array_append(changed_cols, 'modifiers');
    END IF;
    IF NEW."colorA" IS DISTINCT FROM synced."colorA" THEN
      changed_cols := array_append(changed_cols, 'colorA');
    END IF;
    IF NEW."colorB" IS DISTINCT FROM synced."colorB" THEN
      changed_cols := array_append(changed_cols, 'colorB');
    END IF;
    IF NEW."colorC" IS DISTINCT FROM synced."colorC" THEN
      changed_cols := array_append(changed_cols, 'colorC');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "armor_local" (
        "baseDef", "modifiers", "colorA", "colorB", "colorC", "itemId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."baseDef", NEW."modifiers", NEW."colorA", NEW."colorB", NEW."colorC", NEW."itemId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "armor_local"
    SET
        
    "baseDef" = CASE WHEN NEW."baseDef" IS DISTINCT FROM synced."baseDef" THEN NEW."baseDef" ELSE local."baseDef" END,
    "modifiers" = CASE WHEN NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN NEW."modifiers" ELSE local."modifiers" END,
    "colorA" = CASE WHEN NEW."colorA" IS DISTINCT FROM synced."colorA" THEN NEW."colorA" ELSE local."colorA" END,
    "colorB" = CASE WHEN NEW."colorB" IS DISTINCT FROM synced."colorB" THEN NEW."colorB" ELSE local."colorB" END,
    "colorC" = CASE WHEN NEW."colorC" IS DISTINCT FROM synced."colorC" THEN NEW."colorC" ELSE local."colorC" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "itemId" = NEW."itemId";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'armor',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'baseDef', COALESCE(NEW."baseDef", local."baseDef"),
      'modifiers', COALESCE(NEW."modifiers", local."modifiers"),
      'colorA', COALESCE(NEW."colorA", local."colorA"),
      'colorB', COALESCE(NEW."colorB", local."colorB"),
      'colorC', COALESCE(NEW."colorC", local."colorC"),
      'itemId', COALESCE(NEW."itemId", local."itemId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION armor_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "armor_local" WHERE "itemId" = OLD."itemId") THEN
    UPDATE "armor_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "itemId" = OLD."itemId";
    ELSE
    INSERT INTO "armor_local" (
        itemId,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."itemId",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'armor',
    'delete',
    jsonb_build_object('itemId', OLD."itemId"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER armor_insert
INSTEAD OF INSERT ON "armor"
FOR EACH ROW EXECUTE FUNCTION armor_insert_trigger();

CREATE OR REPLACE TRIGGER armor_update
INSTEAD OF UPDATE ON "armor"
FOR EACH ROW EXECUTE FUNCTION armor_update_trigger();

CREATE OR REPLACE TRIGGER armor_delete
INSTEAD OF DELETE ON "armor"
FOR EACH ROW EXECUTE FUNCTION armor_delete_trigger();


CREATE OR REPLACE FUNCTION armor_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "armor_local"
  WHERE "itemId" = NEW."itemId"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION armor_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "armor_local"
  WHERE "itemId" = OLD."itemId";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "armor_synced"
FOR EACH ROW EXECUTE FUNCTION armor_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "armor_synced"
FOR EACH ROW EXECUTE FUNCTION armor_delete_local_on_synced_delete_trigger();

-- CreateTable
-- avatar
CREATE TABLE IF NOT EXISTS "avatar_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "type" "AvatarType" NOT NULL,
  "modifiers" TEXT[],
  "playerId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "avatar_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "avatar_local" (
  "id" TEXT,
  "name" TEXT,
  "type" "AvatarType",
  "modifiers" TEXT[],
  "playerId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "avatar_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "avatar" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   CASE
    WHEN 'modifiers' = ANY(local.changed_columns)
      THEN local."modifiers"
      ELSE synced."modifiers"
    END AS "modifiers",
   CASE
    WHEN 'playerId' = ANY(local.changed_columns)
      THEN local."playerId"
      ELSE synced."playerId"
    END AS "playerId"
  FROM "avatar_synced" AS synced
  FULL OUTER JOIN "avatar_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION avatar_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "avatar_local" (
    "id", "name", "type", "modifiers", "playerId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."type", NEW."modifiers", NEW."playerId",
    ARRAY['name', 'type', 'modifiers', 'playerId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'avatar',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'type', NEW."type",
      'modifiers', NEW."modifiers",
      'playerId', NEW."playerId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION avatar_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "avatar_synced"%ROWTYPE;
    local "avatar_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "avatar_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "avatar_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN
      changed_cols := array_append(changed_cols, 'modifiers');
    END IF;
    IF NEW."playerId" IS DISTINCT FROM synced."playerId" THEN
      changed_cols := array_append(changed_cols, 'playerId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "avatar_local" (
        "id", "name", "type", "modifiers", "playerId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."type", NEW."modifiers", NEW."playerId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "avatar_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "modifiers" = CASE WHEN NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN NEW."modifiers" ELSE local."modifiers" END,
    "playerId" = CASE WHEN NEW."playerId" IS DISTINCT FROM synced."playerId" THEN NEW."playerId" ELSE local."playerId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'avatar',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'type', COALESCE(NEW."type", local."type"),
      'modifiers', COALESCE(NEW."modifiers", local."modifiers"),
      'playerId', COALESCE(NEW."playerId", local."playerId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION avatar_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "avatar_local" WHERE "id" = OLD."id") THEN
    UPDATE "avatar_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "avatar_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'avatar',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER avatar_insert
INSTEAD OF INSERT ON "avatar"
FOR EACH ROW EXECUTE FUNCTION avatar_insert_trigger();

CREATE OR REPLACE TRIGGER avatar_update
INSTEAD OF UPDATE ON "avatar"
FOR EACH ROW EXECUTE FUNCTION avatar_update_trigger();

CREATE OR REPLACE TRIGGER avatar_delete
INSTEAD OF DELETE ON "avatar"
FOR EACH ROW EXECUTE FUNCTION avatar_delete_trigger();


CREATE OR REPLACE FUNCTION avatar_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "avatar_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION avatar_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "avatar_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "avatar_synced"
FOR EACH ROW EXECUTE FUNCTION avatar_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "avatar_synced"
FOR EACH ROW EXECUTE FUNCTION avatar_delete_local_on_synced_delete_trigger();

-- CreateTable
-- character
CREATE TABLE IF NOT EXISTS "character_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "lv" INTEGER NOT NULL,
  "str" INTEGER NOT NULL,
  "int" INTEGER NOT NULL,
  "vit" INTEGER NOT NULL,
  "agi" INTEGER NOT NULL,
  "dex" INTEGER NOT NULL,
  "personalityType" "CharacterPersonalityType" NOT NULL,
  "personalityValue" INTEGER NOT NULL,
  "weaponId" TEXT NOT NULL,
  "subWeaponId" TEXT NOT NULL,
  "armorId" TEXT NOT NULL,
  "optEquipId" TEXT NOT NULL,
  "speEquipId" TEXT NOT NULL,
  "cooking" TEXT[],
  "modifiers" TEXT[],
  "partnerSkillAId" TEXT,
  "partnerSkillAType" "PartnerSkillType" NOT NULL,
  "partnerSkillBId" TEXT,
  "partnerSkillBType" "PartnerSkillType" NOT NULL,
  "masterId" TEXT NOT NULL,
  "details" TEXT,
  "statisticId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "character_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "character_local" (
  "id" TEXT,
  "name" TEXT,
  "lv" INTEGER,
  "str" INTEGER,
  "int" INTEGER,
  "vit" INTEGER,
  "agi" INTEGER,
  "dex" INTEGER,
  "personalityType" "CharacterPersonalityType",
  "personalityValue" INTEGER,
  "weaponId" TEXT,
  "subWeaponId" TEXT,
  "armorId" TEXT,
  "optEquipId" TEXT,
  "speEquipId" TEXT,
  "cooking" TEXT[],
  "modifiers" TEXT[],
  "partnerSkillAId" TEXT,
  "partnerSkillAType" "PartnerSkillType",
  "partnerSkillBId" TEXT,
  "partnerSkillBType" "PartnerSkillType",
  "masterId" TEXT,
  "details" TEXT,
  "statisticId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "character_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "character" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'lv' = ANY(local.changed_columns)
      THEN local."lv"
      ELSE synced."lv"
    END AS "lv",
   CASE
    WHEN 'str' = ANY(local.changed_columns)
      THEN local."str"
      ELSE synced."str"
    END AS "str",
   CASE
    WHEN 'int' = ANY(local.changed_columns)
      THEN local."int"
      ELSE synced."int"
    END AS "int",
   CASE
    WHEN 'vit' = ANY(local.changed_columns)
      THEN local."vit"
      ELSE synced."vit"
    END AS "vit",
   CASE
    WHEN 'agi' = ANY(local.changed_columns)
      THEN local."agi"
      ELSE synced."agi"
    END AS "agi",
   CASE
    WHEN 'dex' = ANY(local.changed_columns)
      THEN local."dex"
      ELSE synced."dex"
    END AS "dex",
   CASE
    WHEN 'personalityType' = ANY(local.changed_columns)
      THEN local."personalityType"
      ELSE synced."personalityType"
    END AS "personalityType",
   CASE
    WHEN 'personalityValue' = ANY(local.changed_columns)
      THEN local."personalityValue"
      ELSE synced."personalityValue"
    END AS "personalityValue",
   CASE
    WHEN 'weaponId' = ANY(local.changed_columns)
      THEN local."weaponId"
      ELSE synced."weaponId"
    END AS "weaponId",
   CASE
    WHEN 'subWeaponId' = ANY(local.changed_columns)
      THEN local."subWeaponId"
      ELSE synced."subWeaponId"
    END AS "subWeaponId",
   CASE
    WHEN 'armorId' = ANY(local.changed_columns)
      THEN local."armorId"
      ELSE synced."armorId"
    END AS "armorId",
   CASE
    WHEN 'optEquipId' = ANY(local.changed_columns)
      THEN local."optEquipId"
      ELSE synced."optEquipId"
    END AS "optEquipId",
   CASE
    WHEN 'speEquipId' = ANY(local.changed_columns)
      THEN local."speEquipId"
      ELSE synced."speEquipId"
    END AS "speEquipId",
   CASE
    WHEN 'cooking' = ANY(local.changed_columns)
      THEN local."cooking"
      ELSE synced."cooking"
    END AS "cooking",
   CASE
    WHEN 'modifiers' = ANY(local.changed_columns)
      THEN local."modifiers"
      ELSE synced."modifiers"
    END AS "modifiers",
   CASE
    WHEN 'partnerSkillAId' = ANY(local.changed_columns)
      THEN local."partnerSkillAId"
      ELSE synced."partnerSkillAId"
    END AS "partnerSkillAId",
   CASE
    WHEN 'partnerSkillAType' = ANY(local.changed_columns)
      THEN local."partnerSkillAType"
      ELSE synced."partnerSkillAType"
    END AS "partnerSkillAType",
   CASE
    WHEN 'partnerSkillBId' = ANY(local.changed_columns)
      THEN local."partnerSkillBId"
      ELSE synced."partnerSkillBId"
    END AS "partnerSkillBId",
   CASE
    WHEN 'partnerSkillBType' = ANY(local.changed_columns)
      THEN local."partnerSkillBType"
      ELSE synced."partnerSkillBType"
    END AS "partnerSkillBType",
   CASE
    WHEN 'masterId' = ANY(local.changed_columns)
      THEN local."masterId"
      ELSE synced."masterId"
    END AS "masterId",
   CASE
    WHEN 'details' = ANY(local.changed_columns)
      THEN local."details"
      ELSE synced."details"
    END AS "details",
   CASE
    WHEN 'statisticId' = ANY(local.changed_columns)
      THEN local."statisticId"
      ELSE synced."statisticId"
    END AS "statisticId"
  FROM "character_synced" AS synced
  FULL OUTER JOIN "character_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION character_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "character_local" (
    "id", "name", "lv", "str", "int", "vit", "agi", "dex", "personalityType", "personalityValue", "weaponId", "subWeaponId", "armorId", "optEquipId", "speEquipId", "cooking", "modifiers", "partnerSkillAId", "partnerSkillAType", "partnerSkillBId", "partnerSkillBType", "masterId", "details", "statisticId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."lv", NEW."str", NEW."int", NEW."vit", NEW."agi", NEW."dex", NEW."personalityType", NEW."personalityValue", NEW."weaponId", NEW."subWeaponId", NEW."armorId", NEW."optEquipId", NEW."speEquipId", NEW."cooking", NEW."modifiers", NEW."partnerSkillAId", NEW."partnerSkillAType", NEW."partnerSkillBId", NEW."partnerSkillBType", NEW."masterId", NEW."details", NEW."statisticId",
    ARRAY['name', 'lv', 'str', 'int', 'vit', 'agi', 'dex', 'personalityType', 'personalityValue', 'weaponId', 'subWeaponId', 'armorId', 'optEquipId', 'speEquipId', 'cooking', 'modifiers', 'partnerSkillAId', 'partnerSkillAType', 'partnerSkillBId', 'partnerSkillBType', 'masterId', 'details', 'statisticId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'character',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'lv', NEW."lv",
      'str', NEW."str",
      'int', NEW."int",
      'vit', NEW."vit",
      'agi', NEW."agi",
      'dex', NEW."dex",
      'personalityType', NEW."personalityType",
      'personalityValue', NEW."personalityValue",
      'weaponId', NEW."weaponId",
      'subWeaponId', NEW."subWeaponId",
      'armorId', NEW."armorId",
      'optEquipId', NEW."optEquipId",
      'speEquipId', NEW."speEquipId",
      'cooking', NEW."cooking",
      'modifiers', NEW."modifiers",
      'partnerSkillAId', NEW."partnerSkillAId",
      'partnerSkillAType', NEW."partnerSkillAType",
      'partnerSkillBId', NEW."partnerSkillBId",
      'partnerSkillBType', NEW."partnerSkillBType",
      'masterId', NEW."masterId",
      'details', NEW."details",
      'statisticId', NEW."statisticId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION character_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "character_synced"%ROWTYPE;
    local "character_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "character_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "character_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."lv" IS DISTINCT FROM synced."lv" THEN
      changed_cols := array_append(changed_cols, 'lv');
    END IF;
    IF NEW."str" IS DISTINCT FROM synced."str" THEN
      changed_cols := array_append(changed_cols, 'str');
    END IF;
    IF NEW."int" IS DISTINCT FROM synced."int" THEN
      changed_cols := array_append(changed_cols, 'int');
    END IF;
    IF NEW."vit" IS DISTINCT FROM synced."vit" THEN
      changed_cols := array_append(changed_cols, 'vit');
    END IF;
    IF NEW."agi" IS DISTINCT FROM synced."agi" THEN
      changed_cols := array_append(changed_cols, 'agi');
    END IF;
    IF NEW."dex" IS DISTINCT FROM synced."dex" THEN
      changed_cols := array_append(changed_cols, 'dex');
    END IF;
    IF NEW."personalityType" IS DISTINCT FROM synced."personalityType" THEN
      changed_cols := array_append(changed_cols, 'personalityType');
    END IF;
    IF NEW."personalityValue" IS DISTINCT FROM synced."personalityValue" THEN
      changed_cols := array_append(changed_cols, 'personalityValue');
    END IF;
    IF NEW."weaponId" IS DISTINCT FROM synced."weaponId" THEN
      changed_cols := array_append(changed_cols, 'weaponId');
    END IF;
    IF NEW."subWeaponId" IS DISTINCT FROM synced."subWeaponId" THEN
      changed_cols := array_append(changed_cols, 'subWeaponId');
    END IF;
    IF NEW."armorId" IS DISTINCT FROM synced."armorId" THEN
      changed_cols := array_append(changed_cols, 'armorId');
    END IF;
    IF NEW."optEquipId" IS DISTINCT FROM synced."optEquipId" THEN
      changed_cols := array_append(changed_cols, 'optEquipId');
    END IF;
    IF NEW."speEquipId" IS DISTINCT FROM synced."speEquipId" THEN
      changed_cols := array_append(changed_cols, 'speEquipId');
    END IF;
    IF NEW."cooking" IS DISTINCT FROM synced."cooking" THEN
      changed_cols := array_append(changed_cols, 'cooking');
    END IF;
    IF NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN
      changed_cols := array_append(changed_cols, 'modifiers');
    END IF;
    IF NEW."partnerSkillAId" IS DISTINCT FROM synced."partnerSkillAId" THEN
      changed_cols := array_append(changed_cols, 'partnerSkillAId');
    END IF;
    IF NEW."partnerSkillAType" IS DISTINCT FROM synced."partnerSkillAType" THEN
      changed_cols := array_append(changed_cols, 'partnerSkillAType');
    END IF;
    IF NEW."partnerSkillBId" IS DISTINCT FROM synced."partnerSkillBId" THEN
      changed_cols := array_append(changed_cols, 'partnerSkillBId');
    END IF;
    IF NEW."partnerSkillBType" IS DISTINCT FROM synced."partnerSkillBType" THEN
      changed_cols := array_append(changed_cols, 'partnerSkillBType');
    END IF;
    IF NEW."masterId" IS DISTINCT FROM synced."masterId" THEN
      changed_cols := array_append(changed_cols, 'masterId');
    END IF;
    IF NEW."details" IS DISTINCT FROM synced."details" THEN
      changed_cols := array_append(changed_cols, 'details');
    END IF;
    IF NEW."statisticId" IS DISTINCT FROM synced."statisticId" THEN
      changed_cols := array_append(changed_cols, 'statisticId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "character_local" (
        "id", "name", "lv", "str", "int", "vit", "agi", "dex", "personalityType", "personalityValue", "weaponId", "subWeaponId", "armorId", "optEquipId", "speEquipId", "cooking", "modifiers", "partnerSkillAId", "partnerSkillAType", "partnerSkillBId", "partnerSkillBType", "masterId", "details", "statisticId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."lv", NEW."str", NEW."int", NEW."vit", NEW."agi", NEW."dex", NEW."personalityType", NEW."personalityValue", NEW."weaponId", NEW."subWeaponId", NEW."armorId", NEW."optEquipId", NEW."speEquipId", NEW."cooking", NEW."modifiers", NEW."partnerSkillAId", NEW."partnerSkillAType", NEW."partnerSkillBId", NEW."partnerSkillBType", NEW."masterId", NEW."details", NEW."statisticId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "character_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "lv" = CASE WHEN NEW."lv" IS DISTINCT FROM synced."lv" THEN NEW."lv" ELSE local."lv" END,
    "str" = CASE WHEN NEW."str" IS DISTINCT FROM synced."str" THEN NEW."str" ELSE local."str" END,
    "int" = CASE WHEN NEW."int" IS DISTINCT FROM synced."int" THEN NEW."int" ELSE local."int" END,
    "vit" = CASE WHEN NEW."vit" IS DISTINCT FROM synced."vit" THEN NEW."vit" ELSE local."vit" END,
    "agi" = CASE WHEN NEW."agi" IS DISTINCT FROM synced."agi" THEN NEW."agi" ELSE local."agi" END,
    "dex" = CASE WHEN NEW."dex" IS DISTINCT FROM synced."dex" THEN NEW."dex" ELSE local."dex" END,
    "personalityType" = CASE WHEN NEW."personalityType" IS DISTINCT FROM synced."personalityType" THEN NEW."personalityType" ELSE local."personalityType" END,
    "personalityValue" = CASE WHEN NEW."personalityValue" IS DISTINCT FROM synced."personalityValue" THEN NEW."personalityValue" ELSE local."personalityValue" END,
    "weaponId" = CASE WHEN NEW."weaponId" IS DISTINCT FROM synced."weaponId" THEN NEW."weaponId" ELSE local."weaponId" END,
    "subWeaponId" = CASE WHEN NEW."subWeaponId" IS DISTINCT FROM synced."subWeaponId" THEN NEW."subWeaponId" ELSE local."subWeaponId" END,
    "armorId" = CASE WHEN NEW."armorId" IS DISTINCT FROM synced."armorId" THEN NEW."armorId" ELSE local."armorId" END,
    "optEquipId" = CASE WHEN NEW."optEquipId" IS DISTINCT FROM synced."optEquipId" THEN NEW."optEquipId" ELSE local."optEquipId" END,
    "speEquipId" = CASE WHEN NEW."speEquipId" IS DISTINCT FROM synced."speEquipId" THEN NEW."speEquipId" ELSE local."speEquipId" END,
    "cooking" = CASE WHEN NEW."cooking" IS DISTINCT FROM synced."cooking" THEN NEW."cooking" ELSE local."cooking" END,
    "modifiers" = CASE WHEN NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN NEW."modifiers" ELSE local."modifiers" END,
    "partnerSkillAId" = CASE WHEN NEW."partnerSkillAId" IS DISTINCT FROM synced."partnerSkillAId" THEN NEW."partnerSkillAId" ELSE local."partnerSkillAId" END,
    "partnerSkillAType" = CASE WHEN NEW."partnerSkillAType" IS DISTINCT FROM synced."partnerSkillAType" THEN NEW."partnerSkillAType" ELSE local."partnerSkillAType" END,
    "partnerSkillBId" = CASE WHEN NEW."partnerSkillBId" IS DISTINCT FROM synced."partnerSkillBId" THEN NEW."partnerSkillBId" ELSE local."partnerSkillBId" END,
    "partnerSkillBType" = CASE WHEN NEW."partnerSkillBType" IS DISTINCT FROM synced."partnerSkillBType" THEN NEW."partnerSkillBType" ELSE local."partnerSkillBType" END,
    "masterId" = CASE WHEN NEW."masterId" IS DISTINCT FROM synced."masterId" THEN NEW."masterId" ELSE local."masterId" END,
    "details" = CASE WHEN NEW."details" IS DISTINCT FROM synced."details" THEN NEW."details" ELSE local."details" END,
    "statisticId" = CASE WHEN NEW."statisticId" IS DISTINCT FROM synced."statisticId" THEN NEW."statisticId" ELSE local."statisticId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'character',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'lv', COALESCE(NEW."lv", local."lv"),
      'str', COALESCE(NEW."str", local."str"),
      'int', COALESCE(NEW."int", local."int"),
      'vit', COALESCE(NEW."vit", local."vit"),
      'agi', COALESCE(NEW."agi", local."agi"),
      'dex', COALESCE(NEW."dex", local."dex"),
      'personalityType', COALESCE(NEW."personalityType", local."personalityType"),
      'personalityValue', COALESCE(NEW."personalityValue", local."personalityValue"),
      'weaponId', COALESCE(NEW."weaponId", local."weaponId"),
      'subWeaponId', COALESCE(NEW."subWeaponId", local."subWeaponId"),
      'armorId', COALESCE(NEW."armorId", local."armorId"),
      'optEquipId', COALESCE(NEW."optEquipId", local."optEquipId"),
      'speEquipId', COALESCE(NEW."speEquipId", local."speEquipId"),
      'cooking', COALESCE(NEW."cooking", local."cooking"),
      'modifiers', COALESCE(NEW."modifiers", local."modifiers"),
      'partnerSkillAId', COALESCE(NEW."partnerSkillAId", local."partnerSkillAId"),
      'partnerSkillAType', COALESCE(NEW."partnerSkillAType", local."partnerSkillAType"),
      'partnerSkillBId', COALESCE(NEW."partnerSkillBId", local."partnerSkillBId"),
      'partnerSkillBType', COALESCE(NEW."partnerSkillBType", local."partnerSkillBType"),
      'masterId', COALESCE(NEW."masterId", local."masterId"),
      'details', COALESCE(NEW."details", local."details"),
      'statisticId', COALESCE(NEW."statisticId", local."statisticId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION character_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "character_local" WHERE "id" = OLD."id") THEN
    UPDATE "character_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "character_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'character',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER character_insert
INSTEAD OF INSERT ON "character"
FOR EACH ROW EXECUTE FUNCTION character_insert_trigger();

CREATE OR REPLACE TRIGGER character_update
INSTEAD OF UPDATE ON "character"
FOR EACH ROW EXECUTE FUNCTION character_update_trigger();

CREATE OR REPLACE TRIGGER character_delete
INSTEAD OF DELETE ON "character"
FOR EACH ROW EXECUTE FUNCTION character_delete_trigger();


CREATE OR REPLACE FUNCTION character_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "character_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION character_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "character_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "character_synced"
FOR EACH ROW EXECUTE FUNCTION character_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "character_synced"
FOR EACH ROW EXECUTE FUNCTION character_delete_local_on_synced_delete_trigger();

-- CreateTable
-- character_skill
CREATE TABLE IF NOT EXISTS "character_skill_synced" (
  "id" TEXT NOT NULL,
  "lv" INTEGER NOT NULL,
  "isStarGem" BOOLEAN NOT NULL,
  "templateId" TEXT NOT NULL,
  "characterId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "character_skill_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "character_skill_local" (
  "id" TEXT,
  "lv" INTEGER,
  "isStarGem" BOOLEAN,
  "templateId" TEXT,
  "characterId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "character_skill_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "character_skill" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'lv' = ANY(local.changed_columns)
      THEN local."lv"
      ELSE synced."lv"
    END AS "lv",
   CASE
    WHEN 'isStarGem' = ANY(local.changed_columns)
      THEN local."isStarGem"
      ELSE synced."isStarGem"
    END AS "isStarGem",
   CASE
    WHEN 'templateId' = ANY(local.changed_columns)
      THEN local."templateId"
      ELSE synced."templateId"
    END AS "templateId",
   CASE
    WHEN 'characterId' = ANY(local.changed_columns)
      THEN local."characterId"
      ELSE synced."characterId"
    END AS "characterId"
  FROM "character_skill_synced" AS synced
  FULL OUTER JOIN "character_skill_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION character_skill_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "character_skill_local" (
    "id", "lv", "isStarGem", "templateId", "characterId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."lv", NEW."isStarGem", NEW."templateId", NEW."characterId",
    ARRAY['lv', 'isStarGem', 'templateId', 'characterId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'character_skill',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'lv', NEW."lv",
      'isStarGem', NEW."isStarGem",
      'templateId', NEW."templateId",
      'characterId', NEW."characterId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION character_skill_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "character_skill_synced"%ROWTYPE;
    local "character_skill_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "character_skill_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "character_skill_local" WHERE "id" = NEW."id";
    
    IF NEW."lv" IS DISTINCT FROM synced."lv" THEN
      changed_cols := array_append(changed_cols, 'lv');
    END IF;
    IF NEW."isStarGem" IS DISTINCT FROM synced."isStarGem" THEN
      changed_cols := array_append(changed_cols, 'isStarGem');
    END IF;
    IF NEW."templateId" IS DISTINCT FROM synced."templateId" THEN
      changed_cols := array_append(changed_cols, 'templateId');
    END IF;
    IF NEW."characterId" IS DISTINCT FROM synced."characterId" THEN
      changed_cols := array_append(changed_cols, 'characterId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "character_skill_local" (
        "id", "lv", "isStarGem", "templateId", "characterId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."lv", NEW."isStarGem", NEW."templateId", NEW."characterId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "character_skill_local"
    SET
        
    "lv" = CASE WHEN NEW."lv" IS DISTINCT FROM synced."lv" THEN NEW."lv" ELSE local."lv" END,
    "isStarGem" = CASE WHEN NEW."isStarGem" IS DISTINCT FROM synced."isStarGem" THEN NEW."isStarGem" ELSE local."isStarGem" END,
    "templateId" = CASE WHEN NEW."templateId" IS DISTINCT FROM synced."templateId" THEN NEW."templateId" ELSE local."templateId" END,
    "characterId" = CASE WHEN NEW."characterId" IS DISTINCT FROM synced."characterId" THEN NEW."characterId" ELSE local."characterId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'character_skill',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'lv', COALESCE(NEW."lv", local."lv"),
      'isStarGem', COALESCE(NEW."isStarGem", local."isStarGem"),
      'templateId', COALESCE(NEW."templateId", local."templateId"),
      'characterId', COALESCE(NEW."characterId", local."characterId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION character_skill_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "character_skill_local" WHERE "id" = OLD."id") THEN
    UPDATE "character_skill_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "character_skill_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'character_skill',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER character_skill_insert
INSTEAD OF INSERT ON "character_skill"
FOR EACH ROW EXECUTE FUNCTION character_skill_insert_trigger();

CREATE OR REPLACE TRIGGER character_skill_update
INSTEAD OF UPDATE ON "character_skill"
FOR EACH ROW EXECUTE FUNCTION character_skill_update_trigger();

CREATE OR REPLACE TRIGGER character_skill_delete
INSTEAD OF DELETE ON "character_skill"
FOR EACH ROW EXECUTE FUNCTION character_skill_delete_trigger();


CREATE OR REPLACE FUNCTION character_skill_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "character_skill_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION character_skill_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "character_skill_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "character_skill_synced"
FOR EACH ROW EXECUTE FUNCTION character_skill_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "character_skill_synced"
FOR EACH ROW EXECUTE FUNCTION character_skill_delete_local_on_synced_delete_trigger();

-- CreateTable
-- combo
CREATE TABLE IF NOT EXISTS "combo_synced" (
  "id" TEXT NOT NULL,
  "disable" BOOLEAN NOT NULL,
  "name" TEXT NOT NULL,
  "characterId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "combo_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "combo_local" (
  "id" TEXT,
  "disable" BOOLEAN,
  "name" TEXT,
  "characterId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "combo_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "combo" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'disable' = ANY(local.changed_columns)
      THEN local."disable"
      ELSE synced."disable"
    END AS "disable",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'characterId' = ANY(local.changed_columns)
      THEN local."characterId"
      ELSE synced."characterId"
    END AS "characterId"
  FROM "combo_synced" AS synced
  FULL OUTER JOIN "combo_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION combo_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "combo_local" (
    "id", "disable", "name", "characterId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."disable", NEW."name", NEW."characterId",
    ARRAY['disable', 'name', 'characterId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'combo',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'disable', NEW."disable",
      'name', NEW."name",
      'characterId', NEW."characterId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION combo_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "combo_synced"%ROWTYPE;
    local "combo_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "combo_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "combo_local" WHERE "id" = NEW."id";
    
    IF NEW."disable" IS DISTINCT FROM synced."disable" THEN
      changed_cols := array_append(changed_cols, 'disable');
    END IF;
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."characterId" IS DISTINCT FROM synced."characterId" THEN
      changed_cols := array_append(changed_cols, 'characterId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "combo_local" (
        "id", "disable", "name", "characterId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."disable", NEW."name", NEW."characterId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "combo_local"
    SET
        
    "disable" = CASE WHEN NEW."disable" IS DISTINCT FROM synced."disable" THEN NEW."disable" ELSE local."disable" END,
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "characterId" = CASE WHEN NEW."characterId" IS DISTINCT FROM synced."characterId" THEN NEW."characterId" ELSE local."characterId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'combo',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'disable', COALESCE(NEW."disable", local."disable"),
      'name', COALESCE(NEW."name", local."name"),
      'characterId', COALESCE(NEW."characterId", local."characterId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION combo_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "combo_local" WHERE "id" = OLD."id") THEN
    UPDATE "combo_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "combo_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'combo',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER combo_insert
INSTEAD OF INSERT ON "combo"
FOR EACH ROW EXECUTE FUNCTION combo_insert_trigger();

CREATE OR REPLACE TRIGGER combo_update
INSTEAD OF UPDATE ON "combo"
FOR EACH ROW EXECUTE FUNCTION combo_update_trigger();

CREATE OR REPLACE TRIGGER combo_delete
INSTEAD OF DELETE ON "combo"
FOR EACH ROW EXECUTE FUNCTION combo_delete_trigger();


CREATE OR REPLACE FUNCTION combo_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "combo_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION combo_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "combo_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "combo_synced"
FOR EACH ROW EXECUTE FUNCTION combo_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "combo_synced"
FOR EACH ROW EXECUTE FUNCTION combo_delete_local_on_synced_delete_trigger();

-- CreateTable
-- combo_step
CREATE TABLE IF NOT EXISTS "combo_step_synced" (
  "id" TEXT NOT NULL,
  "type" "ComboStepType" NOT NULL,
  "characterSkillId" TEXT NOT NULL,
  "comboId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "combo_step_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "combo_step_local" (
  "id" TEXT,
  "type" "ComboStepType",
  "characterSkillId" TEXT,
  "comboId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "combo_step_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "combo_step" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   CASE
    WHEN 'characterSkillId' = ANY(local.changed_columns)
      THEN local."characterSkillId"
      ELSE synced."characterSkillId"
    END AS "characterSkillId",
   CASE
    WHEN 'comboId' = ANY(local.changed_columns)
      THEN local."comboId"
      ELSE synced."comboId"
    END AS "comboId"
  FROM "combo_step_synced" AS synced
  FULL OUTER JOIN "combo_step_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION combo_step_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "combo_step_local" (
    "id", "type", "characterSkillId", "comboId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."type", NEW."characterSkillId", NEW."comboId",
    ARRAY['type', 'characterSkillId', 'comboId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'combo_step',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'type', NEW."type",
      'characterSkillId', NEW."characterSkillId",
      'comboId', NEW."comboId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION combo_step_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "combo_step_synced"%ROWTYPE;
    local "combo_step_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "combo_step_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "combo_step_local" WHERE "id" = NEW."id";
    
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."characterSkillId" IS DISTINCT FROM synced."characterSkillId" THEN
      changed_cols := array_append(changed_cols, 'characterSkillId');
    END IF;
    IF NEW."comboId" IS DISTINCT FROM synced."comboId" THEN
      changed_cols := array_append(changed_cols, 'comboId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "combo_step_local" (
        "id", "type", "characterSkillId", "comboId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."type", NEW."characterSkillId", NEW."comboId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "combo_step_local"
    SET
        
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "characterSkillId" = CASE WHEN NEW."characterSkillId" IS DISTINCT FROM synced."characterSkillId" THEN NEW."characterSkillId" ELSE local."characterSkillId" END,
    "comboId" = CASE WHEN NEW."comboId" IS DISTINCT FROM synced."comboId" THEN NEW."comboId" ELSE local."comboId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'combo_step',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'type', COALESCE(NEW."type", local."type"),
      'characterSkillId', COALESCE(NEW."characterSkillId", local."characterSkillId"),
      'comboId', COALESCE(NEW."comboId", local."comboId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION combo_step_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "combo_step_local" WHERE "id" = OLD."id") THEN
    UPDATE "combo_step_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "combo_step_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'combo_step',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER combo_step_insert
INSTEAD OF INSERT ON "combo_step"
FOR EACH ROW EXECUTE FUNCTION combo_step_insert_trigger();

CREATE OR REPLACE TRIGGER combo_step_update
INSTEAD OF UPDATE ON "combo_step"
FOR EACH ROW EXECUTE FUNCTION combo_step_update_trigger();

CREATE OR REPLACE TRIGGER combo_step_delete
INSTEAD OF DELETE ON "combo_step"
FOR EACH ROW EXECUTE FUNCTION combo_step_delete_trigger();


CREATE OR REPLACE FUNCTION combo_step_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "combo_step_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION combo_step_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "combo_step_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "combo_step_synced"
FOR EACH ROW EXECUTE FUNCTION combo_step_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "combo_step_synced"
FOR EACH ROW EXECUTE FUNCTION combo_step_delete_local_on_synced_delete_trigger();

-- CreateTable
-- consumable
CREATE TABLE IF NOT EXISTS "consumable_synced" (
  "type" "ConsumableType" NOT NULL,
  "effectDuration" INTEGER NOT NULL,
  "effects" TEXT[],
  "itemId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "consumable_synced_pkey" PRIMARY KEY ("itemId")
);
CREATE TABLE IF NOT EXISTS "consumable_local" (
  "type" "ConsumableType",
  "effectDuration" INTEGER,
  "effects" TEXT[],
  "itemId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "consumable_local_pkey" PRIMARY KEY ("itemId")
);

CREATE OR REPLACE VIEW "consumable" AS
  SELECT
     CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   CASE
    WHEN 'effectDuration' = ANY(local.changed_columns)
      THEN local."effectDuration"
      ELSE synced."effectDuration"
    END AS "effectDuration",
   CASE
    WHEN 'effects' = ANY(local.changed_columns)
      THEN local."effects"
      ELSE synced."effects"
    END AS "effects",
   COALESCE(local."itemId", synced."itemId") AS "itemId"
  FROM "consumable_synced" AS synced
  FULL OUTER JOIN "consumable_local" AS local
  ON synced."itemId" = local."itemId"
  WHERE (local."itemId" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION consumable_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "consumable_local" (
    "type", "effectDuration", "effects", "itemId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."type", NEW."effectDuration", NEW."effects", NEW."itemId",
    ARRAY['type', 'effectDuration', 'effects'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'consumable',
    'insert',
    jsonb_build_object(
        'type', NEW."type",
      'effectDuration', NEW."effectDuration",
      'effects', NEW."effects",
      'itemId', NEW."itemId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION consumable_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "consumable_synced"%ROWTYPE;
    local "consumable_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "consumable_synced" WHERE "itemId" = NEW."itemId";
    SELECT * INTO local FROM "consumable_local" WHERE "itemId" = NEW."itemId";
    
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."effectDuration" IS DISTINCT FROM synced."effectDuration" THEN
      changed_cols := array_append(changed_cols, 'effectDuration');
    END IF;
    IF NEW."effects" IS DISTINCT FROM synced."effects" THEN
      changed_cols := array_append(changed_cols, 'effects');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "consumable_local" (
        "type", "effectDuration", "effects", "itemId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."type", NEW."effectDuration", NEW."effects", NEW."itemId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "consumable_local"
    SET
        
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "effectDuration" = CASE WHEN NEW."effectDuration" IS DISTINCT FROM synced."effectDuration" THEN NEW."effectDuration" ELSE local."effectDuration" END,
    "effects" = CASE WHEN NEW."effects" IS DISTINCT FROM synced."effects" THEN NEW."effects" ELSE local."effects" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "itemId" = NEW."itemId";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'consumable',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'type', COALESCE(NEW."type", local."type"),
      'effectDuration', COALESCE(NEW."effectDuration", local."effectDuration"),
      'effects', COALESCE(NEW."effects", local."effects"),
      'itemId', COALESCE(NEW."itemId", local."itemId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION consumable_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "consumable_local" WHERE "itemId" = OLD."itemId") THEN
    UPDATE "consumable_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "itemId" = OLD."itemId";
    ELSE
    INSERT INTO "consumable_local" (
        itemId,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."itemId",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'consumable',
    'delete',
    jsonb_build_object('itemId', OLD."itemId"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER consumable_insert
INSTEAD OF INSERT ON "consumable"
FOR EACH ROW EXECUTE FUNCTION consumable_insert_trigger();

CREATE OR REPLACE TRIGGER consumable_update
INSTEAD OF UPDATE ON "consumable"
FOR EACH ROW EXECUTE FUNCTION consumable_update_trigger();

CREATE OR REPLACE TRIGGER consumable_delete
INSTEAD OF DELETE ON "consumable"
FOR EACH ROW EXECUTE FUNCTION consumable_delete_trigger();


CREATE OR REPLACE FUNCTION consumable_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "consumable_local"
  WHERE "itemId" = NEW."itemId"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION consumable_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "consumable_local"
  WHERE "itemId" = OLD."itemId";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "consumable_synced"
FOR EACH ROW EXECUTE FUNCTION consumable_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "consumable_synced"
FOR EACH ROW EXECUTE FUNCTION consumable_delete_local_on_synced_delete_trigger();

-- CreateTable
-- crystal
CREATE TABLE IF NOT EXISTS "crystal_synced" (
  "type" "CrystalType" NOT NULL,
  "modifiers" TEXT[],
  "itemId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "crystal_synced_pkey" PRIMARY KEY ("itemId")
);
CREATE TABLE IF NOT EXISTS "crystal_local" (
  "type" "CrystalType",
  "modifiers" TEXT[],
  "itemId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "crystal_local_pkey" PRIMARY KEY ("itemId")
);

CREATE OR REPLACE VIEW "crystal" AS
  SELECT
     CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   CASE
    WHEN 'modifiers' = ANY(local.changed_columns)
      THEN local."modifiers"
      ELSE synced."modifiers"
    END AS "modifiers",
   COALESCE(local."itemId", synced."itemId") AS "itemId"
  FROM "crystal_synced" AS synced
  FULL OUTER JOIN "crystal_local" AS local
  ON synced."itemId" = local."itemId"
  WHERE (local."itemId" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION crystal_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "crystal_local" (
    "type", "modifiers", "itemId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."type", NEW."modifiers", NEW."itemId",
    ARRAY['type', 'modifiers'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'crystal',
    'insert',
    jsonb_build_object(
        'type', NEW."type",
      'modifiers', NEW."modifiers",
      'itemId', NEW."itemId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION crystal_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "crystal_synced"%ROWTYPE;
    local "crystal_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "crystal_synced" WHERE "itemId" = NEW."itemId";
    SELECT * INTO local FROM "crystal_local" WHERE "itemId" = NEW."itemId";
    
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN
      changed_cols := array_append(changed_cols, 'modifiers');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "crystal_local" (
        "type", "modifiers", "itemId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."type", NEW."modifiers", NEW."itemId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "crystal_local"
    SET
        
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "modifiers" = CASE WHEN NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN NEW."modifiers" ELSE local."modifiers" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "itemId" = NEW."itemId";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'crystal',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'type', COALESCE(NEW."type", local."type"),
      'modifiers', COALESCE(NEW."modifiers", local."modifiers"),
      'itemId', COALESCE(NEW."itemId", local."itemId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION crystal_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "crystal_local" WHERE "itemId" = OLD."itemId") THEN
    UPDATE "crystal_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "itemId" = OLD."itemId";
    ELSE
    INSERT INTO "crystal_local" (
        itemId,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."itemId",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'crystal',
    'delete',
    jsonb_build_object('itemId', OLD."itemId"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER crystal_insert
INSTEAD OF INSERT ON "crystal"
FOR EACH ROW EXECUTE FUNCTION crystal_insert_trigger();

CREATE OR REPLACE TRIGGER crystal_update
INSTEAD OF UPDATE ON "crystal"
FOR EACH ROW EXECUTE FUNCTION crystal_update_trigger();

CREATE OR REPLACE TRIGGER crystal_delete
INSTEAD OF DELETE ON "crystal"
FOR EACH ROW EXECUTE FUNCTION crystal_delete_trigger();


CREATE OR REPLACE FUNCTION crystal_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "crystal_local"
  WHERE "itemId" = NEW."itemId"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION crystal_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "crystal_local"
  WHERE "itemId" = OLD."itemId";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "crystal_synced"
FOR EACH ROW EXECUTE FUNCTION crystal_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "crystal_synced"
FOR EACH ROW EXECUTE FUNCTION crystal_delete_local_on_synced_delete_trigger();

-- CreateTable
-- drop_item
CREATE TABLE IF NOT EXISTS "drop_item_synced" (
  "id" TEXT NOT NULL,
  "itemId" TEXT NOT NULL,
  "probability" INTEGER NOT NULL,
  "relatedPartType" "BossPartType" NOT NULL,
  "relatedPartInfo" TEXT NOT NULL,
  "breakRewardType" "BossPartBreakRewardType" NOT NULL,
  "dropById" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "drop_item_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "drop_item_local" (
  "id" TEXT,
  "itemId" TEXT,
  "probability" INTEGER,
  "relatedPartType" "BossPartType",
  "relatedPartInfo" TEXT,
  "breakRewardType" "BossPartBreakRewardType",
  "dropById" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "drop_item_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "drop_item" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'itemId' = ANY(local.changed_columns)
      THEN local."itemId"
      ELSE synced."itemId"
    END AS "itemId",
   CASE
    WHEN 'probability' = ANY(local.changed_columns)
      THEN local."probability"
      ELSE synced."probability"
    END AS "probability",
   CASE
    WHEN 'relatedPartType' = ANY(local.changed_columns)
      THEN local."relatedPartType"
      ELSE synced."relatedPartType"
    END AS "relatedPartType",
   CASE
    WHEN 'relatedPartInfo' = ANY(local.changed_columns)
      THEN local."relatedPartInfo"
      ELSE synced."relatedPartInfo"
    END AS "relatedPartInfo",
   CASE
    WHEN 'breakRewardType' = ANY(local.changed_columns)
      THEN local."breakRewardType"
      ELSE synced."breakRewardType"
    END AS "breakRewardType",
   CASE
    WHEN 'dropById' = ANY(local.changed_columns)
      THEN local."dropById"
      ELSE synced."dropById"
    END AS "dropById"
  FROM "drop_item_synced" AS synced
  FULL OUTER JOIN "drop_item_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION drop_item_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "drop_item_local" (
    "id", "itemId", "probability", "relatedPartType", "relatedPartInfo", "breakRewardType", "dropById",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."itemId", NEW."probability", NEW."relatedPartType", NEW."relatedPartInfo", NEW."breakRewardType", NEW."dropById",
    ARRAY['itemId', 'probability', 'relatedPartType', 'relatedPartInfo', 'breakRewardType', 'dropById'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'drop_item',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'itemId', NEW."itemId",
      'probability', NEW."probability",
      'relatedPartType', NEW."relatedPartType",
      'relatedPartInfo', NEW."relatedPartInfo",
      'breakRewardType', NEW."breakRewardType",
      'dropById', NEW."dropById"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION drop_item_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "drop_item_synced"%ROWTYPE;
    local "drop_item_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "drop_item_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "drop_item_local" WHERE "id" = NEW."id";
    
    IF NEW."itemId" IS DISTINCT FROM synced."itemId" THEN
      changed_cols := array_append(changed_cols, 'itemId');
    END IF;
    IF NEW."probability" IS DISTINCT FROM synced."probability" THEN
      changed_cols := array_append(changed_cols, 'probability');
    END IF;
    IF NEW."relatedPartType" IS DISTINCT FROM synced."relatedPartType" THEN
      changed_cols := array_append(changed_cols, 'relatedPartType');
    END IF;
    IF NEW."relatedPartInfo" IS DISTINCT FROM synced."relatedPartInfo" THEN
      changed_cols := array_append(changed_cols, 'relatedPartInfo');
    END IF;
    IF NEW."breakRewardType" IS DISTINCT FROM synced."breakRewardType" THEN
      changed_cols := array_append(changed_cols, 'breakRewardType');
    END IF;
    IF NEW."dropById" IS DISTINCT FROM synced."dropById" THEN
      changed_cols := array_append(changed_cols, 'dropById');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "drop_item_local" (
        "id", "itemId", "probability", "relatedPartType", "relatedPartInfo", "breakRewardType", "dropById",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."itemId", NEW."probability", NEW."relatedPartType", NEW."relatedPartInfo", NEW."breakRewardType", NEW."dropById",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "drop_item_local"
    SET
        
    "itemId" = CASE WHEN NEW."itemId" IS DISTINCT FROM synced."itemId" THEN NEW."itemId" ELSE local."itemId" END,
    "probability" = CASE WHEN NEW."probability" IS DISTINCT FROM synced."probability" THEN NEW."probability" ELSE local."probability" END,
    "relatedPartType" = CASE WHEN NEW."relatedPartType" IS DISTINCT FROM synced."relatedPartType" THEN NEW."relatedPartType" ELSE local."relatedPartType" END,
    "relatedPartInfo" = CASE WHEN NEW."relatedPartInfo" IS DISTINCT FROM synced."relatedPartInfo" THEN NEW."relatedPartInfo" ELSE local."relatedPartInfo" END,
    "breakRewardType" = CASE WHEN NEW."breakRewardType" IS DISTINCT FROM synced."breakRewardType" THEN NEW."breakRewardType" ELSE local."breakRewardType" END,
    "dropById" = CASE WHEN NEW."dropById" IS DISTINCT FROM synced."dropById" THEN NEW."dropById" ELSE local."dropById" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'drop_item',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'itemId', COALESCE(NEW."itemId", local."itemId"),
      'probability', COALESCE(NEW."probability", local."probability"),
      'relatedPartType', COALESCE(NEW."relatedPartType", local."relatedPartType"),
      'relatedPartInfo', COALESCE(NEW."relatedPartInfo", local."relatedPartInfo"),
      'breakRewardType', COALESCE(NEW."breakRewardType", local."breakRewardType"),
      'dropById', COALESCE(NEW."dropById", local."dropById")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION drop_item_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "drop_item_local" WHERE "id" = OLD."id") THEN
    UPDATE "drop_item_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "drop_item_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'drop_item',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER drop_item_insert
INSTEAD OF INSERT ON "drop_item"
FOR EACH ROW EXECUTE FUNCTION drop_item_insert_trigger();

CREATE OR REPLACE TRIGGER drop_item_update
INSTEAD OF UPDATE ON "drop_item"
FOR EACH ROW EXECUTE FUNCTION drop_item_update_trigger();

CREATE OR REPLACE TRIGGER drop_item_delete
INSTEAD OF DELETE ON "drop_item"
FOR EACH ROW EXECUTE FUNCTION drop_item_delete_trigger();


CREATE OR REPLACE FUNCTION drop_item_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "drop_item_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION drop_item_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "drop_item_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "drop_item_synced"
FOR EACH ROW EXECUTE FUNCTION drop_item_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "drop_item_synced"
FOR EACH ROW EXECUTE FUNCTION drop_item_delete_local_on_synced_delete_trigger();

-- CreateTable
-- image
CREATE TABLE IF NOT EXISTS "image_synced" (
  "id" TEXT NOT NULL,
  "dataUrl" TEXT NOT NULL,
  "npcId" TEXT,
  "weaponId" TEXT,
  "armorId" TEXT,
  "optEquipId" TEXT,
  "mobId" TEXT,
  "write_id" UUID,
  CONSTRAINT "image_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "image_local" (
  "id" TEXT,
  "dataUrl" TEXT,
  "npcId" TEXT,
  "weaponId" TEXT,
  "armorId" TEXT,
  "optEquipId" TEXT,
  "mobId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "image_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "image" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'dataUrl' = ANY(local.changed_columns)
      THEN local."dataUrl"
      ELSE synced."dataUrl"
    END AS "dataUrl",
   CASE
    WHEN 'npcId' = ANY(local.changed_columns)
      THEN local."npcId"
      ELSE synced."npcId"
    END AS "npcId",
   CASE
    WHEN 'weaponId' = ANY(local.changed_columns)
      THEN local."weaponId"
      ELSE synced."weaponId"
    END AS "weaponId",
   CASE
    WHEN 'armorId' = ANY(local.changed_columns)
      THEN local."armorId"
      ELSE synced."armorId"
    END AS "armorId",
   CASE
    WHEN 'optEquipId' = ANY(local.changed_columns)
      THEN local."optEquipId"
      ELSE synced."optEquipId"
    END AS "optEquipId",
   CASE
    WHEN 'mobId' = ANY(local.changed_columns)
      THEN local."mobId"
      ELSE synced."mobId"
    END AS "mobId"
  FROM "image_synced" AS synced
  FULL OUTER JOIN "image_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION image_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "image_local" (
    "id", "dataUrl", "npcId", "weaponId", "armorId", "optEquipId", "mobId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."dataUrl", NEW."npcId", NEW."weaponId", NEW."armorId", NEW."optEquipId", NEW."mobId",
    ARRAY['dataUrl', 'npcId', 'weaponId', 'armorId', 'optEquipId', 'mobId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'image',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'dataUrl', NEW."dataUrl",
      'npcId', NEW."npcId",
      'weaponId', NEW."weaponId",
      'armorId', NEW."armorId",
      'optEquipId', NEW."optEquipId",
      'mobId', NEW."mobId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION image_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "image_synced"%ROWTYPE;
    local "image_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "image_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "image_local" WHERE "id" = NEW."id";
    
    IF NEW."dataUrl" IS DISTINCT FROM synced."dataUrl" THEN
      changed_cols := array_append(changed_cols, 'dataUrl');
    END IF;
    IF NEW."npcId" IS DISTINCT FROM synced."npcId" THEN
      changed_cols := array_append(changed_cols, 'npcId');
    END IF;
    IF NEW."weaponId" IS DISTINCT FROM synced."weaponId" THEN
      changed_cols := array_append(changed_cols, 'weaponId');
    END IF;
    IF NEW."armorId" IS DISTINCT FROM synced."armorId" THEN
      changed_cols := array_append(changed_cols, 'armorId');
    END IF;
    IF NEW."optEquipId" IS DISTINCT FROM synced."optEquipId" THEN
      changed_cols := array_append(changed_cols, 'optEquipId');
    END IF;
    IF NEW."mobId" IS DISTINCT FROM synced."mobId" THEN
      changed_cols := array_append(changed_cols, 'mobId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "image_local" (
        "id", "dataUrl", "npcId", "weaponId", "armorId", "optEquipId", "mobId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."dataUrl", NEW."npcId", NEW."weaponId", NEW."armorId", NEW."optEquipId", NEW."mobId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "image_local"
    SET
        
    "dataUrl" = CASE WHEN NEW."dataUrl" IS DISTINCT FROM synced."dataUrl" THEN NEW."dataUrl" ELSE local."dataUrl" END,
    "npcId" = CASE WHEN NEW."npcId" IS DISTINCT FROM synced."npcId" THEN NEW."npcId" ELSE local."npcId" END,
    "weaponId" = CASE WHEN NEW."weaponId" IS DISTINCT FROM synced."weaponId" THEN NEW."weaponId" ELSE local."weaponId" END,
    "armorId" = CASE WHEN NEW."armorId" IS DISTINCT FROM synced."armorId" THEN NEW."armorId" ELSE local."armorId" END,
    "optEquipId" = CASE WHEN NEW."optEquipId" IS DISTINCT FROM synced."optEquipId" THEN NEW."optEquipId" ELSE local."optEquipId" END,
    "mobId" = CASE WHEN NEW."mobId" IS DISTINCT FROM synced."mobId" THEN NEW."mobId" ELSE local."mobId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'image',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'dataUrl', COALESCE(NEW."dataUrl", local."dataUrl"),
      'npcId', COALESCE(NEW."npcId", local."npcId"),
      'weaponId', COALESCE(NEW."weaponId", local."weaponId"),
      'armorId', COALESCE(NEW."armorId", local."armorId"),
      'optEquipId', COALESCE(NEW."optEquipId", local."optEquipId"),
      'mobId', COALESCE(NEW."mobId", local."mobId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION image_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "image_local" WHERE "id" = OLD."id") THEN
    UPDATE "image_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "image_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'image',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER image_insert
INSTEAD OF INSERT ON "image"
FOR EACH ROW EXECUTE FUNCTION image_insert_trigger();

CREATE OR REPLACE TRIGGER image_update
INSTEAD OF UPDATE ON "image"
FOR EACH ROW EXECUTE FUNCTION image_update_trigger();

CREATE OR REPLACE TRIGGER image_delete
INSTEAD OF DELETE ON "image"
FOR EACH ROW EXECUTE FUNCTION image_delete_trigger();


CREATE OR REPLACE FUNCTION image_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "image_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION image_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "image_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "image_synced"
FOR EACH ROW EXECUTE FUNCTION image_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "image_synced"
FOR EACH ROW EXECUTE FUNCTION image_delete_local_on_synced_delete_trigger();

-- CreateTable
-- item
CREATE TABLE IF NOT EXISTS "item_synced" (
  "id" TEXT NOT NULL,
  "type" "ItemType" NOT NULL,
  "name" TEXT NOT NULL,
  "dataSources" TEXT NOT NULL,
  "details" TEXT,
  "statisticId" TEXT NOT NULL,
  "updatedByAccountId" TEXT,
  "createdByAccountId" TEXT,
  "write_id" UUID,
  CONSTRAINT "item_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "item_local" (
  "id" TEXT,
  "type" "ItemType",
  "name" TEXT,
  "dataSources" TEXT,
  "details" TEXT,
  "statisticId" TEXT,
  "updatedByAccountId" TEXT,
  "createdByAccountId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "item_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "item" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'dataSources' = ANY(local.changed_columns)
      THEN local."dataSources"
      ELSE synced."dataSources"
    END AS "dataSources",
   CASE
    WHEN 'details' = ANY(local.changed_columns)
      THEN local."details"
      ELSE synced."details"
    END AS "details",
   CASE
    WHEN 'statisticId' = ANY(local.changed_columns)
      THEN local."statisticId"
      ELSE synced."statisticId"
    END AS "statisticId",
   CASE
    WHEN 'updatedByAccountId' = ANY(local.changed_columns)
      THEN local."updatedByAccountId"
      ELSE synced."updatedByAccountId"
    END AS "updatedByAccountId",
   CASE
    WHEN 'createdByAccountId' = ANY(local.changed_columns)
      THEN local."createdByAccountId"
      ELSE synced."createdByAccountId"
    END AS "createdByAccountId"
  FROM "item_synced" AS synced
  FULL OUTER JOIN "item_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION item_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "item_local" (
    "id", "type", "name", "dataSources", "details", "statisticId", "updatedByAccountId", "createdByAccountId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."type", NEW."name", NEW."dataSources", NEW."details", NEW."statisticId", NEW."updatedByAccountId", NEW."createdByAccountId",
    ARRAY['type', 'name', 'dataSources', 'details', 'statisticId', 'updatedByAccountId', 'createdByAccountId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'item',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'type', NEW."type",
      'name', NEW."name",
      'dataSources', NEW."dataSources",
      'details', NEW."details",
      'statisticId', NEW."statisticId",
      'updatedByAccountId', NEW."updatedByAccountId",
      'createdByAccountId', NEW."createdByAccountId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION item_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "item_synced"%ROWTYPE;
    local "item_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "item_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "item_local" WHERE "id" = NEW."id";
    
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."dataSources" IS DISTINCT FROM synced."dataSources" THEN
      changed_cols := array_append(changed_cols, 'dataSources');
    END IF;
    IF NEW."details" IS DISTINCT FROM synced."details" THEN
      changed_cols := array_append(changed_cols, 'details');
    END IF;
    IF NEW."statisticId" IS DISTINCT FROM synced."statisticId" THEN
      changed_cols := array_append(changed_cols, 'statisticId');
    END IF;
    IF NEW."updatedByAccountId" IS DISTINCT FROM synced."updatedByAccountId" THEN
      changed_cols := array_append(changed_cols, 'updatedByAccountId');
    END IF;
    IF NEW."createdByAccountId" IS DISTINCT FROM synced."createdByAccountId" THEN
      changed_cols := array_append(changed_cols, 'createdByAccountId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "item_local" (
        "id", "type", "name", "dataSources", "details", "statisticId", "updatedByAccountId", "createdByAccountId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."type", NEW."name", NEW."dataSources", NEW."details", NEW."statisticId", NEW."updatedByAccountId", NEW."createdByAccountId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "item_local"
    SET
        
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "dataSources" = CASE WHEN NEW."dataSources" IS DISTINCT FROM synced."dataSources" THEN NEW."dataSources" ELSE local."dataSources" END,
    "details" = CASE WHEN NEW."details" IS DISTINCT FROM synced."details" THEN NEW."details" ELSE local."details" END,
    "statisticId" = CASE WHEN NEW."statisticId" IS DISTINCT FROM synced."statisticId" THEN NEW."statisticId" ELSE local."statisticId" END,
    "updatedByAccountId" = CASE WHEN NEW."updatedByAccountId" IS DISTINCT FROM synced."updatedByAccountId" THEN NEW."updatedByAccountId" ELSE local."updatedByAccountId" END,
    "createdByAccountId" = CASE WHEN NEW."createdByAccountId" IS DISTINCT FROM synced."createdByAccountId" THEN NEW."createdByAccountId" ELSE local."createdByAccountId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'item',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'type', COALESCE(NEW."type", local."type"),
      'name', COALESCE(NEW."name", local."name"),
      'dataSources', COALESCE(NEW."dataSources", local."dataSources"),
      'details', COALESCE(NEW."details", local."details"),
      'statisticId', COALESCE(NEW."statisticId", local."statisticId"),
      'updatedByAccountId', COALESCE(NEW."updatedByAccountId", local."updatedByAccountId"),
      'createdByAccountId', COALESCE(NEW."createdByAccountId", local."createdByAccountId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION item_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "item_local" WHERE "id" = OLD."id") THEN
    UPDATE "item_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "item_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'item',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER item_insert
INSTEAD OF INSERT ON "item"
FOR EACH ROW EXECUTE FUNCTION item_insert_trigger();

CREATE OR REPLACE TRIGGER item_update
INSTEAD OF UPDATE ON "item"
FOR EACH ROW EXECUTE FUNCTION item_update_trigger();

CREATE OR REPLACE TRIGGER item_delete
INSTEAD OF DELETE ON "item"
FOR EACH ROW EXECUTE FUNCTION item_delete_trigger();


CREATE OR REPLACE FUNCTION item_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "item_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION item_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "item_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "item_synced"
FOR EACH ROW EXECUTE FUNCTION item_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "item_synced"
FOR EACH ROW EXECUTE FUNCTION item_delete_local_on_synced_delete_trigger();

-- CreateTable
-- material
CREATE TABLE IF NOT EXISTS "material_synced" (
  "type" "MaterialType" NOT NULL,
  "ptValue" INTEGER NOT NULL,
  "price" INTEGER NOT NULL,
  "itemId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "material_synced_pkey" PRIMARY KEY ("itemId")
);
CREATE TABLE IF NOT EXISTS "material_local" (
  "type" "MaterialType",
  "ptValue" INTEGER,
  "price" INTEGER,
  "itemId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "material_local_pkey" PRIMARY KEY ("itemId")
);

CREATE OR REPLACE VIEW "material" AS
  SELECT
     CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   CASE
    WHEN 'ptValue' = ANY(local.changed_columns)
      THEN local."ptValue"
      ELSE synced."ptValue"
    END AS "ptValue",
   CASE
    WHEN 'price' = ANY(local.changed_columns)
      THEN local."price"
      ELSE synced."price"
    END AS "price",
   COALESCE(local."itemId", synced."itemId") AS "itemId"
  FROM "material_synced" AS synced
  FULL OUTER JOIN "material_local" AS local
  ON synced."itemId" = local."itemId"
  WHERE (local."itemId" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION material_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "material_local" (
    "type", "ptValue", "price", "itemId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."type", NEW."ptValue", NEW."price", NEW."itemId",
    ARRAY['type', 'ptValue', 'price'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'material',
    'insert',
    jsonb_build_object(
        'type', NEW."type",
      'ptValue', NEW."ptValue",
      'price', NEW."price",
      'itemId', NEW."itemId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION material_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "material_synced"%ROWTYPE;
    local "material_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "material_synced" WHERE "itemId" = NEW."itemId";
    SELECT * INTO local FROM "material_local" WHERE "itemId" = NEW."itemId";
    
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."ptValue" IS DISTINCT FROM synced."ptValue" THEN
      changed_cols := array_append(changed_cols, 'ptValue');
    END IF;
    IF NEW."price" IS DISTINCT FROM synced."price" THEN
      changed_cols := array_append(changed_cols, 'price');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "material_local" (
        "type", "ptValue", "price", "itemId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."type", NEW."ptValue", NEW."price", NEW."itemId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "material_local"
    SET
        
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "ptValue" = CASE WHEN NEW."ptValue" IS DISTINCT FROM synced."ptValue" THEN NEW."ptValue" ELSE local."ptValue" END,
    "price" = CASE WHEN NEW."price" IS DISTINCT FROM synced."price" THEN NEW."price" ELSE local."price" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "itemId" = NEW."itemId";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'material',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'type', COALESCE(NEW."type", local."type"),
      'ptValue', COALESCE(NEW."ptValue", local."ptValue"),
      'price', COALESCE(NEW."price", local."price"),
      'itemId', COALESCE(NEW."itemId", local."itemId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION material_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "material_local" WHERE "itemId" = OLD."itemId") THEN
    UPDATE "material_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "itemId" = OLD."itemId";
    ELSE
    INSERT INTO "material_local" (
        itemId,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."itemId",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'material',
    'delete',
    jsonb_build_object('itemId', OLD."itemId"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER material_insert
INSTEAD OF INSERT ON "material"
FOR EACH ROW EXECUTE FUNCTION material_insert_trigger();

CREATE OR REPLACE TRIGGER material_update
INSTEAD OF UPDATE ON "material"
FOR EACH ROW EXECUTE FUNCTION material_update_trigger();

CREATE OR REPLACE TRIGGER material_delete
INSTEAD OF DELETE ON "material"
FOR EACH ROW EXECUTE FUNCTION material_delete_trigger();


CREATE OR REPLACE FUNCTION material_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "material_local"
  WHERE "itemId" = NEW."itemId"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION material_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "material_local"
  WHERE "itemId" = OLD."itemId";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "material_synced"
FOR EACH ROW EXECUTE FUNCTION material_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "material_synced"
FOR EACH ROW EXECUTE FUNCTION material_delete_local_on_synced_delete_trigger();

-- CreateTable
-- member
CREATE TABLE IF NOT EXISTS "member_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "sequence" INTEGER NOT NULL,
  "playerId" TEXT,
  "partnerId" TEXT,
  "mercenaryId" TEXT,
  "mobId" TEXT,
  "mobDifficultyFlag" "MobDifficultyFlag" NOT NULL,
  "teamId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "member_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "member_local" (
  "id" TEXT,
  "name" TEXT,
  "sequence" INTEGER,
  "playerId" TEXT,
  "partnerId" TEXT,
  "mercenaryId" TEXT,
  "mobId" TEXT,
  "mobDifficultyFlag" "MobDifficultyFlag",
  "teamId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "member_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "member" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'sequence' = ANY(local.changed_columns)
      THEN local."sequence"
      ELSE synced."sequence"
    END AS "sequence",
   CASE
    WHEN 'playerId' = ANY(local.changed_columns)
      THEN local."playerId"
      ELSE synced."playerId"
    END AS "playerId",
   CASE
    WHEN 'partnerId' = ANY(local.changed_columns)
      THEN local."partnerId"
      ELSE synced."partnerId"
    END AS "partnerId",
   CASE
    WHEN 'mercenaryId' = ANY(local.changed_columns)
      THEN local."mercenaryId"
      ELSE synced."mercenaryId"
    END AS "mercenaryId",
   CASE
    WHEN 'mobId' = ANY(local.changed_columns)
      THEN local."mobId"
      ELSE synced."mobId"
    END AS "mobId",
   CASE
    WHEN 'mobDifficultyFlag' = ANY(local.changed_columns)
      THEN local."mobDifficultyFlag"
      ELSE synced."mobDifficultyFlag"
    END AS "mobDifficultyFlag",
   CASE
    WHEN 'teamId' = ANY(local.changed_columns)
      THEN local."teamId"
      ELSE synced."teamId"
    END AS "teamId"
  FROM "member_synced" AS synced
  FULL OUTER JOIN "member_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION member_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "member_local" (
    "id", "name", "sequence", "playerId", "partnerId", "mercenaryId", "mobId", "mobDifficultyFlag", "teamId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."sequence", NEW."playerId", NEW."partnerId", NEW."mercenaryId", NEW."mobId", NEW."mobDifficultyFlag", NEW."teamId",
    ARRAY['name', 'sequence', 'playerId', 'partnerId', 'mercenaryId', 'mobId', 'mobDifficultyFlag', 'teamId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'member',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'sequence', NEW."sequence",
      'playerId', NEW."playerId",
      'partnerId', NEW."partnerId",
      'mercenaryId', NEW."mercenaryId",
      'mobId', NEW."mobId",
      'mobDifficultyFlag', NEW."mobDifficultyFlag",
      'teamId', NEW."teamId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION member_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "member_synced"%ROWTYPE;
    local "member_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "member_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "member_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."sequence" IS DISTINCT FROM synced."sequence" THEN
      changed_cols := array_append(changed_cols, 'sequence');
    END IF;
    IF NEW."playerId" IS DISTINCT FROM synced."playerId" THEN
      changed_cols := array_append(changed_cols, 'playerId');
    END IF;
    IF NEW."partnerId" IS DISTINCT FROM synced."partnerId" THEN
      changed_cols := array_append(changed_cols, 'partnerId');
    END IF;
    IF NEW."mercenaryId" IS DISTINCT FROM synced."mercenaryId" THEN
      changed_cols := array_append(changed_cols, 'mercenaryId');
    END IF;
    IF NEW."mobId" IS DISTINCT FROM synced."mobId" THEN
      changed_cols := array_append(changed_cols, 'mobId');
    END IF;
    IF NEW."mobDifficultyFlag" IS DISTINCT FROM synced."mobDifficultyFlag" THEN
      changed_cols := array_append(changed_cols, 'mobDifficultyFlag');
    END IF;
    IF NEW."teamId" IS DISTINCT FROM synced."teamId" THEN
      changed_cols := array_append(changed_cols, 'teamId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "member_local" (
        "id", "name", "sequence", "playerId", "partnerId", "mercenaryId", "mobId", "mobDifficultyFlag", "teamId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."sequence", NEW."playerId", NEW."partnerId", NEW."mercenaryId", NEW."mobId", NEW."mobDifficultyFlag", NEW."teamId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "member_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "sequence" = CASE WHEN NEW."sequence" IS DISTINCT FROM synced."sequence" THEN NEW."sequence" ELSE local."sequence" END,
    "playerId" = CASE WHEN NEW."playerId" IS DISTINCT FROM synced."playerId" THEN NEW."playerId" ELSE local."playerId" END,
    "partnerId" = CASE WHEN NEW."partnerId" IS DISTINCT FROM synced."partnerId" THEN NEW."partnerId" ELSE local."partnerId" END,
    "mercenaryId" = CASE WHEN NEW."mercenaryId" IS DISTINCT FROM synced."mercenaryId" THEN NEW."mercenaryId" ELSE local."mercenaryId" END,
    "mobId" = CASE WHEN NEW."mobId" IS DISTINCT FROM synced."mobId" THEN NEW."mobId" ELSE local."mobId" END,
    "mobDifficultyFlag" = CASE WHEN NEW."mobDifficultyFlag" IS DISTINCT FROM synced."mobDifficultyFlag" THEN NEW."mobDifficultyFlag" ELSE local."mobDifficultyFlag" END,
    "teamId" = CASE WHEN NEW."teamId" IS DISTINCT FROM synced."teamId" THEN NEW."teamId" ELSE local."teamId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'member',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'sequence', COALESCE(NEW."sequence", local."sequence"),
      'playerId', COALESCE(NEW."playerId", local."playerId"),
      'partnerId', COALESCE(NEW."partnerId", local."partnerId"),
      'mercenaryId', COALESCE(NEW."mercenaryId", local."mercenaryId"),
      'mobId', COALESCE(NEW."mobId", local."mobId"),
      'mobDifficultyFlag', COALESCE(NEW."mobDifficultyFlag", local."mobDifficultyFlag"),
      'teamId', COALESCE(NEW."teamId", local."teamId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION member_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "member_local" WHERE "id" = OLD."id") THEN
    UPDATE "member_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "member_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'member',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER member_insert
INSTEAD OF INSERT ON "member"
FOR EACH ROW EXECUTE FUNCTION member_insert_trigger();

CREATE OR REPLACE TRIGGER member_update
INSTEAD OF UPDATE ON "member"
FOR EACH ROW EXECUTE FUNCTION member_update_trigger();

CREATE OR REPLACE TRIGGER member_delete
INSTEAD OF DELETE ON "member"
FOR EACH ROW EXECUTE FUNCTION member_delete_trigger();


CREATE OR REPLACE FUNCTION member_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "member_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION member_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "member_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "member_synced"
FOR EACH ROW EXECUTE FUNCTION member_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "member_synced"
FOR EACH ROW EXECUTE FUNCTION member_delete_local_on_synced_delete_trigger();

-- CreateTable
-- mercenary
CREATE TABLE IF NOT EXISTS "mercenary_synced" (
  "type" "MercenaryType" NOT NULL,
  "templateId" TEXT NOT NULL,
  "skillAId" TEXT NOT NULL,
  "skillAType" "PartnerSkillType" NOT NULL,
  "skillBId" TEXT NOT NULL,
  "skillBType" "PartnerSkillType" NOT NULL,
  "write_id" UUID,
  CONSTRAINT "mercenary_synced_pkey" PRIMARY KEY ("templateId")
);
CREATE TABLE IF NOT EXISTS "mercenary_local" (
  "type" "MercenaryType",
  "templateId" TEXT,
  "skillAId" TEXT,
  "skillAType" "PartnerSkillType",
  "skillBId" TEXT,
  "skillBType" "PartnerSkillType",
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "mercenary_local_pkey" PRIMARY KEY ("templateId")
);

CREATE OR REPLACE VIEW "mercenary" AS
  SELECT
     CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   COALESCE(local."templateId", synced."templateId") AS "templateId",
   CASE
    WHEN 'skillAId' = ANY(local.changed_columns)
      THEN local."skillAId"
      ELSE synced."skillAId"
    END AS "skillAId",
   CASE
    WHEN 'skillAType' = ANY(local.changed_columns)
      THEN local."skillAType"
      ELSE synced."skillAType"
    END AS "skillAType",
   CASE
    WHEN 'skillBId' = ANY(local.changed_columns)
      THEN local."skillBId"
      ELSE synced."skillBId"
    END AS "skillBId",
   CASE
    WHEN 'skillBType' = ANY(local.changed_columns)
      THEN local."skillBType"
      ELSE synced."skillBType"
    END AS "skillBType"
  FROM "mercenary_synced" AS synced
  FULL OUTER JOIN "mercenary_local" AS local
  ON synced."templateId" = local."templateId"
  WHERE (local."templateId" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION mercenary_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "mercenary_local" (
    "type", "templateId", "skillAId", "skillAType", "skillBId", "skillBType",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."type", NEW."templateId", NEW."skillAId", NEW."skillAType", NEW."skillBId", NEW."skillBType",
    ARRAY['type', 'skillAId', 'skillAType', 'skillBId', 'skillBType'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'mercenary',
    'insert',
    jsonb_build_object(
        'type', NEW."type",
      'templateId', NEW."templateId",
      'skillAId', NEW."skillAId",
      'skillAType', NEW."skillAType",
      'skillBId', NEW."skillBId",
      'skillBType', NEW."skillBType"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mercenary_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "mercenary_synced"%ROWTYPE;
    local "mercenary_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "mercenary_synced" WHERE "templateId" = NEW."templateId";
    SELECT * INTO local FROM "mercenary_local" WHERE "templateId" = NEW."templateId";
    
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."skillAId" IS DISTINCT FROM synced."skillAId" THEN
      changed_cols := array_append(changed_cols, 'skillAId');
    END IF;
    IF NEW."skillAType" IS DISTINCT FROM synced."skillAType" THEN
      changed_cols := array_append(changed_cols, 'skillAType');
    END IF;
    IF NEW."skillBId" IS DISTINCT FROM synced."skillBId" THEN
      changed_cols := array_append(changed_cols, 'skillBId');
    END IF;
    IF NEW."skillBType" IS DISTINCT FROM synced."skillBType" THEN
      changed_cols := array_append(changed_cols, 'skillBType');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "mercenary_local" (
        "type", "templateId", "skillAId", "skillAType", "skillBId", "skillBType",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."type", NEW."templateId", NEW."skillAId", NEW."skillAType", NEW."skillBId", NEW."skillBType",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "mercenary_local"
    SET
        
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "skillAId" = CASE WHEN NEW."skillAId" IS DISTINCT FROM synced."skillAId" THEN NEW."skillAId" ELSE local."skillAId" END,
    "skillAType" = CASE WHEN NEW."skillAType" IS DISTINCT FROM synced."skillAType" THEN NEW."skillAType" ELSE local."skillAType" END,
    "skillBId" = CASE WHEN NEW."skillBId" IS DISTINCT FROM synced."skillBId" THEN NEW."skillBId" ELSE local."skillBId" END,
    "skillBType" = CASE WHEN NEW."skillBType" IS DISTINCT FROM synced."skillBType" THEN NEW."skillBType" ELSE local."skillBType" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "templateId" = NEW."templateId";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'mercenary',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'type', COALESCE(NEW."type", local."type"),
      'templateId', COALESCE(NEW."templateId", local."templateId"),
      'skillAId', COALESCE(NEW."skillAId", local."skillAId"),
      'skillAType', COALESCE(NEW."skillAType", local."skillAType"),
      'skillBId', COALESCE(NEW."skillBId", local."skillBId"),
      'skillBType', COALESCE(NEW."skillBType", local."skillBType")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mercenary_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "mercenary_local" WHERE "templateId" = OLD."templateId") THEN
    UPDATE "mercenary_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "templateId" = OLD."templateId";
    ELSE
    INSERT INTO "mercenary_local" (
        templateId,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."templateId",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'mercenary',
    'delete',
    jsonb_build_object('templateId', OLD."templateId"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER mercenary_insert
INSTEAD OF INSERT ON "mercenary"
FOR EACH ROW EXECUTE FUNCTION mercenary_insert_trigger();

CREATE OR REPLACE TRIGGER mercenary_update
INSTEAD OF UPDATE ON "mercenary"
FOR EACH ROW EXECUTE FUNCTION mercenary_update_trigger();

CREATE OR REPLACE TRIGGER mercenary_delete
INSTEAD OF DELETE ON "mercenary"
FOR EACH ROW EXECUTE FUNCTION mercenary_delete_trigger();


CREATE OR REPLACE FUNCTION mercenary_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "mercenary_local"
  WHERE "templateId" = NEW."templateId"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION mercenary_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "mercenary_local"
  WHERE "templateId" = OLD."templateId";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "mercenary_synced"
FOR EACH ROW EXECUTE FUNCTION mercenary_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "mercenary_synced"
FOR EACH ROW EXECUTE FUNCTION mercenary_delete_local_on_synced_delete_trigger();

-- CreateTable
-- mob
CREATE TABLE IF NOT EXISTS "mob_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "type" "MobType" NOT NULL,
  "captureable" BOOLEAN NOT NULL,
  "baseLv" INTEGER NOT NULL,
  "experience" INTEGER NOT NULL,
  "partsExperience" INTEGER NOT NULL,
  "initialElement" "ElementType" NOT NULL,
  "radius" INTEGER NOT NULL,
  "maxhp" INTEGER NOT NULL,
  "physicalDefense" INTEGER NOT NULL,
  "physicalResistance" INTEGER NOT NULL,
  "magicalDefense" INTEGER NOT NULL,
  "magicalResistance" INTEGER NOT NULL,
  "criticalResistance" INTEGER NOT NULL,
  "avoidance" INTEGER NOT NULL,
  "dodge" INTEGER NOT NULL,
  "block" INTEGER NOT NULL,
  "normalAttackResistanceModifier" INTEGER NOT NULL,
  "physicalAttackResistanceModifier" INTEGER NOT NULL,
  "magicalAttackResistanceModifier" INTEGER NOT NULL,
  "actions" JSONB NOT NULL,
  "details" TEXT,
  "dataSources" TEXT NOT NULL,
  "statisticId" TEXT NOT NULL,
  "updatedByAccountId" TEXT,
  "createdByAccountId" TEXT,
  "write_id" UUID,
  CONSTRAINT "mob_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "mob_local" (
  "id" TEXT,
  "name" TEXT,
  "type" "MobType",
  "captureable" BOOLEAN,
  "baseLv" INTEGER,
  "experience" INTEGER,
  "partsExperience" INTEGER,
  "initialElement" "ElementType",
  "radius" INTEGER,
  "maxhp" INTEGER,
  "physicalDefense" INTEGER,
  "physicalResistance" INTEGER,
  "magicalDefense" INTEGER,
  "magicalResistance" INTEGER,
  "criticalResistance" INTEGER,
  "avoidance" INTEGER,
  "dodge" INTEGER,
  "block" INTEGER,
  "normalAttackResistanceModifier" INTEGER,
  "physicalAttackResistanceModifier" INTEGER,
  "magicalAttackResistanceModifier" INTEGER,
  "actions" JSONB,
  "details" TEXT,
  "dataSources" TEXT,
  "statisticId" TEXT,
  "updatedByAccountId" TEXT,
  "createdByAccountId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "mob_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "mob" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   CASE
    WHEN 'captureable' = ANY(local.changed_columns)
      THEN local."captureable"
      ELSE synced."captureable"
    END AS "captureable",
   CASE
    WHEN 'baseLv' = ANY(local.changed_columns)
      THEN local."baseLv"
      ELSE synced."baseLv"
    END AS "baseLv",
   CASE
    WHEN 'experience' = ANY(local.changed_columns)
      THEN local."experience"
      ELSE synced."experience"
    END AS "experience",
   CASE
    WHEN 'partsExperience' = ANY(local.changed_columns)
      THEN local."partsExperience"
      ELSE synced."partsExperience"
    END AS "partsExperience",
   CASE
    WHEN 'initialElement' = ANY(local.changed_columns)
      THEN local."initialElement"
      ELSE synced."initialElement"
    END AS "initialElement",
   CASE
    WHEN 'radius' = ANY(local.changed_columns)
      THEN local."radius"
      ELSE synced."radius"
    END AS "radius",
   CASE
    WHEN 'maxhp' = ANY(local.changed_columns)
      THEN local."maxhp"
      ELSE synced."maxhp"
    END AS "maxhp",
   CASE
    WHEN 'physicalDefense' = ANY(local.changed_columns)
      THEN local."physicalDefense"
      ELSE synced."physicalDefense"
    END AS "physicalDefense",
   CASE
    WHEN 'physicalResistance' = ANY(local.changed_columns)
      THEN local."physicalResistance"
      ELSE synced."physicalResistance"
    END AS "physicalResistance",
   CASE
    WHEN 'magicalDefense' = ANY(local.changed_columns)
      THEN local."magicalDefense"
      ELSE synced."magicalDefense"
    END AS "magicalDefense",
   CASE
    WHEN 'magicalResistance' = ANY(local.changed_columns)
      THEN local."magicalResistance"
      ELSE synced."magicalResistance"
    END AS "magicalResistance",
   CASE
    WHEN 'criticalResistance' = ANY(local.changed_columns)
      THEN local."criticalResistance"
      ELSE synced."criticalResistance"
    END AS "criticalResistance",
   CASE
    WHEN 'avoidance' = ANY(local.changed_columns)
      THEN local."avoidance"
      ELSE synced."avoidance"
    END AS "avoidance",
   CASE
    WHEN 'dodge' = ANY(local.changed_columns)
      THEN local."dodge"
      ELSE synced."dodge"
    END AS "dodge",
   CASE
    WHEN 'block' = ANY(local.changed_columns)
      THEN local."block"
      ELSE synced."block"
    END AS "block",
   CASE
    WHEN 'normalAttackResistanceModifier' = ANY(local.changed_columns)
      THEN local."normalAttackResistanceModifier"
      ELSE synced."normalAttackResistanceModifier"
    END AS "normalAttackResistanceModifier",
   CASE
    WHEN 'physicalAttackResistanceModifier' = ANY(local.changed_columns)
      THEN local."physicalAttackResistanceModifier"
      ELSE synced."physicalAttackResistanceModifier"
    END AS "physicalAttackResistanceModifier",
   CASE
    WHEN 'magicalAttackResistanceModifier' = ANY(local.changed_columns)
      THEN local."magicalAttackResistanceModifier"
      ELSE synced."magicalAttackResistanceModifier"
    END AS "magicalAttackResistanceModifier",
   CASE
    WHEN 'actions' = ANY(local.changed_columns)
      THEN local."actions"
      ELSE synced."actions"
    END AS "actions",
   CASE
    WHEN 'details' = ANY(local.changed_columns)
      THEN local."details"
      ELSE synced."details"
    END AS "details",
   CASE
    WHEN 'dataSources' = ANY(local.changed_columns)
      THEN local."dataSources"
      ELSE synced."dataSources"
    END AS "dataSources",
   CASE
    WHEN 'statisticId' = ANY(local.changed_columns)
      THEN local."statisticId"
      ELSE synced."statisticId"
    END AS "statisticId",
   CASE
    WHEN 'updatedByAccountId' = ANY(local.changed_columns)
      THEN local."updatedByAccountId"
      ELSE synced."updatedByAccountId"
    END AS "updatedByAccountId",
   CASE
    WHEN 'createdByAccountId' = ANY(local.changed_columns)
      THEN local."createdByAccountId"
      ELSE synced."createdByAccountId"
    END AS "createdByAccountId"
  FROM "mob_synced" AS synced
  FULL OUTER JOIN "mob_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION mob_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "mob_local" (
    "id", "name", "type", "captureable", "baseLv", "experience", "partsExperience", "initialElement", "radius", "maxhp", "physicalDefense", "physicalResistance", "magicalDefense", "magicalResistance", "criticalResistance", "avoidance", "dodge", "block", "normalAttackResistanceModifier", "physicalAttackResistanceModifier", "magicalAttackResistanceModifier", "actions", "details", "dataSources", "statisticId", "updatedByAccountId", "createdByAccountId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."type", NEW."captureable", NEW."baseLv", NEW."experience", NEW."partsExperience", NEW."initialElement", NEW."radius", NEW."maxhp", NEW."physicalDefense", NEW."physicalResistance", NEW."magicalDefense", NEW."magicalResistance", NEW."criticalResistance", NEW."avoidance", NEW."dodge", NEW."block", NEW."normalAttackResistanceModifier", NEW."physicalAttackResistanceModifier", NEW."magicalAttackResistanceModifier", NEW."actions", NEW."details", NEW."dataSources", NEW."statisticId", NEW."updatedByAccountId", NEW."createdByAccountId",
    ARRAY['name', 'type', 'captureable', 'baseLv', 'experience', 'partsExperience', 'initialElement', 'radius', 'maxhp', 'physicalDefense', 'physicalResistance', 'magicalDefense', 'magicalResistance', 'criticalResistance', 'avoidance', 'dodge', 'block', 'normalAttackResistanceModifier', 'physicalAttackResistanceModifier', 'magicalAttackResistanceModifier', 'actions', 'details', 'dataSources', 'statisticId', 'updatedByAccountId', 'createdByAccountId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'mob',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'type', NEW."type",
      'captureable', NEW."captureable",
      'baseLv', NEW."baseLv",
      'experience', NEW."experience",
      'partsExperience', NEW."partsExperience",
      'initialElement', NEW."initialElement",
      'radius', NEW."radius",
      'maxhp', NEW."maxhp",
      'physicalDefense', NEW."physicalDefense",
      'physicalResistance', NEW."physicalResistance",
      'magicalDefense', NEW."magicalDefense",
      'magicalResistance', NEW."magicalResistance",
      'criticalResistance', NEW."criticalResistance",
      'avoidance', NEW."avoidance",
      'dodge', NEW."dodge",
      'block', NEW."block",
      'normalAttackResistanceModifier', NEW."normalAttackResistanceModifier",
      'physicalAttackResistanceModifier', NEW."physicalAttackResistanceModifier",
      'magicalAttackResistanceModifier', NEW."magicalAttackResistanceModifier",
      'actions', NEW."actions",
      'details', NEW."details",
      'dataSources', NEW."dataSources",
      'statisticId', NEW."statisticId",
      'updatedByAccountId', NEW."updatedByAccountId",
      'createdByAccountId', NEW."createdByAccountId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mob_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "mob_synced"%ROWTYPE;
    local "mob_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "mob_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "mob_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."captureable" IS DISTINCT FROM synced."captureable" THEN
      changed_cols := array_append(changed_cols, 'captureable');
    END IF;
    IF NEW."baseLv" IS DISTINCT FROM synced."baseLv" THEN
      changed_cols := array_append(changed_cols, 'baseLv');
    END IF;
    IF NEW."experience" IS DISTINCT FROM synced."experience" THEN
      changed_cols := array_append(changed_cols, 'experience');
    END IF;
    IF NEW."partsExperience" IS DISTINCT FROM synced."partsExperience" THEN
      changed_cols := array_append(changed_cols, 'partsExperience');
    END IF;
    IF NEW."initialElement" IS DISTINCT FROM synced."initialElement" THEN
      changed_cols := array_append(changed_cols, 'initialElement');
    END IF;
    IF NEW."radius" IS DISTINCT FROM synced."radius" THEN
      changed_cols := array_append(changed_cols, 'radius');
    END IF;
    IF NEW."maxhp" IS DISTINCT FROM synced."maxhp" THEN
      changed_cols := array_append(changed_cols, 'maxhp');
    END IF;
    IF NEW."physicalDefense" IS DISTINCT FROM synced."physicalDefense" THEN
      changed_cols := array_append(changed_cols, 'physicalDefense');
    END IF;
    IF NEW."physicalResistance" IS DISTINCT FROM synced."physicalResistance" THEN
      changed_cols := array_append(changed_cols, 'physicalResistance');
    END IF;
    IF NEW."magicalDefense" IS DISTINCT FROM synced."magicalDefense" THEN
      changed_cols := array_append(changed_cols, 'magicalDefense');
    END IF;
    IF NEW."magicalResistance" IS DISTINCT FROM synced."magicalResistance" THEN
      changed_cols := array_append(changed_cols, 'magicalResistance');
    END IF;
    IF NEW."criticalResistance" IS DISTINCT FROM synced."criticalResistance" THEN
      changed_cols := array_append(changed_cols, 'criticalResistance');
    END IF;
    IF NEW."avoidance" IS DISTINCT FROM synced."avoidance" THEN
      changed_cols := array_append(changed_cols, 'avoidance');
    END IF;
    IF NEW."dodge" IS DISTINCT FROM synced."dodge" THEN
      changed_cols := array_append(changed_cols, 'dodge');
    END IF;
    IF NEW."block" IS DISTINCT FROM synced."block" THEN
      changed_cols := array_append(changed_cols, 'block');
    END IF;
    IF NEW."normalAttackResistanceModifier" IS DISTINCT FROM synced."normalAttackResistanceModifier" THEN
      changed_cols := array_append(changed_cols, 'normalAttackResistanceModifier');
    END IF;
    IF NEW."physicalAttackResistanceModifier" IS DISTINCT FROM synced."physicalAttackResistanceModifier" THEN
      changed_cols := array_append(changed_cols, 'physicalAttackResistanceModifier');
    END IF;
    IF NEW."magicalAttackResistanceModifier" IS DISTINCT FROM synced."magicalAttackResistanceModifier" THEN
      changed_cols := array_append(changed_cols, 'magicalAttackResistanceModifier');
    END IF;
    IF NEW."actions" IS DISTINCT FROM synced."actions" THEN
      changed_cols := array_append(changed_cols, 'actions');
    END IF;
    IF NEW."details" IS DISTINCT FROM synced."details" THEN
      changed_cols := array_append(changed_cols, 'details');
    END IF;
    IF NEW."dataSources" IS DISTINCT FROM synced."dataSources" THEN
      changed_cols := array_append(changed_cols, 'dataSources');
    END IF;
    IF NEW."statisticId" IS DISTINCT FROM synced."statisticId" THEN
      changed_cols := array_append(changed_cols, 'statisticId');
    END IF;
    IF NEW."updatedByAccountId" IS DISTINCT FROM synced."updatedByAccountId" THEN
      changed_cols := array_append(changed_cols, 'updatedByAccountId');
    END IF;
    IF NEW."createdByAccountId" IS DISTINCT FROM synced."createdByAccountId" THEN
      changed_cols := array_append(changed_cols, 'createdByAccountId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "mob_local" (
        "id", "name", "type", "captureable", "baseLv", "experience", "partsExperience", "initialElement", "radius", "maxhp", "physicalDefense", "physicalResistance", "magicalDefense", "magicalResistance", "criticalResistance", "avoidance", "dodge", "block", "normalAttackResistanceModifier", "physicalAttackResistanceModifier", "magicalAttackResistanceModifier", "actions", "details", "dataSources", "statisticId", "updatedByAccountId", "createdByAccountId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."type", NEW."captureable", NEW."baseLv", NEW."experience", NEW."partsExperience", NEW."initialElement", NEW."radius", NEW."maxhp", NEW."physicalDefense", NEW."physicalResistance", NEW."magicalDefense", NEW."magicalResistance", NEW."criticalResistance", NEW."avoidance", NEW."dodge", NEW."block", NEW."normalAttackResistanceModifier", NEW."physicalAttackResistanceModifier", NEW."magicalAttackResistanceModifier", NEW."actions", NEW."details", NEW."dataSources", NEW."statisticId", NEW."updatedByAccountId", NEW."createdByAccountId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "mob_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "captureable" = CASE WHEN NEW."captureable" IS DISTINCT FROM synced."captureable" THEN NEW."captureable" ELSE local."captureable" END,
    "baseLv" = CASE WHEN NEW."baseLv" IS DISTINCT FROM synced."baseLv" THEN NEW."baseLv" ELSE local."baseLv" END,
    "experience" = CASE WHEN NEW."experience" IS DISTINCT FROM synced."experience" THEN NEW."experience" ELSE local."experience" END,
    "partsExperience" = CASE WHEN NEW."partsExperience" IS DISTINCT FROM synced."partsExperience" THEN NEW."partsExperience" ELSE local."partsExperience" END,
    "initialElement" = CASE WHEN NEW."initialElement" IS DISTINCT FROM synced."initialElement" THEN NEW."initialElement" ELSE local."initialElement" END,
    "radius" = CASE WHEN NEW."radius" IS DISTINCT FROM synced."radius" THEN NEW."radius" ELSE local."radius" END,
    "maxhp" = CASE WHEN NEW."maxhp" IS DISTINCT FROM synced."maxhp" THEN NEW."maxhp" ELSE local."maxhp" END,
    "physicalDefense" = CASE WHEN NEW."physicalDefense" IS DISTINCT FROM synced."physicalDefense" THEN NEW."physicalDefense" ELSE local."physicalDefense" END,
    "physicalResistance" = CASE WHEN NEW."physicalResistance" IS DISTINCT FROM synced."physicalResistance" THEN NEW."physicalResistance" ELSE local."physicalResistance" END,
    "magicalDefense" = CASE WHEN NEW."magicalDefense" IS DISTINCT FROM synced."magicalDefense" THEN NEW."magicalDefense" ELSE local."magicalDefense" END,
    "magicalResistance" = CASE WHEN NEW."magicalResistance" IS DISTINCT FROM synced."magicalResistance" THEN NEW."magicalResistance" ELSE local."magicalResistance" END,
    "criticalResistance" = CASE WHEN NEW."criticalResistance" IS DISTINCT FROM synced."criticalResistance" THEN NEW."criticalResistance" ELSE local."criticalResistance" END,
    "avoidance" = CASE WHEN NEW."avoidance" IS DISTINCT FROM synced."avoidance" THEN NEW."avoidance" ELSE local."avoidance" END,
    "dodge" = CASE WHEN NEW."dodge" IS DISTINCT FROM synced."dodge" THEN NEW."dodge" ELSE local."dodge" END,
    "block" = CASE WHEN NEW."block" IS DISTINCT FROM synced."block" THEN NEW."block" ELSE local."block" END,
    "normalAttackResistanceModifier" = CASE WHEN NEW."normalAttackResistanceModifier" IS DISTINCT FROM synced."normalAttackResistanceModifier" THEN NEW."normalAttackResistanceModifier" ELSE local."normalAttackResistanceModifier" END,
    "physicalAttackResistanceModifier" = CASE WHEN NEW."physicalAttackResistanceModifier" IS DISTINCT FROM synced."physicalAttackResistanceModifier" THEN NEW."physicalAttackResistanceModifier" ELSE local."physicalAttackResistanceModifier" END,
    "magicalAttackResistanceModifier" = CASE WHEN NEW."magicalAttackResistanceModifier" IS DISTINCT FROM synced."magicalAttackResistanceModifier" THEN NEW."magicalAttackResistanceModifier" ELSE local."magicalAttackResistanceModifier" END,
    "actions" = CASE WHEN NEW."actions" IS DISTINCT FROM synced."actions" THEN NEW."actions" ELSE local."actions" END,
    "details" = CASE WHEN NEW."details" IS DISTINCT FROM synced."details" THEN NEW."details" ELSE local."details" END,
    "dataSources" = CASE WHEN NEW."dataSources" IS DISTINCT FROM synced."dataSources" THEN NEW."dataSources" ELSE local."dataSources" END,
    "statisticId" = CASE WHEN NEW."statisticId" IS DISTINCT FROM synced."statisticId" THEN NEW."statisticId" ELSE local."statisticId" END,
    "updatedByAccountId" = CASE WHEN NEW."updatedByAccountId" IS DISTINCT FROM synced."updatedByAccountId" THEN NEW."updatedByAccountId" ELSE local."updatedByAccountId" END,
    "createdByAccountId" = CASE WHEN NEW."createdByAccountId" IS DISTINCT FROM synced."createdByAccountId" THEN NEW."createdByAccountId" ELSE local."createdByAccountId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'mob',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'type', COALESCE(NEW."type", local."type"),
      'captureable', COALESCE(NEW."captureable", local."captureable"),
      'baseLv', COALESCE(NEW."baseLv", local."baseLv"),
      'experience', COALESCE(NEW."experience", local."experience"),
      'partsExperience', COALESCE(NEW."partsExperience", local."partsExperience"),
      'initialElement', COALESCE(NEW."initialElement", local."initialElement"),
      'radius', COALESCE(NEW."radius", local."radius"),
      'maxhp', COALESCE(NEW."maxhp", local."maxhp"),
      'physicalDefense', COALESCE(NEW."physicalDefense", local."physicalDefense"),
      'physicalResistance', COALESCE(NEW."physicalResistance", local."physicalResistance"),
      'magicalDefense', COALESCE(NEW."magicalDefense", local."magicalDefense"),
      'magicalResistance', COALESCE(NEW."magicalResistance", local."magicalResistance"),
      'criticalResistance', COALESCE(NEW."criticalResistance", local."criticalResistance"),
      'avoidance', COALESCE(NEW."avoidance", local."avoidance"),
      'dodge', COALESCE(NEW."dodge", local."dodge"),
      'block', COALESCE(NEW."block", local."block"),
      'normalAttackResistanceModifier', COALESCE(NEW."normalAttackResistanceModifier", local."normalAttackResistanceModifier"),
      'physicalAttackResistanceModifier', COALESCE(NEW."physicalAttackResistanceModifier", local."physicalAttackResistanceModifier"),
      'magicalAttackResistanceModifier', COALESCE(NEW."magicalAttackResistanceModifier", local."magicalAttackResistanceModifier"),
      'actions', COALESCE(NEW."actions", local."actions"),
      'details', COALESCE(NEW."details", local."details"),
      'dataSources', COALESCE(NEW."dataSources", local."dataSources"),
      'statisticId', COALESCE(NEW."statisticId", local."statisticId"),
      'updatedByAccountId', COALESCE(NEW."updatedByAccountId", local."updatedByAccountId"),
      'createdByAccountId', COALESCE(NEW."createdByAccountId", local."createdByAccountId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION mob_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "mob_local" WHERE "id" = OLD."id") THEN
    UPDATE "mob_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "mob_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'mob',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER mob_insert
INSTEAD OF INSERT ON "mob"
FOR EACH ROW EXECUTE FUNCTION mob_insert_trigger();

CREATE OR REPLACE TRIGGER mob_update
INSTEAD OF UPDATE ON "mob"
FOR EACH ROW EXECUTE FUNCTION mob_update_trigger();

CREATE OR REPLACE TRIGGER mob_delete
INSTEAD OF DELETE ON "mob"
FOR EACH ROW EXECUTE FUNCTION mob_delete_trigger();


CREATE OR REPLACE FUNCTION mob_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "mob_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION mob_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "mob_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "mob_synced"
FOR EACH ROW EXECUTE FUNCTION mob_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "mob_synced"
FOR EACH ROW EXECUTE FUNCTION mob_delete_local_on_synced_delete_trigger();

-- CreateTable
-- npc
CREATE TABLE IF NOT EXISTS "npc_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "zoneId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "npc_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "npc_local" (
  "id" TEXT,
  "name" TEXT,
  "zoneId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "npc_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "npc" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'zoneId' = ANY(local.changed_columns)
      THEN local."zoneId"
      ELSE synced."zoneId"
    END AS "zoneId"
  FROM "npc_synced" AS synced
  FULL OUTER JOIN "npc_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION npc_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "npc_local" (
    "id", "name", "zoneId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."zoneId",
    ARRAY['name', 'zoneId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'npc',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'zoneId', NEW."zoneId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION npc_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "npc_synced"%ROWTYPE;
    local "npc_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "npc_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "npc_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."zoneId" IS DISTINCT FROM synced."zoneId" THEN
      changed_cols := array_append(changed_cols, 'zoneId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "npc_local" (
        "id", "name", "zoneId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."zoneId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "npc_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "zoneId" = CASE WHEN NEW."zoneId" IS DISTINCT FROM synced."zoneId" THEN NEW."zoneId" ELSE local."zoneId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'npc',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'zoneId', COALESCE(NEW."zoneId", local."zoneId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION npc_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "npc_local" WHERE "id" = OLD."id") THEN
    UPDATE "npc_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "npc_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'npc',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER npc_insert
INSTEAD OF INSERT ON "npc"
FOR EACH ROW EXECUTE FUNCTION npc_insert_trigger();

CREATE OR REPLACE TRIGGER npc_update
INSTEAD OF UPDATE ON "npc"
FOR EACH ROW EXECUTE FUNCTION npc_update_trigger();

CREATE OR REPLACE TRIGGER npc_delete
INSTEAD OF DELETE ON "npc"
FOR EACH ROW EXECUTE FUNCTION npc_delete_trigger();


CREATE OR REPLACE FUNCTION npc_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "npc_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION npc_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "npc_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "npc_synced"
FOR EACH ROW EXECUTE FUNCTION npc_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "npc_synced"
FOR EACH ROW EXECUTE FUNCTION npc_delete_local_on_synced_delete_trigger();

-- CreateTable
-- option
CREATE TABLE IF NOT EXISTS "option_synced" (
  "baseDef" INTEGER NOT NULL,
  "modifiers" TEXT[],
  "colorA" INTEGER NOT NULL,
  "colorB" INTEGER NOT NULL,
  "colorC" INTEGER NOT NULL,
  "itemId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "option_synced_pkey" PRIMARY KEY ("itemId")
);
CREATE TABLE IF NOT EXISTS "option_local" (
  "baseDef" INTEGER,
  "modifiers" TEXT[],
  "colorA" INTEGER,
  "colorB" INTEGER,
  "colorC" INTEGER,
  "itemId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "option_local_pkey" PRIMARY KEY ("itemId")
);

CREATE OR REPLACE VIEW "option" AS
  SELECT
     CASE
    WHEN 'baseDef' = ANY(local.changed_columns)
      THEN local."baseDef"
      ELSE synced."baseDef"
    END AS "baseDef",
   CASE
    WHEN 'modifiers' = ANY(local.changed_columns)
      THEN local."modifiers"
      ELSE synced."modifiers"
    END AS "modifiers",
   CASE
    WHEN 'colorA' = ANY(local.changed_columns)
      THEN local."colorA"
      ELSE synced."colorA"
    END AS "colorA",
   CASE
    WHEN 'colorB' = ANY(local.changed_columns)
      THEN local."colorB"
      ELSE synced."colorB"
    END AS "colorB",
   CASE
    WHEN 'colorC' = ANY(local.changed_columns)
      THEN local."colorC"
      ELSE synced."colorC"
    END AS "colorC",
   COALESCE(local."itemId", synced."itemId") AS "itemId"
  FROM "option_synced" AS synced
  FULL OUTER JOIN "option_local" AS local
  ON synced."itemId" = local."itemId"
  WHERE (local."itemId" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION option_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "option_local" (
    "baseDef", "modifiers", "colorA", "colorB", "colorC", "itemId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."baseDef", NEW."modifiers", NEW."colorA", NEW."colorB", NEW."colorC", NEW."itemId",
    ARRAY['baseDef', 'modifiers', 'colorA', 'colorB', 'colorC'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'option',
    'insert',
    jsonb_build_object(
        'baseDef', NEW."baseDef",
      'modifiers', NEW."modifiers",
      'colorA', NEW."colorA",
      'colorB', NEW."colorB",
      'colorC', NEW."colorC",
      'itemId', NEW."itemId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION option_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "option_synced"%ROWTYPE;
    local "option_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "option_synced" WHERE "itemId" = NEW."itemId";
    SELECT * INTO local FROM "option_local" WHERE "itemId" = NEW."itemId";
    
    IF NEW."baseDef" IS DISTINCT FROM synced."baseDef" THEN
      changed_cols := array_append(changed_cols, 'baseDef');
    END IF;
    IF NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN
      changed_cols := array_append(changed_cols, 'modifiers');
    END IF;
    IF NEW."colorA" IS DISTINCT FROM synced."colorA" THEN
      changed_cols := array_append(changed_cols, 'colorA');
    END IF;
    IF NEW."colorB" IS DISTINCT FROM synced."colorB" THEN
      changed_cols := array_append(changed_cols, 'colorB');
    END IF;
    IF NEW."colorC" IS DISTINCT FROM synced."colorC" THEN
      changed_cols := array_append(changed_cols, 'colorC');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "option_local" (
        "baseDef", "modifiers", "colorA", "colorB", "colorC", "itemId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."baseDef", NEW."modifiers", NEW."colorA", NEW."colorB", NEW."colorC", NEW."itemId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "option_local"
    SET
        
    "baseDef" = CASE WHEN NEW."baseDef" IS DISTINCT FROM synced."baseDef" THEN NEW."baseDef" ELSE local."baseDef" END,
    "modifiers" = CASE WHEN NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN NEW."modifiers" ELSE local."modifiers" END,
    "colorA" = CASE WHEN NEW."colorA" IS DISTINCT FROM synced."colorA" THEN NEW."colorA" ELSE local."colorA" END,
    "colorB" = CASE WHEN NEW."colorB" IS DISTINCT FROM synced."colorB" THEN NEW."colorB" ELSE local."colorB" END,
    "colorC" = CASE WHEN NEW."colorC" IS DISTINCT FROM synced."colorC" THEN NEW."colorC" ELSE local."colorC" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "itemId" = NEW."itemId";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'option',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'baseDef', COALESCE(NEW."baseDef", local."baseDef"),
      'modifiers', COALESCE(NEW."modifiers", local."modifiers"),
      'colorA', COALESCE(NEW."colorA", local."colorA"),
      'colorB', COALESCE(NEW."colorB", local."colorB"),
      'colorC', COALESCE(NEW."colorC", local."colorC"),
      'itemId', COALESCE(NEW."itemId", local."itemId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION option_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "option_local" WHERE "itemId" = OLD."itemId") THEN
    UPDATE "option_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "itemId" = OLD."itemId";
    ELSE
    INSERT INTO "option_local" (
        itemId,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."itemId",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'option',
    'delete',
    jsonb_build_object('itemId', OLD."itemId"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER option_insert
INSTEAD OF INSERT ON "option"
FOR EACH ROW EXECUTE FUNCTION option_insert_trigger();

CREATE OR REPLACE TRIGGER option_update
INSTEAD OF UPDATE ON "option"
FOR EACH ROW EXECUTE FUNCTION option_update_trigger();

CREATE OR REPLACE TRIGGER option_delete
INSTEAD OF DELETE ON "option"
FOR EACH ROW EXECUTE FUNCTION option_delete_trigger();


CREATE OR REPLACE FUNCTION option_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "option_local"
  WHERE "itemId" = NEW."itemId"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION option_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "option_local"
  WHERE "itemId" = OLD."itemId";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "option_synced"
FOR EACH ROW EXECUTE FUNCTION option_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "option_synced"
FOR EACH ROW EXECUTE FUNCTION option_delete_local_on_synced_delete_trigger();

-- CreateTable
-- player
CREATE TABLE IF NOT EXISTS "player_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "useIn" TEXT NOT NULL,
  "actions" JSONB NOT NULL,
  "accountId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "player_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "player_local" (
  "id" TEXT,
  "name" TEXT,
  "useIn" TEXT,
  "actions" JSONB,
  "accountId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "player_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "player" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'useIn' = ANY(local.changed_columns)
      THEN local."useIn"
      ELSE synced."useIn"
    END AS "useIn",
   CASE
    WHEN 'actions' = ANY(local.changed_columns)
      THEN local."actions"
      ELSE synced."actions"
    END AS "actions",
   CASE
    WHEN 'accountId' = ANY(local.changed_columns)
      THEN local."accountId"
      ELSE synced."accountId"
    END AS "accountId"
  FROM "player_synced" AS synced
  FULL OUTER JOIN "player_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION player_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "player_local" (
    "id", "name", "useIn", "actions", "accountId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."useIn", NEW."actions", NEW."accountId",
    ARRAY['name', 'useIn', 'actions', 'accountId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'useIn', NEW."useIn",
      'actions', NEW."actions",
      'accountId', NEW."accountId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION player_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "player_synced"%ROWTYPE;
    local "player_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "player_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "player_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."useIn" IS DISTINCT FROM synced."useIn" THEN
      changed_cols := array_append(changed_cols, 'useIn');
    END IF;
    IF NEW."actions" IS DISTINCT FROM synced."actions" THEN
      changed_cols := array_append(changed_cols, 'actions');
    END IF;
    IF NEW."accountId" IS DISTINCT FROM synced."accountId" THEN
      changed_cols := array_append(changed_cols, 'accountId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "player_local" (
        "id", "name", "useIn", "actions", "accountId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."useIn", NEW."actions", NEW."accountId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "player_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "useIn" = CASE WHEN NEW."useIn" IS DISTINCT FROM synced."useIn" THEN NEW."useIn" ELSE local."useIn" END,
    "actions" = CASE WHEN NEW."actions" IS DISTINCT FROM synced."actions" THEN NEW."actions" ELSE local."actions" END,
    "accountId" = CASE WHEN NEW."accountId" IS DISTINCT FROM synced."accountId" THEN NEW."accountId" ELSE local."accountId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'useIn', COALESCE(NEW."useIn", local."useIn"),
      'actions', COALESCE(NEW."actions", local."actions"),
      'accountId', COALESCE(NEW."accountId", local."accountId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION player_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "player_local" WHERE "id" = OLD."id") THEN
    UPDATE "player_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "player_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER player_insert
INSTEAD OF INSERT ON "player"
FOR EACH ROW EXECUTE FUNCTION player_insert_trigger();

CREATE OR REPLACE TRIGGER player_update
INSTEAD OF UPDATE ON "player"
FOR EACH ROW EXECUTE FUNCTION player_update_trigger();

CREATE OR REPLACE TRIGGER player_delete
INSTEAD OF DELETE ON "player"
FOR EACH ROW EXECUTE FUNCTION player_delete_trigger();


CREATE OR REPLACE FUNCTION player_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "player_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION player_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "player_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "player_synced"
FOR EACH ROW EXECUTE FUNCTION player_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "player_synced"
FOR EACH ROW EXECUTE FUNCTION player_delete_local_on_synced_delete_trigger();

-- CreateTable
-- player_armor
CREATE TABLE IF NOT EXISTS "player_armor_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "extraAbi" INTEGER NOT NULL,
  "ability" "PlayerArmorAbilityType" NOT NULL,
  "templateId" TEXT,
  "refinement" INTEGER NOT NULL,
  "modifiers" TEXT[],
  "masterId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "player_armor_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "player_armor_local" (
  "id" TEXT,
  "name" TEXT,
  "extraAbi" INTEGER,
  "ability" "PlayerArmorAbilityType",
  "templateId" TEXT,
  "refinement" INTEGER,
  "modifiers" TEXT[],
  "masterId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "player_armor_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "player_armor" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'extraAbi' = ANY(local.changed_columns)
      THEN local."extraAbi"
      ELSE synced."extraAbi"
    END AS "extraAbi",
   CASE
    WHEN 'ability' = ANY(local.changed_columns)
      THEN local."ability"
      ELSE synced."ability"
    END AS "ability",
   CASE
    WHEN 'templateId' = ANY(local.changed_columns)
      THEN local."templateId"
      ELSE synced."templateId"
    END AS "templateId",
   CASE
    WHEN 'refinement' = ANY(local.changed_columns)
      THEN local."refinement"
      ELSE synced."refinement"
    END AS "refinement",
   CASE
    WHEN 'modifiers' = ANY(local.changed_columns)
      THEN local."modifiers"
      ELSE synced."modifiers"
    END AS "modifiers",
   CASE
    WHEN 'masterId' = ANY(local.changed_columns)
      THEN local."masterId"
      ELSE synced."masterId"
    END AS "masterId"
  FROM "player_armor_synced" AS synced
  FULL OUTER JOIN "player_armor_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION player_armor_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "player_armor_local" (
    "id", "name", "extraAbi", "ability", "templateId", "refinement", "modifiers", "masterId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."extraAbi", NEW."ability", NEW."templateId", NEW."refinement", NEW."modifiers", NEW."masterId",
    ARRAY['name', 'extraAbi', 'ability', 'templateId', 'refinement', 'modifiers', 'masterId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_armor',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'extraAbi', NEW."extraAbi",
      'ability', NEW."ability",
      'templateId', NEW."templateId",
      'refinement', NEW."refinement",
      'modifiers', NEW."modifiers",
      'masterId', NEW."masterId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION player_armor_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "player_armor_synced"%ROWTYPE;
    local "player_armor_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "player_armor_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "player_armor_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."extraAbi" IS DISTINCT FROM synced."extraAbi" THEN
      changed_cols := array_append(changed_cols, 'extraAbi');
    END IF;
    IF NEW."ability" IS DISTINCT FROM synced."ability" THEN
      changed_cols := array_append(changed_cols, 'ability');
    END IF;
    IF NEW."templateId" IS DISTINCT FROM synced."templateId" THEN
      changed_cols := array_append(changed_cols, 'templateId');
    END IF;
    IF NEW."refinement" IS DISTINCT FROM synced."refinement" THEN
      changed_cols := array_append(changed_cols, 'refinement');
    END IF;
    IF NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN
      changed_cols := array_append(changed_cols, 'modifiers');
    END IF;
    IF NEW."masterId" IS DISTINCT FROM synced."masterId" THEN
      changed_cols := array_append(changed_cols, 'masterId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "player_armor_local" (
        "id", "name", "extraAbi", "ability", "templateId", "refinement", "modifiers", "masterId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."extraAbi", NEW."ability", NEW."templateId", NEW."refinement", NEW."modifiers", NEW."masterId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "player_armor_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "extraAbi" = CASE WHEN NEW."extraAbi" IS DISTINCT FROM synced."extraAbi" THEN NEW."extraAbi" ELSE local."extraAbi" END,
    "ability" = CASE WHEN NEW."ability" IS DISTINCT FROM synced."ability" THEN NEW."ability" ELSE local."ability" END,
    "templateId" = CASE WHEN NEW."templateId" IS DISTINCT FROM synced."templateId" THEN NEW."templateId" ELSE local."templateId" END,
    "refinement" = CASE WHEN NEW."refinement" IS DISTINCT FROM synced."refinement" THEN NEW."refinement" ELSE local."refinement" END,
    "modifiers" = CASE WHEN NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN NEW."modifiers" ELSE local."modifiers" END,
    "masterId" = CASE WHEN NEW."masterId" IS DISTINCT FROM synced."masterId" THEN NEW."masterId" ELSE local."masterId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_armor',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'extraAbi', COALESCE(NEW."extraAbi", local."extraAbi"),
      'ability', COALESCE(NEW."ability", local."ability"),
      'templateId', COALESCE(NEW."templateId", local."templateId"),
      'refinement', COALESCE(NEW."refinement", local."refinement"),
      'modifiers', COALESCE(NEW."modifiers", local."modifiers"),
      'masterId', COALESCE(NEW."masterId", local."masterId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION player_armor_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "player_armor_local" WHERE "id" = OLD."id") THEN
    UPDATE "player_armor_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "player_armor_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_armor',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER player_armor_insert
INSTEAD OF INSERT ON "player_armor"
FOR EACH ROW EXECUTE FUNCTION player_armor_insert_trigger();

CREATE OR REPLACE TRIGGER player_armor_update
INSTEAD OF UPDATE ON "player_armor"
FOR EACH ROW EXECUTE FUNCTION player_armor_update_trigger();

CREATE OR REPLACE TRIGGER player_armor_delete
INSTEAD OF DELETE ON "player_armor"
FOR EACH ROW EXECUTE FUNCTION player_armor_delete_trigger();


CREATE OR REPLACE FUNCTION player_armor_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "player_armor_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION player_armor_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "player_armor_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "player_armor_synced"
FOR EACH ROW EXECUTE FUNCTION player_armor_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "player_armor_synced"
FOR EACH ROW EXECUTE FUNCTION player_armor_delete_local_on_synced_delete_trigger();

-- CreateTable
-- player_option
CREATE TABLE IF NOT EXISTS "player_option_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "extraAbi" INTEGER NOT NULL,
  "templateId" TEXT NOT NULL,
  "refinement" INTEGER NOT NULL,
  "masterId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "player_option_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "player_option_local" (
  "id" TEXT,
  "name" TEXT,
  "extraAbi" INTEGER,
  "templateId" TEXT,
  "refinement" INTEGER,
  "masterId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "player_option_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "player_option" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'extraAbi' = ANY(local.changed_columns)
      THEN local."extraAbi"
      ELSE synced."extraAbi"
    END AS "extraAbi",
   CASE
    WHEN 'templateId' = ANY(local.changed_columns)
      THEN local."templateId"
      ELSE synced."templateId"
    END AS "templateId",
   CASE
    WHEN 'refinement' = ANY(local.changed_columns)
      THEN local."refinement"
      ELSE synced."refinement"
    END AS "refinement",
   CASE
    WHEN 'masterId' = ANY(local.changed_columns)
      THEN local."masterId"
      ELSE synced."masterId"
    END AS "masterId"
  FROM "player_option_synced" AS synced
  FULL OUTER JOIN "player_option_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION player_option_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "player_option_local" (
    "id", "name", "extraAbi", "templateId", "refinement", "masterId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."extraAbi", NEW."templateId", NEW."refinement", NEW."masterId",
    ARRAY['name', 'extraAbi', 'templateId', 'refinement', 'masterId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_option',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'extraAbi', NEW."extraAbi",
      'templateId', NEW."templateId",
      'refinement', NEW."refinement",
      'masterId', NEW."masterId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION player_option_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "player_option_synced"%ROWTYPE;
    local "player_option_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "player_option_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "player_option_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."extraAbi" IS DISTINCT FROM synced."extraAbi" THEN
      changed_cols := array_append(changed_cols, 'extraAbi');
    END IF;
    IF NEW."templateId" IS DISTINCT FROM synced."templateId" THEN
      changed_cols := array_append(changed_cols, 'templateId');
    END IF;
    IF NEW."refinement" IS DISTINCT FROM synced."refinement" THEN
      changed_cols := array_append(changed_cols, 'refinement');
    END IF;
    IF NEW."masterId" IS DISTINCT FROM synced."masterId" THEN
      changed_cols := array_append(changed_cols, 'masterId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "player_option_local" (
        "id", "name", "extraAbi", "templateId", "refinement", "masterId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."extraAbi", NEW."templateId", NEW."refinement", NEW."masterId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "player_option_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "extraAbi" = CASE WHEN NEW."extraAbi" IS DISTINCT FROM synced."extraAbi" THEN NEW."extraAbi" ELSE local."extraAbi" END,
    "templateId" = CASE WHEN NEW."templateId" IS DISTINCT FROM synced."templateId" THEN NEW."templateId" ELSE local."templateId" END,
    "refinement" = CASE WHEN NEW."refinement" IS DISTINCT FROM synced."refinement" THEN NEW."refinement" ELSE local."refinement" END,
    "masterId" = CASE WHEN NEW."masterId" IS DISTINCT FROM synced."masterId" THEN NEW."masterId" ELSE local."masterId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_option',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'extraAbi', COALESCE(NEW."extraAbi", local."extraAbi"),
      'templateId', COALESCE(NEW."templateId", local."templateId"),
      'refinement', COALESCE(NEW."refinement", local."refinement"),
      'masterId', COALESCE(NEW."masterId", local."masterId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION player_option_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "player_option_local" WHERE "id" = OLD."id") THEN
    UPDATE "player_option_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "player_option_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_option',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER player_option_insert
INSTEAD OF INSERT ON "player_option"
FOR EACH ROW EXECUTE FUNCTION player_option_insert_trigger();

CREATE OR REPLACE TRIGGER player_option_update
INSTEAD OF UPDATE ON "player_option"
FOR EACH ROW EXECUTE FUNCTION player_option_update_trigger();

CREATE OR REPLACE TRIGGER player_option_delete
INSTEAD OF DELETE ON "player_option"
FOR EACH ROW EXECUTE FUNCTION player_option_delete_trigger();


CREATE OR REPLACE FUNCTION player_option_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "player_option_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION player_option_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "player_option_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "player_option_synced"
FOR EACH ROW EXECUTE FUNCTION player_option_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "player_option_synced"
FOR EACH ROW EXECUTE FUNCTION player_option_delete_local_on_synced_delete_trigger();

-- CreateTable
-- player_pet
CREATE TABLE IF NOT EXISTS "player_pet_synced" (
  "id" TEXT NOT NULL,
  "templateId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "pStr" INTEGER NOT NULL,
  "pInt" INTEGER NOT NULL,
  "pVit" INTEGER NOT NULL,
  "pAgi" INTEGER NOT NULL,
  "pDex" INTEGER NOT NULL,
  "str" INTEGER NOT NULL,
  "int" INTEGER NOT NULL,
  "vit" INTEGER NOT NULL,
  "agi" INTEGER NOT NULL,
  "dex" INTEGER NOT NULL,
  "weaponType" "MainWeaponType" NOT NULL,
  "personaType" "PetPersonaType" NOT NULL,
  "type" "PetType" NOT NULL,
  "weaponAtk" INTEGER NOT NULL,
  "generation" INTEGER NOT NULL,
  "maxLv" INTEGER NOT NULL,
  "masterId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "player_pet_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "player_pet_local" (
  "id" TEXT,
  "templateId" TEXT,
  "name" TEXT,
  "pStr" INTEGER,
  "pInt" INTEGER,
  "pVit" INTEGER,
  "pAgi" INTEGER,
  "pDex" INTEGER,
  "str" INTEGER,
  "int" INTEGER,
  "vit" INTEGER,
  "agi" INTEGER,
  "dex" INTEGER,
  "weaponType" "MainWeaponType",
  "personaType" "PetPersonaType",
  "type" "PetType",
  "weaponAtk" INTEGER,
  "generation" INTEGER,
  "maxLv" INTEGER,
  "masterId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "player_pet_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "player_pet" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'templateId' = ANY(local.changed_columns)
      THEN local."templateId"
      ELSE synced."templateId"
    END AS "templateId",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'pStr' = ANY(local.changed_columns)
      THEN local."pStr"
      ELSE synced."pStr"
    END AS "pStr",
   CASE
    WHEN 'pInt' = ANY(local.changed_columns)
      THEN local."pInt"
      ELSE synced."pInt"
    END AS "pInt",
   CASE
    WHEN 'pVit' = ANY(local.changed_columns)
      THEN local."pVit"
      ELSE synced."pVit"
    END AS "pVit",
   CASE
    WHEN 'pAgi' = ANY(local.changed_columns)
      THEN local."pAgi"
      ELSE synced."pAgi"
    END AS "pAgi",
   CASE
    WHEN 'pDex' = ANY(local.changed_columns)
      THEN local."pDex"
      ELSE synced."pDex"
    END AS "pDex",
   CASE
    WHEN 'str' = ANY(local.changed_columns)
      THEN local."str"
      ELSE synced."str"
    END AS "str",
   CASE
    WHEN 'int' = ANY(local.changed_columns)
      THEN local."int"
      ELSE synced."int"
    END AS "int",
   CASE
    WHEN 'vit' = ANY(local.changed_columns)
      THEN local."vit"
      ELSE synced."vit"
    END AS "vit",
   CASE
    WHEN 'agi' = ANY(local.changed_columns)
      THEN local."agi"
      ELSE synced."agi"
    END AS "agi",
   CASE
    WHEN 'dex' = ANY(local.changed_columns)
      THEN local."dex"
      ELSE synced."dex"
    END AS "dex",
   CASE
    WHEN 'weaponType' = ANY(local.changed_columns)
      THEN local."weaponType"
      ELSE synced."weaponType"
    END AS "weaponType",
   CASE
    WHEN 'personaType' = ANY(local.changed_columns)
      THEN local."personaType"
      ELSE synced."personaType"
    END AS "personaType",
   CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   CASE
    WHEN 'weaponAtk' = ANY(local.changed_columns)
      THEN local."weaponAtk"
      ELSE synced."weaponAtk"
    END AS "weaponAtk",
   CASE
    WHEN 'generation' = ANY(local.changed_columns)
      THEN local."generation"
      ELSE synced."generation"
    END AS "generation",
   CASE
    WHEN 'maxLv' = ANY(local.changed_columns)
      THEN local."maxLv"
      ELSE synced."maxLv"
    END AS "maxLv",
   CASE
    WHEN 'masterId' = ANY(local.changed_columns)
      THEN local."masterId"
      ELSE synced."masterId"
    END AS "masterId"
  FROM "player_pet_synced" AS synced
  FULL OUTER JOIN "player_pet_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION player_pet_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "player_pet_local" (
    "id", "templateId", "name", "pStr", "pInt", "pVit", "pAgi", "pDex", "str", "int", "vit", "agi", "dex", "weaponType", "personaType", "type", "weaponAtk", "generation", "maxLv", "masterId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."templateId", NEW."name", NEW."pStr", NEW."pInt", NEW."pVit", NEW."pAgi", NEW."pDex", NEW."str", NEW."int", NEW."vit", NEW."agi", NEW."dex", NEW."weaponType", NEW."personaType", NEW."type", NEW."weaponAtk", NEW."generation", NEW."maxLv", NEW."masterId",
    ARRAY['templateId', 'name', 'pStr', 'pInt', 'pVit', 'pAgi', 'pDex', 'str', 'int', 'vit', 'agi', 'dex', 'weaponType', 'personaType', 'type', 'weaponAtk', 'generation', 'maxLv', 'masterId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_pet',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'templateId', NEW."templateId",
      'name', NEW."name",
      'pStr', NEW."pStr",
      'pInt', NEW."pInt",
      'pVit', NEW."pVit",
      'pAgi', NEW."pAgi",
      'pDex', NEW."pDex",
      'str', NEW."str",
      'int', NEW."int",
      'vit', NEW."vit",
      'agi', NEW."agi",
      'dex', NEW."dex",
      'weaponType', NEW."weaponType",
      'personaType', NEW."personaType",
      'type', NEW."type",
      'weaponAtk', NEW."weaponAtk",
      'generation', NEW."generation",
      'maxLv', NEW."maxLv",
      'masterId', NEW."masterId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION player_pet_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "player_pet_synced"%ROWTYPE;
    local "player_pet_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "player_pet_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "player_pet_local" WHERE "id" = NEW."id";
    
    IF NEW."templateId" IS DISTINCT FROM synced."templateId" THEN
      changed_cols := array_append(changed_cols, 'templateId');
    END IF;
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."pStr" IS DISTINCT FROM synced."pStr" THEN
      changed_cols := array_append(changed_cols, 'pStr');
    END IF;
    IF NEW."pInt" IS DISTINCT FROM synced."pInt" THEN
      changed_cols := array_append(changed_cols, 'pInt');
    END IF;
    IF NEW."pVit" IS DISTINCT FROM synced."pVit" THEN
      changed_cols := array_append(changed_cols, 'pVit');
    END IF;
    IF NEW."pAgi" IS DISTINCT FROM synced."pAgi" THEN
      changed_cols := array_append(changed_cols, 'pAgi');
    END IF;
    IF NEW."pDex" IS DISTINCT FROM synced."pDex" THEN
      changed_cols := array_append(changed_cols, 'pDex');
    END IF;
    IF NEW."str" IS DISTINCT FROM synced."str" THEN
      changed_cols := array_append(changed_cols, 'str');
    END IF;
    IF NEW."int" IS DISTINCT FROM synced."int" THEN
      changed_cols := array_append(changed_cols, 'int');
    END IF;
    IF NEW."vit" IS DISTINCT FROM synced."vit" THEN
      changed_cols := array_append(changed_cols, 'vit');
    END IF;
    IF NEW."agi" IS DISTINCT FROM synced."agi" THEN
      changed_cols := array_append(changed_cols, 'agi');
    END IF;
    IF NEW."dex" IS DISTINCT FROM synced."dex" THEN
      changed_cols := array_append(changed_cols, 'dex');
    END IF;
    IF NEW."weaponType" IS DISTINCT FROM synced."weaponType" THEN
      changed_cols := array_append(changed_cols, 'weaponType');
    END IF;
    IF NEW."personaType" IS DISTINCT FROM synced."personaType" THEN
      changed_cols := array_append(changed_cols, 'personaType');
    END IF;
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."weaponAtk" IS DISTINCT FROM synced."weaponAtk" THEN
      changed_cols := array_append(changed_cols, 'weaponAtk');
    END IF;
    IF NEW."generation" IS DISTINCT FROM synced."generation" THEN
      changed_cols := array_append(changed_cols, 'generation');
    END IF;
    IF NEW."maxLv" IS DISTINCT FROM synced."maxLv" THEN
      changed_cols := array_append(changed_cols, 'maxLv');
    END IF;
    IF NEW."masterId" IS DISTINCT FROM synced."masterId" THEN
      changed_cols := array_append(changed_cols, 'masterId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "player_pet_local" (
        "id", "templateId", "name", "pStr", "pInt", "pVit", "pAgi", "pDex", "str", "int", "vit", "agi", "dex", "weaponType", "personaType", "type", "weaponAtk", "generation", "maxLv", "masterId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."templateId", NEW."name", NEW."pStr", NEW."pInt", NEW."pVit", NEW."pAgi", NEW."pDex", NEW."str", NEW."int", NEW."vit", NEW."agi", NEW."dex", NEW."weaponType", NEW."personaType", NEW."type", NEW."weaponAtk", NEW."generation", NEW."maxLv", NEW."masterId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "player_pet_local"
    SET
        
    "templateId" = CASE WHEN NEW."templateId" IS DISTINCT FROM synced."templateId" THEN NEW."templateId" ELSE local."templateId" END,
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "pStr" = CASE WHEN NEW."pStr" IS DISTINCT FROM synced."pStr" THEN NEW."pStr" ELSE local."pStr" END,
    "pInt" = CASE WHEN NEW."pInt" IS DISTINCT FROM synced."pInt" THEN NEW."pInt" ELSE local."pInt" END,
    "pVit" = CASE WHEN NEW."pVit" IS DISTINCT FROM synced."pVit" THEN NEW."pVit" ELSE local."pVit" END,
    "pAgi" = CASE WHEN NEW."pAgi" IS DISTINCT FROM synced."pAgi" THEN NEW."pAgi" ELSE local."pAgi" END,
    "pDex" = CASE WHEN NEW."pDex" IS DISTINCT FROM synced."pDex" THEN NEW."pDex" ELSE local."pDex" END,
    "str" = CASE WHEN NEW."str" IS DISTINCT FROM synced."str" THEN NEW."str" ELSE local."str" END,
    "int" = CASE WHEN NEW."int" IS DISTINCT FROM synced."int" THEN NEW."int" ELSE local."int" END,
    "vit" = CASE WHEN NEW."vit" IS DISTINCT FROM synced."vit" THEN NEW."vit" ELSE local."vit" END,
    "agi" = CASE WHEN NEW."agi" IS DISTINCT FROM synced."agi" THEN NEW."agi" ELSE local."agi" END,
    "dex" = CASE WHEN NEW."dex" IS DISTINCT FROM synced."dex" THEN NEW."dex" ELSE local."dex" END,
    "weaponType" = CASE WHEN NEW."weaponType" IS DISTINCT FROM synced."weaponType" THEN NEW."weaponType" ELSE local."weaponType" END,
    "personaType" = CASE WHEN NEW."personaType" IS DISTINCT FROM synced."personaType" THEN NEW."personaType" ELSE local."personaType" END,
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "weaponAtk" = CASE WHEN NEW."weaponAtk" IS DISTINCT FROM synced."weaponAtk" THEN NEW."weaponAtk" ELSE local."weaponAtk" END,
    "generation" = CASE WHEN NEW."generation" IS DISTINCT FROM synced."generation" THEN NEW."generation" ELSE local."generation" END,
    "maxLv" = CASE WHEN NEW."maxLv" IS DISTINCT FROM synced."maxLv" THEN NEW."maxLv" ELSE local."maxLv" END,
    "masterId" = CASE WHEN NEW."masterId" IS DISTINCT FROM synced."masterId" THEN NEW."masterId" ELSE local."masterId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_pet',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'templateId', COALESCE(NEW."templateId", local."templateId"),
      'name', COALESCE(NEW."name", local."name"),
      'pStr', COALESCE(NEW."pStr", local."pStr"),
      'pInt', COALESCE(NEW."pInt", local."pInt"),
      'pVit', COALESCE(NEW."pVit", local."pVit"),
      'pAgi', COALESCE(NEW."pAgi", local."pAgi"),
      'pDex', COALESCE(NEW."pDex", local."pDex"),
      'str', COALESCE(NEW."str", local."str"),
      'int', COALESCE(NEW."int", local."int"),
      'vit', COALESCE(NEW."vit", local."vit"),
      'agi', COALESCE(NEW."agi", local."agi"),
      'dex', COALESCE(NEW."dex", local."dex"),
      'weaponType', COALESCE(NEW."weaponType", local."weaponType"),
      'personaType', COALESCE(NEW."personaType", local."personaType"),
      'type', COALESCE(NEW."type", local."type"),
      'weaponAtk', COALESCE(NEW."weaponAtk", local."weaponAtk"),
      'generation', COALESCE(NEW."generation", local."generation"),
      'maxLv', COALESCE(NEW."maxLv", local."maxLv"),
      'masterId', COALESCE(NEW."masterId", local."masterId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION player_pet_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "player_pet_local" WHERE "id" = OLD."id") THEN
    UPDATE "player_pet_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "player_pet_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_pet',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER player_pet_insert
INSTEAD OF INSERT ON "player_pet"
FOR EACH ROW EXECUTE FUNCTION player_pet_insert_trigger();

CREATE OR REPLACE TRIGGER player_pet_update
INSTEAD OF UPDATE ON "player_pet"
FOR EACH ROW EXECUTE FUNCTION player_pet_update_trigger();

CREATE OR REPLACE TRIGGER player_pet_delete
INSTEAD OF DELETE ON "player_pet"
FOR EACH ROW EXECUTE FUNCTION player_pet_delete_trigger();


CREATE OR REPLACE FUNCTION player_pet_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "player_pet_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION player_pet_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "player_pet_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "player_pet_synced"
FOR EACH ROW EXECUTE FUNCTION player_pet_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "player_pet_synced"
FOR EACH ROW EXECUTE FUNCTION player_pet_delete_local_on_synced_delete_trigger();

-- CreateTable
-- player_special
CREATE TABLE IF NOT EXISTS "player_special_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "extraAbi" INTEGER NOT NULL,
  "templateId" TEXT NOT NULL,
  "masterId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "player_special_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "player_special_local" (
  "id" TEXT,
  "name" TEXT,
  "extraAbi" INTEGER,
  "templateId" TEXT,
  "masterId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "player_special_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "player_special" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'extraAbi' = ANY(local.changed_columns)
      THEN local."extraAbi"
      ELSE synced."extraAbi"
    END AS "extraAbi",
   CASE
    WHEN 'templateId' = ANY(local.changed_columns)
      THEN local."templateId"
      ELSE synced."templateId"
    END AS "templateId",
   CASE
    WHEN 'masterId' = ANY(local.changed_columns)
      THEN local."masterId"
      ELSE synced."masterId"
    END AS "masterId"
  FROM "player_special_synced" AS synced
  FULL OUTER JOIN "player_special_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION player_special_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "player_special_local" (
    "id", "name", "extraAbi", "templateId", "masterId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."extraAbi", NEW."templateId", NEW."masterId",
    ARRAY['name', 'extraAbi', 'templateId', 'masterId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_special',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'extraAbi', NEW."extraAbi",
      'templateId', NEW."templateId",
      'masterId', NEW."masterId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION player_special_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "player_special_synced"%ROWTYPE;
    local "player_special_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "player_special_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "player_special_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."extraAbi" IS DISTINCT FROM synced."extraAbi" THEN
      changed_cols := array_append(changed_cols, 'extraAbi');
    END IF;
    IF NEW."templateId" IS DISTINCT FROM synced."templateId" THEN
      changed_cols := array_append(changed_cols, 'templateId');
    END IF;
    IF NEW."masterId" IS DISTINCT FROM synced."masterId" THEN
      changed_cols := array_append(changed_cols, 'masterId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "player_special_local" (
        "id", "name", "extraAbi", "templateId", "masterId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."extraAbi", NEW."templateId", NEW."masterId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "player_special_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "extraAbi" = CASE WHEN NEW."extraAbi" IS DISTINCT FROM synced."extraAbi" THEN NEW."extraAbi" ELSE local."extraAbi" END,
    "templateId" = CASE WHEN NEW."templateId" IS DISTINCT FROM synced."templateId" THEN NEW."templateId" ELSE local."templateId" END,
    "masterId" = CASE WHEN NEW."masterId" IS DISTINCT FROM synced."masterId" THEN NEW."masterId" ELSE local."masterId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_special',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'extraAbi', COALESCE(NEW."extraAbi", local."extraAbi"),
      'templateId', COALESCE(NEW."templateId", local."templateId"),
      'masterId', COALESCE(NEW."masterId", local."masterId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION player_special_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "player_special_local" WHERE "id" = OLD."id") THEN
    UPDATE "player_special_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "player_special_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_special',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER player_special_insert
INSTEAD OF INSERT ON "player_special"
FOR EACH ROW EXECUTE FUNCTION player_special_insert_trigger();

CREATE OR REPLACE TRIGGER player_special_update
INSTEAD OF UPDATE ON "player_special"
FOR EACH ROW EXECUTE FUNCTION player_special_update_trigger();

CREATE OR REPLACE TRIGGER player_special_delete
INSTEAD OF DELETE ON "player_special"
FOR EACH ROW EXECUTE FUNCTION player_special_delete_trigger();


CREATE OR REPLACE FUNCTION player_special_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "player_special_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION player_special_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "player_special_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "player_special_synced"
FOR EACH ROW EXECUTE FUNCTION player_special_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "player_special_synced"
FOR EACH ROW EXECUTE FUNCTION player_special_delete_local_on_synced_delete_trigger();

-- CreateTable
-- player_weapon
CREATE TABLE IF NOT EXISTS "player_weapon_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "baseAbi" INTEGER NOT NULL,
  "stability" INTEGER NOT NULL,
  "extraAbi" INTEGER NOT NULL,
  "templateId" TEXT,
  "refinement" INTEGER NOT NULL,
  "modifiers" TEXT[],
  "masterId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "player_weapon_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "player_weapon_local" (
  "id" TEXT,
  "name" TEXT,
  "baseAbi" INTEGER,
  "stability" INTEGER,
  "extraAbi" INTEGER,
  "templateId" TEXT,
  "refinement" INTEGER,
  "modifiers" TEXT[],
  "masterId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "player_weapon_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "player_weapon" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'baseAbi' = ANY(local.changed_columns)
      THEN local."baseAbi"
      ELSE synced."baseAbi"
    END AS "baseAbi",
   CASE
    WHEN 'stability' = ANY(local.changed_columns)
      THEN local."stability"
      ELSE synced."stability"
    END AS "stability",
   CASE
    WHEN 'extraAbi' = ANY(local.changed_columns)
      THEN local."extraAbi"
      ELSE synced."extraAbi"
    END AS "extraAbi",
   CASE
    WHEN 'templateId' = ANY(local.changed_columns)
      THEN local."templateId"
      ELSE synced."templateId"
    END AS "templateId",
   CASE
    WHEN 'refinement' = ANY(local.changed_columns)
      THEN local."refinement"
      ELSE synced."refinement"
    END AS "refinement",
   CASE
    WHEN 'modifiers' = ANY(local.changed_columns)
      THEN local."modifiers"
      ELSE synced."modifiers"
    END AS "modifiers",
   CASE
    WHEN 'masterId' = ANY(local.changed_columns)
      THEN local."masterId"
      ELSE synced."masterId"
    END AS "masterId"
  FROM "player_weapon_synced" AS synced
  FULL OUTER JOIN "player_weapon_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION player_weapon_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "player_weapon_local" (
    "id", "name", "baseAbi", "stability", "extraAbi", "templateId", "refinement", "modifiers", "masterId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."baseAbi", NEW."stability", NEW."extraAbi", NEW."templateId", NEW."refinement", NEW."modifiers", NEW."masterId",
    ARRAY['name', 'baseAbi', 'stability', 'extraAbi', 'templateId', 'refinement', 'modifiers', 'masterId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_weapon',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'baseAbi', NEW."baseAbi",
      'stability', NEW."stability",
      'extraAbi', NEW."extraAbi",
      'templateId', NEW."templateId",
      'refinement', NEW."refinement",
      'modifiers', NEW."modifiers",
      'masterId', NEW."masterId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION player_weapon_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "player_weapon_synced"%ROWTYPE;
    local "player_weapon_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "player_weapon_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "player_weapon_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."baseAbi" IS DISTINCT FROM synced."baseAbi" THEN
      changed_cols := array_append(changed_cols, 'baseAbi');
    END IF;
    IF NEW."stability" IS DISTINCT FROM synced."stability" THEN
      changed_cols := array_append(changed_cols, 'stability');
    END IF;
    IF NEW."extraAbi" IS DISTINCT FROM synced."extraAbi" THEN
      changed_cols := array_append(changed_cols, 'extraAbi');
    END IF;
    IF NEW."templateId" IS DISTINCT FROM synced."templateId" THEN
      changed_cols := array_append(changed_cols, 'templateId');
    END IF;
    IF NEW."refinement" IS DISTINCT FROM synced."refinement" THEN
      changed_cols := array_append(changed_cols, 'refinement');
    END IF;
    IF NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN
      changed_cols := array_append(changed_cols, 'modifiers');
    END IF;
    IF NEW."masterId" IS DISTINCT FROM synced."masterId" THEN
      changed_cols := array_append(changed_cols, 'masterId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "player_weapon_local" (
        "id", "name", "baseAbi", "stability", "extraAbi", "templateId", "refinement", "modifiers", "masterId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."baseAbi", NEW."stability", NEW."extraAbi", NEW."templateId", NEW."refinement", NEW."modifiers", NEW."masterId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "player_weapon_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "baseAbi" = CASE WHEN NEW."baseAbi" IS DISTINCT FROM synced."baseAbi" THEN NEW."baseAbi" ELSE local."baseAbi" END,
    "stability" = CASE WHEN NEW."stability" IS DISTINCT FROM synced."stability" THEN NEW."stability" ELSE local."stability" END,
    "extraAbi" = CASE WHEN NEW."extraAbi" IS DISTINCT FROM synced."extraAbi" THEN NEW."extraAbi" ELSE local."extraAbi" END,
    "templateId" = CASE WHEN NEW."templateId" IS DISTINCT FROM synced."templateId" THEN NEW."templateId" ELSE local."templateId" END,
    "refinement" = CASE WHEN NEW."refinement" IS DISTINCT FROM synced."refinement" THEN NEW."refinement" ELSE local."refinement" END,
    "modifiers" = CASE WHEN NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN NEW."modifiers" ELSE local."modifiers" END,
    "masterId" = CASE WHEN NEW."masterId" IS DISTINCT FROM synced."masterId" THEN NEW."masterId" ELSE local."masterId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_weapon',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'baseAbi', COALESCE(NEW."baseAbi", local."baseAbi"),
      'stability', COALESCE(NEW."stability", local."stability"),
      'extraAbi', COALESCE(NEW."extraAbi", local."extraAbi"),
      'templateId', COALESCE(NEW."templateId", local."templateId"),
      'refinement', COALESCE(NEW."refinement", local."refinement"),
      'modifiers', COALESCE(NEW."modifiers", local."modifiers"),
      'masterId', COALESCE(NEW."masterId", local."masterId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION player_weapon_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "player_weapon_local" WHERE "id" = OLD."id") THEN
    UPDATE "player_weapon_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "player_weapon_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'player_weapon',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER player_weapon_insert
INSTEAD OF INSERT ON "player_weapon"
FOR EACH ROW EXECUTE FUNCTION player_weapon_insert_trigger();

CREATE OR REPLACE TRIGGER player_weapon_update
INSTEAD OF UPDATE ON "player_weapon"
FOR EACH ROW EXECUTE FUNCTION player_weapon_update_trigger();

CREATE OR REPLACE TRIGGER player_weapon_delete
INSTEAD OF DELETE ON "player_weapon"
FOR EACH ROW EXECUTE FUNCTION player_weapon_delete_trigger();


CREATE OR REPLACE FUNCTION player_weapon_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "player_weapon_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION player_weapon_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "player_weapon_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "player_weapon_synced"
FOR EACH ROW EXECUTE FUNCTION player_weapon_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "player_weapon_synced"
FOR EACH ROW EXECUTE FUNCTION player_weapon_delete_local_on_synced_delete_trigger();

-- CreateTable
-- post
CREATE TABLE IF NOT EXISTS "post_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  "createdById" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "post_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "post_local" (
  "id" TEXT,
  "name" TEXT,
  "createdAt" TIMESTAMP(3),
  "updatedAt" TIMESTAMP(3),
  "createdById" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "post_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "post" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'createdAt' = ANY(local.changed_columns)
      THEN local."createdAt"
      ELSE synced."createdAt"
    END AS "createdAt",
   CASE
    WHEN 'updatedAt' = ANY(local.changed_columns)
      THEN local."updatedAt"
      ELSE synced."updatedAt"
    END AS "updatedAt",
   CASE
    WHEN 'createdById' = ANY(local.changed_columns)
      THEN local."createdById"
      ELSE synced."createdById"
    END AS "createdById"
  FROM "post_synced" AS synced
  FULL OUTER JOIN "post_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION post_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "post_local" (
    "id", "name", "createdAt", "updatedAt", "createdById",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."createdAt", NEW."updatedAt", NEW."createdById",
    ARRAY['name', 'createdAt', 'updatedAt', 'createdById'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'post',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'createdAt', NEW."createdAt",
      'updatedAt', NEW."updatedAt",
      'createdById', NEW."createdById"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION post_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "post_synced"%ROWTYPE;
    local "post_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "post_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "post_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."createdAt" IS DISTINCT FROM synced."createdAt" THEN
      changed_cols := array_append(changed_cols, 'createdAt');
    END IF;
    IF NEW."updatedAt" IS DISTINCT FROM synced."updatedAt" THEN
      changed_cols := array_append(changed_cols, 'updatedAt');
    END IF;
    IF NEW."createdById" IS DISTINCT FROM synced."createdById" THEN
      changed_cols := array_append(changed_cols, 'createdById');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "post_local" (
        "id", "name", "createdAt", "updatedAt", "createdById",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."createdAt", NEW."updatedAt", NEW."createdById",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "post_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "createdAt" = CASE WHEN NEW."createdAt" IS DISTINCT FROM synced."createdAt" THEN NEW."createdAt" ELSE local."createdAt" END,
    "updatedAt" = CASE WHEN NEW."updatedAt" IS DISTINCT FROM synced."updatedAt" THEN NEW."updatedAt" ELSE local."updatedAt" END,
    "createdById" = CASE WHEN NEW."createdById" IS DISTINCT FROM synced."createdById" THEN NEW."createdById" ELSE local."createdById" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'post',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'createdAt', COALESCE(NEW."createdAt", local."createdAt"),
      'updatedAt', COALESCE(NEW."updatedAt", local."updatedAt"),
      'createdById', COALESCE(NEW."createdById", local."createdById")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION post_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "post_local" WHERE "id" = OLD."id") THEN
    UPDATE "post_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "post_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'post',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER post_insert
INSTEAD OF INSERT ON "post"
FOR EACH ROW EXECUTE FUNCTION post_insert_trigger();

CREATE OR REPLACE TRIGGER post_update
INSTEAD OF UPDATE ON "post"
FOR EACH ROW EXECUTE FUNCTION post_update_trigger();

CREATE OR REPLACE TRIGGER post_delete
INSTEAD OF DELETE ON "post"
FOR EACH ROW EXECUTE FUNCTION post_delete_trigger();


CREATE OR REPLACE FUNCTION post_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "post_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION post_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "post_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "post_synced"
FOR EACH ROW EXECUTE FUNCTION post_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "post_synced"
FOR EACH ROW EXECUTE FUNCTION post_delete_local_on_synced_delete_trigger();

-- CreateTable
-- recipe
CREATE TABLE IF NOT EXISTS "recipe_synced" (
  "id" TEXT NOT NULL,
  "itemId" TEXT NOT NULL,
  "activityId" TEXT,
  "write_id" UUID,
  CONSTRAINT "recipe_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "recipe_local" (
  "id" TEXT,
  "itemId" TEXT,
  "activityId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "recipe_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "recipe" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'itemId' = ANY(local.changed_columns)
      THEN local."itemId"
      ELSE synced."itemId"
    END AS "itemId",
   CASE
    WHEN 'activityId' = ANY(local.changed_columns)
      THEN local."activityId"
      ELSE synced."activityId"
    END AS "activityId"
  FROM "recipe_synced" AS synced
  FULL OUTER JOIN "recipe_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION recipe_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "recipe_local" (
    "id", "itemId", "activityId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."itemId", NEW."activityId",
    ARRAY['itemId', 'activityId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'recipe',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'itemId', NEW."itemId",
      'activityId', NEW."activityId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION recipe_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "recipe_synced"%ROWTYPE;
    local "recipe_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "recipe_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "recipe_local" WHERE "id" = NEW."id";
    
    IF NEW."itemId" IS DISTINCT FROM synced."itemId" THEN
      changed_cols := array_append(changed_cols, 'itemId');
    END IF;
    IF NEW."activityId" IS DISTINCT FROM synced."activityId" THEN
      changed_cols := array_append(changed_cols, 'activityId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "recipe_local" (
        "id", "itemId", "activityId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."itemId", NEW."activityId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "recipe_local"
    SET
        
    "itemId" = CASE WHEN NEW."itemId" IS DISTINCT FROM synced."itemId" THEN NEW."itemId" ELSE local."itemId" END,
    "activityId" = CASE WHEN NEW."activityId" IS DISTINCT FROM synced."activityId" THEN NEW."activityId" ELSE local."activityId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'recipe',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'itemId', COALESCE(NEW."itemId", local."itemId"),
      'activityId', COALESCE(NEW."activityId", local."activityId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION recipe_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "recipe_local" WHERE "id" = OLD."id") THEN
    UPDATE "recipe_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "recipe_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'recipe',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER recipe_insert
INSTEAD OF INSERT ON "recipe"
FOR EACH ROW EXECUTE FUNCTION recipe_insert_trigger();

CREATE OR REPLACE TRIGGER recipe_update
INSTEAD OF UPDATE ON "recipe"
FOR EACH ROW EXECUTE FUNCTION recipe_update_trigger();

CREATE OR REPLACE TRIGGER recipe_delete
INSTEAD OF DELETE ON "recipe"
FOR EACH ROW EXECUTE FUNCTION recipe_delete_trigger();


CREATE OR REPLACE FUNCTION recipe_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "recipe_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION recipe_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "recipe_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "recipe_synced"
FOR EACH ROW EXECUTE FUNCTION recipe_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "recipe_synced"
FOR EACH ROW EXECUTE FUNCTION recipe_delete_local_on_synced_delete_trigger();

-- CreateTable
-- recipe_ingredient
CREATE TABLE IF NOT EXISTS "recipe_ingredient_synced" (
  "id" TEXT NOT NULL,
  "count" INTEGER NOT NULL,
  "type" "RecipeIngredientType" NOT NULL,
  "itemId" TEXT,
  "recipeId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "recipe_ingredient_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "recipe_ingredient_local" (
  "id" TEXT,
  "count" INTEGER,
  "type" "RecipeIngredientType",
  "itemId" TEXT,
  "recipeId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "recipe_ingredient_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "recipe_ingredient" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'count' = ANY(local.changed_columns)
      THEN local."count"
      ELSE synced."count"
    END AS "count",
   CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   CASE
    WHEN 'itemId' = ANY(local.changed_columns)
      THEN local."itemId"
      ELSE synced."itemId"
    END AS "itemId",
   CASE
    WHEN 'recipeId' = ANY(local.changed_columns)
      THEN local."recipeId"
      ELSE synced."recipeId"
    END AS "recipeId"
  FROM "recipe_ingredient_synced" AS synced
  FULL OUTER JOIN "recipe_ingredient_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION recipe_ingredient_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "recipe_ingredient_local" (
    "id", "count", "type", "itemId", "recipeId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."count", NEW."type", NEW."itemId", NEW."recipeId",
    ARRAY['count', 'type', 'itemId', 'recipeId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'recipe_ingredient',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'count', NEW."count",
      'type', NEW."type",
      'itemId', NEW."itemId",
      'recipeId', NEW."recipeId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION recipe_ingredient_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "recipe_ingredient_synced"%ROWTYPE;
    local "recipe_ingredient_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "recipe_ingredient_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "recipe_ingredient_local" WHERE "id" = NEW."id";
    
    IF NEW."count" IS DISTINCT FROM synced."count" THEN
      changed_cols := array_append(changed_cols, 'count');
    END IF;
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."itemId" IS DISTINCT FROM synced."itemId" THEN
      changed_cols := array_append(changed_cols, 'itemId');
    END IF;
    IF NEW."recipeId" IS DISTINCT FROM synced."recipeId" THEN
      changed_cols := array_append(changed_cols, 'recipeId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "recipe_ingredient_local" (
        "id", "count", "type", "itemId", "recipeId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."count", NEW."type", NEW."itemId", NEW."recipeId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "recipe_ingredient_local"
    SET
        
    "count" = CASE WHEN NEW."count" IS DISTINCT FROM synced."count" THEN NEW."count" ELSE local."count" END,
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "itemId" = CASE WHEN NEW."itemId" IS DISTINCT FROM synced."itemId" THEN NEW."itemId" ELSE local."itemId" END,
    "recipeId" = CASE WHEN NEW."recipeId" IS DISTINCT FROM synced."recipeId" THEN NEW."recipeId" ELSE local."recipeId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'recipe_ingredient',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'count', COALESCE(NEW."count", local."count"),
      'type', COALESCE(NEW."type", local."type"),
      'itemId', COALESCE(NEW."itemId", local."itemId"),
      'recipeId', COALESCE(NEW."recipeId", local."recipeId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION recipe_ingredient_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "recipe_ingredient_local" WHERE "id" = OLD."id") THEN
    UPDATE "recipe_ingredient_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "recipe_ingredient_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'recipe_ingredient',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER recipe_ingredient_insert
INSTEAD OF INSERT ON "recipe_ingredient"
FOR EACH ROW EXECUTE FUNCTION recipe_ingredient_insert_trigger();

CREATE OR REPLACE TRIGGER recipe_ingredient_update
INSTEAD OF UPDATE ON "recipe_ingredient"
FOR EACH ROW EXECUTE FUNCTION recipe_ingredient_update_trigger();

CREATE OR REPLACE TRIGGER recipe_ingredient_delete
INSTEAD OF DELETE ON "recipe_ingredient"
FOR EACH ROW EXECUTE FUNCTION recipe_ingredient_delete_trigger();


CREATE OR REPLACE FUNCTION recipe_ingredient_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "recipe_ingredient_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION recipe_ingredient_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "recipe_ingredient_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "recipe_ingredient_synced"
FOR EACH ROW EXECUTE FUNCTION recipe_ingredient_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "recipe_ingredient_synced"
FOR EACH ROW EXECUTE FUNCTION recipe_ingredient_delete_local_on_synced_delete_trigger();

-- CreateTable
-- session
CREATE TABLE IF NOT EXISTS "session_synced" (
  "id" TEXT NOT NULL,
  "sessionToken" TEXT NOT NULL,
  "expires" TIMESTAMP(3) NOT NULL,
  "userId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "session_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "session_local" (
  "id" TEXT,
  "sessionToken" TEXT,
  "expires" TIMESTAMP(3),
  "userId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "session_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "session" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'sessionToken' = ANY(local.changed_columns)
      THEN local."sessionToken"
      ELSE synced."sessionToken"
    END AS "sessionToken",
   CASE
    WHEN 'expires' = ANY(local.changed_columns)
      THEN local."expires"
      ELSE synced."expires"
    END AS "expires",
   CASE
    WHEN 'userId' = ANY(local.changed_columns)
      THEN local."userId"
      ELSE synced."userId"
    END AS "userId"
  FROM "session_synced" AS synced
  FULL OUTER JOIN "session_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION session_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "session_local" (
    "id", "sessionToken", "expires", "userId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."sessionToken", NEW."expires", NEW."userId",
    ARRAY['sessionToken', 'expires', 'userId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'session',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'sessionToken', NEW."sessionToken",
      'expires', NEW."expires",
      'userId', NEW."userId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION session_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "session_synced"%ROWTYPE;
    local "session_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "session_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "session_local" WHERE "id" = NEW."id";
    
    IF NEW."sessionToken" IS DISTINCT FROM synced."sessionToken" THEN
      changed_cols := array_append(changed_cols, 'sessionToken');
    END IF;
    IF NEW."expires" IS DISTINCT FROM synced."expires" THEN
      changed_cols := array_append(changed_cols, 'expires');
    END IF;
    IF NEW."userId" IS DISTINCT FROM synced."userId" THEN
      changed_cols := array_append(changed_cols, 'userId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "session_local" (
        "id", "sessionToken", "expires", "userId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."sessionToken", NEW."expires", NEW."userId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "session_local"
    SET
        
    "sessionToken" = CASE WHEN NEW."sessionToken" IS DISTINCT FROM synced."sessionToken" THEN NEW."sessionToken" ELSE local."sessionToken" END,
    "expires" = CASE WHEN NEW."expires" IS DISTINCT FROM synced."expires" THEN NEW."expires" ELSE local."expires" END,
    "userId" = CASE WHEN NEW."userId" IS DISTINCT FROM synced."userId" THEN NEW."userId" ELSE local."userId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'session',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'sessionToken', COALESCE(NEW."sessionToken", local."sessionToken"),
      'expires', COALESCE(NEW."expires", local."expires"),
      'userId', COALESCE(NEW."userId", local."userId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION session_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "session_local" WHERE "id" = OLD."id") THEN
    UPDATE "session_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "session_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'session',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER session_insert
INSTEAD OF INSERT ON "session"
FOR EACH ROW EXECUTE FUNCTION session_insert_trigger();

CREATE OR REPLACE TRIGGER session_update
INSTEAD OF UPDATE ON "session"
FOR EACH ROW EXECUTE FUNCTION session_update_trigger();

CREATE OR REPLACE TRIGGER session_delete
INSTEAD OF DELETE ON "session"
FOR EACH ROW EXECUTE FUNCTION session_delete_trigger();


CREATE OR REPLACE FUNCTION session_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "session_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION session_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "session_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "session_synced"
FOR EACH ROW EXECUTE FUNCTION session_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "session_synced"
FOR EACH ROW EXECUTE FUNCTION session_delete_local_on_synced_delete_trigger();

-- CreateTable
-- simulator
CREATE TABLE IF NOT EXISTS "simulator_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "details" TEXT,
  "statisticId" TEXT NOT NULL,
  "updatedByAccountId" TEXT,
  "createdByAccountId" TEXT,
  "write_id" UUID,
  CONSTRAINT "simulator_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "simulator_local" (
  "id" TEXT,
  "name" TEXT,
  "details" TEXT,
  "statisticId" TEXT,
  "updatedByAccountId" TEXT,
  "createdByAccountId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "simulator_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "simulator" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'details' = ANY(local.changed_columns)
      THEN local."details"
      ELSE synced."details"
    END AS "details",
   CASE
    WHEN 'statisticId' = ANY(local.changed_columns)
      THEN local."statisticId"
      ELSE synced."statisticId"
    END AS "statisticId",
   CASE
    WHEN 'updatedByAccountId' = ANY(local.changed_columns)
      THEN local."updatedByAccountId"
      ELSE synced."updatedByAccountId"
    END AS "updatedByAccountId",
   CASE
    WHEN 'createdByAccountId' = ANY(local.changed_columns)
      THEN local."createdByAccountId"
      ELSE synced."createdByAccountId"
    END AS "createdByAccountId"
  FROM "simulator_synced" AS synced
  FULL OUTER JOIN "simulator_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION simulator_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "simulator_local" (
    "id", "name", "details", "statisticId", "updatedByAccountId", "createdByAccountId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."details", NEW."statisticId", NEW."updatedByAccountId", NEW."createdByAccountId",
    ARRAY['name', 'details', 'statisticId', 'updatedByAccountId', 'createdByAccountId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'simulator',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'details', NEW."details",
      'statisticId', NEW."statisticId",
      'updatedByAccountId', NEW."updatedByAccountId",
      'createdByAccountId', NEW."createdByAccountId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION simulator_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "simulator_synced"%ROWTYPE;
    local "simulator_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "simulator_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "simulator_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."details" IS DISTINCT FROM synced."details" THEN
      changed_cols := array_append(changed_cols, 'details');
    END IF;
    IF NEW."statisticId" IS DISTINCT FROM synced."statisticId" THEN
      changed_cols := array_append(changed_cols, 'statisticId');
    END IF;
    IF NEW."updatedByAccountId" IS DISTINCT FROM synced."updatedByAccountId" THEN
      changed_cols := array_append(changed_cols, 'updatedByAccountId');
    END IF;
    IF NEW."createdByAccountId" IS DISTINCT FROM synced."createdByAccountId" THEN
      changed_cols := array_append(changed_cols, 'createdByAccountId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "simulator_local" (
        "id", "name", "details", "statisticId", "updatedByAccountId", "createdByAccountId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."details", NEW."statisticId", NEW."updatedByAccountId", NEW."createdByAccountId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "simulator_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "details" = CASE WHEN NEW."details" IS DISTINCT FROM synced."details" THEN NEW."details" ELSE local."details" END,
    "statisticId" = CASE WHEN NEW."statisticId" IS DISTINCT FROM synced."statisticId" THEN NEW."statisticId" ELSE local."statisticId" END,
    "updatedByAccountId" = CASE WHEN NEW."updatedByAccountId" IS DISTINCT FROM synced."updatedByAccountId" THEN NEW."updatedByAccountId" ELSE local."updatedByAccountId" END,
    "createdByAccountId" = CASE WHEN NEW."createdByAccountId" IS DISTINCT FROM synced."createdByAccountId" THEN NEW."createdByAccountId" ELSE local."createdByAccountId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'simulator',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'details', COALESCE(NEW."details", local."details"),
      'statisticId', COALESCE(NEW."statisticId", local."statisticId"),
      'updatedByAccountId', COALESCE(NEW."updatedByAccountId", local."updatedByAccountId"),
      'createdByAccountId', COALESCE(NEW."createdByAccountId", local."createdByAccountId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION simulator_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "simulator_local" WHERE "id" = OLD."id") THEN
    UPDATE "simulator_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "simulator_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'simulator',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER simulator_insert
INSTEAD OF INSERT ON "simulator"
FOR EACH ROW EXECUTE FUNCTION simulator_insert_trigger();

CREATE OR REPLACE TRIGGER simulator_update
INSTEAD OF UPDATE ON "simulator"
FOR EACH ROW EXECUTE FUNCTION simulator_update_trigger();

CREATE OR REPLACE TRIGGER simulator_delete
INSTEAD OF DELETE ON "simulator"
FOR EACH ROW EXECUTE FUNCTION simulator_delete_trigger();


CREATE OR REPLACE FUNCTION simulator_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "simulator_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION simulator_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "simulator_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "simulator_synced"
FOR EACH ROW EXECUTE FUNCTION simulator_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "simulator_synced"
FOR EACH ROW EXECUTE FUNCTION simulator_delete_local_on_synced_delete_trigger();

-- CreateTable
-- skill
CREATE TABLE IF NOT EXISTS "skill_synced" (
  "id" TEXT NOT NULL,
  "treeType" "SkillTreeType" NOT NULL,
  "posX" INTEGER NOT NULL,
  "posY" INTEGER NOT NULL,
  "tier" INTEGER NOT NULL,
  "name" TEXT NOT NULL,
  "isPassive" BOOLEAN NOT NULL,
  "chargingType" "SkillChargingType" NOT NULL,
  "distanceType" "SkillDistanceType" NOT NULL,
  "targetType" "SkillTargetType" NOT NULL,
  "details" TEXT NOT NULL,
  "dataSources" TEXT NOT NULL,
  "statisticId" TEXT NOT NULL,
  "updatedByAccountId" TEXT,
  "createdByAccountId" TEXT,
  "write_id" UUID,
  CONSTRAINT "skill_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "skill_local" (
  "id" TEXT,
  "treeType" "SkillTreeType",
  "posX" INTEGER,
  "posY" INTEGER,
  "tier" INTEGER,
  "name" TEXT,
  "isPassive" BOOLEAN,
  "chargingType" "SkillChargingType",
  "distanceType" "SkillDistanceType",
  "targetType" "SkillTargetType",
  "details" TEXT,
  "dataSources" TEXT,
  "statisticId" TEXT,
  "updatedByAccountId" TEXT,
  "createdByAccountId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "skill_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "skill" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'treeType' = ANY(local.changed_columns)
      THEN local."treeType"
      ELSE synced."treeType"
    END AS "treeType",
   CASE
    WHEN 'posX' = ANY(local.changed_columns)
      THEN local."posX"
      ELSE synced."posX"
    END AS "posX",
   CASE
    WHEN 'posY' = ANY(local.changed_columns)
      THEN local."posY"
      ELSE synced."posY"
    END AS "posY",
   CASE
    WHEN 'tier' = ANY(local.changed_columns)
      THEN local."tier"
      ELSE synced."tier"
    END AS "tier",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'isPassive' = ANY(local.changed_columns)
      THEN local."isPassive"
      ELSE synced."isPassive"
    END AS "isPassive",
   CASE
    WHEN 'chargingType' = ANY(local.changed_columns)
      THEN local."chargingType"
      ELSE synced."chargingType"
    END AS "chargingType",
   CASE
    WHEN 'distanceType' = ANY(local.changed_columns)
      THEN local."distanceType"
      ELSE synced."distanceType"
    END AS "distanceType",
   CASE
    WHEN 'targetType' = ANY(local.changed_columns)
      THEN local."targetType"
      ELSE synced."targetType"
    END AS "targetType",
   CASE
    WHEN 'details' = ANY(local.changed_columns)
      THEN local."details"
      ELSE synced."details"
    END AS "details",
   CASE
    WHEN 'dataSources' = ANY(local.changed_columns)
      THEN local."dataSources"
      ELSE synced."dataSources"
    END AS "dataSources",
   CASE
    WHEN 'statisticId' = ANY(local.changed_columns)
      THEN local."statisticId"
      ELSE synced."statisticId"
    END AS "statisticId",
   CASE
    WHEN 'updatedByAccountId' = ANY(local.changed_columns)
      THEN local."updatedByAccountId"
      ELSE synced."updatedByAccountId"
    END AS "updatedByAccountId",
   CASE
    WHEN 'createdByAccountId' = ANY(local.changed_columns)
      THEN local."createdByAccountId"
      ELSE synced."createdByAccountId"
    END AS "createdByAccountId"
  FROM "skill_synced" AS synced
  FULL OUTER JOIN "skill_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION skill_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "skill_local" (
    "id", "treeType", "posX", "posY", "tier", "name", "isPassive", "chargingType", "distanceType", "targetType", "details", "dataSources", "statisticId", "updatedByAccountId", "createdByAccountId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."treeType", NEW."posX", NEW."posY", NEW."tier", NEW."name", NEW."isPassive", NEW."chargingType", NEW."distanceType", NEW."targetType", NEW."details", NEW."dataSources", NEW."statisticId", NEW."updatedByAccountId", NEW."createdByAccountId",
    ARRAY['treeType', 'posX', 'posY', 'tier', 'name', 'isPassive', 'chargingType', 'distanceType', 'targetType', 'details', 'dataSources', 'statisticId', 'updatedByAccountId', 'createdByAccountId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'skill',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'treeType', NEW."treeType",
      'posX', NEW."posX",
      'posY', NEW."posY",
      'tier', NEW."tier",
      'name', NEW."name",
      'isPassive', NEW."isPassive",
      'chargingType', NEW."chargingType",
      'distanceType', NEW."distanceType",
      'targetType', NEW."targetType",
      'details', NEW."details",
      'dataSources', NEW."dataSources",
      'statisticId', NEW."statisticId",
      'updatedByAccountId', NEW."updatedByAccountId",
      'createdByAccountId', NEW."createdByAccountId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION skill_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "skill_synced"%ROWTYPE;
    local "skill_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "skill_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "skill_local" WHERE "id" = NEW."id";
    
    IF NEW."treeType" IS DISTINCT FROM synced."treeType" THEN
      changed_cols := array_append(changed_cols, 'treeType');
    END IF;
    IF NEW."posX" IS DISTINCT FROM synced."posX" THEN
      changed_cols := array_append(changed_cols, 'posX');
    END IF;
    IF NEW."posY" IS DISTINCT FROM synced."posY" THEN
      changed_cols := array_append(changed_cols, 'posY');
    END IF;
    IF NEW."tier" IS DISTINCT FROM synced."tier" THEN
      changed_cols := array_append(changed_cols, 'tier');
    END IF;
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."isPassive" IS DISTINCT FROM synced."isPassive" THEN
      changed_cols := array_append(changed_cols, 'isPassive');
    END IF;
    IF NEW."chargingType" IS DISTINCT FROM synced."chargingType" THEN
      changed_cols := array_append(changed_cols, 'chargingType');
    END IF;
    IF NEW."distanceType" IS DISTINCT FROM synced."distanceType" THEN
      changed_cols := array_append(changed_cols, 'distanceType');
    END IF;
    IF NEW."targetType" IS DISTINCT FROM synced."targetType" THEN
      changed_cols := array_append(changed_cols, 'targetType');
    END IF;
    IF NEW."details" IS DISTINCT FROM synced."details" THEN
      changed_cols := array_append(changed_cols, 'details');
    END IF;
    IF NEW."dataSources" IS DISTINCT FROM synced."dataSources" THEN
      changed_cols := array_append(changed_cols, 'dataSources');
    END IF;
    IF NEW."statisticId" IS DISTINCT FROM synced."statisticId" THEN
      changed_cols := array_append(changed_cols, 'statisticId');
    END IF;
    IF NEW."updatedByAccountId" IS DISTINCT FROM synced."updatedByAccountId" THEN
      changed_cols := array_append(changed_cols, 'updatedByAccountId');
    END IF;
    IF NEW."createdByAccountId" IS DISTINCT FROM synced."createdByAccountId" THEN
      changed_cols := array_append(changed_cols, 'createdByAccountId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "skill_local" (
        "id", "treeType", "posX", "posY", "tier", "name", "isPassive", "chargingType", "distanceType", "targetType", "details", "dataSources", "statisticId", "updatedByAccountId", "createdByAccountId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."treeType", NEW."posX", NEW."posY", NEW."tier", NEW."name", NEW."isPassive", NEW."chargingType", NEW."distanceType", NEW."targetType", NEW."details", NEW."dataSources", NEW."statisticId", NEW."updatedByAccountId", NEW."createdByAccountId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "skill_local"
    SET
        
    "treeType" = CASE WHEN NEW."treeType" IS DISTINCT FROM synced."treeType" THEN NEW."treeType" ELSE local."treeType" END,
    "posX" = CASE WHEN NEW."posX" IS DISTINCT FROM synced."posX" THEN NEW."posX" ELSE local."posX" END,
    "posY" = CASE WHEN NEW."posY" IS DISTINCT FROM synced."posY" THEN NEW."posY" ELSE local."posY" END,
    "tier" = CASE WHEN NEW."tier" IS DISTINCT FROM synced."tier" THEN NEW."tier" ELSE local."tier" END,
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "isPassive" = CASE WHEN NEW."isPassive" IS DISTINCT FROM synced."isPassive" THEN NEW."isPassive" ELSE local."isPassive" END,
    "chargingType" = CASE WHEN NEW."chargingType" IS DISTINCT FROM synced."chargingType" THEN NEW."chargingType" ELSE local."chargingType" END,
    "distanceType" = CASE WHEN NEW."distanceType" IS DISTINCT FROM synced."distanceType" THEN NEW."distanceType" ELSE local."distanceType" END,
    "targetType" = CASE WHEN NEW."targetType" IS DISTINCT FROM synced."targetType" THEN NEW."targetType" ELSE local."targetType" END,
    "details" = CASE WHEN NEW."details" IS DISTINCT FROM synced."details" THEN NEW."details" ELSE local."details" END,
    "dataSources" = CASE WHEN NEW."dataSources" IS DISTINCT FROM synced."dataSources" THEN NEW."dataSources" ELSE local."dataSources" END,
    "statisticId" = CASE WHEN NEW."statisticId" IS DISTINCT FROM synced."statisticId" THEN NEW."statisticId" ELSE local."statisticId" END,
    "updatedByAccountId" = CASE WHEN NEW."updatedByAccountId" IS DISTINCT FROM synced."updatedByAccountId" THEN NEW."updatedByAccountId" ELSE local."updatedByAccountId" END,
    "createdByAccountId" = CASE WHEN NEW."createdByAccountId" IS DISTINCT FROM synced."createdByAccountId" THEN NEW."createdByAccountId" ELSE local."createdByAccountId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'skill',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'treeType', COALESCE(NEW."treeType", local."treeType"),
      'posX', COALESCE(NEW."posX", local."posX"),
      'posY', COALESCE(NEW."posY", local."posY"),
      'tier', COALESCE(NEW."tier", local."tier"),
      'name', COALESCE(NEW."name", local."name"),
      'isPassive', COALESCE(NEW."isPassive", local."isPassive"),
      'chargingType', COALESCE(NEW."chargingType", local."chargingType"),
      'distanceType', COALESCE(NEW."distanceType", local."distanceType"),
      'targetType', COALESCE(NEW."targetType", local."targetType"),
      'details', COALESCE(NEW."details", local."details"),
      'dataSources', COALESCE(NEW."dataSources", local."dataSources"),
      'statisticId', COALESCE(NEW."statisticId", local."statisticId"),
      'updatedByAccountId', COALESCE(NEW."updatedByAccountId", local."updatedByAccountId"),
      'createdByAccountId', COALESCE(NEW."createdByAccountId", local."createdByAccountId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION skill_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "skill_local" WHERE "id" = OLD."id") THEN
    UPDATE "skill_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "skill_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'skill',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER skill_insert
INSTEAD OF INSERT ON "skill"
FOR EACH ROW EXECUTE FUNCTION skill_insert_trigger();

CREATE OR REPLACE TRIGGER skill_update
INSTEAD OF UPDATE ON "skill"
FOR EACH ROW EXECUTE FUNCTION skill_update_trigger();

CREATE OR REPLACE TRIGGER skill_delete
INSTEAD OF DELETE ON "skill"
FOR EACH ROW EXECUTE FUNCTION skill_delete_trigger();


CREATE OR REPLACE FUNCTION skill_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "skill_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION skill_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "skill_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "skill_synced"
FOR EACH ROW EXECUTE FUNCTION skill_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "skill_synced"
FOR EACH ROW EXECUTE FUNCTION skill_delete_local_on_synced_delete_trigger();

-- CreateTable
-- skill_effect
CREATE TABLE IF NOT EXISTS "skill_effect_synced" (
  "id" TEXT NOT NULL,
  "condition" TEXT NOT NULL,
  "elementLogic" TEXT NOT NULL,
  "castingRange" INTEGER NOT NULL,
  "effectiveRange" INTEGER NOT NULL,
  "motionFixed" TEXT NOT NULL,
  "motionModified" TEXT NOT NULL,
  "chantingFixed" TEXT NOT NULL,
  "chantingModified" TEXT NOT NULL,
  "reservoirFixed" TEXT NOT NULL,
  "reservoirModified" TEXT NOT NULL,
  "startupFrames" TEXT NOT NULL,
  "cost" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "logic" JSONB NOT NULL,
  "details" TEXT,
  "belongToskillId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "skill_effect_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "skill_effect_local" (
  "id" TEXT,
  "condition" TEXT,
  "elementLogic" TEXT,
  "castingRange" INTEGER,
  "effectiveRange" INTEGER,
  "motionFixed" TEXT,
  "motionModified" TEXT,
  "chantingFixed" TEXT,
  "chantingModified" TEXT,
  "reservoirFixed" TEXT,
  "reservoirModified" TEXT,
  "startupFrames" TEXT,
  "cost" TEXT,
  "description" TEXT,
  "logic" JSONB,
  "details" TEXT,
  "belongToskillId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "skill_effect_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "skill_effect" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'condition' = ANY(local.changed_columns)
      THEN local."condition"
      ELSE synced."condition"
    END AS "condition",
   CASE
    WHEN 'elementLogic' = ANY(local.changed_columns)
      THEN local."elementLogic"
      ELSE synced."elementLogic"
    END AS "elementLogic",
   CASE
    WHEN 'castingRange' = ANY(local.changed_columns)
      THEN local."castingRange"
      ELSE synced."castingRange"
    END AS "castingRange",
   CASE
    WHEN 'effectiveRange' = ANY(local.changed_columns)
      THEN local."effectiveRange"
      ELSE synced."effectiveRange"
    END AS "effectiveRange",
   CASE
    WHEN 'motionFixed' = ANY(local.changed_columns)
      THEN local."motionFixed"
      ELSE synced."motionFixed"
    END AS "motionFixed",
   CASE
    WHEN 'motionModified' = ANY(local.changed_columns)
      THEN local."motionModified"
      ELSE synced."motionModified"
    END AS "motionModified",
   CASE
    WHEN 'chantingFixed' = ANY(local.changed_columns)
      THEN local."chantingFixed"
      ELSE synced."chantingFixed"
    END AS "chantingFixed",
   CASE
    WHEN 'chantingModified' = ANY(local.changed_columns)
      THEN local."chantingModified"
      ELSE synced."chantingModified"
    END AS "chantingModified",
   CASE
    WHEN 'reservoirFixed' = ANY(local.changed_columns)
      THEN local."reservoirFixed"
      ELSE synced."reservoirFixed"
    END AS "reservoirFixed",
   CASE
    WHEN 'reservoirModified' = ANY(local.changed_columns)
      THEN local."reservoirModified"
      ELSE synced."reservoirModified"
    END AS "reservoirModified",
   CASE
    WHEN 'startupFrames' = ANY(local.changed_columns)
      THEN local."startupFrames"
      ELSE synced."startupFrames"
    END AS "startupFrames",
   CASE
    WHEN 'cost' = ANY(local.changed_columns)
      THEN local."cost"
      ELSE synced."cost"
    END AS "cost",
   CASE
    WHEN 'description' = ANY(local.changed_columns)
      THEN local."description"
      ELSE synced."description"
    END AS "description",
   CASE
    WHEN 'logic' = ANY(local.changed_columns)
      THEN local."logic"
      ELSE synced."logic"
    END AS "logic",
   CASE
    WHEN 'details' = ANY(local.changed_columns)
      THEN local."details"
      ELSE synced."details"
    END AS "details",
   CASE
    WHEN 'belongToskillId' = ANY(local.changed_columns)
      THEN local."belongToskillId"
      ELSE synced."belongToskillId"
    END AS "belongToskillId"
  FROM "skill_effect_synced" AS synced
  FULL OUTER JOIN "skill_effect_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION skill_effect_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "skill_effect_local" (
    "id", "condition", "elementLogic", "castingRange", "effectiveRange", "motionFixed", "motionModified", "chantingFixed", "chantingModified", "reservoirFixed", "reservoirModified", "startupFrames", "cost", "description", "logic", "details", "belongToskillId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."condition", NEW."elementLogic", NEW."castingRange", NEW."effectiveRange", NEW."motionFixed", NEW."motionModified", NEW."chantingFixed", NEW."chantingModified", NEW."reservoirFixed", NEW."reservoirModified", NEW."startupFrames", NEW."cost", NEW."description", NEW."logic", NEW."details", NEW."belongToskillId",
    ARRAY['condition', 'elementLogic', 'castingRange', 'effectiveRange', 'motionFixed', 'motionModified', 'chantingFixed', 'chantingModified', 'reservoirFixed', 'reservoirModified', 'startupFrames', 'cost', 'description', 'logic', 'details', 'belongToskillId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'skill_effect',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'condition', NEW."condition",
      'elementLogic', NEW."elementLogic",
      'castingRange', NEW."castingRange",
      'effectiveRange', NEW."effectiveRange",
      'motionFixed', NEW."motionFixed",
      'motionModified', NEW."motionModified",
      'chantingFixed', NEW."chantingFixed",
      'chantingModified', NEW."chantingModified",
      'reservoirFixed', NEW."reservoirFixed",
      'reservoirModified', NEW."reservoirModified",
      'startupFrames', NEW."startupFrames",
      'cost', NEW."cost",
      'description', NEW."description",
      'logic', NEW."logic",
      'details', NEW."details",
      'belongToskillId', NEW."belongToskillId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION skill_effect_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "skill_effect_synced"%ROWTYPE;
    local "skill_effect_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "skill_effect_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "skill_effect_local" WHERE "id" = NEW."id";
    
    IF NEW."condition" IS DISTINCT FROM synced."condition" THEN
      changed_cols := array_append(changed_cols, 'condition');
    END IF;
    IF NEW."elementLogic" IS DISTINCT FROM synced."elementLogic" THEN
      changed_cols := array_append(changed_cols, 'elementLogic');
    END IF;
    IF NEW."castingRange" IS DISTINCT FROM synced."castingRange" THEN
      changed_cols := array_append(changed_cols, 'castingRange');
    END IF;
    IF NEW."effectiveRange" IS DISTINCT FROM synced."effectiveRange" THEN
      changed_cols := array_append(changed_cols, 'effectiveRange');
    END IF;
    IF NEW."motionFixed" IS DISTINCT FROM synced."motionFixed" THEN
      changed_cols := array_append(changed_cols, 'motionFixed');
    END IF;
    IF NEW."motionModified" IS DISTINCT FROM synced."motionModified" THEN
      changed_cols := array_append(changed_cols, 'motionModified');
    END IF;
    IF NEW."chantingFixed" IS DISTINCT FROM synced."chantingFixed" THEN
      changed_cols := array_append(changed_cols, 'chantingFixed');
    END IF;
    IF NEW."chantingModified" IS DISTINCT FROM synced."chantingModified" THEN
      changed_cols := array_append(changed_cols, 'chantingModified');
    END IF;
    IF NEW."reservoirFixed" IS DISTINCT FROM synced."reservoirFixed" THEN
      changed_cols := array_append(changed_cols, 'reservoirFixed');
    END IF;
    IF NEW."reservoirModified" IS DISTINCT FROM synced."reservoirModified" THEN
      changed_cols := array_append(changed_cols, 'reservoirModified');
    END IF;
    IF NEW."startupFrames" IS DISTINCT FROM synced."startupFrames" THEN
      changed_cols := array_append(changed_cols, 'startupFrames');
    END IF;
    IF NEW."cost" IS DISTINCT FROM synced."cost" THEN
      changed_cols := array_append(changed_cols, 'cost');
    END IF;
    IF NEW."description" IS DISTINCT FROM synced."description" THEN
      changed_cols := array_append(changed_cols, 'description');
    END IF;
    IF NEW."logic" IS DISTINCT FROM synced."logic" THEN
      changed_cols := array_append(changed_cols, 'logic');
    END IF;
    IF NEW."details" IS DISTINCT FROM synced."details" THEN
      changed_cols := array_append(changed_cols, 'details');
    END IF;
    IF NEW."belongToskillId" IS DISTINCT FROM synced."belongToskillId" THEN
      changed_cols := array_append(changed_cols, 'belongToskillId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "skill_effect_local" (
        "id", "condition", "elementLogic", "castingRange", "effectiveRange", "motionFixed", "motionModified", "chantingFixed", "chantingModified", "reservoirFixed", "reservoirModified", "startupFrames", "cost", "description", "logic", "details", "belongToskillId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."condition", NEW."elementLogic", NEW."castingRange", NEW."effectiveRange", NEW."motionFixed", NEW."motionModified", NEW."chantingFixed", NEW."chantingModified", NEW."reservoirFixed", NEW."reservoirModified", NEW."startupFrames", NEW."cost", NEW."description", NEW."logic", NEW."details", NEW."belongToskillId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "skill_effect_local"
    SET
        
    "condition" = CASE WHEN NEW."condition" IS DISTINCT FROM synced."condition" THEN NEW."condition" ELSE local."condition" END,
    "elementLogic" = CASE WHEN NEW."elementLogic" IS DISTINCT FROM synced."elementLogic" THEN NEW."elementLogic" ELSE local."elementLogic" END,
    "castingRange" = CASE WHEN NEW."castingRange" IS DISTINCT FROM synced."castingRange" THEN NEW."castingRange" ELSE local."castingRange" END,
    "effectiveRange" = CASE WHEN NEW."effectiveRange" IS DISTINCT FROM synced."effectiveRange" THEN NEW."effectiveRange" ELSE local."effectiveRange" END,
    "motionFixed" = CASE WHEN NEW."motionFixed" IS DISTINCT FROM synced."motionFixed" THEN NEW."motionFixed" ELSE local."motionFixed" END,
    "motionModified" = CASE WHEN NEW."motionModified" IS DISTINCT FROM synced."motionModified" THEN NEW."motionModified" ELSE local."motionModified" END,
    "chantingFixed" = CASE WHEN NEW."chantingFixed" IS DISTINCT FROM synced."chantingFixed" THEN NEW."chantingFixed" ELSE local."chantingFixed" END,
    "chantingModified" = CASE WHEN NEW."chantingModified" IS DISTINCT FROM synced."chantingModified" THEN NEW."chantingModified" ELSE local."chantingModified" END,
    "reservoirFixed" = CASE WHEN NEW."reservoirFixed" IS DISTINCT FROM synced."reservoirFixed" THEN NEW."reservoirFixed" ELSE local."reservoirFixed" END,
    "reservoirModified" = CASE WHEN NEW."reservoirModified" IS DISTINCT FROM synced."reservoirModified" THEN NEW."reservoirModified" ELSE local."reservoirModified" END,
    "startupFrames" = CASE WHEN NEW."startupFrames" IS DISTINCT FROM synced."startupFrames" THEN NEW."startupFrames" ELSE local."startupFrames" END,
    "cost" = CASE WHEN NEW."cost" IS DISTINCT FROM synced."cost" THEN NEW."cost" ELSE local."cost" END,
    "description" = CASE WHEN NEW."description" IS DISTINCT FROM synced."description" THEN NEW."description" ELSE local."description" END,
    "logic" = CASE WHEN NEW."logic" IS DISTINCT FROM synced."logic" THEN NEW."logic" ELSE local."logic" END,
    "details" = CASE WHEN NEW."details" IS DISTINCT FROM synced."details" THEN NEW."details" ELSE local."details" END,
    "belongToskillId" = CASE WHEN NEW."belongToskillId" IS DISTINCT FROM synced."belongToskillId" THEN NEW."belongToskillId" ELSE local."belongToskillId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'skill_effect',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'condition', COALESCE(NEW."condition", local."condition"),
      'elementLogic', COALESCE(NEW."elementLogic", local."elementLogic"),
      'castingRange', COALESCE(NEW."castingRange", local."castingRange"),
      'effectiveRange', COALESCE(NEW."effectiveRange", local."effectiveRange"),
      'motionFixed', COALESCE(NEW."motionFixed", local."motionFixed"),
      'motionModified', COALESCE(NEW."motionModified", local."motionModified"),
      'chantingFixed', COALESCE(NEW."chantingFixed", local."chantingFixed"),
      'chantingModified', COALESCE(NEW."chantingModified", local."chantingModified"),
      'reservoirFixed', COALESCE(NEW."reservoirFixed", local."reservoirFixed"),
      'reservoirModified', COALESCE(NEW."reservoirModified", local."reservoirModified"),
      'startupFrames', COALESCE(NEW."startupFrames", local."startupFrames"),
      'cost', COALESCE(NEW."cost", local."cost"),
      'description', COALESCE(NEW."description", local."description"),
      'logic', COALESCE(NEW."logic", local."logic"),
      'details', COALESCE(NEW."details", local."details"),
      'belongToskillId', COALESCE(NEW."belongToskillId", local."belongToskillId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION skill_effect_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "skill_effect_local" WHERE "id" = OLD."id") THEN
    UPDATE "skill_effect_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "skill_effect_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'skill_effect',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER skill_effect_insert
INSTEAD OF INSERT ON "skill_effect"
FOR EACH ROW EXECUTE FUNCTION skill_effect_insert_trigger();

CREATE OR REPLACE TRIGGER skill_effect_update
INSTEAD OF UPDATE ON "skill_effect"
FOR EACH ROW EXECUTE FUNCTION skill_effect_update_trigger();

CREATE OR REPLACE TRIGGER skill_effect_delete
INSTEAD OF DELETE ON "skill_effect"
FOR EACH ROW EXECUTE FUNCTION skill_effect_delete_trigger();


CREATE OR REPLACE FUNCTION skill_effect_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "skill_effect_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION skill_effect_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "skill_effect_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "skill_effect_synced"
FOR EACH ROW EXECUTE FUNCTION skill_effect_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "skill_effect_synced"
FOR EACH ROW EXECUTE FUNCTION skill_effect_delete_local_on_synced_delete_trigger();

-- CreateTable
-- special
CREATE TABLE IF NOT EXISTS "special_synced" (
  "baseDef" INTEGER NOT NULL,
  "modifiers" TEXT[],
  "itemId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "special_synced_pkey" PRIMARY KEY ("itemId")
);
CREATE TABLE IF NOT EXISTS "special_local" (
  "baseDef" INTEGER,
  "modifiers" TEXT[],
  "itemId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "special_local_pkey" PRIMARY KEY ("itemId")
);

CREATE OR REPLACE VIEW "special" AS
  SELECT
     CASE
    WHEN 'baseDef' = ANY(local.changed_columns)
      THEN local."baseDef"
      ELSE synced."baseDef"
    END AS "baseDef",
   CASE
    WHEN 'modifiers' = ANY(local.changed_columns)
      THEN local."modifiers"
      ELSE synced."modifiers"
    END AS "modifiers",
   COALESCE(local."itemId", synced."itemId") AS "itemId"
  FROM "special_synced" AS synced
  FULL OUTER JOIN "special_local" AS local
  ON synced."itemId" = local."itemId"
  WHERE (local."itemId" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION special_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "special_local" (
    "baseDef", "modifiers", "itemId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."baseDef", NEW."modifiers", NEW."itemId",
    ARRAY['baseDef', 'modifiers'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'special',
    'insert',
    jsonb_build_object(
        'baseDef', NEW."baseDef",
      'modifiers', NEW."modifiers",
      'itemId', NEW."itemId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION special_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "special_synced"%ROWTYPE;
    local "special_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "special_synced" WHERE "itemId" = NEW."itemId";
    SELECT * INTO local FROM "special_local" WHERE "itemId" = NEW."itemId";
    
    IF NEW."baseDef" IS DISTINCT FROM synced."baseDef" THEN
      changed_cols := array_append(changed_cols, 'baseDef');
    END IF;
    IF NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN
      changed_cols := array_append(changed_cols, 'modifiers');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "special_local" (
        "baseDef", "modifiers", "itemId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."baseDef", NEW."modifiers", NEW."itemId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "special_local"
    SET
        
    "baseDef" = CASE WHEN NEW."baseDef" IS DISTINCT FROM synced."baseDef" THEN NEW."baseDef" ELSE local."baseDef" END,
    "modifiers" = CASE WHEN NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN NEW."modifiers" ELSE local."modifiers" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "itemId" = NEW."itemId";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'special',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'baseDef', COALESCE(NEW."baseDef", local."baseDef"),
      'modifiers', COALESCE(NEW."modifiers", local."modifiers"),
      'itemId', COALESCE(NEW."itemId", local."itemId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION special_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "special_local" WHERE "itemId" = OLD."itemId") THEN
    UPDATE "special_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "itemId" = OLD."itemId";
    ELSE
    INSERT INTO "special_local" (
        itemId,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."itemId",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'special',
    'delete',
    jsonb_build_object('itemId', OLD."itemId"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER special_insert
INSTEAD OF INSERT ON "special"
FOR EACH ROW EXECUTE FUNCTION special_insert_trigger();

CREATE OR REPLACE TRIGGER special_update
INSTEAD OF UPDATE ON "special"
FOR EACH ROW EXECUTE FUNCTION special_update_trigger();

CREATE OR REPLACE TRIGGER special_delete
INSTEAD OF DELETE ON "special"
FOR EACH ROW EXECUTE FUNCTION special_delete_trigger();


CREATE OR REPLACE FUNCTION special_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "special_local"
  WHERE "itemId" = NEW."itemId"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION special_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "special_local"
  WHERE "itemId" = OLD."itemId";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "special_synced"
FOR EACH ROW EXECUTE FUNCTION special_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "special_synced"
FOR EACH ROW EXECUTE FUNCTION special_delete_local_on_synced_delete_trigger();

-- CreateTable
-- statistic
CREATE TABLE IF NOT EXISTS "statistic_synced" (
  "id" TEXT NOT NULL,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL,
  "usageTimestamps" TIMESTAMP(3)[],
  "viewTimestamps" TIMESTAMP(3)[],
  "write_id" UUID,
  CONSTRAINT "statistic_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "statistic_local" (
  "id" TEXT,
  "updatedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3),
  "usageTimestamps" TIMESTAMP(3)[],
  "viewTimestamps" TIMESTAMP(3)[],
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "statistic_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "statistic" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'updatedAt' = ANY(local.changed_columns)
      THEN local."updatedAt"
      ELSE synced."updatedAt"
    END AS "updatedAt",
   CASE
    WHEN 'createdAt' = ANY(local.changed_columns)
      THEN local."createdAt"
      ELSE synced."createdAt"
    END AS "createdAt",
   CASE
    WHEN 'usageTimestamps' = ANY(local.changed_columns)
      THEN local."usageTimestamps"
      ELSE synced."usageTimestamps"
    END AS "usageTimestamps",
   CASE
    WHEN 'viewTimestamps' = ANY(local.changed_columns)
      THEN local."viewTimestamps"
      ELSE synced."viewTimestamps"
    END AS "viewTimestamps"
  FROM "statistic_synced" AS synced
  FULL OUTER JOIN "statistic_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION statistic_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "statistic_local" (
    "id", "updatedAt", "createdAt", "usageTimestamps", "viewTimestamps",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."updatedAt", NEW."createdAt", NEW."usageTimestamps", NEW."viewTimestamps",
    ARRAY['updatedAt', 'createdAt', 'usageTimestamps', 'viewTimestamps'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'statistic',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'updatedAt', NEW."updatedAt",
      'createdAt', NEW."createdAt",
      'usageTimestamps', NEW."usageTimestamps",
      'viewTimestamps', NEW."viewTimestamps"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION statistic_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "statistic_synced"%ROWTYPE;
    local "statistic_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "statistic_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "statistic_local" WHERE "id" = NEW."id";
    
    IF NEW."updatedAt" IS DISTINCT FROM synced."updatedAt" THEN
      changed_cols := array_append(changed_cols, 'updatedAt');
    END IF;
    IF NEW."createdAt" IS DISTINCT FROM synced."createdAt" THEN
      changed_cols := array_append(changed_cols, 'createdAt');
    END IF;
    IF NEW."usageTimestamps" IS DISTINCT FROM synced."usageTimestamps" THEN
      changed_cols := array_append(changed_cols, 'usageTimestamps');
    END IF;
    IF NEW."viewTimestamps" IS DISTINCT FROM synced."viewTimestamps" THEN
      changed_cols := array_append(changed_cols, 'viewTimestamps');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "statistic_local" (
        "id", "updatedAt", "createdAt", "usageTimestamps", "viewTimestamps",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."updatedAt", NEW."createdAt", NEW."usageTimestamps", NEW."viewTimestamps",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "statistic_local"
    SET
        
    "updatedAt" = CASE WHEN NEW."updatedAt" IS DISTINCT FROM synced."updatedAt" THEN NEW."updatedAt" ELSE local."updatedAt" END,
    "createdAt" = CASE WHEN NEW."createdAt" IS DISTINCT FROM synced."createdAt" THEN NEW."createdAt" ELSE local."createdAt" END,
    "usageTimestamps" = CASE WHEN NEW."usageTimestamps" IS DISTINCT FROM synced."usageTimestamps" THEN NEW."usageTimestamps" ELSE local."usageTimestamps" END,
    "viewTimestamps" = CASE WHEN NEW."viewTimestamps" IS DISTINCT FROM synced."viewTimestamps" THEN NEW."viewTimestamps" ELSE local."viewTimestamps" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'statistic',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'updatedAt', COALESCE(NEW."updatedAt", local."updatedAt"),
      'createdAt', COALESCE(NEW."createdAt", local."createdAt"),
      'usageTimestamps', COALESCE(NEW."usageTimestamps", local."usageTimestamps"),
      'viewTimestamps', COALESCE(NEW."viewTimestamps", local."viewTimestamps")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION statistic_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "statistic_local" WHERE "id" = OLD."id") THEN
    UPDATE "statistic_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "statistic_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'statistic',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER statistic_insert
INSTEAD OF INSERT ON "statistic"
FOR EACH ROW EXECUTE FUNCTION statistic_insert_trigger();

CREATE OR REPLACE TRIGGER statistic_update
INSTEAD OF UPDATE ON "statistic"
FOR EACH ROW EXECUTE FUNCTION statistic_update_trigger();

CREATE OR REPLACE TRIGGER statistic_delete
INSTEAD OF DELETE ON "statistic"
FOR EACH ROW EXECUTE FUNCTION statistic_delete_trigger();


CREATE OR REPLACE FUNCTION statistic_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "statistic_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION statistic_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "statistic_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "statistic_synced"
FOR EACH ROW EXECUTE FUNCTION statistic_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "statistic_synced"
FOR EACH ROW EXECUTE FUNCTION statistic_delete_local_on_synced_delete_trigger();

-- CreateTable
-- task
CREATE TABLE IF NOT EXISTS "task_synced" (
  "id" TEXT NOT NULL,
  "lv" INTEGER NOT NULL,
  "name" TEXT NOT NULL,
  "type" "TaskType" NOT NULL,
  "description" TEXT NOT NULL,
  "npcId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "task_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "task_local" (
  "id" TEXT,
  "lv" INTEGER,
  "name" TEXT,
  "type" "TaskType",
  "description" TEXT,
  "npcId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "task_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "task" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'lv' = ANY(local.changed_columns)
      THEN local."lv"
      ELSE synced."lv"
    END AS "lv",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   CASE
    WHEN 'description' = ANY(local.changed_columns)
      THEN local."description"
      ELSE synced."description"
    END AS "description",
   CASE
    WHEN 'npcId' = ANY(local.changed_columns)
      THEN local."npcId"
      ELSE synced."npcId"
    END AS "npcId"
  FROM "task_synced" AS synced
  FULL OUTER JOIN "task_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION task_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "task_local" (
    "id", "lv", "name", "type", "description", "npcId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."lv", NEW."name", NEW."type", NEW."description", NEW."npcId",
    ARRAY['lv', 'name', 'type', 'description', 'npcId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'task',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'lv', NEW."lv",
      'name', NEW."name",
      'type', NEW."type",
      'description', NEW."description",
      'npcId', NEW."npcId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION task_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "task_synced"%ROWTYPE;
    local "task_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "task_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "task_local" WHERE "id" = NEW."id";
    
    IF NEW."lv" IS DISTINCT FROM synced."lv" THEN
      changed_cols := array_append(changed_cols, 'lv');
    END IF;
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."description" IS DISTINCT FROM synced."description" THEN
      changed_cols := array_append(changed_cols, 'description');
    END IF;
    IF NEW."npcId" IS DISTINCT FROM synced."npcId" THEN
      changed_cols := array_append(changed_cols, 'npcId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "task_local" (
        "id", "lv", "name", "type", "description", "npcId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."lv", NEW."name", NEW."type", NEW."description", NEW."npcId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "task_local"
    SET
        
    "lv" = CASE WHEN NEW."lv" IS DISTINCT FROM synced."lv" THEN NEW."lv" ELSE local."lv" END,
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "description" = CASE WHEN NEW."description" IS DISTINCT FROM synced."description" THEN NEW."description" ELSE local."description" END,
    "npcId" = CASE WHEN NEW."npcId" IS DISTINCT FROM synced."npcId" THEN NEW."npcId" ELSE local."npcId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'task',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'lv', COALESCE(NEW."lv", local."lv"),
      'name', COALESCE(NEW."name", local."name"),
      'type', COALESCE(NEW."type", local."type"),
      'description', COALESCE(NEW."description", local."description"),
      'npcId', COALESCE(NEW."npcId", local."npcId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION task_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "task_local" WHERE "id" = OLD."id") THEN
    UPDATE "task_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "task_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'task',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER task_insert
INSTEAD OF INSERT ON "task"
FOR EACH ROW EXECUTE FUNCTION task_insert_trigger();

CREATE OR REPLACE TRIGGER task_update
INSTEAD OF UPDATE ON "task"
FOR EACH ROW EXECUTE FUNCTION task_update_trigger();

CREATE OR REPLACE TRIGGER task_delete
INSTEAD OF DELETE ON "task"
FOR EACH ROW EXECUTE FUNCTION task_delete_trigger();


CREATE OR REPLACE FUNCTION task_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "task_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION task_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "task_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "task_synced"
FOR EACH ROW EXECUTE FUNCTION task_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "task_synced"
FOR EACH ROW EXECUTE FUNCTION task_delete_local_on_synced_delete_trigger();

-- CreateTable
-- task_collect_require
CREATE TABLE IF NOT EXISTS "task_collect_require_synced" (
  "id" TEXT NOT NULL,
  "count" INTEGER NOT NULL,
  "itemId" TEXT NOT NULL,
  "taskId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "task_collect_require_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "task_collect_require_local" (
  "id" TEXT,
  "count" INTEGER,
  "itemId" TEXT,
  "taskId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "task_collect_require_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "task_collect_require" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'count' = ANY(local.changed_columns)
      THEN local."count"
      ELSE synced."count"
    END AS "count",
   CASE
    WHEN 'itemId' = ANY(local.changed_columns)
      THEN local."itemId"
      ELSE synced."itemId"
    END AS "itemId",
   CASE
    WHEN 'taskId' = ANY(local.changed_columns)
      THEN local."taskId"
      ELSE synced."taskId"
    END AS "taskId"
  FROM "task_collect_require_synced" AS synced
  FULL OUTER JOIN "task_collect_require_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION task_collect_require_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "task_collect_require_local" (
    "id", "count", "itemId", "taskId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."count", NEW."itemId", NEW."taskId",
    ARRAY['count', 'itemId', 'taskId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'task_collect_require',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'count', NEW."count",
      'itemId', NEW."itemId",
      'taskId', NEW."taskId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION task_collect_require_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "task_collect_require_synced"%ROWTYPE;
    local "task_collect_require_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "task_collect_require_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "task_collect_require_local" WHERE "id" = NEW."id";
    
    IF NEW."count" IS DISTINCT FROM synced."count" THEN
      changed_cols := array_append(changed_cols, 'count');
    END IF;
    IF NEW."itemId" IS DISTINCT FROM synced."itemId" THEN
      changed_cols := array_append(changed_cols, 'itemId');
    END IF;
    IF NEW."taskId" IS DISTINCT FROM synced."taskId" THEN
      changed_cols := array_append(changed_cols, 'taskId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "task_collect_require_local" (
        "id", "count", "itemId", "taskId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."count", NEW."itemId", NEW."taskId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "task_collect_require_local"
    SET
        
    "count" = CASE WHEN NEW."count" IS DISTINCT FROM synced."count" THEN NEW."count" ELSE local."count" END,
    "itemId" = CASE WHEN NEW."itemId" IS DISTINCT FROM synced."itemId" THEN NEW."itemId" ELSE local."itemId" END,
    "taskId" = CASE WHEN NEW."taskId" IS DISTINCT FROM synced."taskId" THEN NEW."taskId" ELSE local."taskId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'task_collect_require',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'count', COALESCE(NEW."count", local."count"),
      'itemId', COALESCE(NEW."itemId", local."itemId"),
      'taskId', COALESCE(NEW."taskId", local."taskId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION task_collect_require_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "task_collect_require_local" WHERE "id" = OLD."id") THEN
    UPDATE "task_collect_require_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "task_collect_require_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'task_collect_require',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER task_collect_require_insert
INSTEAD OF INSERT ON "task_collect_require"
FOR EACH ROW EXECUTE FUNCTION task_collect_require_insert_trigger();

CREATE OR REPLACE TRIGGER task_collect_require_update
INSTEAD OF UPDATE ON "task_collect_require"
FOR EACH ROW EXECUTE FUNCTION task_collect_require_update_trigger();

CREATE OR REPLACE TRIGGER task_collect_require_delete
INSTEAD OF DELETE ON "task_collect_require"
FOR EACH ROW EXECUTE FUNCTION task_collect_require_delete_trigger();


CREATE OR REPLACE FUNCTION task_collect_require_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "task_collect_require_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION task_collect_require_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "task_collect_require_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "task_collect_require_synced"
FOR EACH ROW EXECUTE FUNCTION task_collect_require_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "task_collect_require_synced"
FOR EACH ROW EXECUTE FUNCTION task_collect_require_delete_local_on_synced_delete_trigger();

-- CreateTable
-- task_kill_requirement
CREATE TABLE IF NOT EXISTS "task_kill_requirement_synced" (
  "id" TEXT NOT NULL,
  "mobId" TEXT NOT NULL,
  "count" INTEGER NOT NULL,
  "taskId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "task_kill_requirement_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "task_kill_requirement_local" (
  "id" TEXT,
  "mobId" TEXT,
  "count" INTEGER,
  "taskId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "task_kill_requirement_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "task_kill_requirement" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'mobId' = ANY(local.changed_columns)
      THEN local."mobId"
      ELSE synced."mobId"
    END AS "mobId",
   CASE
    WHEN 'count' = ANY(local.changed_columns)
      THEN local."count"
      ELSE synced."count"
    END AS "count",
   CASE
    WHEN 'taskId' = ANY(local.changed_columns)
      THEN local."taskId"
      ELSE synced."taskId"
    END AS "taskId"
  FROM "task_kill_requirement_synced" AS synced
  FULL OUTER JOIN "task_kill_requirement_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION task_kill_requirement_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "task_kill_requirement_local" (
    "id", "mobId", "count", "taskId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."mobId", NEW."count", NEW."taskId",
    ARRAY['mobId', 'count', 'taskId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'task_kill_requirement',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'mobId', NEW."mobId",
      'count', NEW."count",
      'taskId', NEW."taskId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION task_kill_requirement_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "task_kill_requirement_synced"%ROWTYPE;
    local "task_kill_requirement_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "task_kill_requirement_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "task_kill_requirement_local" WHERE "id" = NEW."id";
    
    IF NEW."mobId" IS DISTINCT FROM synced."mobId" THEN
      changed_cols := array_append(changed_cols, 'mobId');
    END IF;
    IF NEW."count" IS DISTINCT FROM synced."count" THEN
      changed_cols := array_append(changed_cols, 'count');
    END IF;
    IF NEW."taskId" IS DISTINCT FROM synced."taskId" THEN
      changed_cols := array_append(changed_cols, 'taskId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "task_kill_requirement_local" (
        "id", "mobId", "count", "taskId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."mobId", NEW."count", NEW."taskId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "task_kill_requirement_local"
    SET
        
    "mobId" = CASE WHEN NEW."mobId" IS DISTINCT FROM synced."mobId" THEN NEW."mobId" ELSE local."mobId" END,
    "count" = CASE WHEN NEW."count" IS DISTINCT FROM synced."count" THEN NEW."count" ELSE local."count" END,
    "taskId" = CASE WHEN NEW."taskId" IS DISTINCT FROM synced."taskId" THEN NEW."taskId" ELSE local."taskId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'task_kill_requirement',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'mobId', COALESCE(NEW."mobId", local."mobId"),
      'count', COALESCE(NEW."count", local."count"),
      'taskId', COALESCE(NEW."taskId", local."taskId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION task_kill_requirement_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "task_kill_requirement_local" WHERE "id" = OLD."id") THEN
    UPDATE "task_kill_requirement_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "task_kill_requirement_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'task_kill_requirement',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER task_kill_requirement_insert
INSTEAD OF INSERT ON "task_kill_requirement"
FOR EACH ROW EXECUTE FUNCTION task_kill_requirement_insert_trigger();

CREATE OR REPLACE TRIGGER task_kill_requirement_update
INSTEAD OF UPDATE ON "task_kill_requirement"
FOR EACH ROW EXECUTE FUNCTION task_kill_requirement_update_trigger();

CREATE OR REPLACE TRIGGER task_kill_requirement_delete
INSTEAD OF DELETE ON "task_kill_requirement"
FOR EACH ROW EXECUTE FUNCTION task_kill_requirement_delete_trigger();


CREATE OR REPLACE FUNCTION task_kill_requirement_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "task_kill_requirement_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION task_kill_requirement_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "task_kill_requirement_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "task_kill_requirement_synced"
FOR EACH ROW EXECUTE FUNCTION task_kill_requirement_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "task_kill_requirement_synced"
FOR EACH ROW EXECUTE FUNCTION task_kill_requirement_delete_local_on_synced_delete_trigger();

-- CreateTable
-- task_reward
CREATE TABLE IF NOT EXISTS "task_reward_synced" (
  "id" TEXT NOT NULL,
  "type" "TaskRewardType" NOT NULL,
  "value" INTEGER NOT NULL,
  "probability" INTEGER NOT NULL,
  "itemId" TEXT,
  "taskId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "task_reward_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "task_reward_local" (
  "id" TEXT,
  "type" "TaskRewardType",
  "value" INTEGER,
  "probability" INTEGER,
  "itemId" TEXT,
  "taskId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "task_reward_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "task_reward" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   CASE
    WHEN 'value' = ANY(local.changed_columns)
      THEN local."value"
      ELSE synced."value"
    END AS "value",
   CASE
    WHEN 'probability' = ANY(local.changed_columns)
      THEN local."probability"
      ELSE synced."probability"
    END AS "probability",
   CASE
    WHEN 'itemId' = ANY(local.changed_columns)
      THEN local."itemId"
      ELSE synced."itemId"
    END AS "itemId",
   CASE
    WHEN 'taskId' = ANY(local.changed_columns)
      THEN local."taskId"
      ELSE synced."taskId"
    END AS "taskId"
  FROM "task_reward_synced" AS synced
  FULL OUTER JOIN "task_reward_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION task_reward_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "task_reward_local" (
    "id", "type", "value", "probability", "itemId", "taskId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."type", NEW."value", NEW."probability", NEW."itemId", NEW."taskId",
    ARRAY['type', 'value', 'probability', 'itemId', 'taskId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'task_reward',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'type', NEW."type",
      'value', NEW."value",
      'probability', NEW."probability",
      'itemId', NEW."itemId",
      'taskId', NEW."taskId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION task_reward_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "task_reward_synced"%ROWTYPE;
    local "task_reward_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "task_reward_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "task_reward_local" WHERE "id" = NEW."id";
    
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."value" IS DISTINCT FROM synced."value" THEN
      changed_cols := array_append(changed_cols, 'value');
    END IF;
    IF NEW."probability" IS DISTINCT FROM synced."probability" THEN
      changed_cols := array_append(changed_cols, 'probability');
    END IF;
    IF NEW."itemId" IS DISTINCT FROM synced."itemId" THEN
      changed_cols := array_append(changed_cols, 'itemId');
    END IF;
    IF NEW."taskId" IS DISTINCT FROM synced."taskId" THEN
      changed_cols := array_append(changed_cols, 'taskId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "task_reward_local" (
        "id", "type", "value", "probability", "itemId", "taskId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."type", NEW."value", NEW."probability", NEW."itemId", NEW."taskId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "task_reward_local"
    SET
        
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "value" = CASE WHEN NEW."value" IS DISTINCT FROM synced."value" THEN NEW."value" ELSE local."value" END,
    "probability" = CASE WHEN NEW."probability" IS DISTINCT FROM synced."probability" THEN NEW."probability" ELSE local."probability" END,
    "itemId" = CASE WHEN NEW."itemId" IS DISTINCT FROM synced."itemId" THEN NEW."itemId" ELSE local."itemId" END,
    "taskId" = CASE WHEN NEW."taskId" IS DISTINCT FROM synced."taskId" THEN NEW."taskId" ELSE local."taskId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'task_reward',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'type', COALESCE(NEW."type", local."type"),
      'value', COALESCE(NEW."value", local."value"),
      'probability', COALESCE(NEW."probability", local."probability"),
      'itemId', COALESCE(NEW."itemId", local."itemId"),
      'taskId', COALESCE(NEW."taskId", local."taskId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION task_reward_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "task_reward_local" WHERE "id" = OLD."id") THEN
    UPDATE "task_reward_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "task_reward_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'task_reward',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER task_reward_insert
INSTEAD OF INSERT ON "task_reward"
FOR EACH ROW EXECUTE FUNCTION task_reward_insert_trigger();

CREATE OR REPLACE TRIGGER task_reward_update
INSTEAD OF UPDATE ON "task_reward"
FOR EACH ROW EXECUTE FUNCTION task_reward_update_trigger();

CREATE OR REPLACE TRIGGER task_reward_delete
INSTEAD OF DELETE ON "task_reward"
FOR EACH ROW EXECUTE FUNCTION task_reward_delete_trigger();


CREATE OR REPLACE FUNCTION task_reward_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "task_reward_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION task_reward_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "task_reward_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "task_reward_synced"
FOR EACH ROW EXECUTE FUNCTION task_reward_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "task_reward_synced"
FOR EACH ROW EXECUTE FUNCTION task_reward_delete_local_on_synced_delete_trigger();

-- CreateTable
-- team
CREATE TABLE IF NOT EXISTS "team_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT,
  "gems" TEXT[],
  "write_id" UUID,
  CONSTRAINT "team_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "team_local" (
  "id" TEXT,
  "name" TEXT,
  "gems" TEXT[],
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "team_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "team" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'gems' = ANY(local.changed_columns)
      THEN local."gems"
      ELSE synced."gems"
    END AS "gems"
  FROM "team_synced" AS synced
  FULL OUTER JOIN "team_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION team_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "team_local" (
    "id", "name", "gems",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."gems",
    ARRAY['name', 'gems'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'team',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'gems', NEW."gems"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION team_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "team_synced"%ROWTYPE;
    local "team_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "team_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "team_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."gems" IS DISTINCT FROM synced."gems" THEN
      changed_cols := array_append(changed_cols, 'gems');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "team_local" (
        "id", "name", "gems",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."gems",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "team_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "gems" = CASE WHEN NEW."gems" IS DISTINCT FROM synced."gems" THEN NEW."gems" ELSE local."gems" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'team',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'gems', COALESCE(NEW."gems", local."gems")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION team_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "team_local" WHERE "id" = OLD."id") THEN
    UPDATE "team_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "team_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'team',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER team_insert
INSTEAD OF INSERT ON "team"
FOR EACH ROW EXECUTE FUNCTION team_insert_trigger();

CREATE OR REPLACE TRIGGER team_update
INSTEAD OF UPDATE ON "team"
FOR EACH ROW EXECUTE FUNCTION team_update_trigger();

CREATE OR REPLACE TRIGGER team_delete
INSTEAD OF DELETE ON "team"
FOR EACH ROW EXECUTE FUNCTION team_delete_trigger();


CREATE OR REPLACE FUNCTION team_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "team_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION team_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "team_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "team_synced"
FOR EACH ROW EXECUTE FUNCTION team_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "team_synced"
FOR EACH ROW EXECUTE FUNCTION team_delete_local_on_synced_delete_trigger();

-- CreateTable
-- user
CREATE TABLE IF NOT EXISTS "user_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT,
  "email" TEXT,
  "emailVerified" TIMESTAMP(3),
  "password" TEXT,
  "image" TEXT,
  "write_id" UUID,
  CONSTRAINT "user_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "user_local" (
  "id" TEXT,
  "name" TEXT,
  "email" TEXT,
  "emailVerified" TIMESTAMP(3),
  "password" TEXT,
  "image" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "user_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "user" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'email' = ANY(local.changed_columns)
      THEN local."email"
      ELSE synced."email"
    END AS "email",
   CASE
    WHEN 'emailVerified' = ANY(local.changed_columns)
      THEN local."emailVerified"
      ELSE synced."emailVerified"
    END AS "emailVerified",
   CASE
    WHEN 'password' = ANY(local.changed_columns)
      THEN local."password"
      ELSE synced."password"
    END AS "password",
   CASE
    WHEN 'image' = ANY(local.changed_columns)
      THEN local."image"
      ELSE synced."image"
    END AS "image"
  FROM "user_synced" AS synced
  FULL OUTER JOIN "user_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION user_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "user_local" (
    "id", "name", "email", "emailVerified", "password", "image",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."email", NEW."emailVerified", NEW."password", NEW."image",
    ARRAY['name', 'email', 'emailVerified', 'password', 'image'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'user',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'email', NEW."email",
      'emailVerified', NEW."emailVerified",
      'password', NEW."password",
      'image', NEW."image"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION user_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "user_synced"%ROWTYPE;
    local "user_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "user_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "user_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."email" IS DISTINCT FROM synced."email" THEN
      changed_cols := array_append(changed_cols, 'email');
    END IF;
    IF NEW."emailVerified" IS DISTINCT FROM synced."emailVerified" THEN
      changed_cols := array_append(changed_cols, 'emailVerified');
    END IF;
    IF NEW."password" IS DISTINCT FROM synced."password" THEN
      changed_cols := array_append(changed_cols, 'password');
    END IF;
    IF NEW."image" IS DISTINCT FROM synced."image" THEN
      changed_cols := array_append(changed_cols, 'image');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "user_local" (
        "id", "name", "email", "emailVerified", "password", "image",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."email", NEW."emailVerified", NEW."password", NEW."image",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "user_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "email" = CASE WHEN NEW."email" IS DISTINCT FROM synced."email" THEN NEW."email" ELSE local."email" END,
    "emailVerified" = CASE WHEN NEW."emailVerified" IS DISTINCT FROM synced."emailVerified" THEN NEW."emailVerified" ELSE local."emailVerified" END,
    "password" = CASE WHEN NEW."password" IS DISTINCT FROM synced."password" THEN NEW."password" ELSE local."password" END,
    "image" = CASE WHEN NEW."image" IS DISTINCT FROM synced."image" THEN NEW."image" ELSE local."image" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'user',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'email', COALESCE(NEW."email", local."email"),
      'emailVerified', COALESCE(NEW."emailVerified", local."emailVerified"),
      'password', COALESCE(NEW."password", local."password"),
      'image', COALESCE(NEW."image", local."image")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION user_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "user_local" WHERE "id" = OLD."id") THEN
    UPDATE "user_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "user_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'user',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER user_insert
INSTEAD OF INSERT ON "user"
FOR EACH ROW EXECUTE FUNCTION user_insert_trigger();

CREATE OR REPLACE TRIGGER user_update
INSTEAD OF UPDATE ON "user"
FOR EACH ROW EXECUTE FUNCTION user_update_trigger();

CREATE OR REPLACE TRIGGER user_delete
INSTEAD OF DELETE ON "user"
FOR EACH ROW EXECUTE FUNCTION user_delete_trigger();


CREATE OR REPLACE FUNCTION user_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "user_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION user_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "user_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "user_synced"
FOR EACH ROW EXECUTE FUNCTION user_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "user_synced"
FOR EACH ROW EXECUTE FUNCTION user_delete_local_on_synced_delete_trigger();

-- CreateTable
-- verification_token
CREATE TABLE IF NOT EXISTS "verification_token_synced" (
  "identifier" TEXT NOT NULL,
  "token" TEXT NOT NULL,
  "expires" TIMESTAMP(3) NOT NULL,
  "write_id" UUID
);
CREATE TABLE IF NOT EXISTS "verification_token_local" (
  "identifier" TEXT,
  "token" TEXT,
  "expires" TIMESTAMP(3),
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL
);
-- Skipped verification_token (no primary key)

-- CreateTable
-- weapon
CREATE TABLE IF NOT EXISTS "weapon_synced" (
  "type" "WeaponType" NOT NULL,
  "baseAbi" INTEGER NOT NULL,
  "stability" INTEGER NOT NULL,
  "modifiers" TEXT[],
  "colorA" INTEGER NOT NULL,
  "colorB" INTEGER NOT NULL,
  "colorC" INTEGER NOT NULL,
  "elementType" "ElementType" NOT NULL,
  "itemId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "weapon_synced_pkey" PRIMARY KEY ("itemId")
);
CREATE TABLE IF NOT EXISTS "weapon_local" (
  "type" "WeaponType",
  "baseAbi" INTEGER,
  "stability" INTEGER,
  "modifiers" TEXT[],
  "colorA" INTEGER,
  "colorB" INTEGER,
  "colorC" INTEGER,
  "elementType" "ElementType",
  "itemId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "weapon_local_pkey" PRIMARY KEY ("itemId")
);

CREATE OR REPLACE VIEW "weapon" AS
  SELECT
     CASE
    WHEN 'type' = ANY(local.changed_columns)
      THEN local."type"
      ELSE synced."type"
    END AS "type",
   CASE
    WHEN 'baseAbi' = ANY(local.changed_columns)
      THEN local."baseAbi"
      ELSE synced."baseAbi"
    END AS "baseAbi",
   CASE
    WHEN 'stability' = ANY(local.changed_columns)
      THEN local."stability"
      ELSE synced."stability"
    END AS "stability",
   CASE
    WHEN 'modifiers' = ANY(local.changed_columns)
      THEN local."modifiers"
      ELSE synced."modifiers"
    END AS "modifiers",
   CASE
    WHEN 'colorA' = ANY(local.changed_columns)
      THEN local."colorA"
      ELSE synced."colorA"
    END AS "colorA",
   CASE
    WHEN 'colorB' = ANY(local.changed_columns)
      THEN local."colorB"
      ELSE synced."colorB"
    END AS "colorB",
   CASE
    WHEN 'colorC' = ANY(local.changed_columns)
      THEN local."colorC"
      ELSE synced."colorC"
    END AS "colorC",
   CASE
    WHEN 'elementType' = ANY(local.changed_columns)
      THEN local."elementType"
      ELSE synced."elementType"
    END AS "elementType",
   COALESCE(local."itemId", synced."itemId") AS "itemId"
  FROM "weapon_synced" AS synced
  FULL OUTER JOIN "weapon_local" AS local
  ON synced."itemId" = local."itemId"
  WHERE (local."itemId" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION weapon_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "weapon_local" (
    "type", "baseAbi", "stability", "modifiers", "colorA", "colorB", "colorC", "elementType", "itemId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."type", NEW."baseAbi", NEW."stability", NEW."modifiers", NEW."colorA", NEW."colorB", NEW."colorC", NEW."elementType", NEW."itemId",
    ARRAY['type', 'baseAbi', 'stability', 'modifiers', 'colorA', 'colorB', 'colorC', 'elementType'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'weapon',
    'insert',
    jsonb_build_object(
        'type', NEW."type",
      'baseAbi', NEW."baseAbi",
      'stability', NEW."stability",
      'modifiers', NEW."modifiers",
      'colorA', NEW."colorA",
      'colorB', NEW."colorB",
      'colorC', NEW."colorC",
      'elementType', NEW."elementType",
      'itemId', NEW."itemId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION weapon_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "weapon_synced"%ROWTYPE;
    local "weapon_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "weapon_synced" WHERE "itemId" = NEW."itemId";
    SELECT * INTO local FROM "weapon_local" WHERE "itemId" = NEW."itemId";
    
    IF NEW."type" IS DISTINCT FROM synced."type" THEN
      changed_cols := array_append(changed_cols, 'type');
    END IF;
    IF NEW."baseAbi" IS DISTINCT FROM synced."baseAbi" THEN
      changed_cols := array_append(changed_cols, 'baseAbi');
    END IF;
    IF NEW."stability" IS DISTINCT FROM synced."stability" THEN
      changed_cols := array_append(changed_cols, 'stability');
    END IF;
    IF NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN
      changed_cols := array_append(changed_cols, 'modifiers');
    END IF;
    IF NEW."colorA" IS DISTINCT FROM synced."colorA" THEN
      changed_cols := array_append(changed_cols, 'colorA');
    END IF;
    IF NEW."colorB" IS DISTINCT FROM synced."colorB" THEN
      changed_cols := array_append(changed_cols, 'colorB');
    END IF;
    IF NEW."colorC" IS DISTINCT FROM synced."colorC" THEN
      changed_cols := array_append(changed_cols, 'colorC');
    END IF;
    IF NEW."elementType" IS DISTINCT FROM synced."elementType" THEN
      changed_cols := array_append(changed_cols, 'elementType');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "weapon_local" (
        "type", "baseAbi", "stability", "modifiers", "colorA", "colorB", "colorC", "elementType", "itemId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."type", NEW."baseAbi", NEW."stability", NEW."modifiers", NEW."colorA", NEW."colorB", NEW."colorC", NEW."elementType", NEW."itemId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "weapon_local"
    SET
        
    "type" = CASE WHEN NEW."type" IS DISTINCT FROM synced."type" THEN NEW."type" ELSE local."type" END,
    "baseAbi" = CASE WHEN NEW."baseAbi" IS DISTINCT FROM synced."baseAbi" THEN NEW."baseAbi" ELSE local."baseAbi" END,
    "stability" = CASE WHEN NEW."stability" IS DISTINCT FROM synced."stability" THEN NEW."stability" ELSE local."stability" END,
    "modifiers" = CASE WHEN NEW."modifiers" IS DISTINCT FROM synced."modifiers" THEN NEW."modifiers" ELSE local."modifiers" END,
    "colorA" = CASE WHEN NEW."colorA" IS DISTINCT FROM synced."colorA" THEN NEW."colorA" ELSE local."colorA" END,
    "colorB" = CASE WHEN NEW."colorB" IS DISTINCT FROM synced."colorB" THEN NEW."colorB" ELSE local."colorB" END,
    "colorC" = CASE WHEN NEW."colorC" IS DISTINCT FROM synced."colorC" THEN NEW."colorC" ELSE local."colorC" END,
    "elementType" = CASE WHEN NEW."elementType" IS DISTINCT FROM synced."elementType" THEN NEW."elementType" ELSE local."elementType" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "itemId" = NEW."itemId";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'weapon',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'type', COALESCE(NEW."type", local."type"),
      'baseAbi', COALESCE(NEW."baseAbi", local."baseAbi"),
      'stability', COALESCE(NEW."stability", local."stability"),
      'modifiers', COALESCE(NEW."modifiers", local."modifiers"),
      'colorA', COALESCE(NEW."colorA", local."colorA"),
      'colorB', COALESCE(NEW."colorB", local."colorB"),
      'colorC', COALESCE(NEW."colorC", local."colorC"),
      'elementType', COALESCE(NEW."elementType", local."elementType"),
      'itemId', COALESCE(NEW."itemId", local."itemId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION weapon_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "weapon_local" WHERE "itemId" = OLD."itemId") THEN
    UPDATE "weapon_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "itemId" = OLD."itemId";
    ELSE
    INSERT INTO "weapon_local" (
        itemId,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."itemId",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'weapon',
    'delete',
    jsonb_build_object('itemId', OLD."itemId"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER weapon_insert
INSTEAD OF INSERT ON "weapon"
FOR EACH ROW EXECUTE FUNCTION weapon_insert_trigger();

CREATE OR REPLACE TRIGGER weapon_update
INSTEAD OF UPDATE ON "weapon"
FOR EACH ROW EXECUTE FUNCTION weapon_update_trigger();

CREATE OR REPLACE TRIGGER weapon_delete
INSTEAD OF DELETE ON "weapon"
FOR EACH ROW EXECUTE FUNCTION weapon_delete_trigger();


CREATE OR REPLACE FUNCTION weapon_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "weapon_local"
  WHERE "itemId" = NEW."itemId"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION weapon_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "weapon_local"
  WHERE "itemId" = OLD."itemId";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "weapon_synced"
FOR EACH ROW EXECUTE FUNCTION weapon_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "weapon_synced"
FOR EACH ROW EXECUTE FUNCTION weapon_delete_local_on_synced_delete_trigger();

-- CreateTable
-- world
CREATE TABLE IF NOT EXISTS "world_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "world_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "world_local" (
  "id" TEXT,
  "name" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "world_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "world" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name"
  FROM "world_synced" AS synced
  FULL OUTER JOIN "world_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION world_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "world_local" (
    "id", "name",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name",
    ARRAY['name'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'world',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION world_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "world_synced"%ROWTYPE;
    local "world_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "world_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "world_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "world_local" (
        "id", "name",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "world_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'world',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION world_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "world_local" WHERE "id" = OLD."id") THEN
    UPDATE "world_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "world_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'world',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER world_insert
INSTEAD OF INSERT ON "world"
FOR EACH ROW EXECUTE FUNCTION world_insert_trigger();

CREATE OR REPLACE TRIGGER world_update
INSTEAD OF UPDATE ON "world"
FOR EACH ROW EXECUTE FUNCTION world_update_trigger();

CREATE OR REPLACE TRIGGER world_delete
INSTEAD OF DELETE ON "world"
FOR EACH ROW EXECUTE FUNCTION world_delete_trigger();


CREATE OR REPLACE FUNCTION world_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "world_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION world_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "world_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "world_synced"
FOR EACH ROW EXECUTE FUNCTION world_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "world_synced"
FOR EACH ROW EXECUTE FUNCTION world_delete_local_on_synced_delete_trigger();

-- CreateTable
-- zone
CREATE TABLE IF NOT EXISTS "zone_synced" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "linkZone" TEXT[],
  "rewardNodes" INTEGER,
  "activityId" TEXT,
  "addressId" TEXT NOT NULL,
  "write_id" UUID,
  CONSTRAINT "zone_synced_pkey" PRIMARY KEY ("id")
);
CREATE TABLE IF NOT EXISTS "zone_local" (
  "id" TEXT,
  "name" TEXT,
  "linkZone" TEXT[],
  "rewardNodes" INTEGER,
  "activityId" TEXT,
  "addressId" TEXT,
  "changed_columns" TEXT[],
  "is_deleted" BOOLEAN NOT NULL DEFAULT FALSE,
  "write_id" UUID NOT NULL,
  CONSTRAINT "zone_local_pkey" PRIMARY KEY ("id")
);

CREATE OR REPLACE VIEW "zone" AS
  SELECT
     COALESCE(local."id", synced."id") AS "id",
   CASE
    WHEN 'name' = ANY(local.changed_columns)
      THEN local."name"
      ELSE synced."name"
    END AS "name",
   CASE
    WHEN 'linkZone' = ANY(local.changed_columns)
      THEN local."linkZone"
      ELSE synced."linkZone"
    END AS "linkZone",
   CASE
    WHEN 'rewardNodes' = ANY(local.changed_columns)
      THEN local."rewardNodes"
      ELSE synced."rewardNodes"
    END AS "rewardNodes",
   CASE
    WHEN 'activityId' = ANY(local.changed_columns)
      THEN local."activityId"
      ELSE synced."activityId"
    END AS "activityId",
   CASE
    WHEN 'addressId' = ANY(local.changed_columns)
      THEN local."addressId"
      ELSE synced."addressId"
    END AS "addressId"
  FROM "zone_synced" AS synced
  FULL OUTER JOIN "zone_local" AS local
  ON synced."id" = local."id"
  WHERE (local."id" IS NULL OR local."is_deleted" = FALSE);

CREATE OR REPLACE FUNCTION zone_insert_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    INSERT INTO "zone_local" (
    "id", "name", "linkZone", "rewardNodes", "activityId", "addressId",
    changed_columns,
    write_id
    )
    VALUES (
    NEW."id", NEW."name", NEW."linkZone", NEW."rewardNodes", NEW."activityId", NEW."addressId",
    ARRAY['name', 'linkZone', 'rewardNodes', 'activityId', 'addressId'],
    local_write_id
    );

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'zone',
    'insert',
    jsonb_build_object(
        'id', NEW."id",
      'name', NEW."name",
      'linkZone', NEW."linkZone",
      'rewardNodes', NEW."rewardNodes",
      'activityId', NEW."activityId",
      'addressId', NEW."addressId"
    ),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION zone_update_trigger()
RETURNS TRIGGER AS $$
DECLARE
    synced "zone_synced"%ROWTYPE;
    local "zone_local"%ROWTYPE;
    changed_cols TEXT[] := '{}';
    local_write_id UUID := gen_random_uuid();
BEGIN
    SELECT * INTO synced FROM "zone_synced" WHERE "id" = NEW."id";
    SELECT * INTO local FROM "zone_local" WHERE "id" = NEW."id";
    
    IF NEW."name" IS DISTINCT FROM synced."name" THEN
      changed_cols := array_append(changed_cols, 'name');
    END IF;
    IF NEW."linkZone" IS DISTINCT FROM synced."linkZone" THEN
      changed_cols := array_append(changed_cols, 'linkZone');
    END IF;
    IF NEW."rewardNodes" IS DISTINCT FROM synced."rewardNodes" THEN
      changed_cols := array_append(changed_cols, 'rewardNodes');
    END IF;
    IF NEW."activityId" IS DISTINCT FROM synced."activityId" THEN
      changed_cols := array_append(changed_cols, 'activityId');
    END IF;
    IF NEW."addressId" IS DISTINCT FROM synced."addressId" THEN
      changed_cols := array_append(changed_cols, 'addressId');
    END IF;
    IF NOT FOUND THEN
    INSERT INTO "zone_local" (
        "id", "name", "linkZone", "rewardNodes", "activityId", "addressId",
        changed_columns,
        write_id
    )
    VALUES (
        NEW."id", NEW."name", NEW."linkZone", NEW."rewardNodes", NEW."activityId", NEW."addressId",
        changed_cols,
        local_write_id
    );
    ELSE
    UPDATE "zone_local"
    SET
        
    "name" = CASE WHEN NEW."name" IS DISTINCT FROM synced."name" THEN NEW."name" ELSE local."name" END,
    "linkZone" = CASE WHEN NEW."linkZone" IS DISTINCT FROM synced."linkZone" THEN NEW."linkZone" ELSE local."linkZone" END,
    "rewardNodes" = CASE WHEN NEW."rewardNodes" IS DISTINCT FROM synced."rewardNodes" THEN NEW."rewardNodes" ELSE local."rewardNodes" END,
    "activityId" = CASE WHEN NEW."activityId" IS DISTINCT FROM synced."activityId" THEN NEW."activityId" ELSE local."activityId" END,
    "addressId" = CASE WHEN NEW."addressId" IS DISTINCT FROM synced."addressId" THEN NEW."addressId" ELSE local."addressId" END,
        changed_columns = (
        SELECT array_agg(DISTINCT col) FROM (
            SELECT unnest(local.changed_columns) AS col
            UNION
            SELECT unnest(changed_cols) AS col
        ) AS cols
        ),
        write_id = local_write_id
    WHERE "id" = NEW."id";
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'zone',
    'update',
    jsonb_strip_nulls(jsonb_build_object(
        'id', COALESCE(NEW."id", local."id"),
      'name', COALESCE(NEW."name", local."name"),
      'linkZone', COALESCE(NEW."linkZone", local."linkZone"),
      'rewardNodes', COALESCE(NEW."rewardNodes", local."rewardNodes"),
      'activityId', COALESCE(NEW."activityId", local."activityId"),
      'addressId', COALESCE(NEW."addressId", local."addressId")
    )),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION zone_delete_trigger()
RETURNS TRIGGER AS $$
DECLARE
    local_write_id UUID := gen_random_uuid();
BEGIN
    IF EXISTS (SELECT 1 FROM "zone_local" WHERE "id" = OLD."id") THEN
    UPDATE "zone_local"
    SET is_deleted = TRUE,
        write_id = local_write_id
    WHERE "id" = OLD."id";
    ELSE
    INSERT INTO "zone_local" (
        id,
        "is_deleted",
        "write_id"
    )
    VALUES (
        OLD."id",
        TRUE,
        local_write_id
    );
    END IF;

    INSERT INTO changes (
    table_name,
    operation,
    value,
    write_id,
    transaction_id
    )
    VALUES (
    'zone',
    'delete',
    jsonb_build_object('id', OLD."id"),
    local_write_id,
    pg_current_xact_id()
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER zone_insert
INSTEAD OF INSERT ON "zone"
FOR EACH ROW EXECUTE FUNCTION zone_insert_trigger();

CREATE OR REPLACE TRIGGER zone_update
INSTEAD OF UPDATE ON "zone"
FOR EACH ROW EXECUTE FUNCTION zone_update_trigger();

CREATE OR REPLACE TRIGGER zone_delete
INSTEAD OF DELETE ON "zone"
FOR EACH ROW EXECUTE FUNCTION zone_delete_trigger();


CREATE OR REPLACE FUNCTION zone_delete_local_on_synced_insert_and_update_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "zone_local"
  WHERE "id" = NEW."id"
    AND write_id IS NOT NULL
    AND write_id = NEW.write_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION zone_delete_local_on_synced_delete_trigger()
RETURNS TRIGGER AS $$
BEGIN
  DELETE FROM "zone_local"
  WHERE "id" = OLD."id";
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER delete_local_on_synced_insert
AFTER INSERT OR UPDATE ON "zone_synced"
FOR EACH ROW EXECUTE FUNCTION zone_delete_local_on_synced_insert_and_update_trigger();

CREATE OR REPLACE TRIGGER delete_local_on_synced_delete
AFTER DELETE ON "zone_synced"
FOR EACH ROW EXECUTE FUNCTION zone_delete_local_on_synced_delete_trigger();
CREATE TABLE IF NOT EXISTS changes (
  id BIGSERIAL PRIMARY KEY,
  table_name TEXT NOT NULL,
  operation TEXT NOT NULL,
  value JSONB NOT NULL,
  write_id UUID NOT NULL,
  transaction_id XID8 NOT NULL
);

CREATE OR REPLACE FUNCTION changes_notify_trigger()
RETURNS TRIGGER AS $$
BEGIN
  NOTIFY changes;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER changes_notify
AFTER INSERT ON changes
FOR EACH ROW
EXECUTE FUNCTION changes_notify_trigger();
`;const API_URL="http://localhost:3001/api",maxRetries=32,backoffMultiplier=1.1,initialDelayMs=1e3;async function retryFetch(e,I,Hn){if(Hn>maxRetries)return;const $n=Hn*backoffMultiplier*initialDelayMs;return await new Promise(qn=>{setTimeout(async()=>{console.log(`重试 ${Hn} 次，等待 ${$n} 毫秒`),qn(await resilientFetch(e,I,Hn))},$n)})}async function resilientFetch(e,I,Hn){try{console.log(`尝试上传：fetching ${e}, retryCount=${Hn}`);const $n=await fetch(e,I);return $n.status>=500&&$n.status<600?(console.warn(`服务器错误（${$n.status}），准备重试`),await retryFetch(e,I,Hn+1)):(console.log("上传成功",$n),$n)}catch($n){return console.log("发生错误，正在重试",$n),await retryFetch(e,I,Hn+1)}}async function request(e,I,Hn,$n){const qn=`${API_URL}${e}`,Xn={method:I,headers:{"Content-Type":"application/json"}};return Hn!==void 0&&(Xn.body=JSON.stringify(Hn)),$n!==void 0&&(Xn.signal=$n),await resilientFetch(qn,Xn,0)}class ChangeLogSynchronizer{#e;#n;#t=!1;#o=!0;#r="idle";#a;#l;constructor(I,Hn=0){this.#e=I,this.#n=Hn}async start(){this.#a=new AbortController,this.#l=await this.#e.listen("changes",this.handle.bind(this)),this.process()}async handle(){if(console.log("接收到来自live插件的changes通知"),this.#r==="processing"){this.#t=!0;return}this.#r="processing",this.process()}async process(){this.#t=!1;const{changes:I,position:Hn}=await this.query();if(I.length)switch(await this.send(I)){case"accepted":await this.proceed(Hn);break;case"rejected":await this.rollback();break;case"retry":this.#t=!0;break}if(this.#t&&this.#o)return await this.process();this.#r="idle"}async query(){const{rows:I}=await this.#e.sql`
      SELECT * from changes
        WHERE id > ${this.#n}
        ORDER BY id asc
    `,Hn=I.length?I.at(-1).id:this.#n;return{changes:I,position:Hn}}async send(I){const Hn="/changes",$n=Object.groupBy(I,Jn=>Jn.transaction_id),Xn=Object.entries($n).sort((Jn,Zn)=>Jn[0].localeCompare(Zn[0])).map(([Jn,Zn])=>({id:Jn,changes:Zn})),Yn=this.#a?.signal;let Kn;try{console.log("发送数据",Xn),Kn=await request(Hn,"POST",Xn,Yn)}catch{return"retry"}return Kn===void 0?"retry":Kn.ok?"accepted":Kn.status<500?"rejected":"retry"}async proceed(I){await this.#e.sql`
      DELETE from changes
        WHERE id <= ${I}
    `,this.#n=I}async rollback(){await this.#e.transaction(async I=>{await I.sql`DELETE from changes`})}async stop(){this.#o=!1,this.#a!==void 0&&this.#a.abort(),this.#l!==void 0&&await this.#l()}}const ELECTRIC_HOST="https://test.kiaclouth.com/v1/shape",notifySyncProgress=e=>{console.log(e+"已同步完成"),self.postMessage({type:"sync",data:{tableName:e,state:"success"},timestamp:Date.now().toLocaleString()})},migrates=[{name:"init",sql:ddl}];se$1({async init(){const e=await Ue.create({dataDir:"idb://toramCalculatorDB",relaxedDurability:!0,extensions:{live:j,electric:ue({debug:!1}),pg_trgm:p}});await e.exec("CREATE EXTENSION IF NOT EXISTS pg_trgm;"),await e.exec(`
      CREATE TABLE IF NOT EXISTS migrations (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);const Hn=(await e.exec("SELECT name FROM migrations ORDER BY id;"))[0].rows.map(Xn=>Xn.name);for(const Xn of migrates)Hn.includes(Xn.name)||(await e.exec(Xn.sql),await e.exec(`
        INSERT INTO migrations (name)
        VALUES ('${Xn.name}');
      `),console.log(`已应用迁移: ${Xn.name}`));const $n=async(Xn,Yn,Kn)=>{const Jn=Kn??Xn;e.electric.syncShapeToTable({shape:{url:ELECTRIC_HOST,params:{table:Jn}},table:`${Xn}_synced`,shapeKey:`${Xn}s`,primaryKey:Yn,onInitialSync:()=>notifySyncProgress(Xn)})};return await $n("account",["id"]),await $n("account_create_data",["userId"]),await $n("account_update_data",["userId"]),await $n("player",["id"]),await $n("statistic",["id"]),await $n("image",["id"]),await $n("world",["id"]),await $n("address",["id"]),await $n("zone",["id"]),await $n("_mobTozone",["A","B"],'"_mobTozone"'),await $n("mob",["id"]),await $n("item",["id"]),await $n("weapon",["itemId"]),await $n("armor",["itemId"]),await $n("option",["itemId"]),await $n("special",["itemId"]),await $n("avatar",["id"]),await $n("crystal",["itemId"]),await $n("_crystalToplayer_weapon",["A","B"],'"_crystalToplayer_weapon"'),await $n("_crystalToplayer_armor",["A","B"],'"_crystalToplayer_armor"'),await $n("_crystalToplayer_option",["A","B"],'"_crystalToplayer_option"'),await $n("_crystalToplayer_special",["A","B"],'"_crystalToplayer_special"'),await $n("skill",["id"]),await $n("skill_effect",["id"]),await $n("player_weapon",["id"]),await $n("player_armor",["id"]),await $n("player_option",["id"]),await $n("player_special",["id"]),await $n("player_pet",["id"]),await $n("character_skill",["id"]),await $n("consumable",["itemId"]),await $n("combo",["id"]),await $n("character",["id"]),await $n("mercenary",["templateId"]),await $n("member",["id"]),await $n("team",["id"]),await $n("simulator",["id"]),new ChangeLogSynchronizer(e).start(),e}});export{C,R$2 as R,T,U$2 as U,u$1 as a,cr as c,h$1 as h,pr as p,ur as u,x$2 as x};
//# sourceMappingURL=PGlite.worker-CwyYoeB4.js.map
