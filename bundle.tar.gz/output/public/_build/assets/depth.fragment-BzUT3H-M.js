import{S as i}from"./(app)-BQcXoKzi.js";import"./clipPlaneFragment-BkQQ1GyC.js";import"./packingFunctions-BlcJEJ_N.js";import"./web-CIHpc6fx.js";import"./index-BOpBpQJ6.js";import"./store-CQ2B4mPE.js";import"./Media-BgKXkKGj.js";import"./input-_8gDkfJ0.js";import"./button-CwbqJzx-.js";import"./i18n-D2sladI6.js";import"./toggle-C_wLPjKz.js";import"./OverlayScrollbarsComponent-D4buOMT4.js";import"./overlayscrollbars-D3GIAgNs.js";import"./preload-helper-CM3UJVvY.js";import"./loadingBar-DLmXW3E3.js";const e="depthPixelShader",t=`#ifdef ALPHATEST
varying vUV: vec2f;var diffuseSamplerSampler: sampler;var diffuseSampler: texture_2d<f32>;
#endif
#include<clipPlaneFragmentDeclaration>
varying vDepthMetric: f32;
#ifdef PACKED
#include<packingFunctions>
#endif
#ifdef STORE_CAMERASPACE_Z
varying vViewPos: vec4f;
#endif
#define CUSTOM_FRAGMENT_DEFINITIONS
@fragment
fn main(input: FragmentInputs)->FragmentOutputs {
#include<clipPlaneFragment>
#ifdef ALPHATEST
if (textureSample(diffuseSampler,diffuseSamplerSampler,input.vUV).a<0.4) {discard;}
#endif
#ifdef STORE_CAMERASPACE_Z
#ifdef PACKED
fragmentOutputs.color=pack(input.vViewPos.z);
#else
fragmentOutputs.color= vec4f(input.vViewPos.z,0.0,0.0,1.0);
#endif
#else
#ifdef NONLINEARDEPTH
#ifdef PACKED
fragmentOutputs.color=pack(input.position.z);
#else
fragmentOutputs.color= vec4f(input.position.z,0.0,0.0,0.0);
#endif
#else
#ifdef PACKED
fragmentOutputs.color=pack(input.vDepthMetric);
#else
fragmentOutputs.color= vec4f(input.vDepthMetric,0.0,0.0,1.0);
#endif
#endif
#endif
}`;i.ShadersStoreWGSL[e]||(i.ShadersStoreWGSL[e]=t);const E={name:e,shader:t};export{E as depthPixelShaderWGSL};
//# sourceMappingURL=depth.fragment-BzUT3H-M.js.map
