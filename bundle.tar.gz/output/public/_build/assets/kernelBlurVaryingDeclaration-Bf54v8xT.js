import{S as e}from"./(app)-BQcXoKzi.js";const r="kernelBlurVaryingDeclaration",a="varying sampleCoord{X}: vec2f;";e.IncludesShadersStoreWGSL[r]||(e.IncludesShadersStoreWGSL[r]=a);
//# sourceMappingURL=kernelBlurVaryingDeclaration-Bf54v8xT.js.map
