import{S as e}from"./(app)-BQcXoKzi.js";const r="kernelBlurVaryingDeclaration",a="varying vec2 sampleCoord{X};";e.IncludesShadersStore[r]||(e.IncludesShadersStore[r]=a);
//# sourceMappingURL=kernelBlurVaryingDeclaration-Dvg3ZI3s.js.map
