import{z as t}from"./web-CIHpc6fx.js";const o=t({width:1920,height:945,orientation:"landscape"});export{o as M};
//# sourceMappingURL=Media-BgKXkKGj.js.map
