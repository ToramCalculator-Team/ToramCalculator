import{S as t}from"./(app)-BQcXoKzi.js";import"./web-CIHpc6fx.js";import"./index-BOpBpQJ6.js";import"./store-CQ2B4mPE.js";import"./Media-BgKXkKGj.js";import"./input-_8gDkfJ0.js";import"./button-CwbqJzx-.js";import"./i18n-D2sladI6.js";import"./toggle-C_wLPjKz.js";import"./OverlayScrollbarsComponent-D4buOMT4.js";import"./overlayscrollbars-D3GIAgNs.js";import"./preload-helper-CM3UJVvY.js";import"./loadingBar-DLmXW3E3.js";const r="passPixelShader",e=`varying vUV: vec2f;var textureSamplerSampler: sampler;var textureSampler: texture_2d<f32>;
#define CUSTOM_FRAGMENT_DEFINITIONS
@fragment
fn main(input: FragmentInputs)->FragmentOutputs {fragmentOutputs.color=textureSample(textureSampler,textureSamplerSampler,input.vUV);}`;t.ShadersStoreWGSL[r]||(t.ShadersStoreWGSL[r]=e);const h={name:r,shader:e};export{h as passPixelShaderWGSL};
//# sourceMappingURL=pass.fragment-DykT_6gR.js.map
