import{S as e}from"./(app)-BQcXoKzi.js";import"./kernelBlurVaryingDeclaration-Dvg3ZI3s.js";import"./web-CIHpc6fx.js";import"./index-BOpBpQJ6.js";import"./store-CQ2B4mPE.js";import"./Media-BgKXkKGj.js";import"./input-_8gDkfJ0.js";import"./button-CwbqJzx-.js";import"./i18n-D2sladI6.js";import"./toggle-C_wLPjKz.js";import"./OverlayScrollbarsComponent-D4buOMT4.js";import"./overlayscrollbars-D3GIAgNs.js";import"./preload-helper-CM3UJVvY.js";import"./loadingBar-DLmXW3E3.js";const r="kernelBlurFragment",n=`#ifdef DOF
factor=sampleCoC(sampleCoord{X}); 
computedWeight=KERNEL_WEIGHT{X}*factor;sumOfWeights+=computedWeight;
#else
computedWeight=KERNEL_WEIGHT{X};
#endif
#ifdef PACKEDFLOAT
blend+=unpack(texture2D(textureSampler,sampleCoord{X}))*computedWeight;
#else
blend+=texture2D(textureSampler,sampleCoord{X})*computedWeight;
#endif
`;e.IncludesShadersStore[r]||(e.IncludesShadersStore[r]=n);const o="kernelBlurFragment2",i=`#ifdef DOF
factor=sampleCoC(sampleCenter+delta*KERNEL_DEP_OFFSET{X});computedWeight=KERNEL_DEP_WEIGHT{X}*factor;sumOfWeights+=computedWeight;
#else
computedWeight=KERNEL_DEP_WEIGHT{X};
#endif
#ifdef PACKEDFLOAT
blend+=unpack(texture2D(textureSampler,sampleCenter+delta*KERNEL_DEP_OFFSET{X}))*computedWeight;
#else
blend+=texture2D(textureSampler,sampleCenter+delta*KERNEL_DEP_OFFSET{X})*computedWeight;
#endif
`;e.IncludesShadersStore[o]||(e.IncludesShadersStore[o]=i);const t="kernelBlurPixelShader",l=`uniform sampler2D textureSampler;uniform vec2 delta;varying vec2 sampleCenter;
#ifdef DOF
uniform sampler2D circleOfConfusionSampler;float sampleCoC(in vec2 offset) {float coc=texture2D(circleOfConfusionSampler,offset).r;return coc; }
#endif
#include<kernelBlurVaryingDeclaration>[0..varyingCount]
#ifdef PACKEDFLOAT
#include<packingFunctions>
#endif
#define CUSTOM_FRAGMENT_DEFINITIONS
void main(void)
{float computedWeight=0.0;
#ifdef PACKEDFLOAT
float blend=0.;
#else
vec4 blend=vec4(0.);
#endif
#ifdef DOF
float sumOfWeights=CENTER_WEIGHT; 
float factor=0.0;
#ifdef PACKEDFLOAT
blend+=unpack(texture2D(textureSampler,sampleCenter))*CENTER_WEIGHT;
#else
blend+=texture2D(textureSampler,sampleCenter)*CENTER_WEIGHT;
#endif
#endif
#include<kernelBlurFragment>[0..varyingCount]
#include<kernelBlurFragment2>[0..depCount]
#ifdef PACKEDFLOAT
gl_FragColor=pack(blend);
#else
gl_FragColor=blend;
#endif
#ifdef DOF
gl_FragColor/=sumOfWeights;
#endif
}`;e.ShadersStore[t]||(e.ShadersStore[t]=l);const F={name:t,shader:l};export{F as kernelBlurPixelShader};
//# sourceMappingURL=kernelBlur.fragment-Bn0zydtV.js.map
