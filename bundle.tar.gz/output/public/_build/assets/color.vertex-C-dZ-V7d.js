import{S as i}from"./(app)-BQcXoKzi.js";import"./vertexColorMixing-D_371lDa.js";import"./web-CIHpc6fx.js";import"./index-BOpBpQJ6.js";import"./store-CQ2B4mPE.js";import"./Media-BgKXkKGj.js";import"./input-_8gDkfJ0.js";import"./button-CwbqJzx-.js";import"./i18n-D2sladI6.js";import"./toggle-C_wLPjKz.js";import"./OverlayScrollbarsComponent-D4buOMT4.js";import"./overlayscrollbars-D3GIAgNs.js";import"./preload-helper-CM3UJVvY.js";import"./loadingBar-DLmXW3E3.js";const e="colorVertexShader",o=`attribute vec3 position;
#ifdef VERTEXCOLOR
attribute vec4 color;
#endif
#include<bonesDeclaration>
#include<bakedVertexAnimationDeclaration>
#include<clipPlaneVertexDeclaration>
#include<fogVertexDeclaration>
#ifdef FOG
uniform mat4 view;
#endif
#include<instancesDeclaration>
uniform mat4 viewProjection;
#ifdef MULTIVIEW
uniform mat4 viewProjectionR;
#endif
#if defined(VERTEXCOLOR) || defined(INSTANCESCOLOR) && defined(INSTANCES)
varying vec4 vColor;
#endif
#define CUSTOM_VERTEX_DEFINITIONS
void main(void) {
#define CUSTOM_VERTEX_MAIN_BEGIN
#ifdef VERTEXCOLOR
vec4 colorUpdated=color;
#endif
#include<instancesVertex>
#include<bonesVertex>
#include<bakedVertexAnimation>
vec4 worldPos=finalWorld*vec4(position,1.0);
#ifdef MULTIVIEW
if (gl_ViewID_OVR==0u) {gl_Position=viewProjection*worldPos;} else {gl_Position=viewProjectionR*worldPos;}
#else
gl_Position=viewProjection*worldPos;
#endif
#include<clipPlaneVertex>
#include<fogVertex>
#include<vertexColorMixing>
#define CUSTOM_VERTEX_MAIN_END
}`;i.ShadersStore[e]||(i.ShadersStore[e]=o);const v={name:e,shader:o};export{v as colorVertexShader};
//# sourceMappingURL=color.vertex-C-dZ-V7d.js.map
