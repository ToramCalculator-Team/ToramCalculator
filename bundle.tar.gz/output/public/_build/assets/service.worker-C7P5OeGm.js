(async e=>{e.addEventListener("install",t=>{console.log("SW: install"),t.waitUntil(e.skipWaiting())}),e.addEventListener("activate",t=>{console.log("SW: activate")}),e.addEventListener("fetch",t=>{new URL(t.request.url).origin===location.origin&&t.request.method})})(self);
//# sourceMappingURL=service.worker-C7P5OeGm.js.map
