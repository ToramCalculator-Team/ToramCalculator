import{e}from"./postgres-BTNW2TY8.js";const t={},r=Object.freeze(Object.defineProperty({__proto__:null,default:t},Symbol.toStringTag,{value:"Module"})),a=e(r);export{a as r};
//# sourceMappingURL=___vite-browser-external_commonjs-proxy-BaOBqZBm.js.map
