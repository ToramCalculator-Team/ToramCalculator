import{S as r}from"./(app)-BQcXoKzi.js";import"./web-CIHpc6fx.js";import"./index-BOpBpQJ6.js";import"./store-CQ2B4mPE.js";import"./Media-BgKXkKGj.js";import"./input-_8gDkfJ0.js";import"./button-CwbqJzx-.js";import"./i18n-D2sladI6.js";import"./toggle-C_wLPjKz.js";import"./OverlayScrollbarsComponent-D4buOMT4.js";import"./overlayscrollbars-D3GIAgNs.js";import"./preload-helper-CM3UJVvY.js";import"./loadingBar-DLmXW3E3.js";const e="passCubePixelShader",t=`varying vec2 vUV;uniform samplerCube textureSampler;
#define CUSTOM_FRAGMENT_DEFINITIONS
void main(void) 
{vec2 uv=vUV*2.0-1.0;
#ifdef POSITIVEX
gl_FragColor=textureCube(textureSampler,vec3(1.001,uv.y,uv.x));
#endif
#ifdef NEGATIVEX
gl_FragColor=textureCube(textureSampler,vec3(-1.001,uv.y,uv.x));
#endif
#ifdef POSITIVEY
gl_FragColor=textureCube(textureSampler,vec3(uv.y,1.001,uv.x));
#endif
#ifdef NEGATIVEY
gl_FragColor=textureCube(textureSampler,vec3(uv.y,-1.001,uv.x));
#endif
#ifdef POSITIVEZ
gl_FragColor=textureCube(textureSampler,vec3(uv,1.001));
#endif
#ifdef NEGATIVEZ
gl_FragColor=textureCube(textureSampler,vec3(uv,-1.001));
#endif
}`;r.ShadersStore[e]||(r.ShadersStore[e]=t);const n={name:e,shader:t};export{n as passCubePixelShader};
//# sourceMappingURL=passCube.fragment-_8imUZNE.js.map
