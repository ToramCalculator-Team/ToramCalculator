import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import http, { Server as Server$1 } from 'node:http';
import https, { Server } from 'node:https';
import { EventEmitter } from 'node:events';
import { Buffer as Buffer$1 } from 'node:buffer';
import { promises, existsSync } from 'node:fs';
import { resolve as resolve$1, dirname as dirname$1, join } from 'node:path';
import { createHash } from 'node:crypto';
import { AsyncLocalStorage } from 'node:async_hooks';
import invariant from 'vinxi/lib/invariant';
import { virtualId, handlerModule, join as join$1 } from 'vinxi/lib/path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { sharedConfig, lazy, createComponent, catchError, onCleanup } from 'solid-js';
import { renderToString, ssrElement, escape, mergeProps, ssr, getRequestEvent, isServer, createComponent as createComponent$1, ssrHydrationKey, NoHydration, ssrAttribute } from 'solid-js/web';
import { provideRequestEvent } from 'solid-js/web/storage';

const suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  if (value[0] === '"' && value[value.length - 1] === '"' && value.indexOf("\\") === -1) {
    return value.slice(1, -1);
  }
  const _value = value.trim();
  if (_value.length <= 9) {
    switch (_value.toLowerCase()) {
      case "true": {
        return true;
      }
      case "false": {
        return false;
      }
      case "undefined": {
        return void 0;
      }
      case "null": {
        return null;
      }
      case "nan": {
        return Number.NaN;
      }
      case "infinity": {
        return Number.POSITIVE_INFINITY;
      }
      case "-infinity": {
        return Number.NEGATIVE_INFINITY;
      }
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error) {
    if (options.strict) {
      throw error;
    }
    return value;
  }
}

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function decode$1(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode$1(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = /* @__PURE__ */ Object.create(null);
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map(
      (_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`
    ).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}

const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return input.endsWith("/");
  }
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return input.endsWith("/") ? input : input + "/";
  }
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    return input;
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const trimmed = input.slice(_base.length);
  return trimmed[0] === "/" ? trimmed : "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}

const protocolRelative = Symbol.for("ufo:protocolRelative");
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

function parse(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = {};
  const opt = {};
  const dec = opt.decode || decode;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (opt?.filter && !opt?.filter(key)) {
      index = endIdx + 1;
      continue;
    }
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function decode(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function tryDecode(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}

const fieldContentRegExp = /^[\u0009\u0020-\u007E\u0080-\u00FF]+$/;
function serialize$1(name, value, options) {
  const opt = options || {};
  const enc = opt.encode || encodeURIComponent;
  if (typeof enc !== "function") {
    throw new TypeError("option encode is invalid");
  }
  if (!fieldContentRegExp.test(name)) {
    throw new TypeError("argument name is invalid");
  }
  const encodedValue = enc(value);
  if (encodedValue && !fieldContentRegExp.test(encodedValue)) {
    throw new TypeError("argument val is invalid");
  }
  let str = name + "=" + encodedValue;
  if (void 0 !== opt.maxAge && opt.maxAge !== null) {
    const maxAge = opt.maxAge - 0;
    if (Number.isNaN(maxAge) || !Number.isFinite(maxAge)) {
      throw new TypeError("option maxAge is invalid");
    }
    str += "; Max-Age=" + Math.floor(maxAge);
  }
  if (opt.domain) {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new TypeError("option domain is invalid");
    }
    str += "; Domain=" + opt.domain;
  }
  if (opt.path) {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new TypeError("option path is invalid");
    }
    str += "; Path=" + opt.path;
  }
  if (opt.expires) {
    if (!isDate(opt.expires) || Number.isNaN(opt.expires.valueOf())) {
      throw new TypeError("option expires is invalid");
    }
    str += "; Expires=" + opt.expires.toUTCString();
  }
  if (opt.httpOnly) {
    str += "; HttpOnly";
  }
  if (opt.secure) {
    str += "; Secure";
  }
  if (opt.priority) {
    const priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
    switch (priority) {
      case "low": {
        str += "; Priority=Low";
        break;
      }
      case "medium": {
        str += "; Priority=Medium";
        break;
      }
      case "high": {
        str += "; Priority=High";
        break;
      }
      default: {
        throw new TypeError("option priority is invalid");
      }
    }
  }
  if (opt.sameSite) {
    const sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
    switch (sameSite) {
      case true: {
        str += "; SameSite=Strict";
        break;
      }
      case "lax": {
        str += "; SameSite=Lax";
        break;
      }
      case "strict": {
        str += "; SameSite=Strict";
        break;
      }
      case "none": {
        str += "; SameSite=None";
        break;
      }
      default: {
        throw new TypeError("option sameSite is invalid");
      }
    }
  }
  if (opt.partitioned) {
    str += "; Partitioned";
  }
  return str;
}
function isDate(val) {
  return Object.prototype.toString.call(val) === "[object Date]" || val instanceof Date;
}

function parseSetCookie(setCookieValue, options) {
  const parts = (setCookieValue || "").split(";").filter((str) => typeof str === "string" && !!str.trim());
  const nameValuePairStr = parts.shift() || "";
  const parsed = _parseNameValuePair(nameValuePairStr);
  const name = parsed.name;
  let value = parsed.value;
  try {
    value = options?.decode === false ? value : (options?.decode || decodeURIComponent)(value);
  } catch {
  }
  const cookie = {
    name,
    value
  };
  for (const part of parts) {
    const sides = part.split("=");
    const partKey = (sides.shift() || "").trimStart().toLowerCase();
    const partValue = sides.join("=");
    switch (partKey) {
      case "expires": {
        cookie.expires = new Date(partValue);
        break;
      }
      case "max-age": {
        cookie.maxAge = Number.parseInt(partValue, 10);
        break;
      }
      case "secure": {
        cookie.secure = true;
        break;
      }
      case "httponly": {
        cookie.httpOnly = true;
        break;
      }
      case "samesite": {
        cookie.sameSite = partValue;
        break;
      }
      default: {
        cookie[partKey] = partValue;
      }
    }
  }
  return cookie;
}
function _parseNameValuePair(nameValuePairStr) {
  let name = "";
  let value = "";
  const nameValueArr = nameValuePairStr.split("=");
  if (nameValueArr.length > 1) {
    name = nameValueArr.shift();
    value = nameValueArr.join("=");
  } else {
    value = nameValuePairStr;
  }
  return { name, value };
}

const NODE_TYPES = {
  NORMAL: 0,
  WILDCARD: 1,
  PLACEHOLDER: 2
};

function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode === void 0) {
      if (node && node.placeholderChildren.length > 1) {
        const remaining = sections.length - i;
        node = node.placeholderChildren.find((c) => c.maxDepth === remaining) || null;
      } else {
        node = node.placeholderChildren[0] || null;
      }
      if (!node) {
        break;
      }
      if (node.paramName) {
        params[node.paramName] = section;
      }
      paramsFound = true;
    } else {
      node = nextNode;
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  const matchedNodes = [node];
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildren.push(childNode);
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      matchedNodes.push(childNode);
      node = childNode;
    }
  }
  for (const [depth, node2] of matchedNodes.entries()) {
    node2.maxDepth = Math.max(matchedNodes.length - depth, node2.maxDepth || 0);
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections.at(-1) || "";
    node.data = null;
    if (Object.keys(node.children).length === 0 && node.parent) {
      node.parent.children.delete(lastSection);
      node.parent.wildcardChildNode = null;
      node.parent.placeholderChildren = [];
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    maxDepth: 0,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildren: []
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}

function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table, router.ctx.options.strictTrailingSlash);
}
function _createMatcher(table, strictTrailingSlash) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table, strictTrailingSlash)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table, strictTrailingSlash) {
  if (strictTrailingSlash !== true && path.endsWith("/")) {
    path = path.slice(0, -1) || "/";
  }
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path === key || path.startsWith(key + "/")) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        if (node.data) {
          table.static.set(path, node.data);
        }
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}

function isPlainObject(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) {
    return false;
  }
  if (Symbol.iterator in value) {
    return false;
  }
  if (Symbol.toStringTag in value) {
    return Object.prototype.toString.call(value) === "[object Module]";
  }
  return true;
}

function _defu(baseObject, defaults, namespace = ".", merger) {
  if (!isPlainObject(defaults)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = Object.assign({}, defaults);
  for (const key in baseObject) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (isPlainObject(value) && isPlainObject(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {})
  );
}
const defu = createDefu();
const defuFn = createDefu((object, key, currentValue) => {
  if (object[key] !== void 0 && typeof currentValue === "function") {
    object[key] = currentValue(object[key]);
    return true;
  }
});

function o(n){throw new Error(`${n} is not implemented yet!`)}let i$1 = class i extends EventEmitter{__unenv__={};readableEncoding=null;readableEnded=true;readableFlowing=false;readableHighWaterMark=0;readableLength=0;readableObjectMode=false;readableAborted=false;readableDidRead=false;closed=false;errored=null;readable=false;destroyed=false;static from(e,t){return new i(t)}constructor(e){super();}_read(e){}read(e){}setEncoding(e){return this}pause(){return this}resume(){return this}isPaused(){return  true}unpipe(e){return this}unshift(e,t){}wrap(e){return this}push(e,t){return  false}_destroy(e,t){this.removeAllListeners();}destroy(e){return this.destroyed=true,this._destroy(e),this}pipe(e,t){return {}}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return this.destroy(),Promise.resolve()}async*[Symbol.asyncIterator](){throw o("Readable.asyncIterator")}iterator(e){throw o("Readable.iterator")}map(e,t){throw o("Readable.map")}filter(e,t){throw o("Readable.filter")}forEach(e,t){throw o("Readable.forEach")}reduce(e,t,r){throw o("Readable.reduce")}find(e,t){throw o("Readable.find")}findIndex(e,t){throw o("Readable.findIndex")}some(e,t){throw o("Readable.some")}toArray(e){throw o("Readable.toArray")}every(e,t){throw o("Readable.every")}flatMap(e,t){throw o("Readable.flatMap")}drop(e,t){throw o("Readable.drop")}take(e,t){throw o("Readable.take")}asIndexedPairs(e){throw o("Readable.asIndexedPairs")}};let l$1 = class l extends EventEmitter{__unenv__={};writable=true;writableEnded=false;writableFinished=false;writableHighWaterMark=0;writableLength=0;writableObjectMode=false;writableCorked=0;closed=false;errored=null;writableNeedDrain=false;destroyed=false;_data;_encoding="utf8";constructor(e){super();}pipe(e,t){return {}}_write(e,t,r){if(this.writableEnded){r&&r();return}if(this._data===void 0)this._data=e;else {const s=typeof this._data=="string"?Buffer$1.from(this._data,this._encoding||t||"utf8"):this._data,a=typeof e=="string"?Buffer$1.from(e,t||this._encoding||"utf8"):e;this._data=Buffer$1.concat([s,a]);}this._encoding=t,r&&r();}_writev(e,t){}_destroy(e,t){}_final(e){}write(e,t,r){const s=typeof t=="string"?this._encoding:"utf8",a=typeof t=="function"?t:typeof r=="function"?r:void 0;return this._write(e,s,a),true}setDefaultEncoding(e){return this}end(e,t,r){const s=typeof e=="function"?e:typeof t=="function"?t:typeof r=="function"?r:void 0;if(this.writableEnded)return s&&s(),this;const a=e===s?void 0:e;if(a){const u=t===s?void 0:t;this.write(a,u,s);}return this.writableEnded=true,this.writableFinished=true,this.emit("close"),this.emit("finish"),this}cork(){}uncork(){}destroy(e){return this.destroyed=true,delete this._data,this.removeAllListeners(),this}compose(e,t){throw new Error("Method not implemented.")}};const c=class{allowHalfOpen=true;_destroy;constructor(e=new i$1,t=new l$1){Object.assign(this,e),Object.assign(this,t),this._destroy=g$2(e._destroy,t._destroy);}};function _(){return Object.assign(c.prototype,i$1.prototype),Object.assign(c.prototype,l$1.prototype),c}function g$2(...n){return function(...e){for(const t of n)t(...e);}}const m=_();class A extends m{__unenv__={};bufferSize=0;bytesRead=0;bytesWritten=0;connecting=false;destroyed=false;pending=false;localAddress="";localPort=0;remoteAddress="";remoteFamily="";remotePort=0;autoSelectFamilyAttemptedAddresses=[];readyState="readOnly";constructor(e){super();}write(e,t,r){return  false}connect(e,t,r){return this}end(e,t,r){return this}setEncoding(e){return this}pause(){return this}resume(){return this}setTimeout(e,t){return this}setNoDelay(e){return this}setKeepAlive(e,t){return this}address(){return {}}unref(){return this}ref(){return this}destroySoon(){this.destroy();}resetAndDestroy(){const e=new Error("ERR_SOCKET_CLOSED");return e.code="ERR_SOCKET_CLOSED",this.destroy(e),this}}let y$2 = class y extends i$1{aborted=false;httpVersion="1.1";httpVersionMajor=1;httpVersionMinor=1;complete=true;connection;socket;headers={};trailers={};method="GET";url="/";statusCode=200;statusMessage="";closed=false;errored=null;readable=false;constructor(e){super(),this.socket=this.connection=e||new A;}get rawHeaders(){const e=this.headers,t=[];for(const r in e)if(Array.isArray(e[r]))for(const s of e[r])t.push(r,s);else t.push(r,e[r]);return t}get rawTrailers(){return []}setTimeout(e,t){return this}get headersDistinct(){return p$2(this.headers)}get trailersDistinct(){return p$2(this.trailers)}};function p$2(n){const e={};for(const[t,r]of Object.entries(n))t&&(e[t]=(Array.isArray(r)?r:[r]).filter(Boolean));return e}class w extends l$1{statusCode=200;statusMessage="";upgrading=false;chunkedEncoding=false;shouldKeepAlive=false;useChunkedEncodingByDefault=false;sendDate=false;finished=false;headersSent=false;strictContentLength=false;connection=null;socket=null;req;_headers={};constructor(e){super(),this.req=e;}assignSocket(e){e._httpMessage=this,this.socket=e,this.connection=e,this.emit("socket",e),this._flush();}_flush(){this.flushHeaders();}detachSocket(e){}writeContinue(e){}writeHead(e,t,r){e&&(this.statusCode=e),typeof t=="string"&&(this.statusMessage=t,t=void 0);const s=r||t;if(s&&!Array.isArray(s))for(const a in s)this.setHeader(a,s[a]);return this.headersSent=true,this}writeProcessing(){}setTimeout(e,t){return this}appendHeader(e,t){e=e.toLowerCase();const r=this._headers[e],s=[...Array.isArray(r)?r:[r],...Array.isArray(t)?t:[t]].filter(Boolean);return this._headers[e]=s.length>1?s:s[0],this}setHeader(e,t){return this._headers[e.toLowerCase()]=t,this}setHeaders(e){for(const[t,r]of Object.entries(e))this.setHeader(t,r);return this}getHeader(e){return this._headers[e.toLowerCase()]}getHeaders(){return this._headers}getHeaderNames(){return Object.keys(this._headers)}hasHeader(e){return e.toLowerCase()in this._headers}removeHeader(e){delete this._headers[e.toLowerCase()];}addTrailers(e){}flushHeaders(){}writeEarlyHints(e,t){typeof t=="function"&&t();}}const E=(()=>{const n=function(){};return n.prototype=Object.create(null),n})();function R(n={}){const e=new E,t=Array.isArray(n)||H(n)?n:Object.entries(n);for(const[r,s]of t)if(s){if(e[r]===void 0){e[r]=s;continue}e[r]=[...Array.isArray(e[r])?e[r]:[e[r]],...Array.isArray(s)?s:[s]];}return e}function H(n){return typeof n?.entries=="function"}function S(n={}){if(n instanceof Headers)return n;const e=new Headers;for(const[t,r]of Object.entries(n))if(r!==void 0){if(Array.isArray(r)){for(const s of r)e.append(t,String(s));continue}e.set(t,String(r));}return e}const C=new Set([101,204,205,304]);async function b(n,e){const t=new y$2,r=new w(t);t.url=e.url?.toString()||"/";let s;if(!t.url.startsWith("/")){const d=new URL(t.url);s=d.host,t.url=d.pathname+d.search+d.hash;}t.method=e.method||"GET",t.headers=R(e.headers||{}),t.headers.host||(t.headers.host=e.host||s||"localhost"),t.connection.encrypted=t.connection.encrypted||e.protocol==="https",t.body=e.body||null,t.__unenv__=e.context,await n(t,r);let a=r._data;(C.has(r.statusCode)||t.method.toUpperCase()==="HEAD")&&(a=null,delete r._headers["content-length"]);const u={status:r.statusCode,statusText:r.statusMessage,headers:r._headers,body:a};return t.destroy(),r.destroy(),u}async function O$2(n,e,t={}){try{const r=await b(n,{url:e,...t});return new Response(r.body,{status:r.status,statusText:r.statusText,headers:S(r.headers)})}catch(r){return new Response(r.toString(),{status:Number.parseInt(r.statusCode||r.code)||500,statusText:r.statusText})}}

function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

class H3Error extends Error {
  static __h3_error__ = true;
  statusCode = 500;
  fatal = false;
  unhandled = false;
  statusMessage;
  data;
  cause;
  constructor(message, opts = {}) {
    super(message, opts);
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
    }
    if (this.data !== undefined) {
      obj.data = this.data;
    }
    return obj;
  }
}
function createError$1(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== undefined) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== undefined) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError(error) ? error : createError$1(error);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l) => l.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES.json);
  event.node.res.end(JSON.stringify(responseBody, undefined, 2));
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}
function isMethod(event, expected, allowHead) {
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected)) {
    throw createError$1({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const xForwardedHost = event.node.req.headers["x-forwarded-host"];
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function getRequestURL(event, opts = {}) {
  const host = getRequestHost(event, opts);
  const protocol = getRequestProtocol(event, opts);
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  return new URL(path, `${protocol}://${host}`);
}
function getRequestIP(event, opts = {}) {
  if (event.context.clientAddress) {
    return event.context.clientAddress;
  }
  if (opts.xForwardedFor) {
    const xForwardedFor = getRequestHeader(event, "x-forwarded-for")?.split(",").shift()?.trim();
    if (xForwardedFor) {
      return xForwardedFor;
    }
  }
  if (event.node.req.socket.remoteAddress) {
    return event.node.req.socket.remoteAddress;
  }
}

const RawBodySymbol = Symbol.for("h3RawBody");
const PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.rawBody || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      if (_resolved instanceof URLSearchParams) {
        return Buffer.from(_resolved.toString());
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "") && !String(event.node.req.headers["transfer-encoding"] ?? "").split(",").map((e) => e.trim()).filter(Boolean).includes("chunked")) {
    return Promise.resolve(undefined);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  const bodyStream = event.web?.request?.body || event._requestBody;
  if (bodyStream) {
    return bodyStream;
  }
  const _hasRawBody = RawBodySymbol in event.node.req || "rawBody" in event.node.req || "body" in event.node.req || "__unenv__" in event.node.req;
  if (_hasRawBody) {
    return new ReadableStream({
      async start(controller) {
        const _rawBody = await readRawBody(event, false);
        if (_rawBody) {
          controller.enqueue(_rawBody);
        }
        controller.close();
      }
    });
  }
  return new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}

function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== undefined) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= opts.modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}

const MIMES = {
  html: "text/html",
  json: "application/json"
};

const DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}

function getDistinctCookieKey(name, opts) {
  return [
    name,
    opts.domain || "",
    opts.path || "/",
    Boolean(opts.secure),
    Boolean(opts.httpOnly),
    Boolean(opts.sameSite)
  ].join(";");
}

function parseCookies(event) {
  return parse(event.node.req.headers.cookie || "");
}
function getCookie(event, name) {
  return parseCookies(event)[name];
}
function setCookie(event, name, value, serializeOptions = {}) {
  if (!serializeOptions.path) {
    serializeOptions = { path: "/", ...serializeOptions };
  }
  const newCookie = serialize$1(name, value, serializeOptions);
  const currentCookies = splitCookiesString(
    event.node.res.getHeader("set-cookie")
  );
  if (currentCookies.length === 0) {
    event.node.res.setHeader("set-cookie", newCookie);
    return;
  }
  const newCookieKey = getDistinctCookieKey(name, serializeOptions);
  event.node.res.removeHeader("set-cookie");
  for (const cookie of currentCookies) {
    const parsed = parseSetCookie(cookie);
    const key = getDistinctCookieKey(parsed.name, parsed);
    if (key === newCookieKey) {
      continue;
    }
    event.node.res.appendHeader("set-cookie", cookie);
  }
  event.node.res.appendHeader("set-cookie", newCookie);
}
function deleteCookie(event, name, serializeOptions) {
  setCookie(event, name, "", {
    ...serializeOptions,
    maxAge: 0
  });
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start));
    }
  }
  return cookiesStrings;
}

const defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage(text);
  }
}
function getResponseStatus(event) {
  return event.node.res.statusCode;
}
function getResponseStatusText(event) {
  return event.node.res.statusMessage;
}
function defaultContentType(event, type) {
  if (type && event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}
function getResponseHeaders(event) {
  return event.node.res.getHeaders();
}
function getResponseHeader(event, name) {
  return event.node.res.getHeader(name);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(
      name,
      value
    );
  }
}
const setHeaders = setResponseHeaders;
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
const setHeader = setResponseHeader;
function appendResponseHeader(event, name, value) {
  let current = event.node.res.getHeader(name);
  if (!current) {
    event.node.res.setHeader(name, value);
    return;
  }
  if (!Array.isArray(current)) {
    current = [current.toString()];
  }
  event.node.res.setHeader(name, [...current, value]);
}
function removeResponseHeader(event, name) {
  return event.node.res.removeHeader(name);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve();
        });
        stream.on("error", (error) => {
          reject(error);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}

const PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
const ignoredHeaders = /* @__PURE__ */ new Set([
  "transfer-encoding",
  "accept-encoding",
  "connection",
  "keep-alive",
  "upgrade",
  "expect",
  "host",
  "accept"
]);
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => undefined);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders$1(
    getProxyRequestHeaders(event, { host: target.startsWith("/") }),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  let response;
  try {
    response = await _getFetch(opts.fetch)(target, {
      headers: opts.headers,
      ignoreResponseError: true,
      // make $ofetch.raw transparent
      ...opts.fetchOptions
    });
  } catch (error) {
    throw createError$1({
      status: 502,
      statusMessage: "Bad Gateway",
      cause: error
    });
  }
  event.node.res.statusCode = sanitizeStatusCode(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== undefined) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event, opts) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name) || name === "host" && opts?.host) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event, {
        host: typeof req === "string" && req.startsWith("/")
      }),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders$1(defaults, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults;
  }
  const merged = new Headers(defaults);
  for (const input of _inputs) {
    for (const [key, value] of Object.entries(input)) {
      if (value !== undefined) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}

class H3Event {
  "__is_event__" = true;
  // Context
  node;
  // Node
  web;
  // Web
  context = {};
  // Shared
  // Request
  _method;
  _path;
  _headers;
  _requestBody;
  // Response
  _handled = false;
  // Hooks
  _onBeforeResponseCalled;
  _onAfterResponseCalled;
  constructor(req, res) {
    this.node = { req, res };
  }
  // --- Request ---
  get method() {
    if (!this._method) {
      this._method = (this.node.req.method || "GET").toUpperCase();
    }
    return this._method;
  }
  get path() {
    return this._path || this.node.req.url || "/";
  }
  get headers() {
    if (!this._headers) {
      this._headers = _normalizeNodeHeaders(this.node.req.headers);
    }
    return this._headers;
  }
  // --- Respoonse ---
  get handled() {
    return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
  }
  respondWith(response) {
    return Promise.resolve(response).then(
      (_response) => sendWebResponse(this, _response)
    );
  }
  // --- Utils ---
  toString() {
    return `[${this.method}] ${this.path}`;
  }
  toJSON() {
    return this.toString();
  }
  // --- Deprecated ---
  /** @deprecated Please use `event.node.req` instead. */
  get req() {
    return this.node.req;
  }
  /** @deprecated Please use `event.node.res` instead. */
  get res() {
    return this.node.res;
  }
}
function isEvent(input) {
  return hasProp(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}

function defineEventHandler(handler) {
  if (typeof handler === "function") {
    handler.__is_handler__ = true;
    return handler;
  }
  const _hooks = {
    onRequest: _normalizeArray(handler.onRequest),
    onBeforeResponse: _normalizeArray(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler.handler, _hooks);
  };
  _handler.__is_handler__ = true;
  _handler.__resolve__ = handler.handler.__resolve__;
  _handler.__websocket__ = handler.websocket;
  return _handler;
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : undefined;
}
async function _callHandler(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler = defineEventHandler;
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  if (!isEventHandler(input)) {
    console.warn(
      "[h3] Implicit event handler conversion is deprecated. Use `eventHandler()` or `fromNodeMiddleware()` to define event handlers.",
      _route && _route !== "/" ? `
     Route: ${_route}` : "",
      `
     Handler: ${input}`
    );
  }
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler2 = r.default || r;
        if (typeof handler2 !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler2
          );
        }
        _resolved = { handler: toEventHandler(r.default || r) };
        return _resolved;
      });
    }
    return _promise;
  };
  const handler = eventHandler((event) => {
    if (_resolved) {
      return _resolved.handler(event);
    }
    return resolveHandler().then((r) => r.handler(event));
  });
  handler.__resolve__ = resolveHandler;
  return handler;
}
const lazyEventHandler = defineLazyEventHandler;

function createApp(options = {}) {
  const stack = [];
  const handler = createAppEventHandler(stack, options);
  const resolve = createResolver(stack);
  handler.__resolve__ = resolve;
  const getWebsocket = cachedFn(() => websocketOptions(resolve, options));
  const app = {
    // @ts-expect-error
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    resolve,
    handler,
    stack,
    options,
    get websocket() {
      return getWebsocket();
    }
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i of arg1) {
      use(app, i, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i of arg2) {
      use(app, arg1, i, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(normalizeLayer({ ...arg2, handler: arg1 }));
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : undefined;
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _reqPath = event._path || event.node.req.url || "/";
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _layerPath;
      const val = await layer.handler(event);
      const _body = val === undefined ? undefined : await val;
      if (_body !== undefined) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          event._onBeforeResponseCalled = true;
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, undefined);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$1({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      event._onAfterResponseCalled = true;
      await options.onAfterResponse(event, undefined);
    }
  });
}
function createResolver(stack) {
  return async (path) => {
    let _layerPath;
    for (const layer of stack) {
      if (layer.route === "/" && !layer.handler.__resolve__) {
        continue;
      }
      if (!path.startsWith(layer.route)) {
        continue;
      }
      _layerPath = path.slice(layer.route.length) || "/";
      if (layer.match && !layer.match(_layerPath, undefined)) {
        continue;
      }
      let res = { route: layer.route, handler: layer.handler };
      if (res.handler.__resolve__) {
        const _res = await res.handler.__resolve__(_layerPath);
        if (!_res) {
          continue;
        }
        res = {
          ...res,
          ..._res,
          route: joinURL(res.route || "/", _res.route || "/")
        };
      }
      return res;
    }
  };
}
function normalizeLayer(input) {
  let handler = input.handler;
  if (handler.handler) {
    handler = handler.handler;
  }
  if (input.lazy) {
    handler = lazyEventHandler(handler);
  } else if (!isEventHandler(handler)) {
    handler = toEventHandler(handler, undefined, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$1(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send(event, val, MIMES.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send(event, JSON.stringify(val, undefined, jsonSpace), MIMES.json);
  }
  if (valType === "bigint") {
    return send(event, val.toString(), MIMES.json);
  }
  throw createError$1({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}
function cachedFn(fn) {
  let cache;
  return () => {
    if (!cache) {
      cache = fn();
    }
    return cache;
  };
}
function websocketOptions(evResolver, appOptions) {
  return {
    ...appOptions.websocket,
    async resolve(info) {
      const url = info.request?.url || info.url || "/";
      const { pathname } = typeof url === "string" ? parseURL(url) : url;
      const resolved = await evResolver(pathname);
      return resolved?.handler?.__websocket__ || {};
    }
  };
}

const RouterMethods = [
  "connect",
  "delete",
  "get",
  "head",
  "options",
  "post",
  "put",
  "trace",
  "patch"
];
function createRouter(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler, m);
      }
    } else {
      route.handlers[method] = toEventHandler(handler, undefined, path);
    }
    return router;
  };
  router.use = router.add = (path, handler, method) => addRoute(path, handler, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  const matchHandler = (path = "/", method = "get") => {
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      return {
        error: createError$1({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${path || "/"}.`
        })
      };
    }
    let handler = matched.handlers[method] || matched.handlers.all;
    if (!handler) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler;
          break;
        }
        if (_match.handlers.all) {
          handler = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler;
          break;
        }
      }
    }
    if (!handler) {
      return {
        error: createError$1({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        })
      };
    }
    return { matched, handler };
  };
  const isPreemptive = opts.preemptive || opts.preemtive;
  router.handler = eventHandler((event) => {
    const match = matchHandler(
      event.path,
      event.method.toLowerCase()
    );
    if ("error" in match) {
      if (isPreemptive) {
        throw match.error;
      } else {
        return;
      }
    }
    event.context.matchedRoute = match.matched;
    const params = match.matched.params || {};
    event.context.params = params;
    return Promise.resolve(match.handler(event)).then((res) => {
      if (res === undefined && isPreemptive) {
        return null;
      }
      return res;
    });
  });
  router.handler.__resolve__ = async (path) => {
    path = withLeadingSlash(path);
    const match = matchHandler(path);
    if ("error" in match) {
      return;
    }
    let res = {
      route: match.matched.path,
      handler: match.handler
    };
    if (match.handler.__resolve__) {
      const _res = await match.handler.__resolve__(path);
      if (!_res) {
        return;
      }
      res = { ...res, ..._res };
    }
    return res;
  };
  return router;
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error = createError$1(_error);
      if (!isError(_error)) {
        error.unhandled = true;
      }
      setResponseStatus(event, error.statusCode, error.statusMessage);
      if (app.options.onError) {
        await app.options.onError(error, event);
      }
      if (event.handled) {
        return;
      }
      if (error.unhandled || error.fatal) {
        console.error("[h3]", error.fatal ? "[fatal]" : "[unhandled]", error);
      }
      if (app.options.onBeforeResponse && !event._onBeforeResponseCalled) {
        await app.options.onBeforeResponse(event, { body: error });
      }
      await sendError(event, error, !!app.options.debug);
      if (app.options.onAfterResponse && !event._onAfterResponseCalled) {
        await app.options.onAfterResponse(event, { body: error });
      }
    }
  };
  return toNodeHandle;
}

function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
const defaultTask = { run: (function_) => function_() };
const _createTask = () => defaultTask;
const createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = void 0;
    this._after = void 0;
    this._deprecatedMessages = void 0;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set();
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = void 0;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = void 0;
      _function = void 0;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map(
      (key) => this.hook(key, hooks[key])
    );
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(
      name in this._hooks ? [...this._hooks[name]] : [],
      arguments_
    );
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== void 0) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== void 0) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}
function createHooks() {
  return new Hookable();
}

const s$3=globalThis.Headers,i=globalThis.AbortController,l=globalThis.fetch||(()=>{throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!")});

class FetchError extends Error {
  constructor(message, opts) {
    super(message, opts);
    this.name = "FetchError";
    if (opts?.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}

const payloadMethods = new Set(
  Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
);
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function resolveFetchOptions(request, input, defaults, Headers) {
  const headers = mergeHeaders(
    input?.headers ?? request?.headers,
    defaults?.headers,
    Headers
  );
  let query;
  if (defaults?.query || defaults?.params || input?.params || input?.query) {
    query = {
      ...defaults?.params,
      ...defaults?.query,
      ...input?.params,
      ...input?.query
    };
  }
  return {
    ...defaults,
    ...input,
    query,
    params: query,
    headers
  };
}
function mergeHeaders(input, defaults, Headers) {
  if (!defaults) {
    return new Headers(input);
  }
  const headers = new Headers(defaults);
  if (input) {
    for (const [key, value] of Symbol.iterator in input || Array.isArray(input) ? input : new Headers(input)) {
      headers.set(key, value);
    }
  }
  return headers;
}
async function callHooks(context, hooks) {
  if (hooks) {
    if (Array.isArray(hooks)) {
      for (const hook of hooks) {
        await hook(context);
      }
    } else {
      await hooks(context);
    }
  }
}

const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  // Request Timeout
  409,
  // Conflict
  425,
  // Too Early (Experimental)
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  // Gateway Timeout
]);
const nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createFetch(globalOptions = {}) {
  const {
    fetch = globalThis.fetch,
    Headers = globalThis.Headers,
    AbortController = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = typeof context.options.retryDelay === "function" ? context.options.retryDelay(context) : context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1
        });
      }
    }
    const error = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error, $fetchRaw);
    }
    throw error;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: resolveFetchOptions(
        _request,
        _options,
        globalOptions.defaults,
        Headers
      ),
      response: void 0,
      error: void 0
    };
    if (context.options.method) {
      context.options.method = context.options.method.toUpperCase();
    }
    if (context.options.onRequest) {
      await callHooks(context, context.options.onRequest);
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query) {
        context.request = withQuery(context.request, context.options.query);
        delete context.options.query;
      }
      if ("query" in context.options) {
        delete context.options.query;
      }
      if ("params" in context.options) {
        delete context.options.params;
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        context.options.body = typeof context.options.body === "string" ? context.options.body : JSON.stringify(context.options.body);
        context.options.headers = new Headers(context.options.headers || {});
        if (!context.options.headers.has("content-type")) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    let abortTimeout;
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController();
      abortTimeout = setTimeout(() => {
        const error = new Error(
          "[TimeoutError]: The operation was aborted due to timeout"
        );
        error.name = "TimeoutError";
        error.code = 23;
        controller.abort(error);
      }, context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch(
        context.request,
        context.options
      );
    } catch (error) {
      context.error = error;
      if (context.options.onRequestError) {
        await callHooks(
          context,
          context.options.onRequestError
        );
      }
      return await onError(context);
    } finally {
      if (abortTimeout) {
        clearTimeout(abortTimeout);
      }
    }
    const hasBody = (context.response.body || // https://github.com/unjs/ofetch/issues/324
    // https://github.com/unjs/ofetch/issues/294
    // https://github.com/JakeChampion/fetch/issues/1454
    context.response._bodyInit) && !nullBodyResponses.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body || context.response._bodyInit;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await callHooks(
        context,
        context.options.onResponse
      );
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await callHooks(
          context,
          context.options.onResponseError
        );
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch = async function $fetch2(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch.raw = $fetchRaw;
  $fetch.native = (...args) => fetch(...args);
  $fetch.create = (defaultOptions = {}, customGlobalOptions = {}) => createFetch({
    ...globalOptions,
    ...customGlobalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...customGlobalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch;
}

function createNodeFetch() {
  const useKeepAlive = JSON.parse(process.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
const fetch = globalThis.fetch ? (...args) => globalThis.fetch(...args) : createNodeFetch();
const Headers$1 = globalThis.Headers || s$3;
const AbortController$1 = globalThis.AbortController || i;
createFetch({ fetch, Headers: Headers$1, AbortController: AbortController$1 });

function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error) {
    return Promise.reject(error);
  }
}
function isPrimitive(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify(value) {
  if (isPrimitive(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
const BASE64_PREFIX = "base64:";
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  return BASE64_PREFIX + base64Encode(value);
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  return base64Decode(value.slice(BASE64_PREFIX.length));
}
function base64Decode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input, "base64");
  }
  return Uint8Array.from(
    globalThis.atob(input),
    (c) => c.codePointAt(0)
  );
}
function base64Encode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input).toString("base64");
  }
  return globalThis.btoa(String.fromCodePoint(...input));
}

const storageKeyProperties = [
  "has",
  "hasItem",
  "get",
  "getItem",
  "getItemRaw",
  "set",
  "setItem",
  "setItemRaw",
  "del",
  "remove",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
function prefixStorage(storage, base) {
  base = normalizeBaseKey(base);
  if (!base) {
    return storage;
  }
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  return nsStorage;
}
function normalizeKey$1(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
}
function joinKeys(...keys) {
  return normalizeKey$1(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$1(base);
  return base ? base + ":" : "";
}
function filterKeyByDepth(key, depth) {
  if (depth === void 0) {
    return true;
  }
  let substrCount = 0;
  let index = key.indexOf(":");
  while (index > -1) {
    substrCount++;
    index = key.indexOf(":", index + 1);
  }
  return substrCount <= depth;
}
function filterKeyByBase(key, base) {
  if (base) {
    return key.startsWith(base) && key[key.length - 1] !== "$";
  }
  return key[key.length - 1] !== "$";
}

function defineDriver$1(factory) {
  return factory;
}

const DRIVER_NAME$1 = "memory";
const memory = defineDriver$1(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$1,
    getInstance: () => data,
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return [...data.keys()];
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$1(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeKey$1(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage = {
    // Item
    hasItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    getItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    getItems(items, commonOptions = {}) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    getItemRaw(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          return asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key, opts);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    setMeta(key, value, opts = {}) {
      return this.setItem(key + "$", value, opts);
    },
    removeMeta(key, opts = {}) {
      return this.removeItem(key + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBaseKey(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      let allMountsSupportMaxDepth = true;
      for (const mount of mounts) {
        if (!mount.driver.flags?.maxDepth) {
          allMountsSupportMaxDepth = false;
        }
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        for (const key of rawKeys) {
          const fullKey = mount.mountpoint + normalizeKey$1(key);
          if (!maskedMounts.some((p) => fullKey.startsWith(p))) {
            allKeys.push(fullKey);
          }
        }
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      const shouldFilterByDepth = opts.maxDepth !== void 0 && !allMountsSupportMaxDepth;
      return allKeys.filter(
        (key) => (!shouldFilterByDepth || filterKeyByDepth(key, opts.maxDepth)) && filterKeyByBase(key, base)
      );
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBaseKey(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBaseKey(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]?.();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$1(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$1(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    },
    // Aliases
    keys: (base, opts = {}) => storage.getKeys(base, opts),
    get: (key, opts = {}) => storage.getItem(key, opts),
    set: (key, value, opts = {}) => storage.setItem(key, value, opts),
    has: (key, opts = {}) => storage.hasItem(key, opts),
    del: (key, opts = {}) => storage.removeItem(key, opts),
    remove: (key, opts = {}) => storage.removeItem(key, opts)
  };
  return storage;
}
function watch(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}

const _assets = {

};

const normalizeKey = function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
};

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

function defineDriver(factory) {
  return factory;
}
function createError(driver, message, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message}`, opts);
  if (Error.captureStackTrace) {
    Error.captureStackTrace(err, createError);
  }
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError(driver, `Missing required option \`${name}\`.`);
}

function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname$1(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname$1(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore, maxDepth) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        if (maxDepth === void 0 || maxDepth > 0) {
          const dirFiles = await readdirRecursive(
            entryPath,
            ignore,
            maxDepth === void 0 ? void 0 : maxDepth - 1
          );
          files.push(...dirFiles.map((f) => entry.name + "/" + f));
        }
      } else {
        if (!(ignore && ignore(entry.name))) {
          files.push(entry.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}

const PATH_TRAVERSE_RE = /\.\.:|\.\.$/;
const DRIVER_NAME = "fs-lite";
const unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
  if (!opts.base) {
    throw createRequiredError(DRIVER_NAME, "base");
  }
  opts.base = resolve$1(opts.base);
  const r = (key) => {
    if (PATH_TRAVERSE_RE.test(key)) {
      throw createError(
        DRIVER_NAME,
        `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
      );
    }
    const resolved = join(opts.base, key.replace(/:/g, "/"));
    return resolved;
  };
  return {
    name: DRIVER_NAME,
    options: opts,
    flags: {
      maxDepth: true
    },
    hasItem(key) {
      return existsSync(r(key));
    },
    getItem(key) {
      return readFile(r(key), "utf8");
    },
    getItemRaw(key) {
      return readFile(r(key));
    },
    async getMeta(key) {
      const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
      return { atime, mtime, size, birthtime, ctime };
    },
    setItem(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value, "utf8");
    },
    setItemRaw(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value);
    },
    removeItem(key) {
      if (opts.readOnly) {
        return;
      }
      return unlink(r(key));
    },
    getKeys(_base, topts) {
      return readdirRecursive(r("."), opts.ignore, topts?.maxDepth);
    },
    async clear() {
      if (opts.readOnly || opts.noClear) {
        return;
      }
      await rmRecursive(r("."));
    }
  };
});

const storage = createStorage({});

storage.mount('/assets', assets$1);

storage.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"./.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

const e=globalThis.process?.getBuiltinModule?.("crypto")?.hash,r="sha256",s$2="base64url";function digest(t){if(e)return e(r,t,s$2);const o=createHash(r).update(t);return globalThis.process?.versions?.webcontainer?o.digest().toString(s$2):o.digest(s$2)}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.waitUntil = incomingEvent.waitUntil;
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Set]') {
		tmp = new Set;
		x.forEach(function (val) {
			tmp.add(klona(val));
		});
		return tmp;
	}

	if (str === '[object Map]') {
		tmp = new Map;
		x.forEach(function (val, key) {
			tmp.set(klona(key), klona(val));
		});
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	if (str === '[object DataView]') {
		return new x.constructor( klona(x.buffer) );
	}

	if (str === '[object ArrayBuffer]') {
		return x.slice(0);
	}

	// ArrayBuffer.isView(x)
	// ~> `new` bcuz `Buffer.slice` => ref
	if (str.slice(-6) === 'Array]') {
		return new x.constructor(x);
	}

	return x;
}

const inlineAppConfig = {};



const appConfig$1 = defuFn(inlineAppConfig);

const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char !== char.toLowerCase();
}
function splitByCase(str, separators) {
  const splitters = STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner) : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/"
  },
  "nitro": {
    "routeRules": {
      "/_build/assets/**": {
        "headers": {
          "cache-control": "public, immutable, max-age=31536000"
        }
      }
    }
  }
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  {
    return _sharedRuntimeConfig;
  }
}
_deepFreeze(klona(appConfig$1));
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

function createContext(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext({ ...defaultOpts, ...opts });
      }
      return contexts[key];
    }
  };
}
const _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey = "__unctx__";
const defaultNamespace = _globalThis[globalKey] || (_globalThis[globalKey] = createNamespace());
const getContext = (key, opts = {}) => defaultNamespace.get(key, opts);
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis[asyncHandlersKey] || (_globalThis[asyncHandlersKey] = /* @__PURE__ */ new Set());

const nitroAsyncContext = getContext("nitro-app", {
  asyncContext: true,
  AsyncLocalStorage: AsyncLocalStorage 
});

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter$1({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$0 = defineNitroErrorHandler(
  function defaultNitroErrorHandler(error, event) {
    const res = defaultHandler(error, event);
    setResponseHeaders(event, res.headers);
    setResponseStatus(event, res.status, res.statusText);
    return send(event, JSON.stringify(res.body, null, 2));
  }
);
function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    console.error(`[request error] ${tags} [${event.method}] ${url}
`, error);
  }
  const headers = {
    "content-type": "application/json",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'none'; frame-ancestors 'none';"
  };
  setResponseStatus(event, statusCode, statusMessage);
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = {
    error: true,
    url: url.href,
    statusCode,
    statusMessage,
    message: isSensitive ? "Server Error" : error.message,
    data: isSensitive ? void 0 : error.data
  };
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}

const errorHandlers = [errorHandler$0];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

const appConfig = {"name":"vinxi","routers":[{"name":"public","type":"static","base":"/","dir":"./public","root":"/root/code/ToramCalculator","order":0,"outDir":"/root/code/ToramCalculator/.vinxi/build/public"},{"name":"ssr","type":"http","link":{"client":"client"},"handler":"src/entry-server.tsx","extensions":["js","jsx","ts","tsx"],"target":"server","root":"/root/code/ToramCalculator","base":"/","outDir":"/root/code/ToramCalculator/.vinxi/build/ssr","order":1},{"name":"client","type":"client","base":"/_build","handler":"src/entry-client.tsx","extensions":["js","jsx","ts","tsx"],"target":"browser","root":"/root/code/ToramCalculator","outDir":"/root/code/ToramCalculator/.vinxi/build/client","order":2},{"name":"server-fns","type":"http","base":"/_server","handler":"node_modules/.pnpm/@solidjs+start@1.1.3_@types+node@22.14.0_jiti@2.4.2_lightningcss@1.29.2_solid-js@1.9.5_terser_rblim7x45jzx4dvbhi7a2ho3se/node_modules/@solidjs/start/dist/runtime/server-handler.js","target":"server","root":"/root/code/ToramCalculator","outDir":"/root/code/ToramCalculator/.vinxi/build/server-fns","order":3}],"server":{"compressPublicAssets":{"brotli":true},"routeRules":{"/_build/assets/**":{"headers":{"cache-control":"public, immutable, max-age=31536000"}}},"experimental":{"asyncContext":true},"prerender":{}},"root":"/root/code/ToramCalculator"};
				const buildManifest = {"ssr":{"_database-D2B4jluP.js":{"file":"assets/database-D2B4jluP.js","name":"database","dynamicImports":["src/repositories/dialect/dialect.ts","src/initialWorker.ts"]},"_http-BEtiV9uB.js":{"file":"assets/http-BEtiV9uB.js","name":"http"},"_user-BatkDO93.js":{"file":"assets/user-BatkDO93.js","name":"user","imports":["_database-D2B4jluP.js"]},"src/initialWorker.ts":{"file":"assets/initialWorker-Cc4f1geA.js","name":"initialWorker","src":"src/initialWorker.ts","isDynamicEntry":true},"src/repositories/dialect/dialect.ts":{"file":"assets/dialect-D2JFOh1E.js","name":"dialect","src":"src/repositories/dialect/dialect.ts","isDynamicEntry":true},"src/routes/api/auth/[...solidauth].ts?pick=GET":{"file":"_...solidauth_.js","name":"_...solidauth_","src":"src/routes/api/auth/[...solidauth].ts?pick=GET","isEntry":true,"isDynamicEntry":true},"src/routes/api/auth/[...solidauth].ts?pick=POST":{"file":"_...solidauth_2.js","name":"_...solidauth_","src":"src/routes/api/auth/[...solidauth].ts?pick=POST","isEntry":true,"isDynamicEntry":true},"src/routes/api/auth/login.ts?pick=POST":{"file":"login.js","name":"login","src":"src/routes/api/auth/login.ts?pick=POST","isEntry":true,"isDynamicEntry":true,"imports":["_http-BEtiV9uB.js","_user-BatkDO93.js","_database-D2B4jluP.js"]},"src/routes/api/auth/logout.ts?pick=GET":{"file":"logout.js","name":"logout","src":"src/routes/api/auth/logout.ts?pick=GET","isEntry":true,"isDynamicEntry":true,"imports":["_http-BEtiV9uB.js"]},"src/routes/api/auth/register.ts?pick=POST":{"file":"register.js","name":"register","src":"src/routes/api/auth/register.ts?pick=POST","isEntry":true,"isDynamicEntry":true,"imports":["_http-BEtiV9uB.js","_user-BatkDO93.js","_database-D2B4jluP.js"]},"src/routes/api/changes.ts?pick=POST":{"file":"changes.js","name":"changes","src":"src/routes/api/changes.ts?pick=POST","isEntry":true,"isDynamicEntry":true,"imports":["_http-BEtiV9uB.js","_database-D2B4jluP.js"]},"src/routes/api/envLog.ts?pick=GET":{"file":"envLog.js","name":"envLog","src":"src/routes/api/envLog.ts?pick=GET","isEntry":true,"isDynamicEntry":true,"imports":["_http-BEtiV9uB.js"]},"virtual:$vinxi/handler/ssr":{"file":"ssr.js","name":"ssr","src":"virtual:$vinxi/handler/ssr","isEntry":true,"imports":["_http-BEtiV9uB.js"],"dynamicImports":["src/routes/api/changes.ts?pick=POST","src/routes/api/changes.ts?pick=POST","src/routes/api/envLog.ts?pick=GET","src/routes/api/envLog.ts?pick=GET","src/routes/api/envLog.ts?pick=GET","src/routes/api/envLog.ts?pick=GET","src/routes/api/auth/[...solidauth].ts?pick=GET","src/routes/api/auth/[...solidauth].ts?pick=GET","src/routes/api/auth/[...solidauth].ts?pick=GET","src/routes/api/auth/[...solidauth].ts?pick=GET","src/routes/api/auth/[...solidauth].ts?pick=POST","src/routes/api/auth/[...solidauth].ts?pick=POST","src/routes/api/auth/login.ts?pick=POST","src/routes/api/auth/login.ts?pick=POST","src/routes/api/auth/logout.ts?pick=GET","src/routes/api/auth/logout.ts?pick=GET","src/routes/api/auth/logout.ts?pick=GET","src/routes/api/auth/logout.ts?pick=GET","src/routes/api/auth/register.ts?pick=POST","src/routes/api/auth/register.ts?pick=POST"]}},"client":{"_(app)-BQcXoKzi.js":{"file":"assets/(app)-BQcXoKzi.js","name":"(app)","isDynamicEntry":true,"imports":["_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"],"dynamicImports":["node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/iesTextureLoader.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/ddsTextureLoader.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/basisTextureLoader.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/envTextureLoader.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/hdrTextureLoader.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/ktxTextureLoader.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/ktxTextureLoader.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/tgaTextureLoader.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/exrTextureLoader.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Misc/dds.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/postprocess.vertex.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/postprocess.vertex.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Misc/dumpTools.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/pass.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/pass.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/passCube.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/passCube.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/rgbdDecode.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/rgbdDecode.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/rgbdEncode.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/rgbdEncode.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/pbr.vertex.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/pbr.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/pbr.vertex.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/pbr.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Meshes/mesh.vertexData.functions.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/depth.vertex.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/depth.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/kernelBlur.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/kernelBlur.vertex.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/kernelBlur.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/kernelBlur.vertex.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/shadowMap.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/shadowMap.vertex.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/depthBoxBlur.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/ShadersInclude/shadowMapFragmentSoftTransparentShadow.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/shadowMap.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/shadowMap.vertex.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/depthBoxBlur.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/ShadersInclude/shadowMapFragmentSoftTransparentShadow.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/default.vertex.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/default.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/default.vertex.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/default.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/color.vertex.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/color.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/color.vertex.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/color.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Animations/animationGroup.js","node_modules/.pnpm/@babylonjs+loaders@7.54.3_@babylonjs+core@7.54.3_babylonjs-gltf2interface@7.54.3/node_modules/@babylonjs/loaders/glTF/2.0/glTFLoaderAnimation.js"]},"_Media-BgKXkKGj.js":{"file":"assets/Media-BgKXkKGj.js","name":"Media","imports":["_web-CIHpc6fx.js"]},"_OverlayScrollbarsComponent-D4buOMT4.js":{"file":"assets/OverlayScrollbarsComponent-D4buOMT4.js","name":"OverlayScrollbarsComponent","imports":["_web-CIHpc6fx.js","_overlayscrollbars-D3GIAgNs.js"]},"____vite-browser-external_commonjs-proxy-BaOBqZBm.js":{"file":"assets/___vite-browser-external_commonjs-proxy-BaOBqZBm.js","name":"___vite-browser-external_commonjs-proxy","imports":["_postgres-BTNW2TY8.js"]},"_button-CwbqJzx-.js":{"file":"assets/button-CwbqJzx-.js","name":"button","imports":["_web-CIHpc6fx.js"]},"_character-COjYLq76.js":{"file":"assets/character-COjYLq76.js","name":"character","imports":["_postgres-BTNW2TY8.js","_crystal-N5N_6jwz.js"]},"_clipPlaneFragment-BkQQ1GyC.js":{"file":"assets/clipPlaneFragment-BkQQ1GyC.js","name":"clipPlaneFragment","imports":["_(app)-BQcXoKzi.js"]},"_clipPlaneVertex-De8KeaKc.js":{"file":"assets/clipPlaneVertex-De8KeaKc.js","name":"clipPlaneVertex","imports":["_(app)-BQcXoKzi.js"]},"_crystal-N5N_6jwz.js":{"file":"assets/crystal-N5N_6jwz.js","name":"crystal","imports":["_postgres-BTNW2TY8.js"]},"_defaultUboDeclaration-B2iZi9ZV.js":{"file":"assets/defaultUboDeclaration-B2iZi9ZV.js","name":"defaultUboDeclaration","imports":["_(app)-BQcXoKzi.js","_meshUboDeclaration-BiJrn2Ce.js"]},"_defaultUboDeclaration-CjpA1lw4.js":{"file":"assets/defaultUboDeclaration-CjpA1lw4.js","name":"defaultUboDeclaration","imports":["_(app)-BQcXoKzi.js","_meshUboDeclaration-BKO5nIf3.js"]},"_dialog-Cio2qlvj.js":{"file":"assets/dialog-Cio2qlvj.js","name":"dialog","imports":["_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js"]},"_fogFragment-C3bm6_WD.js":{"file":"assets/fogFragment-C3bm6_WD.js","name":"fogFragment","imports":["_(app)-BQcXoKzi.js"]},"_fogFragment-DV8vZhIr.js":{"file":"assets/fogFragment-DV8vZhIr.js","name":"fogFragment","imports":["_(app)-BQcXoKzi.js"]},"_harmonicsFunctions-C1iqzSwe.js":{"file":"assets/harmonicsFunctions-C1iqzSwe.js","name":"harmonicsFunctions","imports":["_(app)-BQcXoKzi.js","_meshUboDeclaration-BiJrn2Ce.js"]},"_harmonicsFunctions-DhQO3qhe.js":{"file":"assets/harmonicsFunctions-DhQO3qhe.js","name":"harmonicsFunctions","imports":["_(app)-BQcXoKzi.js","_meshUboDeclaration-BKO5nIf3.js"]},"_helperFunctions-P85AnhYT.js":{"file":"assets/helperFunctions-P85AnhYT.js","name":"helperFunctions","imports":["_(app)-BQcXoKzi.js"]},"_helperFunctions-f59Nn5SX.js":{"file":"assets/helperFunctions-f59Nn5SX.js","name":"helperFunctions","imports":["_(app)-BQcXoKzi.js"]},"_i18n-D2sladI6.js":{"file":"assets/i18n-D2sladI6.js","name":"i18n"},"_index-BOpBpQJ6.js":{"file":"assets/index-BOpBpQJ6.js","name":"index","imports":["_web-CIHpc6fx.js"]},"_index-DVCtmx-_.js":{"file":"assets/index-DVCtmx-_.js","name":"index","isDynamicEntry":true,"imports":["_postgres-BTNW2TY8.js","____vite-browser-external_commonjs-proxy-BaOBqZBm.js"]},"_index-l1SMoKQ2.js":{"file":"assets/index-l1SMoKQ2.js","name":"index","imports":["_postgres-BTNW2TY8.js","_i18n-D2sladI6.js","_web-CIHpc6fx.js","_store-CQ2B4mPE.js"]},"_input-_8gDkfJ0.js":{"file":"assets/input-_8gDkfJ0.js","name":"input","imports":["_web-CIHpc6fx.js"]},"_instancesDeclaration-B9Iadifl.js":{"file":"assets/instancesDeclaration-B9Iadifl.js","name":"instancesDeclaration","imports":["_(app)-BQcXoKzi.js"]},"_kernelBlurVaryingDeclaration-Bf54v8xT.js":{"file":"assets/kernelBlurVaryingDeclaration-Bf54v8xT.js","name":"kernelBlurVaryingDeclaration","imports":["_(app)-BQcXoKzi.js"]},"_kernelBlurVaryingDeclaration-Dvg3ZI3s.js":{"file":"assets/kernelBlurVaryingDeclaration-Dvg3ZI3s.js","name":"kernelBlurVaryingDeclaration","imports":["_(app)-BQcXoKzi.js"]},"_loadingBar-DLmXW3E3.js":{"file":"assets/loadingBar-DLmXW3E3.js","name":"loadingBar","imports":["_web-CIHpc6fx.js","_index-BOpBpQJ6.js"]},"_logDepthDeclaration-CYTyTGtw.js":{"file":"assets/logDepthDeclaration-CYTyTGtw.js","name":"logDepthDeclaration","imports":["_(app)-BQcXoKzi.js"]},"_logDepthDeclaration-IeIsWGfQ.js":{"file":"assets/logDepthDeclaration-IeIsWGfQ.js","name":"logDepthDeclaration","imports":["_(app)-BQcXoKzi.js"]},"_logDepthVertex-CLfxK9SS.js":{"file":"assets/logDepthVertex-CLfxK9SS.js","name":"logDepthVertex","imports":["_(app)-BQcXoKzi.js"]},"_logDepthVertex-D6DRg3sW.js":{"file":"assets/logDepthVertex-D6DRg3sW.js","name":"logDepthVertex","imports":["_(app)-BQcXoKzi.js"]},"_main-BPc2iFPx.js":{"file":"assets/main-BPc2iFPx.js","name":"main","isDynamicEntry":true,"imports":["_postgres-BTNW2TY8.js"]},"_main-CfqK61NJ.js":{"file":"assets/main-CfqK61NJ.js","name":"main","isDynamicEntry":true,"imports":["_postgres-BTNW2TY8.js","____vite-browser-external_commonjs-proxy-BaOBqZBm.js"]},"_meshUboDeclaration-BKO5nIf3.js":{"file":"assets/meshUboDeclaration-BKO5nIf3.js","name":"meshUboDeclaration","imports":["_(app)-BQcXoKzi.js"]},"_meshUboDeclaration-BiJrn2Ce.js":{"file":"assets/meshUboDeclaration-BiJrn2Ce.js","name":"meshUboDeclaration","imports":["_(app)-BQcXoKzi.js"]},"_morphTargetsVertex-ByOdyGdD.js":{"file":"assets/morphTargetsVertex-ByOdyGdD.js","name":"morphTargetsVertex","imports":["_(app)-BQcXoKzi.js"]},"_nodeEditor-CxjmBjoL.js":{"file":"assets/nodeEditor-CxjmBjoL.js","name":"nodeEditor","imports":["_web-CIHpc6fx.js","_store-CQ2B4mPE.js","_button-CwbqJzx-.js","_index-BOpBpQJ6.js","_Media-BgKXkKGj.js","_OverlayScrollbarsComponent-D4buOMT4.js","_postgres-BTNW2TY8.js"]},"_oitFragment-BplfZmSk.js":{"file":"assets/oitFragment-BplfZmSk.js","name":"oitFragment","imports":["_(app)-BQcXoKzi.js"]},"_oitFragment-BvELClzu.js":{"file":"assets/oitFragment-BvELClzu.js","name":"oitFragment","imports":["_(app)-BQcXoKzi.js"]},"_overlayscrollbars-D3GIAgNs.js":{"file":"assets/overlayscrollbars-D3GIAgNs.js","name":"overlayscrollbars"},"_packingFunctions-BlcJEJ_N.js":{"file":"assets/packingFunctions-BlcJEJ_N.js","name":"packingFunctions","imports":["_(app)-BQcXoKzi.js"]},"_postgres-BTNW2TY8.js":{"file":"assets/postgres-BTNW2TY8.js","name":"postgres","imports":["_preload-helper-CM3UJVvY.js"],"dynamicImports":["_index-DVCtmx-_.js","_main-CfqK61NJ.js","_main-BPc2iFPx.js","node_modules/.pnpm/kysely@0.27.6/node_modules/kysely/dist/esm/index.js","src/repositories/dialect/dialect.ts","src/initialWorker.ts"]},"_postgres-adapter-BZkHrcCt.js":{"file":"assets/postgres-adapter-BZkHrcCt.js","name":"postgres-adapter","imports":["_postgres-BTNW2TY8.js"]},"_preload-helper-CM3UJVvY.js":{"file":"assets/preload-helper-CM3UJVvY.js","name":"preload-helper"},"_routing-BQBHs4po.js":{"file":"assets/routing-BQBHs4po.js","name":"routing","imports":["_web-CIHpc6fx.js"]},"_skill-CSHBowvw.js":{"file":"assets/skill-CSHBowvw.js","name":"skill","imports":["_postgres-BTNW2TY8.js","_i18n-D2sladI6.js"]},"_store-CQ2B4mPE.js":{"file":"assets/store-CQ2B4mPE.js","name":"store","imports":["_web-CIHpc6fx.js"]},"_toggle-C_wLPjKz.js":{"file":"assets/toggle-C_wLPjKz.js","name":"toggle","imports":["_web-CIHpc6fx.js"]},"_vertexColorMixing-D_371lDa.js":{"file":"assets/vertexColorMixing-D_371lDa.js","name":"vertexColorMixing","imports":["_(app)-BQcXoKzi.js"]},"_vertexColorMixing-gujWcexK.js":{"file":"assets/vertexColorMixing-gujWcexK.js","name":"vertexColorMixing","imports":["_(app)-BQcXoKzi.js"]},"_web-CIHpc6fx.js":{"file":"assets/web-CIHpc6fx.js","name":"web"},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Animations/animationGroup.js":{"file":"assets/animationGroup-BSSLStS5.js","name":"animationGroup","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Animations/animationGroup.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/basisTextureLoader.js":{"file":"assets/basisTextureLoader-BI9kl61O.js","name":"basisTextureLoader","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/basisTextureLoader.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/ddsTextureLoader.js":{"file":"assets/ddsTextureLoader-KsoYTBhu.js","name":"ddsTextureLoader","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/ddsTextureLoader.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Misc/dds.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/envTextureLoader.js":{"file":"assets/envTextureLoader-BpVV0IaR.js","name":"envTextureLoader","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/envTextureLoader.js","isDynamicEntry":true,"imports":["_preload-helper-CM3UJVvY.js","_(app)-BQcXoKzi.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Misc/dumpTools.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_loadingBar-DLmXW3E3.js"],"dynamicImports":["node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/rgbdDecode.fragment.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/rgbdDecode.fragment.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/exrTextureLoader.js":{"file":"assets/exrTextureLoader-qwxirmvS.js","name":"exrTextureLoader","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/exrTextureLoader.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/hdrTextureLoader.js":{"file":"assets/hdrTextureLoader-NtFIYVoK.js","name":"hdrTextureLoader","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/hdrTextureLoader.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/iesTextureLoader.js":{"file":"assets/iesTextureLoader-CDlrATOY.js","name":"iesTextureLoader","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/iesTextureLoader.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/ktxTextureLoader.js":{"file":"assets/ktxTextureLoader-BMc6KHr9.js","name":"ktxTextureLoader","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/ktxTextureLoader.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/tgaTextureLoader.js":{"file":"assets/tgaTextureLoader-BKIq2ss1.js","name":"tgaTextureLoader","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Materials/Textures/Loaders/tgaTextureLoader.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Meshes/mesh.vertexData.functions.js":{"file":"assets/mesh.vertexData.functions-BYooUupK.js","name":"mesh.vertexData.functions","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Meshes/mesh.vertexData.functions.js","isDynamicEntry":true},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Misc/dds.js":{"file":"assets/dds-Bel29An_.js","name":"dds","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Misc/dds.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Misc/dumpTools.js":{"file":"assets/dumpTools-DBZfhSG7.js","name":"dumpTools","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Misc/dumpTools.js","isDynamicEntry":true,"imports":["_preload-helper-CM3UJVvY.js","_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_loadingBar-DLmXW3E3.js"],"dynamicImports":["_(app)-BQcXoKzi.js","node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/pass.fragment.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/ShadersInclude/shadowMapFragmentSoftTransparentShadow.js":{"file":"assets/shadowMapFragmentSoftTransparentShadow-CTid4Cu2.js","name":"shadowMapFragmentSoftTransparentShadow","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/ShadersInclude/shadowMapFragmentSoftTransparentShadow.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/color.fragment.js":{"file":"assets/color.fragment-BcSMXLut.js","name":"color.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/color.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_fogFragment-C3bm6_WD.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/color.vertex.js":{"file":"assets/color.vertex-C-dZ-V7d.js","name":"color.vertex","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/color.vertex.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_vertexColorMixing-D_371lDa.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/default.fragment.js":{"file":"assets/default.fragment-CmYItz2C.js","name":"default.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/default.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_oitFragment-BplfZmSk.js","_defaultUboDeclaration-B2iZi9ZV.js","_logDepthDeclaration-CYTyTGtw.js","_helperFunctions-P85AnhYT.js","_fogFragment-C3bm6_WD.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js","_meshUboDeclaration-BiJrn2Ce.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/default.vertex.js":{"file":"assets/default.vertex-xFdFxYIR.js","name":"default.vertex","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/default.vertex.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_logDepthVertex-D6DRg3sW.js","_defaultUboDeclaration-B2iZi9ZV.js","_helperFunctions-P85AnhYT.js","_logDepthDeclaration-CYTyTGtw.js","_vertexColorMixing-D_371lDa.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js","_meshUboDeclaration-BiJrn2Ce.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/depthBoxBlur.fragment.js":{"file":"assets/depthBoxBlur.fragment-hIZ7bqwb.js","name":"depthBoxBlur.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/depthBoxBlur.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/kernelBlur.fragment.js":{"file":"assets/kernelBlur.fragment-Bn0zydtV.js","name":"kernelBlur.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/kernelBlur.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_kernelBlurVaryingDeclaration-Dvg3ZI3s.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/kernelBlur.vertex.js":{"file":"assets/kernelBlur.vertex-Bh8KCmEs.js","name":"kernelBlur.vertex","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/kernelBlur.vertex.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_kernelBlurVaryingDeclaration-Dvg3ZI3s.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/pass.fragment.js":{"file":"assets/pass.fragment-DQCGvPvp.js","name":"pass.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/pass.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/passCube.fragment.js":{"file":"assets/passCube.fragment-_8imUZNE.js","name":"passCube.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/passCube.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/pbr.fragment.js":{"file":"assets/pbr.fragment-DrMkpjTy.js","name":"pbr.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/pbr.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_oitFragment-BplfZmSk.js","_harmonicsFunctions-C1iqzSwe.js","_logDepthDeclaration-CYTyTGtw.js","_fogFragment-C3bm6_WD.js","_helperFunctions-P85AnhYT.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js","_meshUboDeclaration-BiJrn2Ce.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/pbr.vertex.js":{"file":"assets/pbr.vertex-CIgTTeLZ.js","name":"pbr.vertex","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/pbr.vertex.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_logDepthVertex-D6DRg3sW.js","_harmonicsFunctions-C1iqzSwe.js","_logDepthDeclaration-CYTyTGtw.js","_helperFunctions-P85AnhYT.js","_vertexColorMixing-D_371lDa.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js","_meshUboDeclaration-BiJrn2Ce.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/rgbdDecode.fragment.js":{"file":"assets/rgbdDecode.fragment-Wyqo4jJ2.js","name":"rgbdDecode.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/rgbdDecode.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_helperFunctions-P85AnhYT.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/rgbdEncode.fragment.js":{"file":"assets/rgbdEncode.fragment-C7NDOEi3.js","name":"rgbdEncode.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/rgbdEncode.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_helperFunctions-P85AnhYT.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/shadowMap.fragment.js":{"file":"assets/shadowMap.fragment-deamnz7Q.js","name":"shadowMap.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/shadowMap.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/shadowMap.vertex.js":{"file":"assets/shadowMap.vertex-CD5nPTp_.js","name":"shadowMap.vertex","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/Shaders/shadowMap.vertex.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_helperFunctions-P85AnhYT.js","_meshUboDeclaration-BiJrn2Ce.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/ShadersInclude/shadowMapFragmentSoftTransparentShadow.js":{"file":"assets/shadowMapFragmentSoftTransparentShadow-AhAYEMnc.js","name":"shadowMapFragmentSoftTransparentShadow","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/ShadersInclude/shadowMapFragmentSoftTransparentShadow.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/color.fragment.js":{"file":"assets/color.fragment-DcIs4BP6.js","name":"color.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/color.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_clipPlaneFragment-BkQQ1GyC.js","_fogFragment-DV8vZhIr.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/color.vertex.js":{"file":"assets/color.vertex-Ima1XzTd.js","name":"color.vertex","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/color.vertex.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_clipPlaneVertex-De8KeaKc.js","_vertexColorMixing-gujWcexK.js","_instancesDeclaration-B9Iadifl.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/default.fragment.js":{"file":"assets/default.fragment-BhpweL4x.js","name":"default.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/default.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_defaultUboDeclaration-CjpA1lw4.js","_oitFragment-BvELClzu.js","_logDepthDeclaration-IeIsWGfQ.js","_helperFunctions-f59Nn5SX.js","_clipPlaneFragment-BkQQ1GyC.js","_fogFragment-DV8vZhIr.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js","_meshUboDeclaration-BKO5nIf3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/default.vertex.js":{"file":"assets/default.vertex-BG7rHPQG.js","name":"default.vertex","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/default.vertex.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_defaultUboDeclaration-CjpA1lw4.js","_logDepthVertex-CLfxK9SS.js","_helperFunctions-f59Nn5SX.js","_clipPlaneVertex-De8KeaKc.js","_instancesDeclaration-B9Iadifl.js","_logDepthDeclaration-IeIsWGfQ.js","_vertexColorMixing-gujWcexK.js","_morphTargetsVertex-ByOdyGdD.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js","_meshUboDeclaration-BKO5nIf3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/depth.fragment.js":{"file":"assets/depth.fragment-BzUT3H-M.js","name":"depth.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/depth.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_clipPlaneFragment-BkQQ1GyC.js","_packingFunctions-BlcJEJ_N.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/depth.vertex.js":{"file":"assets/depth.vertex-zPU91nl3.js","name":"depth.vertex","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/depth.vertex.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_clipPlaneVertex-De8KeaKc.js","_morphTargetsVertex-ByOdyGdD.js","_instancesDeclaration-B9Iadifl.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/depthBoxBlur.fragment.js":{"file":"assets/depthBoxBlur.fragment-CZ1bTGnn.js","name":"depthBoxBlur.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/depthBoxBlur.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/kernelBlur.fragment.js":{"file":"assets/kernelBlur.fragment-D2e2kUE6.js","name":"kernelBlur.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/kernelBlur.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_kernelBlurVaryingDeclaration-Bf54v8xT.js","_packingFunctions-BlcJEJ_N.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/kernelBlur.vertex.js":{"file":"assets/kernelBlur.vertex-4UPr9Wqw.js","name":"kernelBlur.vertex","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/kernelBlur.vertex.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_kernelBlurVaryingDeclaration-Bf54v8xT.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/pass.fragment.js":{"file":"assets/pass.fragment-DykT_6gR.js","name":"pass.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/pass.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/passCube.fragment.js":{"file":"assets/passCube.fragment-CdtuTapX.js","name":"passCube.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/passCube.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/pbr.fragment.js":{"file":"assets/pbr.fragment-D2GjthOJ.js","name":"pbr.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/pbr.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_oitFragment-BvELClzu.js","_harmonicsFunctions-DhQO3qhe.js","_logDepthDeclaration-IeIsWGfQ.js","_clipPlaneFragment-BkQQ1GyC.js","_fogFragment-DV8vZhIr.js","_helperFunctions-f59Nn5SX.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js","_meshUboDeclaration-BKO5nIf3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/pbr.vertex.js":{"file":"assets/pbr.vertex-B3qiKKWg.js","name":"pbr.vertex","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/pbr.vertex.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_harmonicsFunctions-DhQO3qhe.js","_logDepthVertex-CLfxK9SS.js","_logDepthDeclaration-IeIsWGfQ.js","_helperFunctions-f59Nn5SX.js","_clipPlaneVertex-De8KeaKc.js","_instancesDeclaration-B9Iadifl.js","_vertexColorMixing-gujWcexK.js","_morphTargetsVertex-ByOdyGdD.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js","_meshUboDeclaration-BKO5nIf3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/postprocess.vertex.js":{"file":"assets/postprocess.vertex-DGnCmbes.js","name":"postprocess.vertex","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/postprocess.vertex.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/rgbdDecode.fragment.js":{"file":"assets/rgbdDecode.fragment-CMvuNNj3.js","name":"rgbdDecode.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/rgbdDecode.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_helperFunctions-f59Nn5SX.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/rgbdEncode.fragment.js":{"file":"assets/rgbdEncode.fragment-Dj0iSxv6.js","name":"rgbdEncode.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/rgbdEncode.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_helperFunctions-f59Nn5SX.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/shadowMap.fragment.js":{"file":"assets/shadowMap.fragment-DSzmv82n.js","name":"shadowMap.fragment","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/shadowMap.fragment.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_packingFunctions-BlcJEJ_N.js","_clipPlaneFragment-BkQQ1GyC.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/shadowMap.vertex.js":{"file":"assets/shadowMap.vertex-CyARZ2qj.js","name":"shadowMap.vertex","src":"node_modules/.pnpm/@babylonjs+core@7.54.3/node_modules/@babylonjs/core/ShadersWGSL/shadowMap.vertex.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_clipPlaneVertex-De8KeaKc.js","_morphTargetsVertex-ByOdyGdD.js","_helperFunctions-f59Nn5SX.js","_meshUboDeclaration-BKO5nIf3.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@babylonjs+loaders@7.54.3_@babylonjs+core@7.54.3_babylonjs-gltf2interface@7.54.3/node_modules/@babylonjs/loaders/glTF/2.0/glTFLoaderAnimation.js":{"file":"assets/glTFLoaderAnimation-Bb4n3cSX.js","name":"glTFLoaderAnimation","src":"node_modules/.pnpm/@babylonjs+loaders@7.54.3_@babylonjs+core@7.54.3_babylonjs-gltf2interface@7.54.3/node_modules/@babylonjs/loaders/glTF/2.0/glTFLoaderAnimation.js","isDynamicEntry":true,"imports":["_(app)-BQcXoKzi.js","_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"node_modules/.pnpm/@electric-sql+pglite@0.2.17/node_modules/@electric-sql/pglite/dist/postgres.data":{"file":"assets/postgres-CkP7QCDB.data","src":"node_modules/.pnpm/@electric-sql+pglite@0.2.17/node_modules/@electric-sql/pglite/dist/postgres.data"},"node_modules/.pnpm/@electric-sql+pglite@0.2.17/node_modules/@electric-sql/pglite/dist/postgres.wasm":{"file":"assets/postgres-CyuUVpXN.wasm","src":"node_modules/.pnpm/@electric-sql+pglite@0.2.17/node_modules/@electric-sql/pglite/dist/postgres.wasm"},"node_modules/.pnpm/kysely@0.27.6/node_modules/kysely/dist/esm/index.js":{"file":"assets/index-CmK9u_yj.js","name":"index","src":"node_modules/.pnpm/kysely@0.27.6/node_modules/kysely/dist/esm/index.js","isDynamicEntry":true,"imports":["_postgres-BTNW2TY8.js","_postgres-adapter-BZkHrcCt.js","_preload-helper-CM3UJVvY.js"]},"public/icons/512.png":{"file":"assets/512-DTiyhobg.png","src":"public/icons/512.png"},"src/initialWorker.ts":{"file":"assets/initialWorker-B3_6tmhz.js","name":"initialWorker","src":"src/initialWorker.ts","isDynamicEntry":true,"imports":["_store-CQ2B4mPE.js","_web-CIHpc6fx.js"]},"src/repositories/dialect/dialect.ts":{"file":"assets/dialect-DI_o0CUc.js","name":"dialect","src":"src/repositories/dialect/dialect.ts","isDynamicEntry":true,"imports":["_postgres-adapter-BZkHrcCt.js","_postgres-BTNW2TY8.js","_preload-helper-CM3UJVvY.js"]},"src/routes/(app).tsx?pick=default&pick=$css":{"file":"assets/(app)-C1swXDvZ.js","name":"(app)","src":"src/routes/(app).tsx?pick=default&pick=$css","isEntry":true,"imports":["_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_(app)-BQcXoKzi.js","_Media-BgKXkKGj.js","_input-_8gDkfJ0.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_toggle-C_wLPjKz.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js","_loadingBar-DLmXW3E3.js"]},"src/routes/(app)/(functionPage).tsx?pick=default&pick=$css":{"file":"assets/(functionPage)-BskoJHmw.js","name":"(functionPage)","src":"src/routes/(app)/(functionPage).tsx?pick=default&pick=$css","isEntry":true,"isDynamicEntry":true,"imports":["_web-CIHpc6fx.js","_index-BOpBpQJ6.js","_store-CQ2B4mPE.js","_button-CwbqJzx-.js","_i18n-D2sladI6.js","_routing-BQBHs4po.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js"]},"src/routes/(app)/(functionPage)/[...404].tsx?pick=default&pick=$css":{"file":"assets/_...404_-C8ob_eDs.js","name":"_...404_","src":"src/routes/(app)/(functionPage)/[...404].tsx?pick=default&pick=$css","isEntry":true,"isDynamicEntry":true,"imports":["_web-CIHpc6fx.js","_loadingBar-DLmXW3E3.js","_i18n-D2sladI6.js","_store-CQ2B4mPE.js","_index-BOpBpQJ6.js"]},"src/routes/(app)/(functionPage)/character/(character).tsx?pick=default&pick=$css":{"file":"assets/(character)-BQOdHxo5.js","name":"(character)","src":"src/routes/(app)/(functionPage)/character/(character).tsx?pick=default&pick=$css","isEntry":true,"isDynamicEntry":true,"imports":["_web-CIHpc6fx.js","_character-COjYLq76.js","_i18n-D2sladI6.js","_store-CQ2B4mPE.js","_postgres-BTNW2TY8.js","_preload-helper-CM3UJVvY.js","_crystal-N5N_6jwz.js"]},"src/routes/(app)/(functionPage)/character/[characterId].tsx?pick=default&pick=$css":{"file":"assets/_characterId_-Cxn0A_mx.js","name":"_characterId_","src":"src/routes/(app)/(functionPage)/character/[characterId].tsx?pick=default&pick=$css","isEntry":true,"isDynamicEntry":true,"imports":["_web-CIHpc6fx.js","_character-COjYLq76.js","_routing-BQBHs4po.js","_OverlayScrollbarsComponent-D4buOMT4.js","_postgres-BTNW2TY8.js","_preload-helper-CM3UJVvY.js","_crystal-N5N_6jwz.js","_overlayscrollbars-D3GIAgNs.js"]},"src/routes/(app)/(functionPage)/petCalculator.tsx?pick=default&pick=$css":{"file":"assets/petCalculator-C_iQ8Ihn.js","name":"petCalculator","src":"src/routes/(app)/(functionPage)/petCalculator.tsx?pick=default&pick=$css","isEntry":true,"isDynamicEntry":true,"imports":["_web-CIHpc6fx.js"]},"src/routes/(app)/(functionPage)/profile/(profile).tsx?pick=default&pick=$css":{"file":"assets/(profile)-CuQvSt6a.js","name":"(profile)","src":"src/routes/(app)/(functionPage)/profile/(profile).tsx?pick=default&pick=$css","isEntry":true,"isDynamicEntry":true,"imports":["_web-CIHpc6fx.js","_i18n-D2sladI6.js","_store-CQ2B4mPE.js","_button-CwbqJzx-.js","_routing-BQBHs4po.js"]},"src/routes/(app)/(functionPage)/wiki/(wiki).tsx?pick=default&pick=$css":{"file":"assets/(wiki)-9Vn9r_TC.js","name":"(wiki)","src":"src/routes/(app)/(functionPage)/wiki/(wiki).tsx?pick=default&pick=$css","isEntry":true,"isDynamicEntry":true,"imports":["_web-CIHpc6fx.js","_i18n-D2sladI6.js","_store-CQ2B4mPE.js"]},"src/routes/(app)/(functionPage)/wiki/mob/(mob).tsx?pick=default&pick=$css":{"file":"assets/(mob)-DZ4B4ONG.js","name":"(mob)","src":"src/routes/(app)/(functionPage)/wiki/mob/(mob).tsx?pick=default&pick=$css","isEntry":true,"isDynamicEntry":true,"imports":["_web-CIHpc6fx.js","_nodeEditor-CxjmBjoL.js","_index-BOpBpQJ6.js","_index-l1SMoKQ2.js","_store-CQ2B4mPE.js","_i18n-D2sladI6.js","_button-CwbqJzx-.js","_dialog-Cio2qlvj.js","_input-_8gDkfJ0.js","_toggle-C_wLPjKz.js","_postgres-BTNW2TY8.js","_Media-BgKXkKGj.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_preload-helper-CM3UJVvY.js"]},"src/routes/(app)/(functionPage)/wiki/pet/(pet).tsx?pick=default&pick=$css":{"file":"assets/(pet)-CYB2UBTx.js","name":"(pet)","src":"src/routes/(app)/(functionPage)/wiki/pet/(pet).tsx?pick=default&pick=$css","isEntry":true,"isDynamicEntry":true,"imports":["_web-CIHpc6fx.js","_i18n-D2sladI6.js","_store-CQ2B4mPE.js"]},"src/routes/(app)/(functionPage)/wiki/skill/(skill).tsx?pick=default&pick=$css":{"file":"assets/(skill)-BCqofgzE.js","name":"(skill)","src":"src/routes/(app)/(functionPage)/wiki/skill/(skill).tsx?pick=default&pick=$css","isEntry":true,"isDynamicEntry":true,"imports":["_web-CIHpc6fx.js","_nodeEditor-CxjmBjoL.js","_index-BOpBpQJ6.js","_skill-CSHBowvw.js","_store-CQ2B4mPE.js","_i18n-D2sladI6.js","_button-CwbqJzx-.js","_dialog-Cio2qlvj.js","_Media-BgKXkKGj.js","_OverlayScrollbarsComponent-D4buOMT4.js","_overlayscrollbars-D3GIAgNs.js","_postgres-BTNW2TY8.js","_preload-helper-CM3UJVvY.js"]},"src/routes/(app)/index.tsx?pick=default&pick=$css":{"file":"assets/index-BBuiUxA4.js","name":"index","src":"src/routes/(app)/index.tsx?pick=default&pick=$css","isEntry":true,"isDynamicEntry":true,"imports":["_web-CIHpc6fx.js","_i18n-D2sladI6.js","_button-CwbqJzx-.js","_index-l1SMoKQ2.js","_skill-CSHBowvw.js","_crystal-N5N_6jwz.js","_index-BOpBpQJ6.js","_dialog-Cio2qlvj.js","_postgres-BTNW2TY8.js","_Media-BgKXkKGj.js","_store-CQ2B4mPE.js","src/initialWorker.ts","_input-_8gDkfJ0.js","_routing-BQBHs4po.js","_OverlayScrollbarsComponent-D4buOMT4.js","_preload-helper-CM3UJVvY.js","_overlayscrollbars-D3GIAgNs.js"],"assets":["assets/512-DTiyhobg.png"]},"src/routes/(app)/repl.jsx?pick=default&pick=$css":{"file":"assets/repl-Dc2voNrl.js","name":"repl","src":"src/routes/(app)/repl.jsx?pick=default&pick=$css","isEntry":true,"isDynamicEntry":true,"imports":["_preload-helper-CM3UJVvY.js","_web-CIHpc6fx.js","src/initialWorker.ts","_store-CQ2B4mPE.js"]},"src/routes/api/auth/qq.ts?pick=default&pick=$css":{"file":"assets/qq-C4pIMC0Y.js","name":"qq","src":"src/routes/api/auth/qq.ts?pick=default&pick=$css","isEntry":true,"isDynamicEntry":true},"virtual:$vinxi/handler/client":{"file":"assets/client-TFvGbaZz.js","name":"client","src":"virtual:$vinxi/handler/client","isEntry":true,"imports":["_overlayscrollbars-D3GIAgNs.js","_web-CIHpc6fx.js","_preload-helper-CM3UJVvY.js","_store-CQ2B4mPE.js","_routing-BQBHs4po.js"],"dynamicImports":["src/routes/(app).tsx?pick=default&pick=$css","src/routes/(app)/(functionPage).tsx?pick=default&pick=$css","src/routes/(app)/index.tsx?pick=default&pick=$css","src/routes/(app)/repl.jsx?pick=default&pick=$css","src/routes/(app)/(functionPage)/[...404].tsx?pick=default&pick=$css","src/routes/(app)/(functionPage)/petCalculator.tsx?pick=default&pick=$css","src/routes/api/auth/qq.ts?pick=default&pick=$css","src/routes/(app)/(functionPage)/character/(character).tsx?pick=default&pick=$css","src/routes/(app)/(functionPage)/character/[characterId].tsx?pick=default&pick=$css","src/routes/(app)/(functionPage)/profile/(profile).tsx?pick=default&pick=$css","src/routes/(app)/(functionPage)/wiki/(wiki).tsx?pick=default&pick=$css","src/routes/(app)/(functionPage)/wiki/mob/(mob).tsx?pick=default&pick=$css","src/routes/(app)/(functionPage)/wiki/pet/(pet).tsx?pick=default&pick=$css","src/routes/(app)/(functionPage)/wiki/skill/(skill).tsx?pick=default&pick=$css"],"css":["assets/client-D8qH7JAh.css"]}},"server-fns":{"_database-RW067y32.js":{"file":"assets/database-RW067y32.js","name":"database","dynamicImports":["src/repositories/dialect/dialect.ts","src/initialWorker.ts"]},"_http-Dfsrx3wX.js":{"file":"assets/http-Dfsrx3wX.js","name":"http"},"_server-fns-BczFCVeQ.js":{"file":"assets/server-fns-BczFCVeQ.js","name":"server-fns","imports":["_http-Dfsrx3wX.js"],"dynamicImports":["src/routes/api/changes.ts?pick=POST","src/routes/api/changes.ts?pick=POST","src/routes/api/envLog.ts?pick=GET","src/routes/api/envLog.ts?pick=GET","src/routes/api/envLog.ts?pick=GET","src/routes/api/envLog.ts?pick=GET","src/routes/api/auth/[...solidauth].ts?pick=GET","src/routes/api/auth/[...solidauth].ts?pick=GET","src/routes/api/auth/[...solidauth].ts?pick=GET","src/routes/api/auth/[...solidauth].ts?pick=GET","src/routes/api/auth/[...solidauth].ts?pick=POST","src/routes/api/auth/[...solidauth].ts?pick=POST","src/routes/api/auth/login.ts?pick=POST","src/routes/api/auth/login.ts?pick=POST","src/routes/api/auth/logout.ts?pick=GET","src/routes/api/auth/logout.ts?pick=GET","src/routes/api/auth/logout.ts?pick=GET","src/routes/api/auth/logout.ts?pick=GET","src/routes/api/auth/register.ts?pick=POST","src/routes/api/auth/register.ts?pick=POST","src/lib/session.ts?tsr-directive-use-server=","src/lib/session.ts?tsr-directive-use-server=","src/app.tsx"]},"_user-BNai-P02.js":{"file":"assets/user-BNai-P02.js","name":"user","imports":["_database-RW067y32.js"]},"src/app.tsx":{"file":"assets/app-DK5u2c7Z.js","name":"app","src":"src/app.tsx","isDynamicEntry":true,"imports":["_server-fns-BczFCVeQ.js","_http-Dfsrx3wX.js"]},"src/initialWorker.ts":{"file":"assets/initialWorker-CH3MGkTl.js","name":"initialWorker","src":"src/initialWorker.ts","isDynamicEntry":true},"src/lib/session.ts?tsr-directive-use-server=":{"file":"assets/session-gJxBGr18.js","name":"session","src":"src/lib/session.ts?tsr-directive-use-server=","isDynamicEntry":true,"imports":["_server-fns-BczFCVeQ.js","_user-BNai-P02.js","_http-Dfsrx3wX.js","_database-RW067y32.js"]},"src/repositories/dialect/dialect.ts":{"file":"assets/dialect-D2JFOh1E.js","name":"dialect","src":"src/repositories/dialect/dialect.ts","isDynamicEntry":true},"src/routes/api/auth/[...solidauth].ts?pick=GET":{"file":"_...solidauth_.js","name":"_...solidauth_","src":"src/routes/api/auth/[...solidauth].ts?pick=GET","isEntry":true,"isDynamicEntry":true},"src/routes/api/auth/[...solidauth].ts?pick=POST":{"file":"_...solidauth_2.js","name":"_...solidauth_","src":"src/routes/api/auth/[...solidauth].ts?pick=POST","isEntry":true,"isDynamicEntry":true},"src/routes/api/auth/login.ts?pick=POST":{"file":"login.js","name":"login","src":"src/routes/api/auth/login.ts?pick=POST","isEntry":true,"isDynamicEntry":true,"imports":["_http-Dfsrx3wX.js","_user-BNai-P02.js","_database-RW067y32.js"]},"src/routes/api/auth/logout.ts?pick=GET":{"file":"logout.js","name":"logout","src":"src/routes/api/auth/logout.ts?pick=GET","isEntry":true,"isDynamicEntry":true,"imports":["_http-Dfsrx3wX.js"]},"src/routes/api/auth/register.ts?pick=POST":{"file":"register.js","name":"register","src":"src/routes/api/auth/register.ts?pick=POST","isEntry":true,"isDynamicEntry":true,"imports":["_http-Dfsrx3wX.js","_user-BNai-P02.js","_database-RW067y32.js"]},"src/routes/api/changes.ts?pick=POST":{"file":"changes.js","name":"changes","src":"src/routes/api/changes.ts?pick=POST","isEntry":true,"isDynamicEntry":true,"imports":["_http-Dfsrx3wX.js","_database-RW067y32.js"]},"src/routes/api/envLog.ts?pick=GET":{"file":"envLog.js","name":"envLog","src":"src/routes/api/envLog.ts?pick=GET","isEntry":true,"isDynamicEntry":true,"imports":["_http-Dfsrx3wX.js"]},"virtual:$vinxi/handler/server-fns":{"file":"server-fns.js","name":"server-fns","src":"virtual:$vinxi/handler/server-fns","isEntry":true,"imports":["_server-fns-BczFCVeQ.js","_http-Dfsrx3wX.js"]}}};

				const routeManifest = {"ssr":{},"client":{},"server-fns":{}};

        function createProdApp(appConfig) {
          return {
            config: { ...appConfig, buildManifest, routeManifest },
            getRouter(name) {
              return appConfig.routers.find(router => router.name === name)
            }
          }
        }

        function plugin$2(app) {
          const prodApp = createProdApp(appConfig);
          globalThis.app = prodApp;
        }

function plugin$1(app) {
	globalThis.$handle = (event) => app.h3App.handler(event);
}

/**
 * Traverses the module graph and collects assets for a given chunk
 *
 * @param {any} manifest Client manifest
 * @param {string} id Chunk id
 * @param {Map<string, string[]>} assetMap Cache of assets
 * @param {string[]} stack Stack of chunk ids to prevent circular dependencies
 * @returns Array of asset URLs
 */
function findAssetsInViteManifest(manifest, id, assetMap = new Map(), stack = []) {
	if (stack.includes(id)) {
		return [];
	}

	const cached = assetMap.get(id);
	if (cached) {
		return cached;
	}
	const chunk = manifest[id];
	if (!chunk) {
		return [];
	}

	const assets = [
		...(chunk.assets?.filter(Boolean) || []),
		...(chunk.css?.filter(Boolean) || [])
	];
	if (chunk.imports) {
		stack.push(id);
		for (let i = 0, l = chunk.imports.length; i < l; i++) {
			assets.push(...findAssetsInViteManifest(manifest, chunk.imports[i], assetMap, stack));
		}
		stack.pop();
	}
	assets.push(chunk.file);
	const all = Array.from(new Set(assets));
	assetMap.set(id, all);

	return all;
}

/** @typedef {import("../app.js").App & { config: { buildManifest: { [key:string]: any } }}} ProdApp */

function createHtmlTagsForAssets(router, app, assets) {
	return assets
		.filter(
			(asset) =>
				asset.endsWith(".css") ||
				asset.endsWith(".js") ||
				asset.endsWith(".mjs"),
		)
		.map((asset) => ({
			tag: "link",
			attrs: {
				href: joinURL(app.config.server.baseURL ?? "/", router.base, asset),
				key: join$1(app.config.server.baseURL ?? "", router.base, asset),
				...(asset.endsWith(".css")
					? { rel: "stylesheet", fetchPriority: "high" }
					: { rel: "modulepreload" }),
			},
		}));
}

/**
 *
 * @param {ProdApp} app
 * @returns
 */
function createProdManifest(app) {
	const manifest = new Proxy(
		{},
		{
			get(target, routerName) {
				invariant(typeof routerName === "string", "Bundler name expected");
				const router = app.getRouter(routerName);
				const bundlerManifest = app.config.buildManifest[routerName];

				invariant(
					router.type !== "static",
					"manifest not available for static router",
				);
				return {
					handler: router.handler,
					async assets() {
						/** @type {{ [key: string]: string[] }} */
						let assets = {};
						assets[router.handler] = await this.inputs[router.handler].assets();
						for (const route of (await router.internals.routes?.getRoutes()) ??
							[]) {
							assets[route.filePath] = await this.inputs[
								route.filePath
							].assets();
						}
						return assets;
					},
					async routes() {
						return (await router.internals.routes?.getRoutes()) ?? [];
					},
					async json() {
						/** @type {{ [key: string]: { output: string; assets: string[]} }} */
						let json = {};
						for (const input of Object.keys(this.inputs)) {
							json[input] = {
								output: this.inputs[input].output.path,
								assets: await this.inputs[input].assets(),
							};
						}
						return json;
					},
					chunks: new Proxy(
						{},
						{
							get(target, chunk) {
								invariant(typeof chunk === "string", "Chunk expected");
								const chunkPath = join$1(
									router.outDir,
									router.base,
									chunk + ".mjs",
								);
								return {
									import() {
										if (globalThis.$$chunks[chunk + ".mjs"]) {
											return globalThis.$$chunks[chunk + ".mjs"];
										}
										return import(
											/* @vite-ignore */ pathToFileURL(chunkPath).href
										);
									},
									output: {
										path: chunkPath,
									},
								};
							},
						},
					),
					inputs: new Proxy(
						{},
						{
							ownKeys(target) {
								const keys = Object.keys(bundlerManifest)
									.filter((id) => bundlerManifest[id].isEntry)
									.map((id) => id);
								return keys;
							},
							getOwnPropertyDescriptor(k) {
								return {
									enumerable: true,
									configurable: true,
								};
							},
							get(target, input) {
								invariant(typeof input === "string", "Input expected");
								if (router.target === "server") {
									const id =
										input === router.handler
											? virtualId(handlerModule(router))
											: input;
									return {
										assets() {
											return createHtmlTagsForAssets(
												router,
												app,
												findAssetsInViteManifest(bundlerManifest, id),
											);
										},
										output: {
											path: join$1(
												router.outDir,
												router.base,
												bundlerManifest[id].file,
											),
										},
									};
								} else if (router.target === "browser") {
									const id =
										input === router.handler && !input.endsWith(".html")
											? virtualId(handlerModule(router))
											: input;
									return {
										import() {
											return import(
												/* @vite-ignore */ joinURL(
													app.config.server.baseURL ?? "",
													router.base,
													bundlerManifest[id].file,
												)
											);
										},
										assets() {
											return createHtmlTagsForAssets(
												router,
												app,
												findAssetsInViteManifest(bundlerManifest, id),
											);
										},
										output: {
											path: joinURL(
												app.config.server.baseURL ?? "",
												router.base,
												bundlerManifest[id].file,
											),
										},
									};
								}
							},
						},
					),
				};
			},
		},
	);

	return manifest;
}

function plugin() {
	globalThis.MANIFEST =
		createProdManifest(globalThis.app)
			;
}

const chunks = {};
			 



			 function app() {
				 globalThis.$$chunks = chunks;
			 }

const plugins = [
  plugin$2,
plugin$1,
plugin,
app
];

const assets = {
  "/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"583d-SkrRi/zdbTlr7tO7122Mew3oX4U\"",
    "mtime": "2025-04-16T08:55:49.116Z",
    "size": 22589,
    "path": "../public/index.html"
  },
  "/index.html.br": {
    "type": "text/html; charset=utf-8",
    "encoding": "br",
    "etag": "\"765-yysbjqqwH5U9lwfn7oEZMoKfMFU\"",
    "mtime": "2025-04-16T08:55:49.236Z",
    "size": 1893,
    "path": "../public/index.html.br"
  },
  "/index.html.gz": {
    "type": "text/html; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"946-5mVMak+OhrNuS+/ue/LBRf/Dea4\"",
    "mtime": "2025-04-16T08:55:49.196Z",
    "size": 2374,
    "path": "../public/index.html.gz"
  },
  "/manifest.json": {
    "type": "application/json",
    "etag": "\"6d4-UWa/+uvzhqDsn7BXRVq5dx5Poz8\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 1748,
    "path": "../public/manifest.json"
  },
  "/manifest.json.br": {
    "type": "application/json",
    "encoding": "br",
    "etag": "\"1c9-JFPKA9OEVZcMFKab4MvLMneO0+c\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 457,
    "path": "../public/manifest.json.br"
  },
  "/manifest.json.gz": {
    "type": "application/json",
    "encoding": "gzip",
    "etag": "\"24d-9i7MyLL2G8eS6QDz5cox5EQJ5Hw\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 589,
    "path": "../public/manifest.json.gz"
  },
  "/robots.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"16-iUOtJ2RsHfdY9DoQxaq0wz1LZCU\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 22,
    "path": "../public/robots.txt"
  },
  "/app-image/bg.jpg": {
    "type": "image/jpeg",
    "etag": "\"1f843-VkqK3nr1AYO3MxGBpouO5m0zFYA\"",
    "mtime": "2025-04-16T08:54:50.742Z",
    "size": 129091,
    "path": "../public/app-image/bg.jpg"
  },
  "/app-image/bg.png": {
    "type": "image/png",
    "etag": "\"589b2f-mKjIf4vDESGgCt9r2oYHgpOMilg\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 5806895,
    "path": "../public/app-image/bg.png"
  },
  "/app-image/screenShotMobile.png": {
    "type": "image/png",
    "etag": "\"dad6-r3GJIm+cF5wDiuKEZIFwCZY+3yc\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 56022,
    "path": "../public/app-image/screenShotMobile.png"
  },
  "/app-image/screenShotPC.png": {
    "type": "image/png",
    "etag": "\"81ed-ElbO4+WHwTO2rli3cE0vxZdLn0w\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 33261,
    "path": "../public/app-image/screenShotPC.png"
  },
  "/assets/PGlite.worker-CwyYoeB4.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1c09e-BKcW6fNgLTQ1jRUxT+5v0MJPp+w\"",
    "mtime": "2025-04-16T08:54:57.685Z",
    "size": 114846,
    "path": "../public/assets/PGlite.worker-CwyYoeB4.js.br"
  },
  "/assets/PGlite.worker-CwyYoeB4.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"23417-VbBe28FJRPun8UzIX6unZnxB0Bk\"",
    "mtime": "2025-04-16T08:54:58.807Z",
    "size": 144407,
    "path": "../public/assets/PGlite.worker-CwyYoeB4.js.gz"
  },
  "/assets/PGlite.worker-CwyYoeB4.js.map": {
    "type": "application/json",
    "etag": "\"184d63-b8qPv+1TETas9RQMiVQ1RWaveCk\"",
    "mtime": "2025-04-16T08:54:50.779Z",
    "size": 1592675,
    "path": "../public/assets/PGlite.worker-CwyYoeB4.js.map"
  },
  "/assets/__vite-browser-external-9wXp6ZBx.js.map": {
    "type": "application/json",
    "etag": "\"ce-qwnyo3qSPkU7CXm3MQOvrH54YVo\"",
    "mtime": "2025-04-16T08:54:50.770Z",
    "size": 206,
    "path": "../public/assets/__vite-browser-external-9wXp6ZBx.js.map"
  },
  "/assets/database-D2B4jluP.js.map": {
    "type": "application/json",
    "etag": "\"a23-pIslZjWDebiIC9rVAeA9IeMW/y0\"",
    "mtime": "2025-04-16T08:54:50.779Z",
    "size": 2595,
    "path": "../public/assets/database-D2B4jluP.js.map"
  },
  "/assets/dialect-D2JFOh1E.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"225-FdPs+1tlS5cerlwixW9II9GTvHM\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 549,
    "path": "../public/assets/dialect-D2JFOh1E.js.br"
  },
  "/assets/dialect-D2JFOh1E.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"271-/2Edkt864pTUrJtL58yrj+qnDrw\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 625,
    "path": "../public/assets/dialect-D2JFOh1E.js.gz"
  },
  "/assets/dialect-D2JFOh1E.js.map": {
    "type": "application/json",
    "etag": "\"1909-K1Vqx5FxR4Y4myzGYD0Qapv7iik\"",
    "mtime": "2025-04-16T08:54:50.779Z",
    "size": 6409,
    "path": "../public/assets/dialect-D2JFOh1E.js.map"
  },
  "/assets/http-BEtiV9uB.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"48e-K4I56Tx6bypAfBrNQIAZ0XMVkpk\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 1166,
    "path": "../public/assets/http-BEtiV9uB.js.br"
  },
  "/assets/http-BEtiV9uB.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"532-i+H4a297xF3Aa4mcdu2BGfkDnpw\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 1330,
    "path": "../public/assets/http-BEtiV9uB.js.gz"
  },
  "/assets/http-BEtiV9uB.js.map": {
    "type": "application/json",
    "etag": "\"523d-fysVEJ0pyKNOvoJjzNYwq5oORdo\"",
    "mtime": "2025-04-16T08:54:50.779Z",
    "size": 21053,
    "path": "../public/assets/http-BEtiV9uB.js.map"
  },
  "/assets/initialWorker-Cc4f1geA.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3a4-/5SEiKq1wTsV6QHgURqjEX6oSvk\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 932,
    "path": "../public/assets/initialWorker-Cc4f1geA.js.br"
  },
  "/assets/initialWorker-Cc4f1geA.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"447-4xYac9U05iJoRQMY7MmTmdc+CVg\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 1095,
    "path": "../public/assets/initialWorker-Cc4f1geA.js.gz"
  },
  "/assets/initialWorker-Cc4f1geA.js.map": {
    "type": "application/json",
    "etag": "\"2236-ZDCItfYlIYRrzLkiDPAcPXUFvJg\"",
    "mtime": "2025-04-16T08:54:50.779Z",
    "size": 8758,
    "path": "../public/assets/initialWorker-Cc4f1geA.js.map"
  },
  "/assets/nodefs-LGIbJnh3.js.map": {
    "type": "application/json",
    "etag": "\"527-L4wNewFdfvDdRP0R98B0H5S813k\"",
    "mtime": "2025-04-16T08:54:50.779Z",
    "size": 1319,
    "path": "../public/assets/nodefs-LGIbJnh3.js.map"
  },
  "/assets/opfs-ahp-D7M8L902.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"ae3-sbieHv859E1Xxl+HFsmRWeaYHZk\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 2787,
    "path": "../public/assets/opfs-ahp-D7M8L902.js.br"
  },
  "/assets/opfs-ahp-D7M8L902.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"c0d-i5AcFHiddkSU9DnAXiJ70ob1foM\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 3085,
    "path": "../public/assets/opfs-ahp-D7M8L902.js.gz"
  },
  "/assets/opfs-ahp-D7M8L902.js.map": {
    "type": "application/json",
    "etag": "\"5fa4-3l4thWet9aMH6s/gvGhHq37SqEQ\"",
    "mtime": "2025-04-16T08:54:50.779Z",
    "size": 24484,
    "path": "../public/assets/opfs-ahp-D7M8L902.js.map"
  },
  "/assets/pg_trgm.tar-CUnu0XkG.gz": {
    "type": "text/plain; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"104fd-WsaPjGdQHb4QY9BEu0uK/WUdUAM\"",
    "mtime": "2025-04-16T08:54:50.779Z",
    "size": 66813,
    "path": "../public/assets/pg_trgm.tar-CUnu0XkG.gz"
  },
  "/assets/postgres-CkP7QCDB.data": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"526c95-lJxjLrWmf85THgb36V23e/arOxw\"",
    "mtime": "2025-04-16T08:54:50.779Z",
    "size": 5401749,
    "path": "../public/assets/postgres-CkP7QCDB.data"
  },
  "/assets/postgres-CkP7QCDB.data.br": {
    "type": "text/plain; charset=utf-8",
    "encoding": "br",
    "etag": "\"f9092-JXet2gFsRKbBn6ofhF3lz09VBSs\"",
    "mtime": "2025-04-16T08:55:26.835Z",
    "size": 1020050,
    "path": "../public/assets/postgres-CkP7QCDB.data.br"
  },
  "/assets/postgres-CkP7QCDB.data.gz": {
    "type": "text/plain; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"175dfb-uJJkYcJ9/tkeBwxxU8L/FHmLVK4\"",
    "mtime": "2025-04-16T08:55:27.534Z",
    "size": 1531387,
    "path": "../public/assets/postgres-CkP7QCDB.data.gz"
  },
  "/assets/postgres-CyuUVpXN.wasm": {
    "type": "application/wasm",
    "etag": "\"7b746e-/KD270APleSKl3yPAnPB1+qpHLY\"",
    "mtime": "2025-04-16T08:54:50.779Z",
    "size": 8090734,
    "path": "../public/assets/postgres-CyuUVpXN.wasm"
  },
  "/assets/postgres-CyuUVpXN.wasm.br": {
    "type": "application/wasm",
    "encoding": "br",
    "etag": "\"208c72-60cpR2n87V/DYDUBZzLBybxHodo\"",
    "mtime": "2025-04-16T08:55:38.132Z",
    "size": 2133106,
    "path": "../public/assets/postgres-CyuUVpXN.wasm.br"
  },
  "/assets/postgres-CyuUVpXN.wasm.gz": {
    "type": "application/wasm",
    "encoding": "gzip",
    "etag": "\"2a5bf3-4VFWj+cTRy6hgNRypBzaoiBq5ds\"",
    "mtime": "2025-04-16T08:55:28.168Z",
    "size": 2776051,
    "path": "../public/assets/postgres-CyuUVpXN.wasm.gz"
  },
  "/assets/user-BatkDO93.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"17e-HDTABibhUT/jpdbIwZoNxFBPrD4\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 382,
    "path": "../public/assets/user-BatkDO93.js.br"
  },
  "/assets/user-BatkDO93.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1bb-Pu/w23wZvwcWHpavUISxPrbw+u4\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 443,
    "path": "../public/assets/user-BatkDO93.js.gz"
  },
  "/assets/user-BatkDO93.js.map": {
    "type": "application/json",
    "etag": "\"2bfe-ADHGHK6EI4JDpFl6LKbGFF1YPag\"",
    "mtime": "2025-04-16T08:54:50.779Z",
    "size": 11262,
    "path": "../public/assets/user-BatkDO93.js.map"
  },
  "/icons/128.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"1083e-GtlL44NhBY6jAOUJOJfpOQqU/Vk\"",
    "mtime": "2025-04-16T08:54:50.742Z",
    "size": 67646,
    "path": "../public/icons/128.ico"
  },
  "/icons/128.png": {
    "type": "image/png",
    "etag": "\"a53-4Mwemb9Qr/9x064WXh4lo0nTCVc\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 2643,
    "path": "../public/icons/128.png"
  },
  "/icons/144.png": {
    "type": "image/png",
    "etag": "\"b97-C8Co2GuXlvATK7UpEFVF/v9A1yo\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 2967,
    "path": "../public/icons/144.png"
  },
  "/icons/152.png": {
    "type": "image/png",
    "etag": "\"c2a-hsAht4s2Ij5szDloGmulvMVJ/O8\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 3114,
    "path": "../public/icons/152.png"
  },
  "/icons/192.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"2523e-NTDkR3y9RvuC5XdNJcye5oFcEHs\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 152126,
    "path": "../public/icons/192.ico"
  },
  "/icons/192.png": {
    "type": "image/png",
    "etag": "\"f3a-87Bya6xmuvix/ajN3S2uLyl4ofQ\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 3898,
    "path": "../public/icons/192.png"
  },
  "/icons/256.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"25db-LXsWa9bNlXYJBkNd+mwAbfW2WmY\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 9691,
    "path": "../public/icons/256.ico"
  },
  "/icons/32.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"10be-dsBKrA2O6OIStr+XagiqiVB1UIA\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 4286,
    "path": "../public/icons/32.ico"
  },
  "/icons/384.png": {
    "type": "image/png",
    "etag": "\"1e93-gdGbIJm2GjauxMPZ29BMh6g4pCM\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 7827,
    "path": "../public/icons/384.png"
  },
  "/icons/48.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"25be-1FJ7sdM9GEG4Pw1Cqa56dWcjtCI\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 9662,
    "path": "../public/icons/48.ico"
  },
  "/icons/48.png": {
    "type": "image/png",
    "etag": "\"42a-mm9nsS2kMwbGBvP5nnSswpihyak\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 1066,
    "path": "../public/icons/48.png"
  },
  "/icons/512.png": {
    "type": "image/png",
    "etag": "\"2749-rQEbDesWO7dcprMBsONIeqb/eeI\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 10057,
    "path": "../public/icons/512.png"
  },
  "/icons/72.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"549e-o/wymQqUzgOJVvBTLLSCLkegKm8\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 21662,
    "path": "../public/icons/72.ico"
  },
  "/icons/72.png": {
    "type": "image/png",
    "etag": "\"5f8-ADUy3KAGc4X43/MovIVwQml44RU\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 1528,
    "path": "../public/icons/72.png"
  },
  "/icons/96.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"94be-PCffdMCYCB+WrmHi5sjjekg6I0I\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 38078,
    "path": "../public/icons/96.ico"
  },
  "/icons/96.png": {
    "type": "image/png",
    "etag": "\"7d6-l9rG6730Qx9X28w82vl+nkFhXtw\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 2006,
    "path": "../public/icons/96.png"
  },
  "/models/bg.blend": {
    "type": "application/x-blender",
    "etag": "\"dd7d4-VBcm720w0H1D53JcnmZGg43WAK8\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 907220,
    "path": "../public/models/bg.blend"
  },
  "/models/bg.blend1": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"cb610-OvhHftiSp4z1LVdJy74spzTUmYQ\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 833040,
    "path": "../public/models/bg.blend1"
  },
  "/models/bg.blend1.br": {
    "type": "text/plain; charset=utf-8",
    "encoding": "br",
    "etag": "\"135dd-HZ4szAg2NYPnMDUAZLPQCRjIrB0\"",
    "mtime": "2025-04-16T08:54:54.528Z",
    "size": 79325,
    "path": "../public/models/bg.blend1.br"
  },
  "/models/bg.blend1.gz": {
    "type": "text/plain; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"19340-8/orZ6SJg0uYAPhn4j/SirZTIRk\"",
    "mtime": "2025-04-16T08:54:54.937Z",
    "size": 103232,
    "path": "../public/models/bg.blend1.gz"
  },
  "/models/bg.glb": {
    "type": "model/gltf-binary",
    "etag": "\"a34-pTrDsiMBFTivxA98zfabFIXIAAI\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 2612,
    "path": "../public/models/bg.glb"
  },
  "/models/bg0.glb": {
    "type": "model/gltf-binary",
    "etag": "\"dc0-GODWyd0A4fJlFO0111ZjdIh8BPU\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 3520,
    "path": "../public/models/bg0.glb"
  },
  "/models/bg1.glb": {
    "type": "model/gltf-binary",
    "etag": "\"11b68-huJG1qBkPYenImtiE8oDvy/vjRs\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 72552,
    "path": "../public/models/bg1.glb"
  },
  "/models/landscape.glb": {
    "type": "model/gltf-binary",
    "etag": "\"63db40-4pjorkQm8MpdRa2KCO5Aetqp1iM\"",
    "mtime": "2025-04-16T08:54:50.761Z",
    "size": 6544192,
    "path": "../public/models/landscape.glb"
  },
  "/models/rocket.glb": {
    "type": "model/gltf-binary",
    "etag": "\"3add94-bR72bxRLNNM3yKcf3TV47hRA0Cw\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 3857812,
    "path": "../public/models/rocket.glb"
  },
  "/models/scene.bin": {
    "type": "application/octet-stream",
    "etag": "\"244610-YzlzQV5Z6uzYHaIvj1fXJHKZKbU\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 2377232,
    "path": "../public/models/scene.bin"
  },
  "/models/scene.gltf": {
    "type": "model/gltf+json",
    "etag": "\"d739-DNHz1cenhq3FEYSMtjGLsSqcq4I\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 55097,
    "path": "../public/models/scene.gltf"
  },
  "/models/火箭.blend": {
    "type": "application/x-blender",
    "etag": "\"59cc7c-SEltsWKLRXp27pwkpjQG2CIglAk\"",
    "mtime": "2025-04-16T08:54:50.761Z",
    "size": 5885052,
    "path": "../public/models/火箭.blend"
  },
  "/_build/.vite/manifest.json": {
    "type": "application/json",
    "etag": "\"105df-sON6fZrfWRt/YlEgtIP7XJWSQ1Y\"",
    "mtime": "2025-04-16T08:54:50.909Z",
    "size": 67039,
    "path": "../public/_build/.vite/manifest.json"
  },
  "/_build/.vite/manifest.json.br": {
    "type": "application/json",
    "encoding": "br",
    "etag": "\"fb9-dpEtgSPMtXMBJR7dllifTIg4myM\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 4025,
    "path": "../public/_build/.vite/manifest.json.br"
  },
  "/_build/.vite/manifest.json.gz": {
    "type": "application/json",
    "encoding": "gzip",
    "etag": "\"12c4-oiz/0JoWRmIwJ7rVz+3VN3ecOlQ\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 4804,
    "path": "../public/_build/.vite/manifest.json.gz"
  },
  "/_server/assets/PGlite.worker-DGOWxXuD.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1c0c2-XNNYQrzhmS9ofefHzYKkaFPROuA\"",
    "mtime": "2025-04-16T08:54:58.835Z",
    "size": 114882,
    "path": "../public/_server/assets/PGlite.worker-DGOWxXuD.js.br"
  },
  "/_server/assets/PGlite.worker-DGOWxXuD.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2341c-Uc6n8BRRCaS2zg4Cjalcs+VL7uI\"",
    "mtime": "2025-04-16T08:54:58.807Z",
    "size": 144412,
    "path": "../public/_server/assets/PGlite.worker-DGOWxXuD.js.gz"
  },
  "/_server/assets/PGlite.worker-DGOWxXuD.js.map": {
    "type": "application/json",
    "etag": "\"184d63-ZrriAxF9NLM69pXPasFp+wl0n/c\"",
    "mtime": "2025-04-16T08:54:50.984Z",
    "size": 1592675,
    "path": "../public/_server/assets/PGlite.worker-DGOWxXuD.js.map"
  },
  "/_server/assets/__vite-browser-external-9wXp6ZBx.js.map": {
    "type": "application/json",
    "etag": "\"ce-qwnyo3qSPkU7CXm3MQOvrH54YVo\"",
    "mtime": "2025-04-16T08:54:50.984Z",
    "size": 206,
    "path": "../public/_server/assets/__vite-browser-external-9wXp6ZBx.js.map"
  },
  "/_server/assets/app-DK5u2c7Z.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1427-Dcp6mDYW0drVE7SdAuh0fuZnwSo\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 5159,
    "path": "../public/_server/assets/app-DK5u2c7Z.js.br"
  },
  "/_server/assets/app-DK5u2c7Z.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1633-GA962uD1QHMxcKXdMKmDkG7OgeU\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 5683,
    "path": "../public/_server/assets/app-DK5u2c7Z.js.gz"
  },
  "/_server/assets/app-DK5u2c7Z.js.map": {
    "type": "application/json",
    "etag": "\"12a28-0slqg4DaOllrhRCNvsD4cTgJ8xA\"",
    "mtime": "2025-04-16T08:54:50.984Z",
    "size": 76328,
    "path": "../public/_server/assets/app-DK5u2c7Z.js.map"
  },
  "/_server/assets/database-RW067y32.js.map": {
    "type": "application/json",
    "etag": "\"a26-ojWllu8wcfajC1MoJgkGMrCg/ng\"",
    "mtime": "2025-04-16T08:54:50.984Z",
    "size": 2598,
    "path": "../public/_server/assets/database-RW067y32.js.map"
  },
  "/_server/assets/dialect-D2JFOh1E.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"225-FdPs+1tlS5cerlwixW9II9GTvHM\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 549,
    "path": "../public/_server/assets/dialect-D2JFOh1E.js.br"
  },
  "/_server/assets/dialect-D2JFOh1E.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"271-/2Edkt864pTUrJtL58yrj+qnDrw\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 625,
    "path": "../public/_server/assets/dialect-D2JFOh1E.js.gz"
  },
  "/_server/assets/dialect-D2JFOh1E.js.map": {
    "type": "application/json",
    "etag": "\"190f-5f/jl/J4oxsV3teuw56Us09thBM\"",
    "mtime": "2025-04-16T08:54:50.984Z",
    "size": 6415,
    "path": "../public/_server/assets/dialect-D2JFOh1E.js.map"
  },
  "/_server/assets/http-Dfsrx3wX.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4a2-zYA0FtaIQuh6pPmv7ebFJBwNjw4\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 1186,
    "path": "../public/_server/assets/http-Dfsrx3wX.js.br"
  },
  "/_server/assets/http-Dfsrx3wX.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"53f-ITSP9q8oy5OB4Q/sLLYtExXlmcE\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 1343,
    "path": "../public/_server/assets/http-Dfsrx3wX.js.gz"
  },
  "/_server/assets/http-Dfsrx3wX.js.map": {
    "type": "application/json",
    "etag": "\"5277-C1dHK0EOgMYJxIr05UiPSZWRfxg\"",
    "mtime": "2025-04-16T08:54:50.984Z",
    "size": 21111,
    "path": "../public/_server/assets/http-Dfsrx3wX.js.map"
  },
  "/_server/assets/initialWorker-CH3MGkTl.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"394-YgwivkHh8Rd/WAM3aWTROzgVK3k\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 916,
    "path": "../public/_server/assets/initialWorker-CH3MGkTl.js.br"
  },
  "/_server/assets/initialWorker-CH3MGkTl.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"449-EvDs2db/onMZECk8RADO2h76UvI\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 1097,
    "path": "../public/_server/assets/initialWorker-CH3MGkTl.js.gz"
  },
  "/_server/assets/initialWorker-CH3MGkTl.js.map": {
    "type": "application/json",
    "etag": "\"223c-WGg0EEPwyu9tEnKNlSCTpewHmiQ\"",
    "mtime": "2025-04-16T08:54:50.984Z",
    "size": 8764,
    "path": "../public/_server/assets/initialWorker-CH3MGkTl.js.map"
  },
  "/_server/assets/nodefs-DMcTgmWp.js.map": {
    "type": "application/json",
    "etag": "\"527-x6EmBWCj6fAPpdhds0UiptDV2qY\"",
    "mtime": "2025-04-16T08:54:50.984Z",
    "size": 1319,
    "path": "../public/_server/assets/nodefs-DMcTgmWp.js.map"
  },
  "/_server/assets/opfs-ahp-BzUw8_oa.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"ae2-R3XVWwFcp5n/e2+zgs0UczWZiQY\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 2786,
    "path": "../public/_server/assets/opfs-ahp-BzUw8_oa.js.br"
  },
  "/_server/assets/opfs-ahp-BzUw8_oa.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"c0c-gOva76AVwtpw8RSBq/I40Mppoxg\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 3084,
    "path": "../public/_server/assets/opfs-ahp-BzUw8_oa.js.gz"
  },
  "/_server/assets/opfs-ahp-BzUw8_oa.js.map": {
    "type": "application/json",
    "etag": "\"5fa4-1n8mOe0yDNXGkfCxmS8QE2yNdj4\"",
    "mtime": "2025-04-16T08:54:50.984Z",
    "size": 24484,
    "path": "../public/_server/assets/opfs-ahp-BzUw8_oa.js.map"
  },
  "/_server/assets/pg_trgm.tar-CUnu0XkG.gz": {
    "type": "text/plain; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"104fd-WsaPjGdQHb4QY9BEu0uK/WUdUAM\"",
    "mtime": "2025-04-16T08:54:50.984Z",
    "size": 66813,
    "path": "../public/_server/assets/pg_trgm.tar-CUnu0XkG.gz"
  },
  "/_server/assets/postgres-CkP7QCDB.data": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"526c95-lJxjLrWmf85THgb36V23e/arOxw\"",
    "mtime": "2025-04-16T08:54:50.993Z",
    "size": 5401749,
    "path": "../public/_server/assets/postgres-CkP7QCDB.data"
  },
  "/_server/assets/postgres-CkP7QCDB.data.br": {
    "type": "text/plain; charset=utf-8",
    "encoding": "br",
    "etag": "\"f9092-JXet2gFsRKbBn6ofhF3lz09VBSs\"",
    "mtime": "2025-04-16T08:55:26.816Z",
    "size": 1020050,
    "path": "../public/_server/assets/postgres-CkP7QCDB.data.br"
  },
  "/_server/assets/postgres-CkP7QCDB.data.gz": {
    "type": "text/plain; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"175dfb-uJJkYcJ9/tkeBwxxU8L/FHmLVK4\"",
    "mtime": "2025-04-16T08:55:27.534Z",
    "size": 1531387,
    "path": "../public/_server/assets/postgres-CkP7QCDB.data.gz"
  },
  "/_server/assets/postgres-CyuUVpXN.wasm": {
    "type": "application/wasm",
    "etag": "\"7b746e-/KD270APleSKl3yPAnPB1+qpHLY\"",
    "mtime": "2025-04-16T08:54:50.993Z",
    "size": 8090734,
    "path": "../public/_server/assets/postgres-CyuUVpXN.wasm"
  },
  "/_server/assets/postgres-CyuUVpXN.wasm.br": {
    "type": "application/wasm",
    "encoding": "br",
    "etag": "\"208c72-60cpR2n87V/DYDUBZzLBybxHodo\"",
    "mtime": "2025-04-16T08:55:38.862Z",
    "size": 2133106,
    "path": "../public/_server/assets/postgres-CyuUVpXN.wasm.br"
  },
  "/_server/assets/postgres-CyuUVpXN.wasm.gz": {
    "type": "application/wasm",
    "encoding": "gzip",
    "etag": "\"2a5bf3-4VFWj+cTRy6hgNRypBzaoiBq5ds\"",
    "mtime": "2025-04-16T08:55:28.168Z",
    "size": 2776051,
    "path": "../public/_server/assets/postgres-CyuUVpXN.wasm.gz"
  },
  "/_server/assets/server-fns-BczFCVeQ.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"392d-XELYzCHUois8utFOjlfi32SERUI\"",
    "mtime": "2025-04-16T08:54:54.361Z",
    "size": 14637,
    "path": "../public/_server/assets/server-fns-BczFCVeQ.js.br"
  },
  "/_server/assets/server-fns-BczFCVeQ.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"4060-zk9k24Qgqyt6QwYdmo5V1HeZ1zU\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 16480,
    "path": "../public/_server/assets/server-fns-BczFCVeQ.js.gz"
  },
  "/_server/assets/server-fns-BczFCVeQ.js.map": {
    "type": "application/json",
    "etag": "\"2e4b6-J35nO4oKaVVSYYe1uKrqXxbfUZ0\"",
    "mtime": "2025-04-16T08:54:50.984Z",
    "size": 189622,
    "path": "../public/_server/assets/server-fns-BczFCVeQ.js.map"
  },
  "/_server/assets/session-gJxBGr18.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"290-jYHNbuyDPqMXWC8ZDQqgPa38YP0\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 656,
    "path": "../public/_server/assets/session-gJxBGr18.js.br"
  },
  "/_server/assets/session-gJxBGr18.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2f1-kr8oVe08mljnyTY2jTYoUMu3Lj4\"",
    "mtime": "2025-04-16T08:54:54.352Z",
    "size": 753,
    "path": "../public/_server/assets/session-gJxBGr18.js.gz"
  },
  "/_server/assets/session-gJxBGr18.js.map": {
    "type": "application/json",
    "etag": "\"104a-27QAZFeu53Z5B4PmPRM96O8mE+w\"",
    "mtime": "2025-04-16T08:54:50.984Z",
    "size": 4170,
    "path": "../public/_server/assets/session-gJxBGr18.js.map"
  },
  "/_server/assets/user-BNai-P02.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1bf-IwuXKJk8PXTWkKZPZ78IWQyD0H8\"",
    "mtime": "2025-04-16T08:54:54.361Z",
    "size": 447,
    "path": "../public/_server/assets/user-BNai-P02.js.br"
  },
  "/_server/assets/user-BNai-P02.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"207-UQpAcDldmnLa/Oz9T9YXHokuqJM\"",
    "mtime": "2025-04-16T08:54:54.361Z",
    "size": 519,
    "path": "../public/_server/assets/user-BNai-P02.js.gz"
  },
  "/_server/assets/user-BNai-P02.js.map": {
    "type": "application/json",
    "etag": "\"2da3-khGwhhLlRRpQYainS60VucB1xew\"",
    "mtime": "2025-04-16T08:54:50.984Z",
    "size": 11683,
    "path": "../public/_server/assets/user-BNai-P02.js.map"
  },
  "/app-image/404/0.png": {
    "type": "image/png",
    "etag": "\"7427f-b5LZa5v/zzuHQf2Zm2xm6TqXidw\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 475775,
    "path": "../public/app-image/404/0.png"
  },
  "/app-image/404/1.png": {
    "type": "image/png",
    "etag": "\"6904-frjl/vUalXU0WjmtDxq/QCYtIZ8\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 26884,
    "path": "../public/app-image/404/1.png"
  },
  "/app-image/404/2.png": {
    "type": "image/png",
    "etag": "\"1d1a6-pbk9os+O/CeETeSGWsYIj2TXuyk\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 119206,
    "path": "../public/app-image/404/2.png"
  },
  "/app-image/404/3.png": {
    "type": "image/png",
    "etag": "\"4c0c0-o+jJINyJs4BdNT4cFZuzEYHUEGo\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 311488,
    "path": "../public/app-image/404/3.png"
  },
  "/_build/assets/(app)-BQcXoKzi.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"187c66-95T55O6bEi1nZpUzkpt6Qeisg1Y\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 1604710,
    "path": "../public/_build/assets/(app)-BQcXoKzi.js"
  },
  "/_build/assets/(app)-BQcXoKzi.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4d500-iv3A+k3Q1iacNq/y7Nh2EHIxnJU\"",
    "mtime": "2025-04-16T08:55:25.722Z",
    "size": 316672,
    "path": "../public/_build/assets/(app)-BQcXoKzi.js.br"
  },
  "/_build/assets/(app)-BQcXoKzi.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"62da1-HjvQwhPVddNokqDBeQoHtX0rl0Q\"",
    "mtime": "2025-04-16T08:55:25.685Z",
    "size": 404897,
    "path": "../public/_build/assets/(app)-BQcXoKzi.js.gz"
  },
  "/_build/assets/(app)-BQcXoKzi.js.map": {
    "type": "application/json",
    "etag": "\"6a7893-NAAZPyUGBsMg+ik/yQemSG5+ypY\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 6977683,
    "path": "../public/_build/assets/(app)-BQcXoKzi.js.map"
  },
  "/_build/assets/(app)-C1swXDvZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1e7-FO4ca1vO1jn1esEWLSsVJJnQB2U\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 487,
    "path": "../public/_build/assets/(app)-C1swXDvZ.js"
  },
  "/_build/assets/(app)-C1swXDvZ.js.map": {
    "type": "application/json",
    "etag": "\"62-9E/TOPgTnYgv11z9NPJ9INSMQFQ\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 98,
    "path": "../public/_build/assets/(app)-C1swXDvZ.js.map"
  },
  "/_build/assets/(character)-BQOdHxo5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"290-oUj1HeIruYj9rOD8uo1an1vwlFg\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 656,
    "path": "../public/_build/assets/(character)-BQOdHxo5.js"
  },
  "/_build/assets/(character)-BQOdHxo5.js.map": {
    "type": "application/json",
    "etag": "\"637-vuPx0sCQOHjnr5+Adi7dVOwIwlc\"",
    "mtime": "2025-04-16T08:54:50.909Z",
    "size": 1591,
    "path": "../public/_build/assets/(character)-BQOdHxo5.js.map"
  },
  "/_build/assets/(functionPage)-BskoJHmw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2098-4QghpFmPgnW0SgEhByQLjwbN4Qg\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 8344,
    "path": "../public/_build/assets/(functionPage)-BskoJHmw.js"
  },
  "/_build/assets/(functionPage)-BskoJHmw.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"9c7-PFNUu9tFFrd7y6/iC0PC5Jpr7Xs\"",
    "mtime": "2025-04-16T08:54:54.361Z",
    "size": 2503,
    "path": "../public/_build/assets/(functionPage)-BskoJHmw.js.br"
  },
  "/_build/assets/(functionPage)-BskoJHmw.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"b06-eQpFX5WwRntIE6nYZwyFRKmT/Pk\"",
    "mtime": "2025-04-16T08:54:54.361Z",
    "size": 2822,
    "path": "../public/_build/assets/(functionPage)-BskoJHmw.js.gz"
  },
  "/_build/assets/(functionPage)-BskoJHmw.js.map": {
    "type": "application/json",
    "etag": "\"57d0-70dFO7V/LQ4oBzKdQcS3UbMXsag\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 22480,
    "path": "../public/_build/assets/(functionPage)-BskoJHmw.js.map"
  },
  "/_build/assets/(mob)-DZ4B4ONG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"17415-POEY9gehebcz6TMBEr1zYm+ioQ8\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 95253,
    "path": "../public/_build/assets/(mob)-DZ4B4ONG.js"
  },
  "/_build/assets/(mob)-DZ4B4ONG.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5d65-OmIg8zAGdOT9sXI2iBU01xolwRw\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 23909,
    "path": "../public/_build/assets/(mob)-DZ4B4ONG.js.br"
  },
  "/_build/assets/(mob)-DZ4B4ONG.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6bc5-JbUUYTp4BQhJrwwqOc/THNM2Tdw\"",
    "mtime": "2025-04-16T08:54:54.417Z",
    "size": 27589,
    "path": "../public/_build/assets/(mob)-DZ4B4ONG.js.gz"
  },
  "/_build/assets/(mob)-DZ4B4ONG.js.map": {
    "type": "application/json",
    "etag": "\"46c83-kKeSljuqpcqG+/kn48KJ/1fBw+Y\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 289923,
    "path": "../public/_build/assets/(mob)-DZ4B4ONG.js.map"
  },
  "/_build/assets/(pet)-CYB2UBTx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1d1-Daycw7+seCGrDtyOg5+MlGaxM0A\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 465,
    "path": "../public/_build/assets/(pet)-CYB2UBTx.js"
  },
  "/_build/assets/(pet)-CYB2UBTx.js.map": {
    "type": "application/json",
    "etag": "\"4cd-tSr60UAu3f1ZnjzSo8TSui42zsU\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 1229,
    "path": "../public/_build/assets/(pet)-CYB2UBTx.js.map"
  },
  "/_build/assets/(profile)-CuQvSt6a.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"523-W8ak2pU8eaUBxCOlQsW9KyYgiXM\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 1315,
    "path": "../public/_build/assets/(profile)-CuQvSt6a.js"
  },
  "/_build/assets/(profile)-CuQvSt6a.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"27c-zRG2Y9CSjonxPZB9HiNtTcrFWpA\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 636,
    "path": "../public/_build/assets/(profile)-CuQvSt6a.js.br"
  },
  "/_build/assets/(profile)-CuQvSt6a.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2e6-5KdlzsZk0AvlSlZrugYJnFSWaHg\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 742,
    "path": "../public/_build/assets/(profile)-CuQvSt6a.js.gz"
  },
  "/_build/assets/(profile)-CuQvSt6a.js.map": {
    "type": "application/json",
    "etag": "\"df1-lxVafBC+lYDZI2LR678EFOa+xfw\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 3569,
    "path": "../public/_build/assets/(profile)-CuQvSt6a.js.map"
  },
  "/_build/assets/(skill)-BCqofgzE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1449-qaPC4D+yW35zFLYwFomV/PIo5Rk\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 5193,
    "path": "../public/_build/assets/(skill)-BCqofgzE.js"
  },
  "/_build/assets/(skill)-BCqofgzE.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"751-ROx+wRGKiSlN9C/9eP5QnJvtaDs\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1873,
    "path": "../public/_build/assets/(skill)-BCqofgzE.js.br"
  },
  "/_build/assets/(skill)-BCqofgzE.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"860-JuW4d8SW+jSZWjPY2hjQTmcGi18\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 2144,
    "path": "../public/_build/assets/(skill)-BCqofgzE.js.gz"
  },
  "/_build/assets/(skill)-BCqofgzE.js.map": {
    "type": "application/json",
    "etag": "\"4212-BhFMOy6gxoaz2w1moQeqKS411Po\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 16914,
    "path": "../public/_build/assets/(skill)-BCqofgzE.js.map"
  },
  "/_build/assets/(wiki)-9Vn9r_TC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1bc-/JGdnrB+vhyQfC8FeTyCQKpMzbM\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 444,
    "path": "../public/_build/assets/(wiki)-9Vn9r_TC.js"
  },
  "/_build/assets/(wiki)-9Vn9r_TC.js.map": {
    "type": "application/json",
    "etag": "\"4e5-BVi0bj2rKk/nb4DUCsaqwWs6BCs\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 1253,
    "path": "../public/_build/assets/(wiki)-9Vn9r_TC.js.map"
  },
  "/_build/assets/512-DTiyhobg.png": {
    "type": "image/png",
    "etag": "\"2749-rQEbDesWO7dcprMBsONIeqb/eeI\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 10057,
    "path": "../public/_build/assets/512-DTiyhobg.png"
  },
  "/_build/assets/Media-BgKXkKGj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9c-iBIV0snK6sqL89Hl/86new8piV0\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 156,
    "path": "../public/_build/assets/Media-BgKXkKGj.js"
  },
  "/_build/assets/Media-BgKXkKGj.js.map": {
    "type": "application/json",
    "etag": "\"22a-OoTRTetpFvvWyEqwyVLzxfJT4SE\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 554,
    "path": "../public/_build/assets/Media-BgKXkKGj.js.map"
  },
  "/_build/assets/OverlayScrollbarsComponent-D4buOMT4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"62a-Q90xwZZzIlJ7OzjaiHRaik9d+/s\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 1578,
    "path": "../public/_build/assets/OverlayScrollbarsComponent-D4buOMT4.js"
  },
  "/_build/assets/OverlayScrollbarsComponent-D4buOMT4.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2ec-1EoPIZGITBKAb5FifsuVNj0d704\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 748,
    "path": "../public/_build/assets/OverlayScrollbarsComponent-D4buOMT4.js.br"
  },
  "/_build/assets/OverlayScrollbarsComponent-D4buOMT4.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"345-p9/YFmyIn5JgyYg1RaO9r8r41P4\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 837,
    "path": "../public/_build/assets/OverlayScrollbarsComponent-D4buOMT4.js.gz"
  },
  "/_build/assets/OverlayScrollbarsComponent-D4buOMT4.js.map": {
    "type": "application/json",
    "etag": "\"21fe-eX7/2alV3VAFKshVKKq6f87JpTQ\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 8702,
    "path": "../public/_build/assets/OverlayScrollbarsComponent-D4buOMT4.js.map"
  },
  "/_build/assets/PGlite.worker-CwyYoeB4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dff54-+HPiGBq5N7iRTO6FlwxNhsAI4uI\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 917332,
    "path": "../public/_build/assets/PGlite.worker-CwyYoeB4.js"
  },
  "/_build/assets/PGlite.worker-CwyYoeB4.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1c09e-BKcW6fNgLTQ1jRUxT+5v0MJPp+w\"",
    "mtime": "2025-04-16T08:55:25.243Z",
    "size": 114846,
    "path": "../public/_build/assets/PGlite.worker-CwyYoeB4.js.br"
  },
  "/_build/assets/PGlite.worker-CwyYoeB4.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"23417-VbBe28FJRPun8UzIX6unZnxB0Bk\"",
    "mtime": "2025-04-16T08:54:58.835Z",
    "size": 144407,
    "path": "../public/_build/assets/PGlite.worker-CwyYoeB4.js.gz"
  },
  "/_build/assets/PGlite.worker-CwyYoeB4.js.map": {
    "type": "application/json",
    "etag": "\"184d63-b8qPv+1TETas9RQMiVQ1RWaveCk\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 1592675,
    "path": "../public/_build/assets/PGlite.worker-CwyYoeB4.js.map"
  },
  "/_build/assets/_...404_-C8ob_eDs.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9ed-3HpKbKbhCl31y1Wcup40ykwkKKY\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 2541,
    "path": "../public/_build/assets/_...404_-C8ob_eDs.js"
  },
  "/_build/assets/_...404_-C8ob_eDs.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"35e-/RsjgsK/gnuCchmal5TBkMDDUrw\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 862,
    "path": "../public/_build/assets/_...404_-C8ob_eDs.js.br"
  },
  "/_build/assets/_...404_-C8ob_eDs.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3f9-QZv8+u8iW5Imd2SDu4JH2E1d3GQ\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1017,
    "path": "../public/_build/assets/_...404_-C8ob_eDs.js.gz"
  },
  "/_build/assets/_...404_-C8ob_eDs.js.map": {
    "type": "application/json",
    "etag": "\"1556-lvX0RIWu5cq4d0ugwze7YwobRVE\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 5462,
    "path": "../public/_build/assets/_...404_-C8ob_eDs.js.map"
  },
  "/_build/assets/___vite-browser-external_commonjs-proxy-BaOBqZBm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"fc-rdasmQoyQ9pJPsAcm1MW3LfW/JU\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 252,
    "path": "../public/_build/assets/___vite-browser-external_commonjs-proxy-BaOBqZBm.js"
  },
  "/_build/assets/___vite-browser-external_commonjs-proxy-BaOBqZBm.js.map": {
    "type": "application/json",
    "etag": "\"eb-DzhywXmJYwbNhSaMcq0A9/Y+3xw\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 235,
    "path": "../public/_build/assets/___vite-browser-external_commonjs-proxy-BaOBqZBm.js.map"
  },
  "/_build/assets/__vite-browser-external-9wXp6ZBx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5c-82epPpBgQT5SN3QqU5jKiL9pOtg\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 92,
    "path": "../public/_build/assets/__vite-browser-external-9wXp6ZBx.js"
  },
  "/_build/assets/__vite-browser-external-9wXp6ZBx.js.map": {
    "type": "application/json",
    "etag": "\"ce-qwnyo3qSPkU7CXm3MQOvrH54YVo\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 206,
    "path": "../public/_build/assets/__vite-browser-external-9wXp6ZBx.js.map"
  },
  "/_build/assets/_characterId_-Cxn0A_mx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2a3-idQCGnW0XBYJMfysLwVmUS1vFKU\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 675,
    "path": "../public/_build/assets/_characterId_-Cxn0A_mx.js"
  },
  "/_build/assets/_characterId_-Cxn0A_mx.js.map": {
    "type": "application/json",
    "etag": "\"642-7mKnmmO3kbpit4PU60GYE+Z6lDg\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 1602,
    "path": "../public/_build/assets/_characterId_-Cxn0A_mx.js.map"
  },
  "/_build/assets/animationGroup-BSSLStS5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8689-XqAYCprBTaofnf19bRtPzt4+8ss\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 34441,
    "path": "../public/_build/assets/animationGroup-BSSLStS5.js"
  },
  "/_build/assets/animationGroup-BSSLStS5.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1f77-sOUUAmlbpLWR5Kwxjx3U9+ACdCU\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 8055,
    "path": "../public/_build/assets/animationGroup-BSSLStS5.js.br"
  },
  "/_build/assets/animationGroup-BSSLStS5.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"227f-IKGDfqCd+jsnzxhV40aUkIlEDnY\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 8831,
    "path": "../public/_build/assets/animationGroup-BSSLStS5.js.gz"
  },
  "/_build/assets/animationGroup-BSSLStS5.js.map": {
    "type": "application/json",
    "etag": "\"26a2c-1boM7q4Gewh9HMyqyhGTBiLxJC4\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 158252,
    "path": "../public/_build/assets/animationGroup-BSSLStS5.js.map"
  },
  "/_build/assets/basisTextureLoader-BI9kl61O.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"216a-zBo8i0nEmv4j+XyB4FY/Dkb+WsY\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 8554,
    "path": "../public/_build/assets/basisTextureLoader-BI9kl61O.js"
  },
  "/_build/assets/basisTextureLoader-BI9kl61O.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"c0c-oIz00uhMC5Ldq8xq6Sv885su7iY\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 3084,
    "path": "../public/_build/assets/basisTextureLoader-BI9kl61O.js.br"
  },
  "/_build/assets/basisTextureLoader-BI9kl61O.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"d6d-IpzkLG6uyNu83opa013LKpHOsN0\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 3437,
    "path": "../public/_build/assets/basisTextureLoader-BI9kl61O.js.gz"
  },
  "/_build/assets/basisTextureLoader-BI9kl61O.js.map": {
    "type": "application/json",
    "etag": "\"9f40-S2UqiyqHSY48s5jdEe6+SyuGGi4\"",
    "mtime": "2025-04-16T08:54:50.928Z",
    "size": 40768,
    "path": "../public/_build/assets/basisTextureLoader-BI9kl61O.js.map"
  },
  "/_build/assets/button-CwbqJzx-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"118cd-YcA212jj9e7xrt2mUrzrPHXYIR0\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 71885,
    "path": "../public/_build/assets/button-CwbqJzx-.js"
  },
  "/_build/assets/button-CwbqJzx-.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3ad9-zfMbo/MOeP0oRZNK30AJJrnM03g\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 15065,
    "path": "../public/_build/assets/button-CwbqJzx-.js.br"
  },
  "/_build/assets/button-CwbqJzx-.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"45f8-v6snhilh/VXefnOzdjT/8kl2uqE\"",
    "mtime": "2025-04-16T08:54:54.417Z",
    "size": 17912,
    "path": "../public/_build/assets/button-CwbqJzx-.js.gz"
  },
  "/_build/assets/button-CwbqJzx-.js.map": {
    "type": "application/json",
    "etag": "\"19a16-7ZG4HVrLCkOcO73+RA/ZVplVq90\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 104982,
    "path": "../public/_build/assets/button-CwbqJzx-.js.map"
  },
  "/_build/assets/character-COjYLq76.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e80-ckBWnZzXSFodRs+zMIWP9I4IqUI\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 3712,
    "path": "../public/_build/assets/character-COjYLq76.js"
  },
  "/_build/assets/character-COjYLq76.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2a0-nv9a1iDVpfhPQLE91CgBDvbWiuc\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 672,
    "path": "../public/_build/assets/character-COjYLq76.js.br"
  },
  "/_build/assets/character-COjYLq76.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"309-KskejrtJFs1PpA0E75H+FyebRM4\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 777,
    "path": "../public/_build/assets/character-COjYLq76.js.gz"
  },
  "/_build/assets/character-COjYLq76.js.map": {
    "type": "application/json",
    "etag": "\"d209-k8e6Dcuw9r0qJgaLe+dA4HIJo5M\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 53769,
    "path": "../public/_build/assets/character-COjYLq76.js.map"
  },
  "/_build/assets/client-D8qH7JAh.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"f970-vmOkt4wSPhDI9dvAbHiNrpqjDi8\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 63856,
    "path": "../public/_build/assets/client-D8qH7JAh.css"
  },
  "/_build/assets/client-D8qH7JAh.css.br": {
    "type": "text/css; charset=utf-8",
    "encoding": "br",
    "etag": "\"2a96-NwqpvOUJZTW5Rw2MH5J504YRFAM\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 10902,
    "path": "../public/_build/assets/client-D8qH7JAh.css.br"
  },
  "/_build/assets/client-D8qH7JAh.css.gz": {
    "type": "text/css; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"314c-gnUuWsPVE/8OAsVk4aeZub2IXjY\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 12620,
    "path": "../public/_build/assets/client-D8qH7JAh.css.gz"
  },
  "/_build/assets/client-TFvGbaZz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"52c1-LN9dPkhBx4U+UbEIfW4HN3BiFNY\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 21185,
    "path": "../public/_build/assets/client-TFvGbaZz.js"
  },
  "/_build/assets/client-TFvGbaZz.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"185a-K2Ad67DPjz8yplhf1TwBngJW3yY\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 6234,
    "path": "../public/_build/assets/client-TFvGbaZz.js.br"
  },
  "/_build/assets/client-TFvGbaZz.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1b1d-qU+iHTtsJRNZW1XVKcV56Uxg+k8\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 6941,
    "path": "../public/_build/assets/client-TFvGbaZz.js.gz"
  },
  "/_build/assets/client-TFvGbaZz.js.map": {
    "type": "application/json",
    "etag": "\"152b7-ix9oBSBgq5oe5Qf4twPocb//scE\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 86711,
    "path": "../public/_build/assets/client-TFvGbaZz.js.map"
  },
  "/_build/assets/clipPlaneFragment-BkQQ1GyC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4ee-fzu/nkqjCNIEFTy8MqpHHKioQlA\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1262,
    "path": "../public/_build/assets/clipPlaneFragment-BkQQ1GyC.js"
  },
  "/_build/assets/clipPlaneFragment-BkQQ1GyC.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"130-pBVB3z/zxCOyohhgBJuy8GSLAc0\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 304,
    "path": "../public/_build/assets/clipPlaneFragment-BkQQ1GyC.js.br"
  },
  "/_build/assets/clipPlaneFragment-BkQQ1GyC.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"173-XxoZ0ntS7uq2zIUPcjD+use4/sA\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 371,
    "path": "../public/_build/assets/clipPlaneFragment-BkQQ1GyC.js.gz"
  },
  "/_build/assets/clipPlaneFragment-BkQQ1GyC.js.map": {
    "type": "application/json",
    "etag": "\"a7d-wx04W8KXkTI2KE/NqfVQVXOCmpc\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2685,
    "path": "../public/_build/assets/clipPlaneFragment-BkQQ1GyC.js.map"
  },
  "/_build/assets/clipPlaneVertex-De8KeaKc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2598-AlknZM7BFLryZS5L8iR7f1addPk\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 9624,
    "path": "../public/_build/assets/clipPlaneVertex-De8KeaKc.js"
  },
  "/_build/assets/clipPlaneVertex-De8KeaKc.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"59e-iJ6K+BUymhCOnSzoEOgA6Ejb7+U\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1438,
    "path": "../public/_build/assets/clipPlaneVertex-De8KeaKc.js.br"
  },
  "/_build/assets/clipPlaneVertex-De8KeaKc.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"68a-1XoFhl4V2DaNsItJXkwJx8fax1Q\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1674,
    "path": "../public/_build/assets/clipPlaneVertex-De8KeaKc.js.gz"
  },
  "/_build/assets/clipPlaneVertex-De8KeaKc.js.map": {
    "type": "application/json",
    "etag": "\"3851-eB/1BiAIWmVRRLyTcYPSY91LWt8\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 14417,
    "path": "../public/_build/assets/clipPlaneVertex-De8KeaKc.js.map"
  },
  "/_build/assets/color.fragment-BcSMXLut.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"49b-9RHvkv8Qh0gBYMRcc+x0G5PTV74\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1179,
    "path": "../public/_build/assets/color.fragment-BcSMXLut.js"
  },
  "/_build/assets/color.fragment-BcSMXLut.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"204-j49SKb2bsh5Ob1AIoZS4vsxhe18\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 516,
    "path": "../public/_build/assets/color.fragment-BcSMXLut.js.br"
  },
  "/_build/assets/color.fragment-BcSMXLut.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"24f-bDX/TPwzaMeAiiP7wWRvEBNMjso\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 591,
    "path": "../public/_build/assets/color.fragment-BcSMXLut.js.gz"
  },
  "/_build/assets/color.fragment-BcSMXLut.js.map": {
    "type": "application/json",
    "etag": "\"679-SxL1pNWS0+/be3+zWwT7tsNpBQU\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1657,
    "path": "../public/_build/assets/color.fragment-BcSMXLut.js.map"
  },
  "/_build/assets/color.fragment-DcIs4BP6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"527-dfo12zNbRxhf7kcif7zQTdeDXj4\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1319,
    "path": "../public/_build/assets/color.fragment-DcIs4BP6.js"
  },
  "/_build/assets/color.fragment-DcIs4BP6.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"225-DFyLHogdxerpOd5IWzBt++ZaLRY\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 549,
    "path": "../public/_build/assets/color.fragment-DcIs4BP6.js.br"
  },
  "/_build/assets/color.fragment-DcIs4BP6.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"27c-ZbGoekCCogIqq4QxFRmBj0W/G2A\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 636,
    "path": "../public/_build/assets/color.fragment-DcIs4BP6.js.gz"
  },
  "/_build/assets/color.fragment-DcIs4BP6.js.map": {
    "type": "application/json",
    "etag": "\"6f3-MKWRi3o5bVxxa7GsAyV0JY05BPI\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1779,
    "path": "../public/_build/assets/color.fragment-DcIs4BP6.js.map"
  },
  "/_build/assets/color.vertex-C-dZ-V7d.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"66f-xqARC8wPwDSbOJyKUIlPd2LYW4Q\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1647,
    "path": "../public/_build/assets/color.vertex-C-dZ-V7d.js"
  },
  "/_build/assets/color.vertex-C-dZ-V7d.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"28b-DjWXYUrbJykZ0ITWqY+yaJN9eSk\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 651,
    "path": "../public/_build/assets/color.vertex-C-dZ-V7d.js.br"
  },
  "/_build/assets/color.vertex-C-dZ-V7d.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2f0-paMnHwjc65KL3hdxipB1i2T0EqY\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 752,
    "path": "../public/_build/assets/color.vertex-C-dZ-V7d.js.gz"
  },
  "/_build/assets/color.vertex-C-dZ-V7d.js.map": {
    "type": "application/json",
    "etag": "\"a1e-x/mM9J5znwvZ1T+Lx6U6s5PSOok\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2590,
    "path": "../public/_build/assets/color.vertex-C-dZ-V7d.js.map"
  },
  "/_build/assets/color.vertex-Ima1XzTd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"675-jQcmJYPQ0B1tzaSdc0UP28da34M\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1653,
    "path": "../public/_build/assets/color.vertex-Ima1XzTd.js"
  },
  "/_build/assets/color.vertex-Ima1XzTd.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2ba-P4peHnsS+LMaqHck2Y3LVGoafU4\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 698,
    "path": "../public/_build/assets/color.vertex-Ima1XzTd.js.br"
  },
  "/_build/assets/color.vertex-Ima1XzTd.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2ff-LUsf1bC7n/Mi/F/ZXdLgnpMn7Lw\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 767,
    "path": "../public/_build/assets/color.vertex-Ima1XzTd.js.gz"
  },
  "/_build/assets/color.vertex-Ima1XzTd.js.map": {
    "type": "application/json",
    "etag": "\"9ba-6N12mWwscFG9no8UT97jQJiQYnw\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2490,
    "path": "../public/_build/assets/color.vertex-Ima1XzTd.js.map"
  },
  "/_build/assets/crystal-N5N_6jwz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"22a-2G8dMJl1YPDz0B8IP9i+QAX8smM\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 554,
    "path": "../public/_build/assets/crystal-N5N_6jwz.js"
  },
  "/_build/assets/crystal-N5N_6jwz.js.map": {
    "type": "application/json",
    "etag": "\"1471-fYC/+oGMD2eryyIj0NgPkrEqb3g\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 5233,
    "path": "../public/_build/assets/crystal-N5N_6jwz.js.map"
  },
  "/_build/assets/dds-Bel29An_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2579-C1F7+GJV7HUS0/XkzoLF8SSA1U0\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 9593,
    "path": "../public/_build/assets/dds-Bel29An_.js"
  },
  "/_build/assets/dds-Bel29An_.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"c9f-OZGv7ztNqkNqFX9R8e4WrT3j0jI\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 3231,
    "path": "../public/_build/assets/dds-Bel29An_.js.br"
  },
  "/_build/assets/dds-Bel29An_.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"e48-hAhvlYGMdNYdY2AJ2bOumFiWfbg\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 3656,
    "path": "../public/_build/assets/dds-Bel29An_.js.gz"
  },
  "/_build/assets/dds-Bel29An_.js.map": {
    "type": "application/json",
    "etag": "\"c98f-iuPF+VDEt2TXhNZxh1W4t/8hRzw\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 51599,
    "path": "../public/_build/assets/dds-Bel29An_.js.map"
  },
  "/_build/assets/ddsTextureLoader-KsoYTBhu.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6a1-5ykCsOuhGJAhs99bwV6DK6woNaI\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1697,
    "path": "../public/_build/assets/ddsTextureLoader-KsoYTBhu.js"
  },
  "/_build/assets/ddsTextureLoader-KsoYTBhu.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"301-tid1M7dyMP7m1XE0ti2WpzYekC4\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 769,
    "path": "../public/_build/assets/ddsTextureLoader-KsoYTBhu.js.br"
  },
  "/_build/assets/ddsTextureLoader-KsoYTBhu.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"347-HQ+TgF/Xd1N1FNy2XObzbtvY9Tk\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 839,
    "path": "../public/_build/assets/ddsTextureLoader-KsoYTBhu.js.gz"
  },
  "/_build/assets/ddsTextureLoader-KsoYTBhu.js.map": {
    "type": "application/json",
    "etag": "\"188d-IKWuUlvUCw4nRX8+kdoB+Az7aBk\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 6285,
    "path": "../public/_build/assets/ddsTextureLoader-KsoYTBhu.js.map"
  },
  "/_build/assets/default.fragment-BhpweL4x.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"579e-F5Zj0mZhAZlGODCcUMxjJOjVhpI\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 22430,
    "path": "../public/_build/assets/default.fragment-BhpweL4x.js"
  },
  "/_build/assets/default.fragment-BhpweL4x.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"11e7-0RAWKMR5XIuAO6OMe+tsgszAA8A\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 4583,
    "path": "../public/_build/assets/default.fragment-BhpweL4x.js.br"
  },
  "/_build/assets/default.fragment-BhpweL4x.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"13b0-YL1Xr3jOvApMT4oKsz6rcKfO0RA\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 5040,
    "path": "../public/_build/assets/default.fragment-BhpweL4x.js.gz"
  },
  "/_build/assets/default.fragment-BhpweL4x.js.map": {
    "type": "application/json",
    "etag": "\"6b2e-ddSNYnOwXiiI6shFe8WBvXJeYu4\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 27438,
    "path": "../public/_build/assets/default.fragment-BhpweL4x.js.map"
  },
  "/_build/assets/default.fragment-CmYItz2C.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5216-fYPkUZVluxClbBC9p+osjFuU4dU\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 21014,
    "path": "../public/_build/assets/default.fragment-CmYItz2C.js"
  },
  "/_build/assets/default.fragment-CmYItz2C.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"11e3-Vy0XZH8C8PIPdBD3yqBU65Ko4bo\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 4579,
    "path": "../public/_build/assets/default.fragment-CmYItz2C.js.br"
  },
  "/_build/assets/default.fragment-CmYItz2C.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"13dc-eubxve667YqZcln7HXa4HU313Os\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 5084,
    "path": "../public/_build/assets/default.fragment-CmYItz2C.js.gz"
  },
  "/_build/assets/default.fragment-CmYItz2C.js.map": {
    "type": "application/json",
    "etag": "\"69bd-0CukAIFJOJ8K0sE7PkltUj0u1G8\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 27069,
    "path": "../public/_build/assets/default.fragment-CmYItz2C.js.map"
  },
  "/_build/assets/default.vertex-BG7rHPQG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1f17-E9V4oPAEq9uQHtyQgJKoN5seCGs\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 7959,
    "path": "../public/_build/assets/default.vertex-BG7rHPQG.js"
  },
  "/_build/assets/default.vertex-BG7rHPQG.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"7b1-SltIerdArfN4mewYH9q/iM2XoWw\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1969,
    "path": "../public/_build/assets/default.vertex-BG7rHPQG.js.br"
  },
  "/_build/assets/default.vertex-BG7rHPQG.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"882-1sFomRbd7VHLJTIIbcsg87dYo0s\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 2178,
    "path": "../public/_build/assets/default.vertex-BG7rHPQG.js.gz"
  },
  "/_build/assets/default.vertex-BG7rHPQG.js.map": {
    "type": "application/json",
    "etag": "\"2b36-DWKZkwu8CU9UGAUjfbGb4iwTh0Q\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 11062,
    "path": "../public/_build/assets/default.vertex-BG7rHPQG.js.map"
  },
  "/_build/assets/default.vertex-xFdFxYIR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1ca3-Cao0aQVbj5BAzs4iFAeTvvwHs6Q\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 7331,
    "path": "../public/_build/assets/default.vertex-xFdFxYIR.js"
  },
  "/_build/assets/default.vertex-xFdFxYIR.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"70e-dhhaBs9xNNtCZDeR8vZZrSwduqU\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1806,
    "path": "../public/_build/assets/default.vertex-xFdFxYIR.js.br"
  },
  "/_build/assets/default.vertex-xFdFxYIR.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"7f8-nOytxKpMJE5wbtP4Arb3964bVco\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 2040,
    "path": "../public/_build/assets/default.vertex-xFdFxYIR.js.gz"
  },
  "/_build/assets/default.vertex-xFdFxYIR.js.map": {
    "type": "application/json",
    "etag": "\"29f1-SQemWKYfc8xLaqDHyxwgJbwEEdY\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 10737,
    "path": "../public/_build/assets/default.vertex-xFdFxYIR.js.map"
  },
  "/_build/assets/defaultUboDeclaration-B2iZi9ZV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"49e-Sy+kLNhI+siyRNG5w0MwRlZvA9Q\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1182,
    "path": "../public/_build/assets/defaultUboDeclaration-B2iZi9ZV.js"
  },
  "/_build/assets/defaultUboDeclaration-B2iZi9ZV.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1bf-S0KdIr39g9HDVvPtysVwGNBFNlg\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 447,
    "path": "../public/_build/assets/defaultUboDeclaration-B2iZi9ZV.js.br"
  },
  "/_build/assets/defaultUboDeclaration-B2iZi9ZV.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"206-ulWz/Hix+1PXyJHPQLY+KJmTzXw\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 518,
    "path": "../public/_build/assets/defaultUboDeclaration-B2iZi9ZV.js.gz"
  },
  "/_build/assets/defaultUboDeclaration-B2iZi9ZV.js.map": {
    "type": "application/json",
    "etag": "\"740-59EMATdSZBdT0t8VPIjHyvimbB4\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1856,
    "path": "../public/_build/assets/defaultUboDeclaration-B2iZi9ZV.js.map"
  },
  "/_build/assets/defaultUboDeclaration-CjpA1lw4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5f5-aIK8XDgvm68WBLGK4dVpdArlirA\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1525,
    "path": "../public/_build/assets/defaultUboDeclaration-CjpA1lw4.js"
  },
  "/_build/assets/defaultUboDeclaration-CjpA1lw4.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1bc-QRb4GuxedCl7ZeIwbFs+FazQgJg\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 444,
    "path": "../public/_build/assets/defaultUboDeclaration-CjpA1lw4.js.br"
  },
  "/_build/assets/defaultUboDeclaration-CjpA1lw4.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1f7-hdqTrkYjxL5Kfciw2WbOYfkYKYg\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 503,
    "path": "../public/_build/assets/defaultUboDeclaration-CjpA1lw4.js.gz"
  },
  "/_build/assets/defaultUboDeclaration-CjpA1lw4.js.map": {
    "type": "application/json",
    "etag": "\"897-XWHqhNhwUWXn/qVRAwIzfVBpxfs\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2199,
    "path": "../public/_build/assets/defaultUboDeclaration-CjpA1lw4.js.map"
  },
  "/_build/assets/depth.fragment-BzUT3H-M.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"69e-paRfpOatciYYWbBr2vxMwPYMJBg\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1694,
    "path": "../public/_build/assets/depth.fragment-BzUT3H-M.js"
  },
  "/_build/assets/depth.fragment-BzUT3H-M.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2ac-rEMKOSopSgMsQLRzsiHYTcM+6rI\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 684,
    "path": "../public/_build/assets/depth.fragment-BzUT3H-M.js.br"
  },
  "/_build/assets/depth.fragment-BzUT3H-M.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"309-3HsXy9piiTgpCwQintHCT2vbP9k\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 777,
    "path": "../public/_build/assets/depth.fragment-BzUT3H-M.js.gz"
  },
  "/_build/assets/depth.fragment-BzUT3H-M.js.map": {
    "type": "application/json",
    "etag": "\"8a4-PqZnpftmVt/damTCDvdKbYyUNwk\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2212,
    "path": "../public/_build/assets/depth.fragment-BzUT3H-M.js.map"
  },
  "/_build/assets/depth.vertex-zPU91nl3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9c6-UGtlI97dvYbmcqR89iQLzcmnbX4\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2502,
    "path": "../public/_build/assets/depth.vertex-zPU91nl3.js"
  },
  "/_build/assets/depth.vertex-zPU91nl3.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"36c-6d4seTsWk3CpkKXkEhW4RYpIAAs\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 876,
    "path": "../public/_build/assets/depth.vertex-zPU91nl3.js.br"
  },
  "/_build/assets/depth.vertex-zPU91nl3.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3dc-163T4w3U4NztIOpqnF3nLpCDqEQ\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 988,
    "path": "../public/_build/assets/depth.vertex-zPU91nl3.js.gz"
  },
  "/_build/assets/depth.vertex-zPU91nl3.js.map": {
    "type": "application/json",
    "etag": "\"dfe-NCDSywG9Cnirc8yjoLxevc1fH/U\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 3582,
    "path": "../public/_build/assets/depth.vertex-zPU91nl3.js.map"
  },
  "/_build/assets/depthBoxBlur.fragment-CZ1bTGnn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"481-sNeW44OOCqoD+2P4tLvxH0x3bBc\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1153,
    "path": "../public/_build/assets/depthBoxBlur.fragment-CZ1bTGnn.js"
  },
  "/_build/assets/depthBoxBlur.fragment-CZ1bTGnn.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"23a-/tWg7QJGdl8WkMOR831iL1FLWU0\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 570,
    "path": "../public/_build/assets/depthBoxBlur.fragment-CZ1bTGnn.js.br"
  },
  "/_build/assets/depthBoxBlur.fragment-CZ1bTGnn.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"283-e+rBi4jFrKQsod56DiS7Vi9JCms\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 643,
    "path": "../public/_build/assets/depthBoxBlur.fragment-CZ1bTGnn.js.gz"
  },
  "/_build/assets/depthBoxBlur.fragment-CZ1bTGnn.js.map": {
    "type": "application/json",
    "etag": "\"576-3WGSGvOO9xbJP5r62M9B6vqbRQM\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1398,
    "path": "../public/_build/assets/depthBoxBlur.fragment-CZ1bTGnn.js.map"
  },
  "/_build/assets/depthBoxBlur.fragment-hIZ7bqwb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3ce-pxo/ylpbFHURvoAZbWUB4sn1TrM\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 974,
    "path": "../public/_build/assets/depthBoxBlur.fragment-hIZ7bqwb.js"
  },
  "/_build/assets/depthBoxBlur.fragment-hIZ7bqwb.js.map": {
    "type": "application/json",
    "etag": "\"4b9-5j/GVSdIFN5D/aiocl+Y8xrTxwo\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1209,
    "path": "../public/_build/assets/depthBoxBlur.fragment-hIZ7bqwb.js.map"
  },
  "/_build/assets/dialect-DI_o0CUc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"60e-boD9uN3TdLx7fXoa+eGX0KHPf3s\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1550,
    "path": "../public/_build/assets/dialect-DI_o0CUc.js"
  },
  "/_build/assets/dialect-DI_o0CUc.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"25d-WutJgRA4hvV0M5rPFDCjVs8FV7w\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 605,
    "path": "../public/_build/assets/dialect-DI_o0CUc.js.br"
  },
  "/_build/assets/dialect-DI_o0CUc.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2b9-Lu1iA4rlXDRDr9TRtUcDCuEGlDE\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 697,
    "path": "../public/_build/assets/dialect-DI_o0CUc.js.gz"
  },
  "/_build/assets/dialect-DI_o0CUc.js.map": {
    "type": "application/json",
    "etag": "\"190f-74PXvqpKnJAo4B/GlVjkaIyHAyo\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 6415,
    "path": "../public/_build/assets/dialect-DI_o0CUc.js.map"
  },
  "/_build/assets/dialog-Cio2qlvj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6e3-VOJm+l3EUKxP7J+nW3Sxzus+CJ0\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1763,
    "path": "../public/_build/assets/dialog-Cio2qlvj.js"
  },
  "/_build/assets/dialog-Cio2qlvj.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2d9-eAo41crTC97hdllBbObffihtKeY\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 729,
    "path": "../public/_build/assets/dialog-Cio2qlvj.js.br"
  },
  "/_build/assets/dialog-Cio2qlvj.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"350-FjVNtJyjtp5YohlzJWCFwA3v74c\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 848,
    "path": "../public/_build/assets/dialog-Cio2qlvj.js.gz"
  },
  "/_build/assets/dialog-Cio2qlvj.js.map": {
    "type": "application/json",
    "etag": "\"10e6-dtZf7pvU22Msgyz3XM52YlGmrL4\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 4326,
    "path": "../public/_build/assets/dialog-Cio2qlvj.js.map"
  },
  "/_build/assets/dumpTools-DBZfhSG7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d88-O0YzX/5xk8frpW0SohVBkg0il1E\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 3464,
    "path": "../public/_build/assets/dumpTools-DBZfhSG7.js"
  },
  "/_build/assets/dumpTools-DBZfhSG7.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"592-Zf4th18KfZ5WVhSTCvM3/EMTwV4\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1426,
    "path": "../public/_build/assets/dumpTools-DBZfhSG7.js.br"
  },
  "/_build/assets/dumpTools-DBZfhSG7.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"617-DmVu2mp3qAP1QkiunmZ9RFO87PA\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1559,
    "path": "../public/_build/assets/dumpTools-DBZfhSG7.js.gz"
  },
  "/_build/assets/dumpTools-DBZfhSG7.js.map": {
    "type": "application/json",
    "etag": "\"334b-OSf7XjD4idoo/lupYqgrbwTWhZI\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 13131,
    "path": "../public/_build/assets/dumpTools-DBZfhSG7.js.map"
  },
  "/_build/assets/envTextureLoader-BpVV0IaR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1d4b-GfVXc1e3IbtsVw2z5DvHNVZRvfw\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 7499,
    "path": "../public/_build/assets/envTextureLoader-BpVV0IaR.js"
  },
  "/_build/assets/envTextureLoader-BpVV0IaR.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"b0b-zwwL425YXHpjE5NEt/9wFgSEdtI\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 2827,
    "path": "../public/_build/assets/envTextureLoader-BpVV0IaR.js.br"
  },
  "/_build/assets/envTextureLoader-BpVV0IaR.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"c3a-o7P7feVZQfjmsaEAYF/vfKMXU/o\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 3130,
    "path": "../public/_build/assets/envTextureLoader-BpVV0IaR.js.gz"
  },
  "/_build/assets/envTextureLoader-BpVV0IaR.js.map": {
    "type": "application/json",
    "etag": "\"ab7b-+hpTl9IH9TfwOEjVLVpRUaLuuSA\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 43899,
    "path": "../public/_build/assets/envTextureLoader-BpVV0IaR.js.map"
  },
  "/_build/assets/exrTextureLoader-qwxirmvS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3b73-F/t9ioYDO3NW2unRT2iNURZ9RVs\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 15219,
    "path": "../public/_build/assets/exrTextureLoader-qwxirmvS.js"
  },
  "/_build/assets/exrTextureLoader-qwxirmvS.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"14b8-zehSHmPQ7QTaFRytAeej9Mm6/Qw\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 5304,
    "path": "../public/_build/assets/exrTextureLoader-qwxirmvS.js.br"
  },
  "/_build/assets/exrTextureLoader-qwxirmvS.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"16d1-xEGe6pYBeGicd0UQhFFE2QaY6Ak\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 5841,
    "path": "../public/_build/assets/exrTextureLoader-qwxirmvS.js.gz"
  },
  "/_build/assets/exrTextureLoader-qwxirmvS.js.map": {
    "type": "application/json",
    "etag": "\"19589-2WyfsPlcXedzpl7KsOCjJu815I4\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 103817,
    "path": "../public/_build/assets/exrTextureLoader-qwxirmvS.js.map"
  },
  "/_build/assets/fogFragment-C3bm6_WD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"42a-nLqEuC0Sn/tcJlB4AuBkEHBfuVE\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1066,
    "path": "../public/_build/assets/fogFragment-C3bm6_WD.js"
  },
  "/_build/assets/fogFragment-C3bm6_WD.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1af-Z2k+P4Tdn7o+b+8+ZOulTQQjWPo\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 431,
    "path": "../public/_build/assets/fogFragment-C3bm6_WD.js.br"
  },
  "/_build/assets/fogFragment-C3bm6_WD.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"1e9-a45xacPXzs6y1AyoC+tTgnf0tZY\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 489,
    "path": "../public/_build/assets/fogFragment-C3bm6_WD.js.gz"
  },
  "/_build/assets/fogFragment-C3bm6_WD.js.map": {
    "type": "application/json",
    "etag": "\"8f5-PlroxBQe0C+I5PPn9o3sgEOQTyo\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2293,
    "path": "../public/_build/assets/fogFragment-C3bm6_WD.js.map"
  },
  "/_build/assets/fogFragment-DV8vZhIr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4ac-X6EAqtZpDbSt4J1OqNpdx4DLo0c\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1196,
    "path": "../public/_build/assets/fogFragment-DV8vZhIr.js"
  },
  "/_build/assets/fogFragment-DV8vZhIr.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1d6-HTpdaE35KzRsEGutiIeaWpSBZ9c\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 470,
    "path": "../public/_build/assets/fogFragment-DV8vZhIr.js.br"
  },
  "/_build/assets/fogFragment-DV8vZhIr.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"219-mAHvIjE/LBB9od5MiYjRTKHHWdM\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 537,
    "path": "../public/_build/assets/fogFragment-DV8vZhIr.js.gz"
  },
  "/_build/assets/fogFragment-DV8vZhIr.js.map": {
    "type": "application/json",
    "etag": "\"985-blju1+X5rEDPfKvs0OoaTnoy2JM\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2437,
    "path": "../public/_build/assets/fogFragment-DV8vZhIr.js.map"
  },
  "/_build/assets/glTFLoaderAnimation-Bb4n3cSX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"84a-dO0TY0O5q3BWmtjkRnaMk//GfTc\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2122,
    "path": "../public/_build/assets/glTFLoaderAnimation-Bb4n3cSX.js"
  },
  "/_build/assets/glTFLoaderAnimation-Bb4n3cSX.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"370-TbaQ702PrjF3CknRQQ1ct6+I7Jo\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 880,
    "path": "../public/_build/assets/glTFLoaderAnimation-Bb4n3cSX.js.br"
  },
  "/_build/assets/glTFLoaderAnimation-Bb4n3cSX.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3dc-+1GxdqxzLWIQpF0152Gf+KOUwfU\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 988,
    "path": "../public/_build/assets/glTFLoaderAnimation-Bb4n3cSX.js.gz"
  },
  "/_build/assets/glTFLoaderAnimation-Bb4n3cSX.js.map": {
    "type": "application/json",
    "etag": "\"1b5e-ajoo3zl13GEC7O4e79xt6AjsU7I\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 7006,
    "path": "../public/_build/assets/glTFLoaderAnimation-Bb4n3cSX.js.map"
  },
  "/_build/assets/harmonicsFunctions-C1iqzSwe.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a4c-ceSFvypX7EP/xqEIP8VbUQ7s/+4\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2636,
    "path": "../public/_build/assets/harmonicsFunctions-C1iqzSwe.js"
  },
  "/_build/assets/harmonicsFunctions-C1iqzSwe.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"371-lEwAqQSvN59c+sqh3XNKxxox5zA\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 881,
    "path": "../public/_build/assets/harmonicsFunctions-C1iqzSwe.js.br"
  },
  "/_build/assets/harmonicsFunctions-C1iqzSwe.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3c4-Q1Ltlla6//t9fP0YIQ4zWejfLBE\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 964,
    "path": "../public/_build/assets/harmonicsFunctions-C1iqzSwe.js.gz"
  },
  "/_build/assets/harmonicsFunctions-C1iqzSwe.js.map": {
    "type": "application/json",
    "etag": "\"f33-x3ymC9/rmF73+lfoBFMAVbTBxAo\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 3891,
    "path": "../public/_build/assets/harmonicsFunctions-C1iqzSwe.js.map"
  },
  "/_build/assets/harmonicsFunctions-DhQO3qhe.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d8e-Lb35DlG5pFsfTzjjcUsqAVs5/2M\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 3470,
    "path": "../public/_build/assets/harmonicsFunctions-DhQO3qhe.js"
  },
  "/_build/assets/harmonicsFunctions-DhQO3qhe.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"390-jN1TdgipIuVH1HkwuhQ7lAv/DOI\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 912,
    "path": "../public/_build/assets/harmonicsFunctions-DhQO3qhe.js.br"
  },
  "/_build/assets/harmonicsFunctions-DhQO3qhe.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3cb-l3Rg1KgB5SFB8gKP9UR96z3ykVU\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 971,
    "path": "../public/_build/assets/harmonicsFunctions-DhQO3qhe.js.gz"
  },
  "/_build/assets/harmonicsFunctions-DhQO3qhe.js.map": {
    "type": "application/json",
    "etag": "\"1283-abX7gtqVygYyq0OSq1j2G+U9FFY\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 4739,
    "path": "../public/_build/assets/harmonicsFunctions-DhQO3qhe.js.map"
  },
  "/_build/assets/hdrTextureLoader-NtFIYVoK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b32-LnrNZExstvvkyn7GbIZyNJ9RdU0\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2866,
    "path": "../public/_build/assets/hdrTextureLoader-NtFIYVoK.js"
  },
  "/_build/assets/hdrTextureLoader-NtFIYVoK.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4f3-aShQtplzp3oSNx6Nz9DrRsIF2bE\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1267,
    "path": "../public/_build/assets/hdrTextureLoader-NtFIYVoK.js.br"
  },
  "/_build/assets/hdrTextureLoader-NtFIYVoK.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"57a-vEN83wJtIBzbrJhNLNGQUVdyjQU\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1402,
    "path": "../public/_build/assets/hdrTextureLoader-NtFIYVoK.js.gz"
  },
  "/_build/assets/hdrTextureLoader-NtFIYVoK.js.map": {
    "type": "application/json",
    "etag": "\"4119-jJfvgiKACnVSGWt+wABJ1WsUFAk\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 16665,
    "path": "../public/_build/assets/hdrTextureLoader-NtFIYVoK.js.map"
  },
  "/_build/assets/helperFunctions-P85AnhYT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1590-HT75fhsgi5dEhO74M6UoYI7F4Aw\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 5520,
    "path": "../public/_build/assets/helperFunctions-P85AnhYT.js"
  },
  "/_build/assets/helperFunctions-P85AnhYT.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"678-DCYJAC8s7E71fvwdYQMYjflReI0\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1656,
    "path": "../public/_build/assets/helperFunctions-P85AnhYT.js.br"
  },
  "/_build/assets/helperFunctions-P85AnhYT.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"72e-W5Ct4k6FbeXyUSBsLD3AUSOIwwg\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1838,
    "path": "../public/_build/assets/helperFunctions-P85AnhYT.js.gz"
  },
  "/_build/assets/helperFunctions-P85AnhYT.js.map": {
    "type": "application/json",
    "etag": "\"1a40-fFo58KjlvKb2dHi2siQZ4szrYlg\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 6720,
    "path": "../public/_build/assets/helperFunctions-P85AnhYT.js.map"
  },
  "/_build/assets/helperFunctions-f59Nn5SX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"14ed-8c+/YHs3U3hjnQlaYvQv9uCVaE4\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 5357,
    "path": "../public/_build/assets/helperFunctions-f59Nn5SX.js"
  },
  "/_build/assets/helperFunctions-f59Nn5SX.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"67c-wnROwPMExJIbsP9T3Pa3pDNP5ko\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1660,
    "path": "../public/_build/assets/helperFunctions-f59Nn5SX.js.br"
  },
  "/_build/assets/helperFunctions-f59Nn5SX.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"713-83TEBg9k8xGfEA0DC/dkg2y8KV0\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1811,
    "path": "../public/_build/assets/helperFunctions-f59Nn5SX.js.gz"
  },
  "/_build/assets/helperFunctions-f59Nn5SX.js.map": {
    "type": "application/json",
    "etag": "\"1906-Yf3tdUKuodPTXg3LOTwSxX8Rzmg\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 6406,
    "path": "../public/_build/assets/helperFunctions-f59Nn5SX.js.map"
  },
  "/_build/assets/i18n-D2sladI6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"28864-G7KLsr4wnHHRaZdInYcdzA0cdq0\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 165988,
    "path": "../public/_build/assets/i18n-D2sladI6.js"
  },
  "/_build/assets/i18n-D2sladI6.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"3111-R2qpfWtOfOMh/DkDk4ZqSEEtl0U\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 12561,
    "path": "../public/_build/assets/i18n-D2sladI6.js.br"
  },
  "/_build/assets/i18n-D2sladI6.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"69e1-iJMvBmG6XNB9utpT/N7MTj+FGWU\"",
    "mtime": "2025-04-16T08:54:54.417Z",
    "size": 27105,
    "path": "../public/_build/assets/i18n-D2sladI6.js.gz"
  },
  "/_build/assets/i18n-D2sladI6.js.map": {
    "type": "application/json",
    "etag": "\"6f59f-FTS2Vq18NbplJe+BtEghzGqxIuA\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 456095,
    "path": "../public/_build/assets/i18n-D2sladI6.js.map"
  },
  "/_build/assets/iesTextureLoader-CDlrATOY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c35-q1VDE+pYkogEAGK5RUVxnvpFkSE\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 3125,
    "path": "../public/_build/assets/iesTextureLoader-CDlrATOY.js"
  },
  "/_build/assets/iesTextureLoader-CDlrATOY.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4dc-+w7g1wYfGxVdvvRKdzNbUKk4OaE\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1244,
    "path": "../public/_build/assets/iesTextureLoader-CDlrATOY.js.br"
  },
  "/_build/assets/iesTextureLoader-CDlrATOY.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"56e-bNk6QqOHPKi9yc2cn13P/WVGxvo\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1390,
    "path": "../public/_build/assets/iesTextureLoader-CDlrATOY.js.gz"
  },
  "/_build/assets/iesTextureLoader-CDlrATOY.js.map": {
    "type": "application/json",
    "etag": "\"3316-Ybe7xgyFaQnNABTcJnbI7ZYldBI\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 13078,
    "path": "../public/_build/assets/iesTextureLoader-CDlrATOY.js.map"
  },
  "/_build/assets/index-BBuiUxA4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ace4-5rTMy/cyvxxUE5qzn9FTwv9/Bvs\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 44260,
    "path": "../public/_build/assets/index-BBuiUxA4.js"
  },
  "/_build/assets/index-BBuiUxA4.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"309a-aaaezmjgrvCAI7bLFcNztauny6Y\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 12442,
    "path": "../public/_build/assets/index-BBuiUxA4.js.br"
  },
  "/_build/assets/index-BBuiUxA4.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"36c0-FvBQR+QpEUchjG9IR2Ky8S6vG5U\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 14016,
    "path": "../public/_build/assets/index-BBuiUxA4.js.gz"
  },
  "/_build/assets/index-BBuiUxA4.js.map": {
    "type": "application/json",
    "etag": "\"2cca7-rvlFxRRfT6Xzkgv2O8vh54CI1Eg\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 183463,
    "path": "../public/_build/assets/index-BBuiUxA4.js.map"
  },
  "/_build/assets/index-BOpBpQJ6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3a4e-kS54H77AeYgeUVTeM3XlrQQ8DII\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 14926,
    "path": "../public/_build/assets/index-BOpBpQJ6.js"
  },
  "/_build/assets/index-BOpBpQJ6.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"16af-6s/SpPjBH5caAb9Dogjo3HQRc+Q\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 5807,
    "path": "../public/_build/assets/index-BOpBpQJ6.js.br"
  },
  "/_build/assets/index-BOpBpQJ6.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"18c1-k8nccQLJLLkPygVpZz18QZJVDoA\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 6337,
    "path": "../public/_build/assets/index-BOpBpQJ6.js.gz"
  },
  "/_build/assets/index-BOpBpQJ6.js.map": {
    "type": "application/json",
    "etag": "\"1eb1d-TSG1hZuKluFiVXneByIKj5uUydo\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 125725,
    "path": "../public/_build/assets/index-BOpBpQJ6.js.map"
  },
  "/_build/assets/index-CmK9u_yj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1f98-dcTnkLCjKazy1atyhTFAYlL3Qjk\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 8088,
    "path": "../public/_build/assets/index-CmK9u_yj.js"
  },
  "/_build/assets/index-CmK9u_yj.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"aa8-n8q+/tjYqR/tmsX70mTXxkFsNf4\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 2728,
    "path": "../public/_build/assets/index-CmK9u_yj.js.br"
  },
  "/_build/assets/index-CmK9u_yj.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"cb9-njmk7YF8edHuFzCUSqPT7CQtWAI\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 3257,
    "path": "../public/_build/assets/index-CmK9u_yj.js.gz"
  },
  "/_build/assets/index-CmK9u_yj.js.map": {
    "type": "application/json",
    "etag": "\"2893-TfozyufdyePl1F0nvi5oXTrkVv8\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 10387,
    "path": "../public/_build/assets/index-CmK9u_yj.js.map"
  },
  "/_build/assets/index-DVCtmx-_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1c509-slQIhwQUsskAiSfo6iNSotzXmMk\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 115977,
    "path": "../public/_build/assets/index-DVCtmx-_.js"
  },
  "/_build/assets/index-DVCtmx-_.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"7b56-fzkt7veLMg1uA93XRNww2vBu1/4\"",
    "mtime": "2025-04-16T08:54:54.417Z",
    "size": 31574,
    "path": "../public/_build/assets/index-DVCtmx-_.js.br"
  },
  "/_build/assets/index-DVCtmx-_.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"8db1-y+tQG8u56tXzceIP+ckQ/yYKjoA\"",
    "mtime": "2025-04-16T08:54:54.464Z",
    "size": 36273,
    "path": "../public/_build/assets/index-DVCtmx-_.js.gz"
  },
  "/_build/assets/index-DVCtmx-_.js.map": {
    "type": "application/json",
    "etag": "\"6bbb4-u1VYTLJgap8Krs/w6wwXSIw1RU0\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 441268,
    "path": "../public/_build/assets/index-DVCtmx-_.js.map"
  },
  "/_build/assets/index-l1SMoKQ2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"15eae-qNa6RmZjc3fbA30pTUZnE17BOn4\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 89774,
    "path": "../public/_build/assets/index-l1SMoKQ2.js"
  },
  "/_build/assets/index-l1SMoKQ2.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5005-yXcADD/n8ThCyUzUVcLl7ma00E4\"",
    "mtime": "2025-04-16T08:54:54.417Z",
    "size": 20485,
    "path": "../public/_build/assets/index-l1SMoKQ2.js.br"
  },
  "/_build/assets/index-l1SMoKQ2.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"59c1-KRAlVEnKUVy4zcsDUFM7vPiebcs\"",
    "mtime": "2025-04-16T08:54:54.417Z",
    "size": 22977,
    "path": "../public/_build/assets/index-l1SMoKQ2.js.gz"
  },
  "/_build/assets/index-l1SMoKQ2.js.map": {
    "type": "application/json",
    "etag": "\"63b95-cBO95GwIU3MNeC6m93imul+m/2I\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 408469,
    "path": "../public/_build/assets/index-l1SMoKQ2.js.map"
  },
  "/_build/assets/initialWorker-B3_6tmhz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"10224-kpaL20Gi6drB2GgmuYIP2RSF0fs\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 66084,
    "path": "../public/_build/assets/initialWorker-B3_6tmhz.js"
  },
  "/_build/assets/initialWorker-B3_6tmhz.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4a70-qcR6oAKQl92QX09crif/+wQEsYo\"",
    "mtime": "2025-04-16T08:54:54.417Z",
    "size": 19056,
    "path": "../public/_build/assets/initialWorker-B3_6tmhz.js.br"
  },
  "/_build/assets/initialWorker-B3_6tmhz.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"543b-oqb7XeNJ6FL6TfHpaHAq3fGOUS8\"",
    "mtime": "2025-04-16T08:54:54.417Z",
    "size": 21563,
    "path": "../public/_build/assets/initialWorker-B3_6tmhz.js.gz"
  },
  "/_build/assets/initialWorker-B3_6tmhz.js.map": {
    "type": "application/json",
    "etag": "\"2ca2d-dvPrq+8nMyyW3JxFsYeW4Wy7fWk\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 182829,
    "path": "../public/_build/assets/initialWorker-B3_6tmhz.js.map"
  },
  "/_build/assets/input-_8gDkfJ0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"79d-TpscwrPlO0caqoYNbqdMNmV96bY\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1949,
    "path": "../public/_build/assets/input-_8gDkfJ0.js"
  },
  "/_build/assets/input-_8gDkfJ0.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2f4-YLVcFi5mRpRGjugTmf6NasghrNc\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 756,
    "path": "../public/_build/assets/input-_8gDkfJ0.js.br"
  },
  "/_build/assets/input-_8gDkfJ0.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"348-aoaLOM9cE2uFu80QQOvIiXzKQtw\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 840,
    "path": "../public/_build/assets/input-_8gDkfJ0.js.gz"
  },
  "/_build/assets/input-_8gDkfJ0.js.map": {
    "type": "application/json",
    "etag": "\"1720-W++ewrVJvwX8w2XEYJJcuuiomJ0\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 5920,
    "path": "../public/_build/assets/input-_8gDkfJ0.js.map"
  },
  "/_build/assets/instancesDeclaration-B9Iadifl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"420-YPlDlLuTC/LhQCOBTbRbz8XPXAQ\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1056,
    "path": "../public/_build/assets/instancesDeclaration-B9Iadifl.js"
  },
  "/_build/assets/instancesDeclaration-B9Iadifl.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"133-iS0AxHCIogBYzZKkf0cXNZRDTo8\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 307,
    "path": "../public/_build/assets/instancesDeclaration-B9Iadifl.js.br"
  },
  "/_build/assets/instancesDeclaration-B9Iadifl.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"172-4bWBHYaH5FZY+Owl4jBrD4l5tOo\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 370,
    "path": "../public/_build/assets/instancesDeclaration-B9Iadifl.js.gz"
  },
  "/_build/assets/instancesDeclaration-B9Iadifl.js.map": {
    "type": "application/json",
    "etag": "\"70a-SJkwxA696v22JNyCaMXUz+mk3YY\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1802,
    "path": "../public/_build/assets/instancesDeclaration-B9Iadifl.js.map"
  },
  "/_build/assets/kernelBlur.fragment-Bn0zydtV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9ea-lJQvdvh+DQY/id1hsFQztdI7Uac\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2538,
    "path": "../public/_build/assets/kernelBlur.fragment-Bn0zydtV.js"
  },
  "/_build/assets/kernelBlur.fragment-Bn0zydtV.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"35a-5aYPeYOCqk4sYDIHG62jI5aEzcc\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 858,
    "path": "../public/_build/assets/kernelBlur.fragment-Bn0zydtV.js.br"
  },
  "/_build/assets/kernelBlur.fragment-Bn0zydtV.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"39d-gvIwBt0BT4sPHs3EmxvELvoI17o\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 925,
    "path": "../public/_build/assets/kernelBlur.fragment-Bn0zydtV.js.gz"
  },
  "/_build/assets/kernelBlur.fragment-Bn0zydtV.js.map": {
    "type": "application/json",
    "etag": "\"10b9-9GdGrNMu+mHqEmE48Jr7e8deDAY\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 4281,
    "path": "../public/_build/assets/kernelBlur.fragment-Bn0zydtV.js.map"
  },
  "/_build/assets/kernelBlur.fragment-D2e2kUE6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c25-Q/+cp1FB2PgbGG3MF5PLibWIRa4\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 3109,
    "path": "../public/_build/assets/kernelBlur.fragment-D2e2kUE6.js"
  },
  "/_build/assets/kernelBlur.fragment-D2e2kUE6.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"383-FS0LXW5UnDMiy4IGNycmJegdyJU\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 899,
    "path": "../public/_build/assets/kernelBlur.fragment-D2e2kUE6.js.br"
  },
  "/_build/assets/kernelBlur.fragment-D2e2kUE6.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3f3-9jaaq/xyHJFkCnMyWn+gnqXpjP8\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1011,
    "path": "../public/_build/assets/kernelBlur.fragment-D2e2kUE6.js.gz"
  },
  "/_build/assets/kernelBlur.fragment-D2e2kUE6.js.map": {
    "type": "application/json",
    "etag": "\"12f2-iryKRriQmBKdOCNj+aOHmWG/eq0\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 4850,
    "path": "../public/_build/assets/kernelBlur.fragment-D2e2kUE6.js.map"
  },
  "/_build/assets/kernelBlur.vertex-4UPr9Wqw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"53e-7vHQP52/15pEnJeiOx5NzQmse/0\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1342,
    "path": "../public/_build/assets/kernelBlur.vertex-4UPr9Wqw.js"
  },
  "/_build/assets/kernelBlur.vertex-4UPr9Wqw.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"254-C6kH9bRXSfZuxut2iDl4T6/2jfM\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 596,
    "path": "../public/_build/assets/kernelBlur.vertex-4UPr9Wqw.js.br"
  },
  "/_build/assets/kernelBlur.vertex-4UPr9Wqw.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2a9-+h9lFjcDqab2RiGiemzkJYa8KLA\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 681,
    "path": "../public/_build/assets/kernelBlur.vertex-4UPr9Wqw.js.gz"
  },
  "/_build/assets/kernelBlur.vertex-4UPr9Wqw.js.map": {
    "type": "application/json",
    "etag": "\"8a4-r1xt4/xvU71q2hlwq3Vx3XVe0I4\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2212,
    "path": "../public/_build/assets/kernelBlur.vertex-4UPr9Wqw.js.map"
  },
  "/_build/assets/kernelBlur.vertex-Bh8KCmEs.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4af-tHHVSMyxpxEyXedrArIQVoPxwX0\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1199,
    "path": "../public/_build/assets/kernelBlur.vertex-Bh8KCmEs.js"
  },
  "/_build/assets/kernelBlur.vertex-Bh8KCmEs.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"22f-0zf28P/nTfkxGaRNaLZ4649YMhM\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 559,
    "path": "../public/_build/assets/kernelBlur.vertex-Bh8KCmEs.js.br"
  },
  "/_build/assets/kernelBlur.vertex-Bh8KCmEs.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"280-huKZBdTSTNh3DW28X4Ou7Y0HLaI\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 640,
    "path": "../public/_build/assets/kernelBlur.vertex-Bh8KCmEs.js.gz"
  },
  "/_build/assets/kernelBlur.vertex-Bh8KCmEs.js.map": {
    "type": "application/json",
    "etag": "\"7f9-IrFH4CbzVcotH67mihShcBIZlNA\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2041,
    "path": "../public/_build/assets/kernelBlur.vertex-Bh8KCmEs.js.map"
  },
  "/_build/assets/kernelBlurVaryingDeclaration-Bf54v8xT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f6-aLFDzIwSnUfbp+diO99mmpnVN2c\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 246,
    "path": "../public/_build/assets/kernelBlurVaryingDeclaration-Bf54v8xT.js"
  },
  "/_build/assets/kernelBlurVaryingDeclaration-Bf54v8xT.js.map": {
    "type": "application/json",
    "etag": "\"374-A4jV7LsmHAySgoSCt5iDygHyNQ4\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 884,
    "path": "../public/_build/assets/kernelBlurVaryingDeclaration-Bf54v8xT.js.map"
  },
  "/_build/assets/kernelBlurVaryingDeclaration-Dvg3ZI3s.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ec-TjqbB0h+ttSAhRd7Xdpf1ELCAGY\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 236,
    "path": "../public/_build/assets/kernelBlurVaryingDeclaration-Dvg3ZI3s.js"
  },
  "/_build/assets/kernelBlurVaryingDeclaration-Dvg3ZI3s.js.map": {
    "type": "application/json",
    "etag": "\"35e-DqgZNCc04pQh7nO1kvsy86nP4mo\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 862,
    "path": "../public/_build/assets/kernelBlurVaryingDeclaration-Dvg3ZI3s.js.map"
  },
  "/_build/assets/ktxTextureLoader-BMc6KHr9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3e06-qrDo1rlIivMr8JrdtJDo46tDU38\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 15878,
    "path": "../public/_build/assets/ktxTextureLoader-BMc6KHr9.js"
  },
  "/_build/assets/ktxTextureLoader-BMc6KHr9.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"10d4-RL8kOWYj7Wpt/2pog6W609PNPlo\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 4308,
    "path": "../public/_build/assets/ktxTextureLoader-BMc6KHr9.js.br"
  },
  "/_build/assets/ktxTextureLoader-BMc6KHr9.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"12a6-g3EfToSd9mhZL+UNJZQ+KJQyqwg\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 4774,
    "path": "../public/_build/assets/ktxTextureLoader-BMc6KHr9.js.gz"
  },
  "/_build/assets/ktxTextureLoader-BMc6KHr9.js.map": {
    "type": "application/json",
    "etag": "\"fd2d-CBdXlfd+2dWnGv1l9MSSmaWNBXc\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 64813,
    "path": "../public/_build/assets/ktxTextureLoader-BMc6KHr9.js.map"
  },
  "/_build/assets/loadingBar-DLmXW3E3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"372-JV9f1rXPWBwzOi/K/4vzWwze6TA\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 882,
    "path": "../public/_build/assets/loadingBar-DLmXW3E3.js"
  },
  "/_build/assets/loadingBar-DLmXW3E3.js.map": {
    "type": "application/json",
    "etag": "\"867-T+nIHBZPLflOnojORKvuTo8wr9Q\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 2151,
    "path": "../public/_build/assets/loadingBar-DLmXW3E3.js.map"
  },
  "/_build/assets/logDepthDeclaration-CYTyTGtw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1b4-as02NYUBRzoyhXZgptF7jVWxWNY\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 436,
    "path": "../public/_build/assets/logDepthDeclaration-CYTyTGtw.js"
  },
  "/_build/assets/logDepthDeclaration-CYTyTGtw.js.map": {
    "type": "application/json",
    "etag": "\"63c-hX272DiI96PSM6PDKNHncw7lJmo\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1596,
    "path": "../public/_build/assets/logDepthDeclaration-CYTyTGtw.js.map"
  },
  "/_build/assets/logDepthDeclaration-IeIsWGfQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1c4-OcnGDg0SdVoHbgVDbs6XVS+zZdM\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 452,
    "path": "../public/_build/assets/logDepthDeclaration-IeIsWGfQ.js"
  },
  "/_build/assets/logDepthDeclaration-IeIsWGfQ.js.map": {
    "type": "application/json",
    "etag": "\"660-iOn+HBFWSG8iYt2ViT4z74elbxI\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1632,
    "path": "../public/_build/assets/logDepthDeclaration-IeIsWGfQ.js.map"
  },
  "/_build/assets/logDepthVertex-CLfxK9SS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"20b0-6SqtrEftlNGHNQhCKi/YgQESHG0\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 8368,
    "path": "../public/_build/assets/logDepthVertex-CLfxK9SS.js"
  },
  "/_build/assets/logDepthVertex-CLfxK9SS.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"626-t7WxhjeovnzLqtbY3/koT4l53hc\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1574,
    "path": "../public/_build/assets/logDepthVertex-CLfxK9SS.js.br"
  },
  "/_build/assets/logDepthVertex-CLfxK9SS.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"724-zdD7aZGlB6flC//76hEj2DBYVWM\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1828,
    "path": "../public/_build/assets/logDepthVertex-CLfxK9SS.js.gz"
  },
  "/_build/assets/logDepthVertex-CLfxK9SS.js.map": {
    "type": "application/json",
    "etag": "\"3b5f-taRgJF/UPr+ClPHQoPIFzrs3YXI\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 15199,
    "path": "../public/_build/assets/logDepthVertex-CLfxK9SS.js.map"
  },
  "/_build/assets/logDepthVertex-D6DRg3sW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1bf9-3ZOS1L8ZSvHgGwChpcAKgWVgAZY\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 7161,
    "path": "../public/_build/assets/logDepthVertex-D6DRg3sW.js"
  },
  "/_build/assets/logDepthVertex-D6DRg3sW.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5e0-/a0X4iVeAEgYA1LKXmcsBNLR0p8\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 1504,
    "path": "../public/_build/assets/logDepthVertex-D6DRg3sW.js.br"
  },
  "/_build/assets/logDepthVertex-D6DRg3sW.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6c3-V1X2Uhvutrv2vnMYgc9A5Mr5tmk\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1731,
    "path": "../public/_build/assets/logDepthVertex-D6DRg3sW.js.gz"
  },
  "/_build/assets/logDepthVertex-D6DRg3sW.js.map": {
    "type": "application/json",
    "etag": "\"3a5a-5FQ5oX/2lsTcd5aFJHkgu0WkdD4\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 14938,
    "path": "../public/_build/assets/logDepthVertex-D6DRg3sW.js.map"
  },
  "/_build/assets/main-BPc2iFPx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"505-gMo+ceqmoLKWLzuiTI4jdwPHYow\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1285,
    "path": "../public/_build/assets/main-BPc2iFPx.js"
  },
  "/_build/assets/main-BPc2iFPx.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2cd-POL5bbWj0YqPHzuydKORVf8Q5tU\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 717,
    "path": "../public/_build/assets/main-BPc2iFPx.js.br"
  },
  "/_build/assets/main-BPc2iFPx.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"31c-RuhcvCCCxac7YsviWIMYUupF8e8\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 796,
    "path": "../public/_build/assets/main-BPc2iFPx.js.gz"
  },
  "/_build/assets/main-BPc2iFPx.js.map": {
    "type": "application/json",
    "etag": "\"1227-ShfdRODDNvtBYiNqjJMjHOmZI2E\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 4647,
    "path": "../public/_build/assets/main-BPc2iFPx.js.map"
  },
  "/_build/assets/main-CfqK61NJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"14a2-1JkYhmilKsKpx0WRlih3bE6nV30\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 5282,
    "path": "../public/_build/assets/main-CfqK61NJ.js"
  },
  "/_build/assets/main-CfqK61NJ.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"88b-CnFpbRl8oKZngbZJz23Z/4lrPXc\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 2187,
    "path": "../public/_build/assets/main-CfqK61NJ.js.br"
  },
  "/_build/assets/main-CfqK61NJ.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"9bc-0/eZoHpeBEU/0alZVFECnSoppe4\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 2492,
    "path": "../public/_build/assets/main-CfqK61NJ.js.gz"
  },
  "/_build/assets/main-CfqK61NJ.js.map": {
    "type": "application/json",
    "etag": "\"429b-pNLs+aBMmz7F3pqGqyLwINIyTKQ\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 17051,
    "path": "../public/_build/assets/main-CfqK61NJ.js.map"
  },
  "/_build/assets/mesh.vertexData.functions-BYooUupK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3d5-yzxo14F1b/xmmVLuETV2U2CZQ64\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 981,
    "path": "../public/_build/assets/mesh.vertexData.functions-BYooUupK.js"
  },
  "/_build/assets/mesh.vertexData.functions-BYooUupK.js.map": {
    "type": "application/json",
    "etag": "\"1a28-qHfvH/7BIs8ompHQnbHEumMBMCk\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 6696,
    "path": "../public/_build/assets/mesh.vertexData.functions-BYooUupK.js.map"
  },
  "/_build/assets/meshUboDeclaration-BKO5nIf3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"265-ZJ+Q6auYudU7GhXnGQlP5OCE6DY\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 613,
    "path": "../public/_build/assets/meshUboDeclaration-BKO5nIf3.js"
  },
  "/_build/assets/meshUboDeclaration-BKO5nIf3.js.map": {
    "type": "application/json",
    "etag": "\"713-38QoCMhe1wl4NUo/e1RnOIJXlfk\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1811,
    "path": "../public/_build/assets/meshUboDeclaration-BKO5nIf3.js.map"
  },
  "/_build/assets/meshUboDeclaration-BiJrn2Ce.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"269-Ig4vwf9bNa9EI4yj+YN82WVydSU\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 617,
    "path": "../public/_build/assets/meshUboDeclaration-BiJrn2Ce.js"
  },
  "/_build/assets/meshUboDeclaration-BiJrn2Ce.js.map": {
    "type": "application/json",
    "etag": "\"703-YOKSJfOCrq3jk2B0j+PGIZ81KMo\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1795,
    "path": "../public/_build/assets/meshUboDeclaration-BiJrn2Ce.js.map"
  },
  "/_build/assets/morphTargetsVertex-ByOdyGdD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11e5-FNEor+XgTSBJDS4udkPLNYF7CJU\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 4581,
    "path": "../public/_build/assets/morphTargetsVertex-ByOdyGdD.js"
  },
  "/_build/assets/morphTargetsVertex-ByOdyGdD.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"391-vF8jRFXJ+CQ06sJQ7knkAHRBTP4\"",
    "mtime": "2025-04-16T08:54:54.399Z",
    "size": 913,
    "path": "../public/_build/assets/morphTargetsVertex-ByOdyGdD.js.br"
  },
  "/_build/assets/morphTargetsVertex-ByOdyGdD.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3d7-D2aFfnUkUc3Jc3v5s8seA8nrDvU\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 983,
    "path": "../public/_build/assets/morphTargetsVertex-ByOdyGdD.js.gz"
  },
  "/_build/assets/morphTargetsVertex-ByOdyGdD.js.map": {
    "type": "application/json",
    "etag": "\"1cf3-SiTBUC4aoP0sf9b+PZyCuns7jh0\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 7411,
    "path": "../public/_build/assets/morphTargetsVertex-ByOdyGdD.js.map"
  },
  "/_build/assets/nodeEditor-CxjmBjoL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e7de1-H0IURH0PcJkFs414tUEWhv1HfsA\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 949729,
    "path": "../public/_build/assets/nodeEditor-CxjmBjoL.js"
  },
  "/_build/assets/nodeEditor-CxjmBjoL.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2bed8-rce+2OqLv0xP7ayvNl+w0mEKIhY\"",
    "mtime": "2025-04-16T08:55:25.464Z",
    "size": 179928,
    "path": "../public/_build/assets/nodeEditor-CxjmBjoL.js.br"
  },
  "/_build/assets/nodeEditor-CxjmBjoL.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3a109-axUNmqonqVfst3ghoKSJAA2Srsw\"",
    "mtime": "2025-04-16T08:55:25.124Z",
    "size": 237833,
    "path": "../public/_build/assets/nodeEditor-CxjmBjoL.js.gz"
  },
  "/_build/assets/nodeEditor-CxjmBjoL.js.map": {
    "type": "application/json",
    "etag": "\"1a06fa-SxhXCftZAJ8hqTZQ+BWkA1KI/NQ\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1705722,
    "path": "../public/_build/assets/nodeEditor-CxjmBjoL.js.map"
  },
  "/_build/assets/nodefs-LGIbJnh3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1d5-DFfII0I4IgifWPWrN4YJrUTF/1s\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 469,
    "path": "../public/_build/assets/nodefs-LGIbJnh3.js"
  },
  "/_build/assets/nodefs-LGIbJnh3.js.map": {
    "type": "application/json",
    "etag": "\"527-L4wNewFdfvDdRP0R98B0H5S813k\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 1319,
    "path": "../public/_build/assets/nodefs-LGIbJnh3.js.map"
  },
  "/_build/assets/oitFragment-BplfZmSk.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"10b31-gJE9UygKRumqJz/m49VBP4709qY\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 68401,
    "path": "../public/_build/assets/oitFragment-BplfZmSk.js"
  },
  "/_build/assets/oitFragment-BplfZmSk.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2b9c-O7ilgYHPdw3tACtrkGR7qTHnyiQ\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 11164,
    "path": "../public/_build/assets/oitFragment-BplfZmSk.js.br"
  },
  "/_build/assets/oitFragment-BplfZmSk.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"332a-FJTlzzNWhPpLzNyXauEoUEnK1fc\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 13098,
    "path": "../public/_build/assets/oitFragment-BplfZmSk.js.gz"
  },
  "/_build/assets/oitFragment-BplfZmSk.js.map": {
    "type": "application/json",
    "etag": "\"14d81-/ACyU2ImFqy9nof9+AcsSXHVwG4\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 85377,
    "path": "../public/_build/assets/oitFragment-BplfZmSk.js.map"
  },
  "/_build/assets/oitFragment-BvELClzu.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11e34-9HiCFcOvpdbmomMjOFYrvlbPS1U\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 73268,
    "path": "../public/_build/assets/oitFragment-BvELClzu.js"
  },
  "/_build/assets/oitFragment-BvELClzu.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2c3e-h6p/EsoXGxw07qs7VQiJ0Bp8oLg\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 11326,
    "path": "../public/_build/assets/oitFragment-BvELClzu.js.br"
  },
  "/_build/assets/oitFragment-BvELClzu.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"338e-H7SzbMacIP/2MEpobw24nmJNdtQ\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 13198,
    "path": "../public/_build/assets/oitFragment-BvELClzu.js.gz"
  },
  "/_build/assets/oitFragment-BvELClzu.js.map": {
    "type": "application/json",
    "etag": "\"159d7-wRArRV3/CBnULwp8OWthXqyGwb8\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 88535,
    "path": "../public/_build/assets/oitFragment-BvELClzu.js.map"
  },
  "/_build/assets/opfs-ahp-D7M8L902.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2752-0OVTHWmlEMfqJ+XwqhRLPnpGhqQ\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 10066,
    "path": "../public/_build/assets/opfs-ahp-D7M8L902.js"
  },
  "/_build/assets/opfs-ahp-D7M8L902.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"ae3-sbieHv859E1Xxl+HFsmRWeaYHZk\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 2787,
    "path": "../public/_build/assets/opfs-ahp-D7M8L902.js.br"
  },
  "/_build/assets/opfs-ahp-D7M8L902.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"c0d-i5AcFHiddkSU9DnAXiJ70ob1foM\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 3085,
    "path": "../public/_build/assets/opfs-ahp-D7M8L902.js.gz"
  },
  "/_build/assets/opfs-ahp-D7M8L902.js.map": {
    "type": "application/json",
    "etag": "\"5fa4-3l4thWet9aMH6s/gvGhHq37SqEQ\"",
    "mtime": "2025-04-16T08:54:50.937Z",
    "size": 24484,
    "path": "../public/_build/assets/opfs-ahp-D7M8L902.js.map"
  },
  "/_build/assets/overlayscrollbars-D3GIAgNs.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6e21-yg7BcBZ0SorrXX/Wa+wZ4hbhN08\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 28193,
    "path": "../public/_build/assets/overlayscrollbars-D3GIAgNs.js"
  },
  "/_build/assets/overlayscrollbars-D3GIAgNs.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"31e5-N+N3Ol56xJxH+fOi1y3VFxNS6Qk\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 12773,
    "path": "../public/_build/assets/overlayscrollbars-D3GIAgNs.js.br"
  },
  "/_build/assets/overlayscrollbars-D3GIAgNs.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"3807-K+Z4w0iEol86HhOFD0iSUFwAkp4\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 14343,
    "path": "../public/_build/assets/overlayscrollbars-D3GIAgNs.js.gz"
  },
  "/_build/assets/overlayscrollbars-D3GIAgNs.js.map": {
    "type": "application/json",
    "etag": "\"22092-+nctmzyoKa+Us8wIzE+yV0Q5T6s\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 139410,
    "path": "../public/_build/assets/overlayscrollbars-D3GIAgNs.js.map"
  },
  "/_build/assets/packingFunctions-BlcJEJ_N.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"23f-+JFgqsj3ZBkmoJLInP9NHmhtfLw\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 575,
    "path": "../public/_build/assets/packingFunctions-BlcJEJ_N.js"
  },
  "/_build/assets/packingFunctions-BlcJEJ_N.js.map": {
    "type": "application/json",
    "etag": "\"4ab-AmK7IVZDBEzzjYEBCrtOfzxdmYM\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1195,
    "path": "../public/_build/assets/packingFunctions-BlcJEJ_N.js.map"
  },
  "/_build/assets/pass.fragment-DQCGvPvp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2ee-69Rm8HhAhbK+fvNorVSBdD906cc\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 750,
    "path": "../public/_build/assets/pass.fragment-DQCGvPvp.js"
  },
  "/_build/assets/pass.fragment-DQCGvPvp.js.map": {
    "type": "application/json",
    "etag": "\"3b5-N9/utA2afV6iLHrCTFKMsxIeXuY\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 949,
    "path": "../public/_build/assets/pass.fragment-DQCGvPvp.js.map"
  },
  "/_build/assets/pass.fragment-DykT_6gR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"374-X3Y7bvt2ANPyP6EfAbUQh09d65A\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 884,
    "path": "../public/_build/assets/pass.fragment-DykT_6gR.js"
  },
  "/_build/assets/pass.fragment-DykT_6gR.js.map": {
    "type": "application/json",
    "etag": "\"44b-iFBv/VO62Re1nPcOJzsXEJ77u1A\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1099,
    "path": "../public/_build/assets/pass.fragment-DykT_6gR.js.map"
  },
  "/_build/assets/passCube.fragment-CdtuTapX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"620-Q/KxexftkFAUm8bU9BQKAxhQ0Ps\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1568,
    "path": "../public/_build/assets/passCube.fragment-CdtuTapX.js"
  },
  "/_build/assets/passCube.fragment-CdtuTapX.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"228-2tpmspX6Ni1j7amjVsmb4hBVSH4\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 552,
    "path": "../public/_build/assets/passCube.fragment-CdtuTapX.js.br"
  },
  "/_build/assets/passCube.fragment-CdtuTapX.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"26f-PJKMrbRCAypIL8zW5pRfwvCtHnc\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 623,
    "path": "../public/_build/assets/passCube.fragment-CdtuTapX.js.gz"
  },
  "/_build/assets/passCube.fragment-CdtuTapX.js.map": {
    "type": "application/json",
    "etag": "\"775-uKMPZdhcNlpbDYmGFFHL37X8Vl0\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1909,
    "path": "../public/_build/assets/passCube.fragment-CdtuTapX.js.map"
  },
  "/_build/assets/passCube.fragment-_8imUZNE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4eb-mShdQTsM9L1Gljn93Sky65tf6p0\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1259,
    "path": "../public/_build/assets/passCube.fragment-_8imUZNE.js"
  },
  "/_build/assets/passCube.fragment-_8imUZNE.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"1ef-o2ZbJ/ckLNhZxWn8VzzvLCzCjlA\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 495,
    "path": "../public/_build/assets/passCube.fragment-_8imUZNE.js.br"
  },
  "/_build/assets/passCube.fragment-_8imUZNE.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"243-E1HSWoh/Eko22PIGmPjNVP2MLxk\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 579,
    "path": "../public/_build/assets/passCube.fragment-_8imUZNE.js.gz"
  },
  "/_build/assets/passCube.fragment-_8imUZNE.js.map": {
    "type": "application/json",
    "etag": "\"630-74mG/sTikDnQ3z1NvlRejp+ylUo\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1584,
    "path": "../public/_build/assets/passCube.fragment-_8imUZNE.js.map"
  },
  "/_build/assets/pbr.fragment-D2GjthOJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1ef8b-yD+vs/+CsOiRmNYg+NE+BaqfapY\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 126859,
    "path": "../public/_build/assets/pbr.fragment-D2GjthOJ.js"
  },
  "/_build/assets/pbr.fragment-D2GjthOJ.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"503a-qwjaI9Ty1wLCyFm2q4lvoafJ7SU\"",
    "mtime": "2025-04-16T08:54:54.417Z",
    "size": 20538,
    "path": "../public/_build/assets/pbr.fragment-D2GjthOJ.js.br"
  },
  "/_build/assets/pbr.fragment-D2GjthOJ.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5d50-GQXqIq7zpC3S1MZeX/vPlBMmsOo\"",
    "mtime": "2025-04-16T08:54:54.417Z",
    "size": 23888,
    "path": "../public/_build/assets/pbr.fragment-D2GjthOJ.js.gz"
  },
  "/_build/assets/pbr.fragment-D2GjthOJ.js.map": {
    "type": "application/json",
    "etag": "\"28bcf-Ql7g/brY+9LXGBXeC//DcT9Lsyo\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 166863,
    "path": "../public/_build/assets/pbr.fragment-D2GjthOJ.js.map"
  },
  "/_build/assets/pbr.fragment-DrMkpjTy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1dd94-ar+UsIswugp4OljMmPzrkf7so2g\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 122260,
    "path": "../public/_build/assets/pbr.fragment-DrMkpjTy.js"
  },
  "/_build/assets/pbr.fragment-DrMkpjTy.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4f6b-nBpbfok+EVUt1Fn8LPNxeqI5LxI\"",
    "mtime": "2025-04-16T08:54:54.464Z",
    "size": 20331,
    "path": "../public/_build/assets/pbr.fragment-DrMkpjTy.js.br"
  },
  "/_build/assets/pbr.fragment-DrMkpjTy.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"5cf8-ay6T8z2hU1IaGqQ7GWHAsH6k1t0\"",
    "mtime": "2025-04-16T08:54:54.417Z",
    "size": 23800,
    "path": "../public/_build/assets/pbr.fragment-DrMkpjTy.js.gz"
  },
  "/_build/assets/pbr.fragment-DrMkpjTy.js.map": {
    "type": "application/json",
    "etag": "\"27c98-RzCo4gk+tHG0ME6fY56wetECxBI\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 162968,
    "path": "../public/_build/assets/pbr.fragment-DrMkpjTy.js.map"
  },
  "/_build/assets/pbr.vertex-B3qiKKWg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2f53-LSKBMihWLGFPrp82z+O4N3Gc2V8\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 12115,
    "path": "../public/_build/assets/pbr.vertex-B3qiKKWg.js"
  },
  "/_build/assets/pbr.vertex-B3qiKKWg.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"949-AXMHshuHhMEerUPdki1skKJu2fM\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 2377,
    "path": "../public/_build/assets/pbr.vertex-B3qiKKWg.js.br"
  },
  "/_build/assets/pbr.vertex-B3qiKKWg.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"a4c-QFrvPTtuV7orilA3H27qKPZbwts\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 2636,
    "path": "../public/_build/assets/pbr.vertex-B3qiKKWg.js.gz"
  },
  "/_build/assets/pbr.vertex-B3qiKKWg.js.map": {
    "type": "application/json",
    "etag": "\"3a0a-UPPlJch4M8ruKbh/mpbcTwR94tE\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 14858,
    "path": "../public/_build/assets/pbr.vertex-B3qiKKWg.js.map"
  },
  "/_build/assets/pbr.vertex-CIgTTeLZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3c08-uXzAB2GUO1RzLp0rAvA97NbbiLs\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 15368,
    "path": "../public/_build/assets/pbr.vertex-CIgTTeLZ.js"
  },
  "/_build/assets/pbr.vertex-CIgTTeLZ.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"b18-jEIFMy3oydH7TmS+Bn0NJkzn0Rc\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 2840,
    "path": "../public/_build/assets/pbr.vertex-CIgTTeLZ.js.br"
  },
  "/_build/assets/pbr.vertex-CIgTTeLZ.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"c69-mgcviqfdMieWZ7SLLrf6irdIiVE\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 3177,
    "path": "../public/_build/assets/pbr.vertex-CIgTTeLZ.js.gz"
  },
  "/_build/assets/pbr.vertex-CIgTTeLZ.js.map": {
    "type": "application/json",
    "etag": "\"4cc6-lQDx0q5k1PHXaG6JZfDf0PemxS0\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 19654,
    "path": "../public/_build/assets/pbr.vertex-CIgTTeLZ.js.map"
  },
  "/_build/assets/petCalculator-C_iQ8Ihn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c08-Ed+4c3dK3YE4WNzldDJoIziy4Y4\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 3080,
    "path": "../public/_build/assets/petCalculator-C_iQ8Ihn.js"
  },
  "/_build/assets/petCalculator-C_iQ8Ihn.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"490-7MusL0Ig7jNHyZBhdpQlXykABSY\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1168,
    "path": "../public/_build/assets/petCalculator-C_iQ8Ihn.js.br"
  },
  "/_build/assets/petCalculator-C_iQ8Ihn.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"564-+n1aU9WvTC/GfYThWtiQQuvk/U8\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1380,
    "path": "../public/_build/assets/petCalculator-C_iQ8Ihn.js.gz"
  },
  "/_build/assets/petCalculator-C_iQ8Ihn.js.map": {
    "type": "application/json",
    "etag": "\"2bb1-cAP+U16fsSQhBAeBbFM4Jw7ZAp8\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 11185,
    "path": "../public/_build/assets/petCalculator-C_iQ8Ihn.js.map"
  },
  "/_build/assets/pg_trgm.tar-CUnu0XkG.gz": {
    "type": "text/plain; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"104fd-WsaPjGdQHb4QY9BEu0uK/WUdUAM\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 66813,
    "path": "../public/_build/assets/pg_trgm.tar-CUnu0XkG.gz"
  },
  "/_build/assets/postgres-BTNW2TY8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1eab0-GKjhkhKuK+kI8UgQDahVaB1WtAg\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 125616,
    "path": "../public/_build/assets/postgres-BTNW2TY8.js"
  },
  "/_build/assets/postgres-BTNW2TY8.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5919-XDRhA2BjLK9JgMLTVST5IHyndGo\"",
    "mtime": "2025-04-16T08:54:54.417Z",
    "size": 22809,
    "path": "../public/_build/assets/postgres-BTNW2TY8.js.br"
  },
  "/_build/assets/postgres-BTNW2TY8.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"6910-TIJi1C/pSmY8N+EssacoQXTDGcM\"",
    "mtime": "2025-04-16T08:54:54.417Z",
    "size": 26896,
    "path": "../public/_build/assets/postgres-BTNW2TY8.js.gz"
  },
  "/_build/assets/postgres-BTNW2TY8.js.map": {
    "type": "application/json",
    "etag": "\"9c40d-r7saBCYAHafa7v6J3lnPB1sXEfw\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 640013,
    "path": "../public/_build/assets/postgres-BTNW2TY8.js.map"
  },
  "/_build/assets/postgres-CkP7QCDB.data": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"526c95-lJxjLrWmf85THgb36V23e/arOxw\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 5401749,
    "path": "../public/_build/assets/postgres-CkP7QCDB.data"
  },
  "/_build/assets/postgres-CkP7QCDB.data.br": {
    "type": "text/plain; charset=utf-8",
    "encoding": "br",
    "etag": "\"f9092-JXet2gFsRKbBn6ofhF3lz09VBSs\"",
    "mtime": "2025-04-16T08:55:26.853Z",
    "size": 1020050,
    "path": "../public/_build/assets/postgres-CkP7QCDB.data.br"
  },
  "/_build/assets/postgres-CkP7QCDB.data.gz": {
    "type": "text/plain; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"175dfb-uJJkYcJ9/tkeBwxxU8L/FHmLVK4\"",
    "mtime": "2025-04-16T08:55:27.534Z",
    "size": 1531387,
    "path": "../public/_build/assets/postgres-CkP7QCDB.data.gz"
  },
  "/_build/assets/postgres-CyuUVpXN.wasm": {
    "type": "application/wasm",
    "etag": "\"7b746e-/KD270APleSKl3yPAnPB1+qpHLY\"",
    "mtime": "2025-04-16T08:54:50.956Z",
    "size": 8090734,
    "path": "../public/_build/assets/postgres-CyuUVpXN.wasm"
  },
  "/_build/assets/postgres-CyuUVpXN.wasm.br": {
    "type": "application/wasm",
    "encoding": "br",
    "etag": "\"208c72-60cpR2n87V/DYDUBZzLBybxHodo\"",
    "mtime": "2025-04-16T08:55:45.935Z",
    "size": 2133106,
    "path": "../public/_build/assets/postgres-CyuUVpXN.wasm.br"
  },
  "/_build/assets/postgres-CyuUVpXN.wasm.gz": {
    "type": "application/wasm",
    "encoding": "gzip",
    "etag": "\"2a5bf3-4VFWj+cTRy6hgNRypBzaoiBq5ds\"",
    "mtime": "2025-04-16T08:55:28.168Z",
    "size": 2776051,
    "path": "../public/_build/assets/postgres-CyuUVpXN.wasm.gz"
  },
  "/_build/assets/postgres-adapter-BZkHrcCt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6a85-/dfUYJs7ZMuf3mLqlqFOsnfOVKo\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 27269,
    "path": "../public/_build/assets/postgres-adapter-BZkHrcCt.js"
  },
  "/_build/assets/postgres-adapter-BZkHrcCt.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"14cf-UpfWJYVQ4uFuLUwkylsBu2b9p74\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 5327,
    "path": "../public/_build/assets/postgres-adapter-BZkHrcCt.js.br"
  },
  "/_build/assets/postgres-adapter-BZkHrcCt.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"16e1-r0azaSdnuGiCdRyPu2ybe5gBxi0\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 5857,
    "path": "../public/_build/assets/postgres-adapter-BZkHrcCt.js.gz"
  },
  "/_build/assets/postgres-adapter-BZkHrcCt.js.map": {
    "type": "application/json",
    "etag": "\"1b102-+LsWLUXkGVHh1obSVBaVKv4/EtY\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 110850,
    "path": "../public/_build/assets/postgres-adapter-BZkHrcCt.js.map"
  },
  "/_build/assets/postprocess.vertex-DGnCmbes.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3fd-E2JMlR63JnfeMOL9ly7wCFFFmW0\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1021,
    "path": "../public/_build/assets/postprocess.vertex-DGnCmbes.js"
  },
  "/_build/assets/postprocess.vertex-DGnCmbes.js.map": {
    "type": "application/json",
    "etag": "\"503-Sz9J6ww+MzmS3RvaD660lMekSQw\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1283,
    "path": "../public/_build/assets/postprocess.vertex-DGnCmbes.js.map"
  },
  "/_build/assets/preload-helper-CM3UJVvY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"414-yQ1BfivaoslMQ77xGBAljz07FYo\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1044,
    "path": "../public/_build/assets/preload-helper-CM3UJVvY.js"
  },
  "/_build/assets/preload-helper-CM3UJVvY.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"211-JgybyfwT0mmeiuEgsnJ0bb14Pk0\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 529,
    "path": "../public/_build/assets/preload-helper-CM3UJVvY.js.br"
  },
  "/_build/assets/preload-helper-CM3UJVvY.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"28b-dQGJW7vbZbVqXl84AG73RCFjAag\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 651,
    "path": "../public/_build/assets/preload-helper-CM3UJVvY.js.gz"
  },
  "/_build/assets/preload-helper-CM3UJVvY.js.map": {
    "type": "application/json",
    "etag": "\"6b-p2Si/bYdYYpZHCJvjNZB4ucwzKI\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 107,
    "path": "../public/_build/assets/preload-helper-CM3UJVvY.js.map"
  },
  "/_build/assets/qq-C4pIMC0Y.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"bbc-CUapnxBx95QAQMW34pbH5KdVgoc\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 3004,
    "path": "../public/_build/assets/qq-C4pIMC0Y.js"
  },
  "/_build/assets/qq-C4pIMC0Y.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4a1-wMcLPoiAwuQB4wSnYdfGzCxL6Mg\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1185,
    "path": "../public/_build/assets/qq-C4pIMC0Y.js.br"
  },
  "/_build/assets/qq-C4pIMC0Y.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"581-QYdcCbWczzTMeEGKqpGrM0gHcVE\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1409,
    "path": "../public/_build/assets/qq-C4pIMC0Y.js.gz"
  },
  "/_build/assets/qq-C4pIMC0Y.js.map": {
    "type": "application/json",
    "etag": "\"21e9-4YoRwj12iT9aPaYN5Y/y3X8q48o\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 8681,
    "path": "../public/_build/assets/qq-C4pIMC0Y.js.map"
  },
  "/_build/assets/repl-Dc2voNrl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"278-+JX1r9QP99rHJNBepEfHKtsszv0\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 632,
    "path": "../public/_build/assets/repl-Dc2voNrl.js"
  },
  "/_build/assets/repl-Dc2voNrl.js.map": {
    "type": "application/json",
    "etag": "\"364-0AG4wXTHZqv2QjLSPUo99/ElS3o\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 868,
    "path": "../public/_build/assets/repl-Dc2voNrl.js.map"
  },
  "/_build/assets/rgbdDecode.fragment-CMvuNNj3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3db-D27h6x4U4EP9pPftEPrnXzTiros\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 987,
    "path": "../public/_build/assets/rgbdDecode.fragment-CMvuNNj3.js"
  },
  "/_build/assets/rgbdDecode.fragment-CMvuNNj3.js.map": {
    "type": "application/json",
    "etag": "\"4d5-WYhxFOjBP4mwR52sMO+sG/OKaNI\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1237,
    "path": "../public/_build/assets/rgbdDecode.fragment-CMvuNNj3.js.map"
  },
  "/_build/assets/rgbdDecode.fragment-Wyqo4jJ2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"354-T8lPEjBLn9RHUgKXveTqvSJ1snA\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 852,
    "path": "../public/_build/assets/rgbdDecode.fragment-Wyqo4jJ2.js"
  },
  "/_build/assets/rgbdDecode.fragment-Wyqo4jJ2.js.map": {
    "type": "application/json",
    "etag": "\"43e-HIV3/baVPGbtDmYVObQ/kKehxqM\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1086,
    "path": "../public/_build/assets/rgbdDecode.fragment-Wyqo4jJ2.js.map"
  },
  "/_build/assets/rgbdEncode.fragment-C7NDOEi3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"34c-Q0LoDD7fUiad8Q0YV0XIalLFLx0\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 844,
    "path": "../public/_build/assets/rgbdEncode.fragment-C7NDOEi3.js"
  },
  "/_build/assets/rgbdEncode.fragment-C7NDOEi3.js.map": {
    "type": "application/json",
    "etag": "\"436-7YZN2lpY+dBjvn/mlB4wBdKg+Go\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1078,
    "path": "../public/_build/assets/rgbdEncode.fragment-C7NDOEi3.js.map"
  },
  "/_build/assets/rgbdEncode.fragment-Dj0iSxv6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3d2-Hmm2mNnLTD+zXNKRML4bQ+1xmbc\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 978,
    "path": "../public/_build/assets/rgbdEncode.fragment-Dj0iSxv6.js"
  },
  "/_build/assets/rgbdEncode.fragment-Dj0iSxv6.js.map": {
    "type": "application/json",
    "etag": "\"4cc-QXD+5nn43AfpvTkpXyOZmE8vKy8\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1228,
    "path": "../public/_build/assets/rgbdEncode.fragment-Dj0iSxv6.js.map"
  },
  "/_build/assets/routing-BQBHs4po.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1c93-YlSXYx+62Q+2n+SOPdjXxgPSTDk\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 7315,
    "path": "../public/_build/assets/routing-BQBHs4po.js"
  },
  "/_build/assets/routing-BQBHs4po.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"c56-L++oZUv/4hRDoHCOufGmBQ58Apc\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 3158,
    "path": "../public/_build/assets/routing-BQBHs4po.js.br"
  },
  "/_build/assets/routing-BQBHs4po.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"d89-TE4dJiq7WA9UWa+I6uriwzo08iE\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 3465,
    "path": "../public/_build/assets/routing-BQBHs4po.js.gz"
  },
  "/_build/assets/routing-BQBHs4po.js.map": {
    "type": "application/json",
    "etag": "\"ad09-+68qIEWF/9ixntdx9H6g0n/ZfzI\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 44297,
    "path": "../public/_build/assets/routing-BQBHs4po.js.map"
  },
  "/_build/assets/service.worker-C7P5OeGm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"146-JligeV+nq5YHX67MV7cWuSNw2N4\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 326,
    "path": "../public/_build/assets/service.worker-C7P5OeGm.js"
  },
  "/_build/assets/service.worker-C7P5OeGm.js.map": {
    "type": "application/json",
    "etag": "\"cdb-E3jwd4Gwzet36Ipz3Bn11Ad1yW4\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 3291,
    "path": "../public/_build/assets/service.worker-C7P5OeGm.js.map"
  },
  "/_build/assets/shadowMap.fragment-DSzmv82n.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1005-JXe4sPB7IPLQRKnAGdwTgiHubBo\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 4101,
    "path": "../public/_build/assets/shadowMap.fragment-DSzmv82n.js"
  },
  "/_build/assets/shadowMap.fragment-DSzmv82n.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"4e5-MVMHlGejxvuDNb1SiG057Ew2Ec8\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1253,
    "path": "../public/_build/assets/shadowMap.fragment-DSzmv82n.js.br"
  },
  "/_build/assets/shadowMap.fragment-DSzmv82n.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"579-tE58KhPEnCTrkwjUNs76gi8W5p0\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1401,
    "path": "../public/_build/assets/shadowMap.fragment-DSzmv82n.js.gz"
  },
  "/_build/assets/shadowMap.fragment-DSzmv82n.js.map": {
    "type": "application/json",
    "etag": "\"19e4-80qGvSqMcNMMZV2tRI+h3xmK1hE\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 6628,
    "path": "../public/_build/assets/shadowMap.fragment-DSzmv82n.js.map"
  },
  "/_build/assets/shadowMap.fragment-deamnz7Q.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d8e-TSXo2yEkVogsJMG7UD5YU2ldq2w\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 3470,
    "path": "../public/_build/assets/shadowMap.fragment-deamnz7Q.js"
  },
  "/_build/assets/shadowMap.fragment-deamnz7Q.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"479-6TvzbqdrQr5lYK+/elqxkNeLPQc\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1145,
    "path": "../public/_build/assets/shadowMap.fragment-deamnz7Q.js.br"
  },
  "/_build/assets/shadowMap.fragment-deamnz7Q.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"507-rrCgShsbUxwfZ+grZ4N79INRdXY\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1287,
    "path": "../public/_build/assets/shadowMap.fragment-deamnz7Q.js.gz"
  },
  "/_build/assets/shadowMap.fragment-deamnz7Q.js.map": {
    "type": "application/json",
    "etag": "\"1796-biM5ENQSQ0bztNSpyUFmIGVttI4\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 6038,
    "path": "../public/_build/assets/shadowMap.fragment-deamnz7Q.js.map"
  },
  "/_build/assets/shadowMap.vertex-CD5nPTp_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"12fb-/3Jl3TA/qqZ/o2qSvXtBXyzx9cw\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 4859,
    "path": "../public/_build/assets/shadowMap.vertex-CD5nPTp_.js"
  },
  "/_build/assets/shadowMap.vertex-CD5nPTp_.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"5b3-/qbw5WlY90M6wlTPjuVd1VvI4iw\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1459,
    "path": "../public/_build/assets/shadowMap.vertex-CD5nPTp_.js.br"
  },
  "/_build/assets/shadowMap.vertex-CD5nPTp_.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"66e-aPvO+snW55zbVodyv2VgApOH1Hg\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1646,
    "path": "../public/_build/assets/shadowMap.vertex-CD5nPTp_.js.gz"
  },
  "/_build/assets/shadowMap.vertex-CD5nPTp_.js.map": {
    "type": "application/json",
    "etag": "\"2909-4FNpn5OuDzEiIa3/AbWs0HrWvvY\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 10505,
    "path": "../public/_build/assets/shadowMap.vertex-CD5nPTp_.js.map"
  },
  "/_build/assets/shadowMap.vertex-CyARZ2qj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"12cb-NoQxRnadUpQmxaveSWjVusZVSYM\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 4811,
    "path": "../public/_build/assets/shadowMap.vertex-CyARZ2qj.js"
  },
  "/_build/assets/shadowMap.vertex-CyARZ2qj.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"59c-kPTIzky5V2GuS5mixD5EzB6yS8k\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1436,
    "path": "../public/_build/assets/shadowMap.vertex-CyARZ2qj.js.br"
  },
  "/_build/assets/shadowMap.vertex-CyARZ2qj.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"641-2WQd89eS5vvTQdPHoL+f8qvvZTk\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1601,
    "path": "../public/_build/assets/shadowMap.vertex-CyARZ2qj.js.gz"
  },
  "/_build/assets/shadowMap.vertex-CyARZ2qj.js.map": {
    "type": "application/json",
    "etag": "\"1fa7-c8UDhn4qjAuv2Td3yaZaamAIbZI\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 8103,
    "path": "../public/_build/assets/shadowMap.vertex-CyARZ2qj.js.map"
  },
  "/_build/assets/shadowMapFragmentSoftTransparentShadow-AhAYEMnc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"35e-BOwdImvd368gliqzl6juI+eE8/g\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 862,
    "path": "../public/_build/assets/shadowMapFragmentSoftTransparentShadow-AhAYEMnc.js"
  },
  "/_build/assets/shadowMapFragmentSoftTransparentShadow-AhAYEMnc.js.map": {
    "type": "application/json",
    "etag": "\"497-XQSxRd3qMh00SuVMe6e81d/E1LA\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1175,
    "path": "../public/_build/assets/shadowMapFragmentSoftTransparentShadow-AhAYEMnc.js.map"
  },
  "/_build/assets/shadowMapFragmentSoftTransparentShadow-CTid4Cu2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"33b-KWTS3a1tKR82y73V69f+WP2ZSkg\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 827,
    "path": "../public/_build/assets/shadowMapFragmentSoftTransparentShadow-CTid4Cu2.js"
  },
  "/_build/assets/shadowMapFragmentSoftTransparentShadow-CTid4Cu2.js.map": {
    "type": "application/json",
    "etag": "\"468-s2kacH8rsb05Kb5tPVBGtgf/RzM\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1128,
    "path": "../public/_build/assets/shadowMapFragmentSoftTransparentShadow-CTid4Cu2.js.map"
  },
  "/_build/assets/skill-CSHBowvw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4393-pDBW5mTUTEpzLwdXYCjOb+aIqD0\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 17299,
    "path": "../public/_build/assets/skill-CSHBowvw.js"
  },
  "/_build/assets/skill-CSHBowvw.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"c03-NRBxtU4bUxTqwwcJeVGY8DSJdBI\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 3075,
    "path": "../public/_build/assets/skill-CSHBowvw.js.br"
  },
  "/_build/assets/skill-CSHBowvw.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"f7b-PUdIFPbfU9ly6y4U58YotR95IEc\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 3963,
    "path": "../public/_build/assets/skill-CSHBowvw.js.gz"
  },
  "/_build/assets/skill-CSHBowvw.js.map": {
    "type": "application/json",
    "etag": "\"9962-YLVFmyYpjxHlUzfAKuifWTNZ2Wg\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 39266,
    "path": "../public/_build/assets/skill-CSHBowvw.js.map"
  },
  "/_build/assets/store-CQ2B4mPE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4244-m2EObpMeFzyjttfrS78gM51PM2k\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 16964,
    "path": "../public/_build/assets/store-CQ2B4mPE.js"
  },
  "/_build/assets/store-CQ2B4mPE.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"17a0-TIqOCifKUAHJiqltCh33yVaW6VA\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 6048,
    "path": "../public/_build/assets/store-CQ2B4mPE.js.br"
  },
  "/_build/assets/store-CQ2B4mPE.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"19ed-mqUyyABDU/jjX/sdejkcsX9Wlcs\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 6637,
    "path": "../public/_build/assets/store-CQ2B4mPE.js.gz"
  },
  "/_build/assets/store-CQ2B4mPE.js.map": {
    "type": "application/json",
    "etag": "\"1fc16-84d34M+6+GnM9K2RMmlVC4FP3l0\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 130070,
    "path": "../public/_build/assets/store-CQ2B4mPE.js.map"
  },
  "/_build/assets/tgaTextureLoader-BKIq2ss1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f7e-EcNuoBkiSWxi0U4pKaJ/smQBD20\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 3966,
    "path": "../public/_build/assets/tgaTextureLoader-BKIq2ss1.js"
  },
  "/_build/assets/tgaTextureLoader-BKIq2ss1.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"59a-h54bbTY0Tb3x9Il/Zyoz/t1jJoc\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1434,
    "path": "../public/_build/assets/tgaTextureLoader-BKIq2ss1.js.br"
  },
  "/_build/assets/tgaTextureLoader-BKIq2ss1.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"64b-+4dI6spCJJcEu7kCbheB/5GA+oA\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 1611,
    "path": "../public/_build/assets/tgaTextureLoader-BKIq2ss1.js.gz"
  },
  "/_build/assets/tgaTextureLoader-BKIq2ss1.js.map": {
    "type": "application/json",
    "etag": "\"4f11-VphMJXRlLP7XYyeNl/r75kMpsT4\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 20241,
    "path": "../public/_build/assets/tgaTextureLoader-BKIq2ss1.js.map"
  },
  "/_build/assets/toggle-C_wLPjKz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3ff-YogBiYG5lhbAw+mqUY+gs3o4MUs\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 1023,
    "path": "../public/_build/assets/toggle-C_wLPjKz.js"
  },
  "/_build/assets/toggle-C_wLPjKz.js.map": {
    "type": "application/json",
    "etag": "\"b6d-ddoguceDyk/8rX5c6etdBG1Bx7A\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 2925,
    "path": "../public/_build/assets/toggle-C_wLPjKz.js.map"
  },
  "/_build/assets/vertexColorMixing-D_371lDa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2cf-8fUDEHjARXms6PTzZdI3RbXp1BY\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 719,
    "path": "../public/_build/assets/vertexColorMixing-D_371lDa.js"
  },
  "/_build/assets/vertexColorMixing-D_371lDa.js.map": {
    "type": "application/json",
    "etag": "\"973-2mrZBkovMnCYjeRu5hpJs2ZOsbI\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 2419,
    "path": "../public/_build/assets/vertexColorMixing-D_371lDa.js.map"
  },
  "/_build/assets/vertexColorMixing-gujWcexK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3d8-KAmTXXvVps7d/pPNaaJakD7bF+4\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 984,
    "path": "../public/_build/assets/vertexColorMixing-gujWcexK.js"
  },
  "/_build/assets/vertexColorMixing-gujWcexK.js.map": {
    "type": "application/json",
    "etag": "\"ab0-9511602Ygu85AaWtrDIFf0ySD4w\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 2736,
    "path": "../public/_build/assets/vertexColorMixing-gujWcexK.js.map"
  },
  "/_build/assets/web-CIHpc6fx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6884-UiF/ozt2Fm/povU/CE6VLj+nFI4\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 26756,
    "path": "../public/_build/assets/web-CIHpc6fx.js"
  },
  "/_build/assets/web-CIHpc6fx.js.br": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "br",
    "etag": "\"2569-ddjoKpxTdHRTN/hRCW1nFUaSKKo\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 9577,
    "path": "../public/_build/assets/web-CIHpc6fx.js.br"
  },
  "/_build/assets/web-CIHpc6fx.js.gz": {
    "type": "text/javascript; charset=utf-8",
    "encoding": "gzip",
    "etag": "\"2900-dUdAYW5BN81cxX1FzpT9U5/Km1s\"",
    "mtime": "2025-04-16T08:54:54.408Z",
    "size": 10496,
    "path": "../public/_build/assets/web-CIHpc6fx.js.gz"
  },
  "/_build/assets/web-CIHpc6fx.js.map": {
    "type": "application/json",
    "etag": "\"21c4c-m94lf6cl45krgs34p241CmrKoUQ\"",
    "mtime": "2025-04-16T08:54:50.946Z",
    "size": 138316,
    "path": "../public/_build/assets/web-CIHpc6fx.js.map"
  },
  "/app-image/monster/testMonsterImage.png": {
    "type": "image/png",
    "etag": "\"b5143-7pD8INtLiifc9hB1ay9VmI+idcY\"",
    "mtime": "2025-04-16T08:54:50.752Z",
    "size": 741699,
    "path": "../public/app-image/monster/testMonsterImage.png"
  },
  "/auth/provider/icon-svg/QQ.svg": {
    "type": "image/svg+xml",
    "etag": "\"31b-JsA8PfGOxByj3QTZ9me8eifZGSI\"",
    "mtime": "2025-04-16T08:54:50.761Z",
    "size": 795,
    "path": "../public/auth/provider/icon-svg/QQ.svg"
  }
};

const _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
  if (!input) {
    return input;
  }
  return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
const _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
const _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
function cwd() {
  if (typeof process !== "undefined" && typeof process.cwd === "function") {
    return process.cwd().replace(/\\/g, "/");
  }
  return "/";
}
const resolve = function(...arguments_) {
  arguments_ = arguments_.map((argument) => normalizeWindowsPath(argument));
  let resolvedPath = "";
  let resolvedAbsolute = false;
  for (let index = arguments_.length - 1; index >= -1 && !resolvedAbsolute; index--) {
    const path = index >= 0 ? arguments_[index] : cwd();
    if (!path || path.length === 0) {
      continue;
    }
    resolvedPath = `${path}/${resolvedPath}`;
    resolvedAbsolute = isAbsolute(path);
  }
  resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute);
  if (resolvedAbsolute && !isAbsolute(resolvedPath)) {
    return `/${resolvedPath}`;
  }
  return resolvedPath.length > 0 ? resolvedPath : ".";
};
function normalizeString(path, allowAboveRoot) {
  let res = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = null;
  for (let index = 0; index <= path.length; ++index) {
    if (index < path.length) {
      char = path[index];
    } else if (char === "/") {
      break;
    } else {
      char = "/";
    }
    if (char === "/") {
      if (lastSlash === index - 1 || dots === 1) ; else if (dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf("/");
            if (lastSlashIndex === -1) {
              res = "";
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
            }
            lastSlash = index;
            dots = 0;
            continue;
          } else if (res.length > 0) {
            res = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          res += res.length > 0 ? "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) {
          res += `/${path.slice(lastSlash + 1, index)}`;
        } else {
          res = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (char === "." && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}
const isAbsolute = function(p) {
  return _IS_ABSOLUTE_RE.test(p);
};
const dirname = function(p) {
  const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
  if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) {
    segments[0] += "/";
  }
  return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _ccXNhT = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  if (encodings.length > 1) {
    appendResponseHeader(event, "Vary", "Accept-Encoding");
  }
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError$1({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

function B$1(t = {}) {
  let e, o = false;
  const a = (n) => {
    if (e && e !== n) throw new Error("Context conflict");
  };
  let r;
  if (t.asyncContext) {
    const n = t.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    n ? r = new n() : console.warn("[unctx] `AsyncLocalStorage` is not provided.");
  }
  const l = () => {
    if (r) {
      const n = r.getStore();
      if (n !== void 0) return n;
    }
    return e;
  };
  return { use: () => {
    const n = l();
    if (n === void 0) throw new Error("Context is not available");
    return n;
  }, tryUse: () => l(), set: (n, i) => {
    i || a(n), e = n, o = true;
  }, unset: () => {
    e = void 0, o = false;
  }, call: (n, i) => {
    a(n), e = n;
    try {
      return r ? r.run(n, i) : i();
    } finally {
      o || (e = void 0);
    }
  }, async callAsync(n, i) {
    e = n;
    const w = () => {
      e = n;
    }, f = () => e === n ? w : void 0;
    y$1.add(f);
    try {
      const v = r ? r.run(n, i) : i();
      return o || (e = void 0), await v;
    } finally {
      y$1.delete(f);
    }
  } };
}
function I$2(t = {}) {
  const e = {};
  return { get(o, a = {}) {
    return e[o] || (e[o] = B$1({ ...t, ...a })), e[o];
  } };
}
const u$1 = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof global < "u" ? global : {}, d$1 = "__unctx__", M$1 = u$1[d$1] || (u$1[d$1] = I$2()), N$1 = (t, e = {}) => M$1.get(t, e), p$1 = "__unctx_async_handlers__", y$1 = u$1[p$1] || (u$1[p$1] = /* @__PURE__ */ new Set());
function O$1(t) {
  let e;
  const o = h$1(t), a = { duplex: "half", method: t.method, headers: t.headers };
  return t.node.req.body instanceof ArrayBuffer ? new Request(o, { ...a, body: t.node.req.body }) : new Request(o, { ...a, get body() {
    return e || (e = oe$1(t), e);
  } });
}
function W$1(t) {
  var _a;
  return (_a = t.web) != null ? _a : t.web = { request: O$1(t), url: h$1(t) }, t.web.request;
}
function $$1() {
  return ie();
}
const g$1 = Symbol("$HTTPEvent");
function z$1(t) {
  return typeof t == "object" && (t instanceof H3Event || (t == null ? void 0 : t[g$1]) instanceof H3Event || (t == null ? void 0 : t.__is_event__) === true);
}
function s$1(t) {
  return function(...e) {
    var _a;
    let o = e[0];
    if (z$1(o)) e[0] = o instanceof H3Event || o.__is_event__ ? o : o[g$1];
    else {
      if (!((_a = globalThis.app.config.server.experimental) == null ? void 0 : _a.asyncContext)) throw new Error("AsyncLocalStorage was not enabled. Use the `server.experimental.asyncContext: true` option in your app configuration to enable it. Or, pass the instance of HTTPEvent that you have as the first argument to the function.");
      if (o = $$1(), !o) throw new Error("No HTTPEvent found in AsyncLocalStorage. Make sure you are using the function within the server runtime.");
      e.unshift(o);
    }
    return t(...e);
  };
}
const h$1 = s$1(getRequestURL), D$1 = s$1(getRequestIP), F$1 = s$1(setResponseStatus), G$1 = s$1(getResponseStatus), K$1 = s$1(getResponseStatusText), V$1 = s$1(getResponseHeaders), X$1 = s$1(getResponseHeader), Y$1 = s$1(setResponseHeader), Z$1 = s$1(appendResponseHeader), J$1 = s$1(parseCookies), Q$1 = s$1(getCookie), ee$1 = s$1(setCookie), te$1 = s$1(deleteCookie), ne$1 = s$1(setHeader), oe$1 = s$1(getRequestWebStream), se$1 = s$1(removeResponseHeader), ae = s$1(W$1);
function re$1() {
  var _a;
  return N$1("nitro-app", { asyncContext: !!((_a = globalThis.app.config.server.experimental) == null ? void 0 : _a.asyncContext), AsyncLocalStorage: AsyncLocalStorage });
}
function ie() {
  return re$1().use().event;
}

var __defProp$1 = Object.defineProperty;
var __defNormalProp$1 = (obj, key, value) => key in obj ? __defProp$1(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField$1 = (obj, key, value) => __defNormalProp$1(obj, typeof key !== "symbol" ? key + "" : key, value);
let Ke, le, Ge; (async () => {
  var Xe = ((e) => (e[e.AggregateError = 1] = "AggregateError", e[e.ArrowFunction = 2] = "ArrowFunction", e[e.ErrorPrototypeStack = 4] = "ErrorPrototypeStack", e[e.ObjectAssign = 8] = "ObjectAssign", e[e.BigIntTypedArray = 16] = "BigIntTypedArray", e[e.AbortSignal = 32] = "AbortSignal", e))(Xe || {});
  function Ye(e) {
    switch (e) {
      case '"':
        return '\\"';
      case "\\":
        return "\\\\";
      case `
`:
        return "\\n";
      case "\r":
        return "\\r";
      case "\b":
        return "\\b";
      case "	":
        return "\\t";
      case "\f":
        return "\\f";
      case "<":
        return "\\x3C";
      case "\u2028":
        return "\\u2028";
      case "\u2029":
        return "\\u2029";
      default:
        return;
    }
  }
  function g(e) {
    let r = "", t = 0, a;
    for (let i = 0, n = e.length; i < n; i++) a = Ye(e[i]), a && (r += e.slice(t, i) + a, t = i + 1);
    return t === 0 ? r = e : r += e.slice(t), r;
  }
  function Je(e) {
    switch (e) {
      case "\\\\":
        return "\\";
      case '\\"':
        return '"';
      case "\\n":
        return `
`;
      case "\\r":
        return "\r";
      case "\\b":
        return "\b";
      case "\\t":
        return "	";
      case "\\f":
        return "\f";
      case "\\x3C":
        return "<";
      case "\\u2028":
        return "\u2028";
      case "\\u2029":
        return "\u2029";
      default:
        return e;
    }
  }
  function z(e) {
    return e.replace(/(\\\\|\\"|\\n|\\r|\\b|\\t|\\f|\\u2028|\\u2029|\\x3C)/g, Je);
  }
  var E = "__SEROVAL_REFS__", C = "$R", T = `self.${C}`;
  function Ze(e) {
    return e == null ? `${T}=${T}||[]` : `(${T}=${T}||{})["${g(e)}"]=[]`;
  }
  function m(e, r) {
    if (!e) throw r;
  }
  var ue = /* @__PURE__ */ new Map(), S = /* @__PURE__ */ new Map();
  function ce(e) {
    return ue.has(e);
  }
  function Qe(e) {
    return S.has(e);
  }
  function er(e) {
    return m(ce(e), new Nr(e)), ue.get(e);
  }
  function rr(e) {
    return m(Qe(e), new $r(e)), S.get(e);
  }
  typeof globalThis < "u" ? Object.defineProperty(globalThis, E, { value: S, configurable: true, writable: false, enumerable: false }) : typeof self < "u" ? Object.defineProperty(self, E, { value: S, configurable: true, writable: false, enumerable: false }) : typeof global < "u" && Object.defineProperty(global, E, { value: S, configurable: true, writable: false, enumerable: false });
  function he(e, r) {
    for (let t = 0, a = r.length; t < a; t++) {
      let i = r[t];
      e.has(i) || (e.add(i), i.extends && he(e, i.extends));
    }
  }
  function pe(e) {
    if (e) {
      let r = /* @__PURE__ */ new Set();
      return he(r, e), [...r];
    }
  }
  var tr = { 0: "Symbol.asyncIterator", 1: "Symbol.hasInstance", 2: "Symbol.isConcatSpreadable", 3: "Symbol.iterator", 4: "Symbol.match", 5: "Symbol.matchAll", 6: "Symbol.replace", 7: "Symbol.search", 8: "Symbol.species", 9: "Symbol.split", 10: "Symbol.toPrimitive", 11: "Symbol.toStringTag", 12: "Symbol.unscopables" }, fe = { [Symbol.asyncIterator]: 0, [Symbol.hasInstance]: 1, [Symbol.isConcatSpreadable]: 2, [Symbol.iterator]: 3, [Symbol.match]: 4, [Symbol.matchAll]: 5, [Symbol.replace]: 6, [Symbol.search]: 7, [Symbol.species]: 8, [Symbol.split]: 9, [Symbol.toPrimitive]: 10, [Symbol.toStringTag]: 11, [Symbol.unscopables]: 12 }, sr = { 0: Symbol.asyncIterator, 1: Symbol.hasInstance, 2: Symbol.isConcatSpreadable, 3: Symbol.iterator, 4: Symbol.match, 5: Symbol.matchAll, 6: Symbol.replace, 7: Symbol.search, 8: Symbol.species, 9: Symbol.split, 10: Symbol.toPrimitive, 11: Symbol.toStringTag, 12: Symbol.unscopables }, ar = { 2: "!0", 3: "!1", 1: "void 0", 0: "null", 4: "-0", 5: "1/0", 6: "-1/0", 7: "0/0" }, ir = { 2: true, 3: false, 1: void 0, 0: null, 4: -0, 5: Number.POSITIVE_INFINITY, 6: Number.NEGATIVE_INFINITY, 7: Number.NaN }, de = { 0: "Error", 1: "EvalError", 2: "RangeError", 3: "ReferenceError", 4: "SyntaxError", 5: "TypeError", 6: "URIError" }, nr = { 0: Error, 1: EvalError, 2: RangeError, 3: ReferenceError, 4: SyntaxError, 5: TypeError, 6: URIError }, s = void 0;
  function p(e, r, t, a, i, n, o, l, u, c, f, A) {
    return { t: e, i: r, s: t, l: a, c: i, m: n, p: o, e: l, a: u, f: c, b: f, o: A };
  }
  function y(e) {
    return p(2, s, e, s, s, s, s, s, s, s, s, s);
  }
  var M = y(2), U = y(3), or = y(1), lr = y(0), ur = y(4), cr = y(5), hr = y(6), pr = y(7);
  function _(e) {
    return e instanceof EvalError ? 1 : e instanceof RangeError ? 2 : e instanceof ReferenceError ? 3 : e instanceof SyntaxError ? 4 : e instanceof TypeError ? 5 : e instanceof URIError ? 6 : 0;
  }
  function fr(e) {
    let r = de[_(e)];
    return e.name !== r ? { name: e.name } : e.constructor.name !== r ? { name: e.constructor.name } : {};
  }
  function ge(e, r) {
    let t = fr(e), a = Object.getOwnPropertyNames(e);
    for (let i = 0, n = a.length, o; i < n; i++) o = a[i], o !== "name" && o !== "message" && (o === "stack" ? r & 4 && (t = t || {}, t[o] = e[o]) : (t = t || {}, t[o] = e[o]));
    return t;
  }
  function me(e) {
    return Object.isFrozen(e) ? 3 : Object.isSealed(e) ? 2 : Object.isExtensible(e) ? 0 : 1;
  }
  function dr(e) {
    switch (e) {
      case Number.POSITIVE_INFINITY:
        return cr;
      case Number.NEGATIVE_INFINITY:
        return hr;
    }
    return e !== e ? pr : Object.is(e, -0) ? ur : p(0, s, e, s, s, s, s, s, s, s, s, s);
  }
  function L(e) {
    return p(1, s, g(e), s, s, s, s, s, s, s, s, s);
  }
  function gr(e) {
    return p(3, s, "" + e, s, s, s, s, s, s, s, s, s);
  }
  function mr(e) {
    return p(4, e, s, s, s, s, s, s, s, s, s, s);
  }
  function yr(e, r) {
    return p(5, e, r.toISOString(), s, s, s, s, s, s, s, s, s);
  }
  function br(e, r) {
    return p(6, e, s, s, g(r.source), r.flags, s, s, s, s, s, s);
  }
  function zr(e, r) {
    let t = new Uint8Array(r), a = t.length, i = new Array(a);
    for (let n = 0; n < a; n++) i[n] = t[n];
    return p(19, e, i, s, s, s, s, s, s, s, s, s);
  }
  function Sr(e, r) {
    return p(17, e, fe[r], s, s, s, s, s, s, s, s, s);
  }
  function wr(e, r) {
    return p(18, e, g(er(r)), s, s, s, s, s, s, s, s, s);
  }
  function ye(e, r, t) {
    return p(25, e, t, s, g(r), s, s, s, s, s, s, s);
  }
  function vr(e, r, t) {
    return p(9, e, s, r.length, s, s, s, s, t, s, s, me(r));
  }
  function Ar(e, r) {
    return p(21, e, s, s, s, s, s, s, s, r, s, s);
  }
  function Er(e, r, t) {
    return p(15, e, s, r.length, r.constructor.name, s, s, s, s, t, r.byteOffset, s);
  }
  function Pr(e, r, t) {
    return p(16, e, s, r.length, r.constructor.name, s, s, s, s, t, r.byteOffset, s);
  }
  function Ir(e, r, t) {
    return p(20, e, s, r.byteLength, s, s, s, s, s, t, r.byteOffset, s);
  }
  function xr(e, r, t) {
    return p(13, e, _(r), s, s, g(r.message), t, s, s, s, s, s);
  }
  function Rr(e, r, t) {
    return p(14, e, _(r), s, s, g(r.message), t, s, s, s, s, s);
  }
  function kr(e, r, t) {
    return p(7, e, s, r, s, s, s, s, t, s, s, s);
  }
  function be(e, r) {
    return p(28, s, s, s, s, s, s, s, [e, r], s, s, s);
  }
  function ze(e, r) {
    return p(30, s, s, s, s, s, s, s, [e, r], s, s, s);
  }
  function Se(e, r, t) {
    return p(31, e, s, s, s, s, s, s, t, r, s, s);
  }
  function Fr(e, r) {
    return p(32, e, s, s, s, s, s, s, s, r, s, s);
  }
  function Cr(e, r) {
    return p(33, e, s, s, s, s, s, s, s, r, s, s);
  }
  function Tr(e, r) {
    return p(34, e, s, s, s, s, s, s, s, r, s, s);
  }
  var { toString: B } = Object.prototype;
  function Or(e, r) {
    return r instanceof Error ? `Seroval caught an error during the ${e} process.
  
${r.name}
${r.message}

- For more information, please check the "cause" property of this error.
- If you believe this is an error in Seroval, please submit an issue at https://github.com/lxsmnsyc/seroval/issues/new` : `Seroval caught an error during the ${e} process.

"${B.call(r)}"

For more information, please check the "cause" property of this error.`;
  }
  var W = class extends Error {
    constructor(e, r) {
      super(Or(e, r)), this.cause = r;
    }
  }, jr = class extends W {
    constructor(e) {
      super("parsing", e);
    }
  }, Vr = class extends W {
    constructor(e) {
      super("serialization", e);
    }
  }, Dr = class extends W {
    constructor(e) {
      super("deserialization", e);
    }
  }, O = class extends Error {
    constructor(e) {
      super(`The value ${B.call(e)} of type "${typeof e}" cannot be parsed/serialized.
      
There are few workarounds for this problem:
- Transform the value in a way that it can be serialized.
- If the reference is present on multiple runtimes (isomorphic), you can use the Reference API to map the references.`), this.value = e;
    }
  }, we = class extends Error {
    constructor(e) {
      super('Unsupported node type "' + e.t + '".');
    }
  }, ve = class extends Error {
    constructor(e) {
      super('Missing plugin for tag "' + e + '".');
    }
  }, w = class extends Error {
    constructor(e) {
      super('Missing "' + e + '" instance.');
    }
  }, Nr = class extends Error {
    constructor(e) {
      super('Missing reference for the value "' + B.call(e) + '" of type "' + typeof e + '"'), this.value = e;
    }
  }, $r = class extends Error {
    constructor(e) {
      super('Missing reference for id "' + g(e) + '"');
    }
  }, Mr = class extends Error {
    constructor(e) {
      super('Unknown TypedArray "' + e + '"');
    }
  }, Ur = class {
    constructor(e, r) {
      this.value = e, this.replacement = r;
    }
  }, _r = {}, Lr = {}, Br = { 0: {}, 1: {}, 2: {}, 3: {}, 4: {}, 5: {}, 6: {} };
  function q() {
    let e, r;
    return { promise: new Promise((t, a) => {
      e = t, r = a;
    }), resolve(t) {
      e(t);
    }, reject(t) {
      r(t);
    } };
  }
  function Wr(e) {
    return "__SEROVAL_STREAM__" in e;
  }
  function P() {
    let e = /* @__PURE__ */ new Set(), r = [], t = true, a = true;
    function i(l) {
      for (let u of e.keys()) u.next(l);
    }
    function n(l) {
      for (let u of e.keys()) u.throw(l);
    }
    function o(l) {
      for (let u of e.keys()) u.return(l);
    }
    return { __SEROVAL_STREAM__: true, on(l) {
      t && e.add(l);
      for (let u = 0, c = r.length; u < c; u++) {
        let f = r[u];
        u === c - 1 && !t ? a ? l.return(f) : l.throw(f) : l.next(f);
      }
      return () => {
        t && e.delete(l);
      };
    }, next(l) {
      t && (r.push(l), i(l));
    }, throw(l) {
      t && (r.push(l), n(l), t = false, a = false, e.clear());
    }, return(l) {
      t && (r.push(l), o(l), t = false, a = true, e.clear());
    } };
  }
  function qr(e) {
    let r = P(), t = e[Symbol.asyncIterator]();
    async function a() {
      try {
        let i = await t.next();
        i.done ? r.return(i.value) : (r.next(i.value), await a());
      } catch (i) {
        r.throw(i);
      }
    }
    return a().catch(() => {
    }), r;
  }
  function Hr(e) {
    return () => {
      let r = [], t = [], a = 0, i = -1, n = false;
      function o() {
        for (let u = 0, c = t.length; u < c; u++) t[u].resolve({ done: true, value: void 0 });
      }
      e.on({ next(u) {
        let c = t.shift();
        c && c.resolve({ done: false, value: u }), r.push(u);
      }, throw(u) {
        let c = t.shift();
        c && c.reject(u), o(), i = r.length, r.push(u), n = true;
      }, return(u) {
        let c = t.shift();
        c && c.resolve({ done: true, value: u }), o(), i = r.length, r.push(u);
      } });
      function l() {
        let u = a++, c = r[u];
        if (u !== i) return { done: false, value: c };
        if (n) throw c;
        return { done: true, value: c };
      }
      return { [Symbol.asyncIterator]() {
        return this;
      }, async next() {
        if (i === -1) {
          let u = a++;
          if (u >= r.length) {
            let c = q();
            return t.push(c), await c.promise;
          }
          return { done: false, value: r[u] };
        }
        return a > i ? { done: true, value: void 0 } : l();
      } };
    };
  }
  function Ae(e) {
    let r = [], t = -1, a = -1, i = e[Symbol.iterator]();
    for (; ; ) try {
      let n = i.next();
      if (r.push(n.value), n.done) {
        a = r.length - 1;
        break;
      }
    } catch (n) {
      t = r.length, r.push(n);
    }
    return { v: r, t, d: a };
  }
  function Kr(e) {
    return () => {
      let r = 0;
      return { [Symbol.iterator]() {
        return this;
      }, next() {
        if (r > e.d) return { done: true, value: s };
        let t = r++, a = e.v[t];
        if (t === e.t) throw a;
        return { done: t === e.d, value: a };
      } };
    };
  }
  var Gr = class {
    constructor(e) {
      this.marked = /* @__PURE__ */ new Set(), this.plugins = e.plugins, this.features = 47 ^ (e.disabledFeatures || 0), this.refs = e.refs || /* @__PURE__ */ new Map();
    }
    markRef(e) {
      this.marked.add(e);
    }
    isMarked(e) {
      return this.marked.has(e);
    }
    getIndexedValue(e) {
      let r = this.refs.get(e);
      if (r != null) return this.markRef(r), { type: 1, value: mr(r) };
      let t = this.refs.size;
      return this.refs.set(e, t), { type: 0, value: t };
    }
    getReference(e) {
      let r = this.getIndexedValue(e);
      return r.type === 1 ? r : ce(e) ? { type: 2, value: wr(r.value, e) } : r;
    }
    parseWellKnownSymbol(e) {
      let r = this.getReference(e);
      return r.type !== 0 ? r.value : (m(e in fe, new O(e)), Sr(r.value, e));
    }
    parseSpecialReference(e) {
      let r = this.getIndexedValue(Br[e]);
      return r.type === 1 ? r.value : p(26, r.value, e, s, s, s, s, s, s, s, s, s);
    }
    parseIteratorFactory() {
      let e = this.getIndexedValue(_r);
      return e.type === 1 ? e.value : p(27, e.value, s, s, s, s, s, s, s, this.parseWellKnownSymbol(Symbol.iterator), s, s);
    }
    parseAsyncIteratorFactory() {
      let e = this.getIndexedValue(Lr);
      return e.type === 1 ? e.value : p(29, e.value, s, s, s, s, s, s, [this.parseSpecialReference(1), this.parseWellKnownSymbol(Symbol.asyncIterator)], s, s, s);
    }
    createObjectNode(e, r, t, a) {
      return p(t ? 11 : 10, e, s, s, s, s, a, s, s, s, s, me(r));
    }
    createMapNode(e, r, t, a) {
      return p(8, e, s, s, s, s, s, { k: r, v: t, s: a }, s, this.parseSpecialReference(0), s, s);
    }
    createPromiseConstructorNode(e) {
      return p(22, e, s, s, s, s, s, s, s, this.parseSpecialReference(1), s, s);
    }
    createAbortSignalConstructorNode(e) {
      return p(35, e, s, s, s, s, s, s, s, this.parseSpecialReference(5), s, s);
    }
  };
  function Xr(e) {
    switch (e) {
      case "Int8Array":
        return Int8Array;
      case "Int16Array":
        return Int16Array;
      case "Int32Array":
        return Int32Array;
      case "Uint8Array":
        return Uint8Array;
      case "Uint16Array":
        return Uint16Array;
      case "Uint32Array":
        return Uint32Array;
      case "Uint8ClampedArray":
        return Uint8ClampedArray;
      case "Float32Array":
        return Float32Array;
      case "Float64Array":
        return Float64Array;
      case "BigInt64Array":
        return BigInt64Array;
      case "BigUint64Array":
        return BigUint64Array;
      default:
        throw new Mr(e);
    }
  }
  function Ee(e, r) {
    switch (r) {
      case 3:
        return Object.freeze(e);
      case 1:
        return Object.preventExtensions(e);
      case 2:
        return Object.seal(e);
      default:
        return e;
    }
  }
  var Yr = class {
    constructor(e) {
      this.plugins = e.plugins, this.refs = e.refs || /* @__PURE__ */ new Map();
    }
    deserializeReference(e) {
      return this.assignIndexedValue(e.i, rr(z(e.s)));
    }
    deserializeArray(e) {
      let r = e.l, t = this.assignIndexedValue(e.i, new Array(r)), a;
      for (let i = 0; i < r; i++) a = e.a[i], a && (t[i] = this.deserialize(a));
      return Ee(t, e.o), t;
    }
    deserializeProperties(e, r) {
      let t = e.s;
      if (t) {
        let a = e.k, i = e.v;
        for (let n = 0, o; n < t; n++) o = a[n], typeof o == "string" ? r[z(o)] = this.deserialize(i[n]) : r[this.deserialize(o)] = this.deserialize(i[n]);
      }
      return r;
    }
    deserializeObject(e) {
      let r = this.assignIndexedValue(e.i, e.t === 10 ? {} : /* @__PURE__ */ Object.create(null));
      return this.deserializeProperties(e.p, r), Ee(r, e.o), r;
    }
    deserializeDate(e) {
      return this.assignIndexedValue(e.i, new Date(e.s));
    }
    deserializeRegExp(e) {
      return this.assignIndexedValue(e.i, new RegExp(z(e.c), e.m));
    }
    deserializeSet(e) {
      let r = this.assignIndexedValue(e.i, /* @__PURE__ */ new Set()), t = e.a;
      for (let a = 0, i = e.l; a < i; a++) r.add(this.deserialize(t[a]));
      return r;
    }
    deserializeMap(e) {
      let r = this.assignIndexedValue(e.i, /* @__PURE__ */ new Map()), t = e.e.k, a = e.e.v;
      for (let i = 0, n = e.e.s; i < n; i++) r.set(this.deserialize(t[i]), this.deserialize(a[i]));
      return r;
    }
    deserializeArrayBuffer(e) {
      let r = new Uint8Array(e.s);
      return this.assignIndexedValue(e.i, r.buffer);
    }
    deserializeTypedArray(e) {
      let r = Xr(e.c), t = this.deserialize(e.f);
      return this.assignIndexedValue(e.i, new r(t, e.b, e.l));
    }
    deserializeDataView(e) {
      let r = this.deserialize(e.f);
      return this.assignIndexedValue(e.i, new DataView(r, e.b, e.l));
    }
    deserializeDictionary(e, r) {
      if (e.p) {
        let t = this.deserializeProperties(e.p, {});
        Object.assign(r, t);
      }
      return r;
    }
    deserializeAggregateError(e) {
      let r = this.assignIndexedValue(e.i, new AggregateError([], z(e.m)));
      return this.deserializeDictionary(e, r);
    }
    deserializeError(e) {
      let r = nr[e.s], t = this.assignIndexedValue(e.i, new r(z(e.m)));
      return this.deserializeDictionary(e, t);
    }
    deserializePromise(e) {
      let r = q(), t = this.assignIndexedValue(e.i, r), a = this.deserialize(e.f);
      return e.s ? r.resolve(a) : r.reject(a), t.promise;
    }
    deserializeBoxed(e) {
      return this.assignIndexedValue(e.i, Object(this.deserialize(e.f)));
    }
    deserializePlugin(e) {
      let r = this.plugins;
      if (r) {
        let t = z(e.c);
        for (let a = 0, i = r.length; a < i; a++) {
          let n = r[a];
          if (n.tag === t) return this.assignIndexedValue(e.i, n.deserialize(e.s, this, { id: e.i }));
        }
      }
      throw new ve(e.c);
    }
    deserializePromiseConstructor(e) {
      return this.assignIndexedValue(e.i, q()).promise;
    }
    deserializePromiseResolve(e) {
      let r = this.refs.get(e.i);
      m(r, new w("Promise")), r.resolve(this.deserialize(e.a[1]));
    }
    deserializePromiseReject(e) {
      let r = this.refs.get(e.i);
      m(r, new w("Promise")), r.reject(this.deserialize(e.a[1]));
    }
    deserializeIteratorFactoryInstance(e) {
      this.deserialize(e.a[0]);
      let r = this.deserialize(e.a[1]);
      return Kr(r);
    }
    deserializeAsyncIteratorFactoryInstance(e) {
      this.deserialize(e.a[0]);
      let r = this.deserialize(e.a[1]);
      return Hr(r);
    }
    deserializeStreamConstructor(e) {
      let r = this.assignIndexedValue(e.i, P()), t = e.a.length;
      if (t) for (let a = 0; a < t; a++) this.deserialize(e.a[a]);
      return r;
    }
    deserializeStreamNext(e) {
      let r = this.refs.get(e.i);
      m(r, new w("Stream")), r.next(this.deserialize(e.f));
    }
    deserializeStreamThrow(e) {
      let r = this.refs.get(e.i);
      m(r, new w("Stream")), r.throw(this.deserialize(e.f));
    }
    deserializeStreamReturn(e) {
      let r = this.refs.get(e.i);
      m(r, new w("Stream")), r.return(this.deserialize(e.f));
    }
    deserializeIteratorFactory(e) {
      this.deserialize(e.f);
    }
    deserializeAsyncIteratorFactory(e) {
      this.deserialize(e.a[1]);
    }
    deserializeAbortSignalConstructor(e) {
      return this.assignIndexedValue(e.i, new AbortController()).signal;
    }
    deserializeAbortSignalAbort(e) {
      let r = this.refs.get(e.i);
      m(r, new w("AbortSignal")), r.abort(this.deserialize(e.a[1]));
    }
    deserializeAbortSignalSync(e) {
      return this.assignIndexedValue(e.i, AbortSignal.abort(this.deserialize(e.f)));
    }
    deserialize(e) {
      try {
        switch (e.t) {
          case 2:
            return ir[e.s];
          case 0:
            return e.s;
          case 1:
            return z(e.s);
          case 3:
            return BigInt(e.s);
          case 4:
            return this.refs.get(e.i);
          case 18:
            return this.deserializeReference(e);
          case 9:
            return this.deserializeArray(e);
          case 10:
          case 11:
            return this.deserializeObject(e);
          case 5:
            return this.deserializeDate(e);
          case 6:
            return this.deserializeRegExp(e);
          case 7:
            return this.deserializeSet(e);
          case 8:
            return this.deserializeMap(e);
          case 19:
            return this.deserializeArrayBuffer(e);
          case 16:
          case 15:
            return this.deserializeTypedArray(e);
          case 20:
            return this.deserializeDataView(e);
          case 14:
            return this.deserializeAggregateError(e);
          case 13:
            return this.deserializeError(e);
          case 12:
            return this.deserializePromise(e);
          case 17:
            return sr[e.s];
          case 21:
            return this.deserializeBoxed(e);
          case 25:
            return this.deserializePlugin(e);
          case 22:
            return this.deserializePromiseConstructor(e);
          case 23:
            return this.deserializePromiseResolve(e);
          case 24:
            return this.deserializePromiseReject(e);
          case 28:
            return this.deserializeIteratorFactoryInstance(e);
          case 30:
            return this.deserializeAsyncIteratorFactoryInstance(e);
          case 31:
            return this.deserializeStreamConstructor(e);
          case 32:
            return this.deserializeStreamNext(e);
          case 33:
            return this.deserializeStreamThrow(e);
          case 34:
            return this.deserializeStreamReturn(e);
          case 27:
            return this.deserializeIteratorFactory(e);
          case 29:
            return this.deserializeAsyncIteratorFactory(e);
          case 36:
            return this.deserializeAbortSignalAbort(e);
          case 35:
            return this.deserializeAbortSignalConstructor(e);
          case 37:
            return this.deserializeAbortSignalSync(e);
          default:
            throw new we(e);
        }
      } catch (r) {
        throw new Dr(r);
      }
    }
  }, Jr = /^[$A-Z_][0-9A-Z_$]*$/i;
  function Pe(e) {
    let r = e[0];
    return (r === "$" || r === "_" || r >= "A" && r <= "Z" || r >= "a" && r <= "z") && Jr.test(e);
  }
  function I(e) {
    switch (e.t) {
      case 0:
        return e.s + "=" + e.v;
      case 2:
        return e.s + ".set(" + e.k + "," + e.v + ")";
      case 1:
        return e.s + ".add(" + e.v + ")";
      case 3:
        return e.s + ".delete(" + e.k + ")";
    }
  }
  function Zr(e) {
    let r = [], t = e[0];
    for (let a = 1, i = e.length, n, o = t; a < i; a++) n = e[a], n.t === 0 && n.v === o.v ? t = { t: 0, s: n.s, k: s, v: I(t) } : n.t === 2 && n.s === o.s ? t = { t: 2, s: I(t), k: n.k, v: n.v } : n.t === 1 && n.s === o.s ? t = { t: 1, s: I(t), k: s, v: n.v } : n.t === 3 && n.s === o.s ? t = { t: 3, s: I(t), k: n.k, v: s } : (r.push(t), t = n), o = n;
    return r.push(t), r;
  }
  function Ie(e) {
    if (e.length) {
      let r = "", t = Zr(e);
      for (let a = 0, i = t.length; a < i; a++) r += I(t[a]) + ",";
      return r;
    }
    return s;
  }
  var Qr = "Object.create(null)", et = "new Set", rt = "new Map", tt = "Promise.resolve", st = "Promise.reject", at = { 3: "Object.freeze", 2: "Object.seal", 1: "Object.preventExtensions", 0: s }, it = class {
    constructor(e) {
      this.stack = [], this.flags = [], this.assignments = [], this.plugins = e.plugins, this.features = e.features, this.marked = new Set(e.markedRefs);
    }
    createFunction(e, r) {
      return this.features & 2 ? (e.length === 1 ? e[0] : "(" + e.join(",") + ")") + "=>" + (r.startsWith("{") ? "(" + r + ")" : r) : "function(" + e.join(",") + "){return " + r + "}";
    }
    createEffectfulFunction(e, r) {
      return this.features & 2 ? (e.length === 1 ? e[0] : "(" + e.join(",") + ")") + "=>{" + r + "}" : "function(" + e.join(",") + "){" + r + "}";
    }
    markRef(e) {
      this.marked.add(e);
    }
    isMarked(e) {
      return this.marked.has(e);
    }
    pushObjectFlag(e, r) {
      e !== 0 && (this.markRef(r), this.flags.push({ type: e, value: this.getRefParam(r) }));
    }
    resolveFlags() {
      let e = "";
      for (let r = 0, t = this.flags, a = t.length; r < a; r++) {
        let i = t[r];
        e += at[i.type] + "(" + i.value + "),";
      }
      return e;
    }
    resolvePatches() {
      let e = Ie(this.assignments), r = this.resolveFlags();
      return e ? r ? e + r : e : r;
    }
    createAssignment(e, r) {
      this.assignments.push({ t: 0, s: e, k: s, v: r });
    }
    createAddAssignment(e, r) {
      this.assignments.push({ t: 1, s: this.getRefParam(e), k: s, v: r });
    }
    createSetAssignment(e, r, t) {
      this.assignments.push({ t: 2, s: this.getRefParam(e), k: r, v: t });
    }
    createDeleteAssignment(e, r) {
      this.assignments.push({ t: 3, s: this.getRefParam(e), k: r, v: s });
    }
    createArrayAssign(e, r, t) {
      this.createAssignment(this.getRefParam(e) + "[" + r + "]", t);
    }
    createObjectAssign(e, r, t) {
      this.createAssignment(this.getRefParam(e) + "." + r, t);
    }
    isIndexedValueInStack(e) {
      return e.t === 4 && this.stack.includes(e.i);
    }
    serializeReference(e) {
      return this.assignIndexedValue(e.i, E + '.get("' + e.s + '")');
    }
    serializeArrayItem(e, r, t) {
      return r ? this.isIndexedValueInStack(r) ? (this.markRef(e), this.createArrayAssign(e, t, this.getRefParam(r.i)), "") : this.serialize(r) : "";
    }
    serializeArray(e) {
      let r = e.i;
      if (e.l) {
        this.stack.push(r);
        let t = e.a, a = this.serializeArrayItem(r, t[0], 0), i = a === "";
        for (let n = 1, o = e.l, l; n < o; n++) l = this.serializeArrayItem(r, t[n], n), a += "," + l, i = l === "";
        return this.stack.pop(), this.pushObjectFlag(e.o, e.i), this.assignIndexedValue(r, "[" + a + (i ? ",]" : "]"));
      }
      return this.assignIndexedValue(r, "[]");
    }
    serializeProperty(e, r, t) {
      if (typeof r == "string") {
        let a = Number(r), i = a >= 0 && a.toString() === r || Pe(r);
        if (this.isIndexedValueInStack(t)) {
          let n = this.getRefParam(t.i);
          return this.markRef(e.i), i && a !== a ? this.createObjectAssign(e.i, r, n) : this.createArrayAssign(e.i, i ? r : '"' + r + '"', n), "";
        }
        return (i ? r : '"' + r + '"') + ":" + this.serialize(t);
      }
      return "[" + this.serialize(r) + "]:" + this.serialize(t);
    }
    serializeProperties(e, r) {
      let t = r.s;
      if (t) {
        let a = r.k, i = r.v;
        this.stack.push(e.i);
        let n = this.serializeProperty(e, a[0], i[0]);
        for (let o = 1, l = n; o < t; o++) l = this.serializeProperty(e, a[o], i[o]), n += (l && n && ",") + l;
        return this.stack.pop(), "{" + n + "}";
      }
      return "{}";
    }
    serializeObject(e) {
      return this.pushObjectFlag(e.o, e.i), this.assignIndexedValue(e.i, this.serializeProperties(e, e.p));
    }
    serializeWithObjectAssign(e, r, t) {
      let a = this.serializeProperties(e, r);
      return a !== "{}" ? "Object.assign(" + t + "," + a + ")" : t;
    }
    serializeStringKeyAssignment(e, r, t, a) {
      let i = this.serialize(a), n = Number(t), o = n >= 0 && n.toString() === t || Pe(t);
      if (this.isIndexedValueInStack(a)) o && n !== n ? this.createObjectAssign(e.i, t, i) : this.createArrayAssign(e.i, o ? t : '"' + t + '"', i);
      else {
        let l = this.assignments;
        this.assignments = r, o && n !== n ? this.createObjectAssign(e.i, t, i) : this.createArrayAssign(e.i, o ? t : '"' + t + '"', i), this.assignments = l;
      }
    }
    serializeAssignment(e, r, t, a) {
      if (typeof t == "string") this.serializeStringKeyAssignment(e, r, t, a);
      else {
        let i = this.stack;
        this.stack = [];
        let n = this.serialize(a);
        this.stack = i;
        let o = this.assignments;
        this.assignments = r, this.createArrayAssign(e.i, this.serialize(t), n), this.assignments = o;
      }
    }
    serializeAssignments(e, r) {
      let t = r.s;
      if (t) {
        let a = [], i = r.k, n = r.v;
        this.stack.push(e.i);
        for (let o = 0; o < t; o++) this.serializeAssignment(e, a, i[o], n[o]);
        return this.stack.pop(), Ie(a);
      }
      return s;
    }
    serializeDictionary(e, r) {
      if (e.p) if (this.features & 8) r = this.serializeWithObjectAssign(e, e.p, r);
      else {
        this.markRef(e.i);
        let t = this.serializeAssignments(e, e.p);
        if (t) return "(" + this.assignIndexedValue(e.i, r) + "," + t + this.getRefParam(e.i) + ")";
      }
      return this.assignIndexedValue(e.i, r);
    }
    serializeNullConstructor(e) {
      return this.pushObjectFlag(e.o, e.i), this.serializeDictionary(e, Qr);
    }
    serializeDate(e) {
      return this.assignIndexedValue(e.i, 'new Date("' + e.s + '")');
    }
    serializeRegExp(e) {
      return this.assignIndexedValue(e.i, "/" + e.c + "/" + e.m);
    }
    serializeSetItem(e, r) {
      return this.isIndexedValueInStack(r) ? (this.markRef(e), this.createAddAssignment(e, this.getRefParam(r.i)), "") : this.serialize(r);
    }
    serializeSet(e) {
      let r = et, t = e.l, a = e.i;
      if (t) {
        let i = e.a;
        this.stack.push(a);
        let n = this.serializeSetItem(a, i[0]);
        for (let o = 1, l = n; o < t; o++) l = this.serializeSetItem(a, i[o]), n += (l && n && ",") + l;
        this.stack.pop(), n && (r += "([" + n + "])");
      }
      return this.assignIndexedValue(a, r);
    }
    serializeMapEntry(e, r, t, a) {
      if (this.isIndexedValueInStack(r)) {
        let i = this.getRefParam(r.i);
        if (this.markRef(e), this.isIndexedValueInStack(t)) {
          let o = this.getRefParam(t.i);
          return this.createSetAssignment(e, i, o), "";
        }
        if (t.t !== 4 && t.i != null && this.isMarked(t.i)) {
          let o = "(" + this.serialize(t) + ",[" + a + "," + a + "])";
          return this.createSetAssignment(e, i, this.getRefParam(t.i)), this.createDeleteAssignment(e, a), o;
        }
        let n = this.stack;
        return this.stack = [], this.createSetAssignment(e, i, this.serialize(t)), this.stack = n, "";
      }
      if (this.isIndexedValueInStack(t)) {
        let i = this.getRefParam(t.i);
        if (this.markRef(e), r.t !== 4 && r.i != null && this.isMarked(r.i)) {
          let o = "(" + this.serialize(r) + ",[" + a + "," + a + "])";
          return this.createSetAssignment(e, this.getRefParam(r.i), i), this.createDeleteAssignment(e, a), o;
        }
        let n = this.stack;
        return this.stack = [], this.createSetAssignment(e, this.serialize(r), i), this.stack = n, "";
      }
      return "[" + this.serialize(r) + "," + this.serialize(t) + "]";
    }
    serializeMap(e) {
      let r = rt, t = e.e.s, a = e.i, i = e.f, n = this.getRefParam(i.i);
      if (t) {
        let o = e.e.k, l = e.e.v;
        this.stack.push(a);
        let u = this.serializeMapEntry(a, o[0], l[0], n);
        for (let c = 1, f = u; c < t; c++) f = this.serializeMapEntry(a, o[c], l[c], n), u += (f && u && ",") + f;
        this.stack.pop(), u && (r += "([" + u + "])");
      }
      return i.t === 26 && (this.markRef(i.i), r = "(" + this.serialize(i) + "," + r + ")"), this.assignIndexedValue(a, r);
    }
    serializeArrayBuffer(e) {
      let r = "new Uint8Array(", t = e.s, a = t.length;
      if (a) {
        r += "[" + t[0];
        for (let i = 1; i < a; i++) r += "," + t[i];
        r += "]";
      }
      return this.assignIndexedValue(e.i, r + ").buffer");
    }
    serializeTypedArray(e) {
      return this.assignIndexedValue(e.i, "new " + e.c + "(" + this.serialize(e.f) + "," + e.b + "," + e.l + ")");
    }
    serializeDataView(e) {
      return this.assignIndexedValue(e.i, "new DataView(" + this.serialize(e.f) + "," + e.b + "," + e.l + ")");
    }
    serializeAggregateError(e) {
      let r = e.i;
      this.stack.push(r);
      let t = this.serializeDictionary(e, 'new AggregateError([],"' + e.m + '")');
      return this.stack.pop(), t;
    }
    serializeError(e) {
      return this.serializeDictionary(e, "new " + de[e.s] + '("' + e.m + '")');
    }
    serializePromise(e) {
      let r, t = e.f, a = e.i, i = e.s ? tt : st;
      if (this.isIndexedValueInStack(t)) {
        let n = this.getRefParam(t.i);
        r = i + (e.s ? "().then(" + this.createFunction([], n) + ")" : "().catch(" + this.createEffectfulFunction([], "throw " + n) + ")");
      } else {
        this.stack.push(a);
        let n = this.serialize(t);
        this.stack.pop(), r = i + "(" + n + ")";
      }
      return this.assignIndexedValue(a, r);
    }
    serializeWellKnownSymbol(e) {
      return this.assignIndexedValue(e.i, tr[e.s]);
    }
    serializeBoxed(e) {
      return this.assignIndexedValue(e.i, "Object(" + this.serialize(e.f) + ")");
    }
    serializePlugin(e) {
      let r = this.plugins;
      if (r) for (let t = 0, a = r.length; t < a; t++) {
        let i = r[t];
        if (i.tag === e.c) return this.assignIndexedValue(e.i, i.serialize(e.s, this, { id: e.i }));
      }
      throw new ve(e.c);
    }
    getConstructor(e) {
      let r = this.serialize(e);
      return r === this.getRefParam(e.i) ? r : "(" + r + ")";
    }
    serializePromiseConstructor(e) {
      return this.assignIndexedValue(e.i, this.getConstructor(e.f) + "()");
    }
    serializePromiseResolve(e) {
      return this.getConstructor(e.a[0]) + "(" + this.getRefParam(e.i) + "," + this.serialize(e.a[1]) + ")";
    }
    serializePromiseReject(e) {
      return this.getConstructor(e.a[0]) + "(" + this.getRefParam(e.i) + "," + this.serialize(e.a[1]) + ")";
    }
    serializeSpecialReferenceValue(e) {
      switch (e) {
        case 0:
          return "[]";
        case 1:
          return this.createFunction(["s", "f", "p"], "((p=new Promise(" + this.createEffectfulFunction(["a", "b"], "s=a,f=b") + ")).s=s,p.f=f,p)");
        case 2:
          return this.createEffectfulFunction(["p", "d"], 'p.s(d),p.status="success",p.value=d;delete p.s;delete p.f');
        case 3:
          return this.createEffectfulFunction(["p", "d"], 'p.f(d),p.status="failure",p.value=d;delete p.s;delete p.f');
        case 4:
          return this.createFunction(["b", "a", "s", "l", "p", "f", "e", "n"], "(b=[],a=!0,s=!1,l=[],p=0,f=" + this.createEffectfulFunction(["v", "m", "x"], "for(x=0;x<p;x++)l[x]&&l[x][m](v)") + ",n=" + this.createEffectfulFunction(["o", "x", "z", "c"], 'for(x=0,z=b.length;x<z;x++)(c=b[x],(!a&&x===z-1)?o[s?"return":"throw"](c):o.next(c))') + ",e=" + this.createFunction(["o", "t"], "(a&&(l[t=p++]=o),n(o)," + this.createEffectfulFunction([], "a&&(l[t]=void 0)") + ")") + ",{__SEROVAL_STREAM__:!0,on:" + this.createFunction(["o"], "e(o)") + ",next:" + this.createEffectfulFunction(["v"], 'a&&(b.push(v),f(v,"next"))') + ",throw:" + this.createEffectfulFunction(["v"], 'a&&(b.push(v),f(v,"throw"),a=s=!1,l.length=0)') + ",return:" + this.createEffectfulFunction(["v"], 'a&&(b.push(v),f(v,"return"),a=!1,s=!0,l.length=0)') + "})");
        case 5:
          return this.createFunction(["a", "s"], "((s=(a=new AbortController).signal).a=a,s)");
        case 6:
          return this.createEffectfulFunction(["s", "r"], "s.a.abort(r);delete s.a");
        default:
          return "";
      }
    }
    serializeSpecialReference(e) {
      return this.assignIndexedValue(e.i, this.serializeSpecialReferenceValue(e.s));
    }
    serializeIteratorFactory(e) {
      let r = "", t = false;
      return e.f.t !== 4 && (this.markRef(e.f.i), r = "(" + this.serialize(e.f) + ",", t = true), r += this.assignIndexedValue(e.i, this.createFunction(["s"], this.createFunction(["i", "c", "d", "t"], "(i=0,t={[" + this.getRefParam(e.f.i) + "]:" + this.createFunction([], "t") + ",next:" + this.createEffectfulFunction([], "if(i>s.d)return{done:!0,value:void 0};if(d=s.v[c=i++],c===s.t)throw d;return{done:c===s.d,value:d}") + "})"))), t && (r += ")"), r;
    }
    serializeIteratorFactoryInstance(e) {
      return this.getConstructor(e.a[0]) + "(" + this.serialize(e.a[1]) + ")";
    }
    serializeAsyncIteratorFactory(e) {
      let r = e.a[0], t = e.a[1], a = "";
      r.t !== 4 && (this.markRef(r.i), a += "(" + this.serialize(r)), t.t !== 4 && (this.markRef(t.i), a += (a ? "," : "(") + this.serialize(t)), a && (a += ",");
      let i = this.assignIndexedValue(e.i, this.createFunction(["s"], this.createFunction(["b", "c", "p", "d", "e", "t", "f"], "(b=[],c=0,p=[],d=-1,e=!1,f=" + this.createEffectfulFunction(["i", "l"], "for(i=0,l=p.length;i<l;i++)p[i].s({done:!0,value:void 0})") + ",s.on({next:" + this.createEffectfulFunction(["v", "t"], "if(t=p.shift())t.s({done:!1,value:v});b.push(v)") + ",throw:" + this.createEffectfulFunction(["v", "t"], "if(t=p.shift())t.f(v);f(),d=b.length,e=!0,b.push(v)") + ",return:" + this.createEffectfulFunction(["v", "t"], "if(t=p.shift())t.s({done:!0,value:v});f(),d=b.length,b.push(v)") + "}),t={[" + this.getRefParam(t.i) + "]:" + this.createFunction([], "t") + ",next:" + this.createEffectfulFunction(["i", "t", "v"], "if(d===-1){return((i=c++)>=b.length)?(p.push(t=" + this.getRefParam(r.i) + "()),t):{done:!1,value:b[i]}}if(c>d)return{done:!0,value:void 0};if(v=b[i=c++],i!==d)return{done:!1,value:v};if(e)throw v;return{done:!0,value:v}") + "})")));
      return a ? a + i + ")" : i;
    }
    serializeAsyncIteratorFactoryInstance(e) {
      return this.getConstructor(e.a[0]) + "(" + this.serialize(e.a[1]) + ")";
    }
    serializeStreamConstructor(e) {
      let r = this.assignIndexedValue(e.i, this.getConstructor(e.f) + "()"), t = e.a.length;
      if (t) {
        let a = this.serialize(e.a[0]);
        for (let i = 1; i < t; i++) a += "," + this.serialize(e.a[i]);
        return "(" + r + "," + a + "," + this.getRefParam(e.i) + ")";
      }
      return r;
    }
    serializeStreamNext(e) {
      return this.getRefParam(e.i) + ".next(" + this.serialize(e.f) + ")";
    }
    serializeStreamThrow(e) {
      return this.getRefParam(e.i) + ".throw(" + this.serialize(e.f) + ")";
    }
    serializeStreamReturn(e) {
      return this.getRefParam(e.i) + ".return(" + this.serialize(e.f) + ")";
    }
    serializeAbortSignalSync(e) {
      return this.assignIndexedValue(e.i, "AbortSignal.abort(" + this.serialize(e.f) + ")");
    }
    serializeAbortSignalConstructor(e) {
      return this.assignIndexedValue(e.i, this.getConstructor(e.f) + "()");
    }
    serializeAbortSignalAbort(e) {
      return this.getConstructor(e.a[0]) + "(" + this.getRefParam(e.i) + "," + this.serialize(e.a[1]) + ")";
    }
    serialize(e) {
      try {
        switch (e.t) {
          case 2:
            return ar[e.s];
          case 0:
            return "" + e.s;
          case 1:
            return '"' + e.s + '"';
          case 3:
            return e.s + "n";
          case 4:
            return this.getRefParam(e.i);
          case 18:
            return this.serializeReference(e);
          case 9:
            return this.serializeArray(e);
          case 10:
            return this.serializeObject(e);
          case 11:
            return this.serializeNullConstructor(e);
          case 5:
            return this.serializeDate(e);
          case 6:
            return this.serializeRegExp(e);
          case 7:
            return this.serializeSet(e);
          case 8:
            return this.serializeMap(e);
          case 19:
            return this.serializeArrayBuffer(e);
          case 16:
          case 15:
            return this.serializeTypedArray(e);
          case 20:
            return this.serializeDataView(e);
          case 14:
            return this.serializeAggregateError(e);
          case 13:
            return this.serializeError(e);
          case 12:
            return this.serializePromise(e);
          case 17:
            return this.serializeWellKnownSymbol(e);
          case 21:
            return this.serializeBoxed(e);
          case 22:
            return this.serializePromiseConstructor(e);
          case 23:
            return this.serializePromiseResolve(e);
          case 24:
            return this.serializePromiseReject(e);
          case 25:
            return this.serializePlugin(e);
          case 26:
            return this.serializeSpecialReference(e);
          case 27:
            return this.serializeIteratorFactory(e);
          case 28:
            return this.serializeIteratorFactoryInstance(e);
          case 29:
            return this.serializeAsyncIteratorFactory(e);
          case 30:
            return this.serializeAsyncIteratorFactoryInstance(e);
          case 31:
            return this.serializeStreamConstructor(e);
          case 32:
            return this.serializeStreamNext(e);
          case 33:
            return this.serializeStreamThrow(e);
          case 34:
            return this.serializeStreamReturn(e);
          case 36:
            return this.serializeAbortSignalAbort(e);
          case 35:
            return this.serializeAbortSignalConstructor(e);
          case 37:
            return this.serializeAbortSignalSync(e);
          default:
            throw new we(e);
        }
      } catch (r) {
        throw new Vr(r);
      }
    }
  }, nt = class extends it {
    constructor(e) {
      super(e), this.mode = "cross", this.scopeId = e.scopeId;
    }
    getRefParam(e) {
      return C + "[" + e + "]";
    }
    assignIndexedValue(e, r) {
      return this.getRefParam(e) + "=" + r;
    }
    serializeTop(e) {
      let r = this.serialize(e), t = e.i;
      if (t == null) return r;
      let a = this.resolvePatches(), i = this.getRefParam(t), n = this.scopeId == null ? "" : C, o = a ? "(" + r + "," + a + i + ")" : r;
      if (n === "") return e.t === 10 && !a ? "(" + o + ")" : o;
      let l = this.scopeId == null ? "()" : "(" + C + '["' + g(this.scopeId) + '"])';
      return "(" + this.createFunction([n], o) + ")" + l;
    }
  }, ot = class extends Gr {
    parseItems(e) {
      let r = [];
      for (let t = 0, a = e.length; t < a; t++) t in e && (r[t] = this.parse(e[t]));
      return r;
    }
    parseArray(e, r) {
      return vr(e, r, this.parseItems(r));
    }
    parseProperties(e) {
      let r = Object.entries(e), t = [], a = [];
      for (let n = 0, o = r.length; n < o; n++) t.push(g(r[n][0])), a.push(this.parse(r[n][1]));
      let i = Symbol.iterator;
      return i in e && (t.push(this.parseWellKnownSymbol(i)), a.push(be(this.parseIteratorFactory(), this.parse(Ae(e))))), i = Symbol.asyncIterator, i in e && (t.push(this.parseWellKnownSymbol(i)), a.push(ze(this.parseAsyncIteratorFactory(), this.parse(P())))), i = Symbol.toStringTag, i in e && (t.push(this.parseWellKnownSymbol(i)), a.push(L(e[i]))), i = Symbol.isConcatSpreadable, i in e && (t.push(this.parseWellKnownSymbol(i)), a.push(e[i] ? M : U)), { k: t, v: a, s: t.length };
    }
    parsePlainObject(e, r, t) {
      return this.createObjectNode(e, r, t, this.parseProperties(r));
    }
    parseBoxed(e, r) {
      return Ar(e, this.parse(r.valueOf()));
    }
    parseTypedArray(e, r) {
      return Er(e, r, this.parse(r.buffer));
    }
    parseBigIntTypedArray(e, r) {
      return Pr(e, r, this.parse(r.buffer));
    }
    parseDataView(e, r) {
      return Ir(e, r, this.parse(r.buffer));
    }
    parseError(e, r) {
      let t = ge(r, this.features);
      return xr(e, r, t ? this.parseProperties(t) : s);
    }
    parseAggregateError(e, r) {
      let t = ge(r, this.features);
      return Rr(e, r, t ? this.parseProperties(t) : s);
    }
    parseMap(e, r) {
      let t = [], a = [];
      for (let [i, n] of r.entries()) t.push(this.parse(i)), a.push(this.parse(n));
      return this.createMapNode(e, t, a, r.size);
    }
    parseSet(e, r) {
      let t = [];
      for (let a of r.keys()) t.push(this.parse(a));
      return kr(e, r.size, t);
    }
    parsePlugin(e, r) {
      let t = this.plugins;
      if (t) for (let a = 0, i = t.length; a < i; a++) {
        let n = t[a];
        if (n.parse.sync && n.test(r)) return ye(e, n.tag, n.parse.sync(r, this, { id: e }));
      }
    }
    parseStream(e, r) {
      return Se(e, this.parseSpecialReference(4), []);
    }
    parsePromise(e, r) {
      return this.createPromiseConstructorNode(e);
    }
    parseAbortSignalSync(e, r) {
      return p(37, e, s, s, s, s, s, s, s, this.parse(r.reason), s, s);
    }
    parseAbortSignal(e, r) {
      return r.aborted ? this.parseAbortSignalSync(e, r) : this.createAbortSignalConstructorNode(e);
    }
    parseObject(e, r) {
      if (Array.isArray(r)) return this.parseArray(e, r);
      if (Wr(r)) return this.parseStream(e, r);
      let t = r.constructor;
      if (t === Ur) return this.parse(r.replacement);
      let a = this.parsePlugin(e, r);
      if (a) return a;
      switch (t) {
        case Object:
          return this.parsePlainObject(e, r, false);
        case void 0:
          return this.parsePlainObject(e, r, true);
        case Date:
          return yr(e, r);
        case RegExp:
          return br(e, r);
        case Error:
        case EvalError:
        case RangeError:
        case ReferenceError:
        case SyntaxError:
        case TypeError:
        case URIError:
          return this.parseError(e, r);
        case Number:
        case Boolean:
        case String:
        case BigInt:
          return this.parseBoxed(e, r);
        case ArrayBuffer:
          return zr(e, r);
        case Int8Array:
        case Int16Array:
        case Int32Array:
        case Uint8Array:
        case Uint16Array:
        case Uint32Array:
        case Uint8ClampedArray:
        case Float32Array:
        case Float64Array:
          return this.parseTypedArray(e, r);
        case DataView:
          return this.parseDataView(e, r);
        case Map:
          return this.parseMap(e, r);
        case Set:
          return this.parseSet(e, r);
      }
      if (t === Promise || r instanceof Promise) return this.parsePromise(e, r);
      let i = this.features;
      if (i & 32 && typeof AbortSignal < "u" && t === AbortSignal) return this.parseAbortSignal(e, r);
      if (i & 16) switch (t) {
        case BigInt64Array:
        case BigUint64Array:
          return this.parseBigIntTypedArray(e, r);
      }
      if (i & 1 && typeof AggregateError < "u" && (t === AggregateError || r instanceof AggregateError)) return this.parseAggregateError(e, r);
      if (r instanceof Error) return this.parseError(e, r);
      if (Symbol.iterator in r || Symbol.asyncIterator in r) return this.parsePlainObject(e, r, !!t);
      throw new O(r);
    }
    parseFunction(e) {
      let r = this.getReference(e);
      if (r.type !== 0) return r.value;
      let t = this.parsePlugin(r.value, e);
      if (t) return t;
      throw new O(e);
    }
    parse(e) {
      try {
        switch (typeof e) {
          case "boolean":
            return e ? M : U;
          case "undefined":
            return or;
          case "string":
            return L(e);
          case "number":
            return dr(e);
          case "bigint":
            return gr(e);
          case "object": {
            if (e) {
              let r = this.getReference(e);
              return r.type === 0 ? this.parseObject(r.value, e) : r.value;
            }
            return lr;
          }
          case "symbol":
            return this.parseWellKnownSymbol(e);
          case "function":
            return this.parseFunction(e);
          default:
            throw new O(e);
        }
      } catch (r) {
        throw new jr(r);
      }
    }
  }, lt = class extends ot {
    constructor(e) {
      super(e), this.alive = true, this.pending = 0, this.initial = true, this.buffer = [], this.onParseCallback = e.onParse, this.onErrorCallback = e.onError, this.onDoneCallback = e.onDone;
    }
    onParseInternal(e, r) {
      try {
        this.onParseCallback(e, r);
      } catch (t) {
        this.onError(t);
      }
    }
    flush() {
      for (let e = 0, r = this.buffer.length; e < r; e++) this.onParseInternal(this.buffer[e], false);
    }
    onParse(e) {
      this.initial ? this.buffer.push(e) : this.onParseInternal(e, false);
    }
    onError(e) {
      if (this.onErrorCallback) this.onErrorCallback(e);
      else throw e;
    }
    onDone() {
      this.onDoneCallback && this.onDoneCallback();
    }
    pushPendingState() {
      this.pending++;
    }
    popPendingState() {
      --this.pending <= 0 && this.onDone();
    }
    parseProperties(e) {
      let r = Object.entries(e), t = [], a = [];
      for (let n = 0, o = r.length; n < o; n++) t.push(g(r[n][0])), a.push(this.parse(r[n][1]));
      let i = Symbol.iterator;
      return i in e && (t.push(this.parseWellKnownSymbol(i)), a.push(be(this.parseIteratorFactory(), this.parse(Ae(e))))), i = Symbol.asyncIterator, i in e && (t.push(this.parseWellKnownSymbol(i)), a.push(ze(this.parseAsyncIteratorFactory(), this.parse(qr(e))))), i = Symbol.toStringTag, i in e && (t.push(this.parseWellKnownSymbol(i)), a.push(L(e[i]))), i = Symbol.isConcatSpreadable, i in e && (t.push(this.parseWellKnownSymbol(i)), a.push(e[i] ? M : U)), { k: t, v: a, s: t.length };
    }
    parsePromise(e, r) {
      return r.then((t) => {
        let a = this.parseWithError(t);
        a && this.onParse(p(23, e, s, s, s, s, s, s, [this.parseSpecialReference(2), a], s, s, s)), this.popPendingState();
      }, (t) => {
        if (this.alive) {
          let a = this.parseWithError(t);
          a && this.onParse(p(24, e, s, s, s, s, s, s, [this.parseSpecialReference(3), a], s, s, s));
        }
        this.popPendingState();
      }), this.pushPendingState(), this.createPromiseConstructorNode(e);
    }
    parsePlugin(e, r) {
      let t = this.plugins;
      if (t) for (let a = 0, i = t.length; a < i; a++) {
        let n = t[a];
        if (n.parse.stream && n.test(r)) return ye(e, n.tag, n.parse.stream(r, this, { id: e }));
      }
      return s;
    }
    parseStream(e, r) {
      let t = Se(e, this.parseSpecialReference(4), []);
      return this.pushPendingState(), r.on({ next: (a) => {
        if (this.alive) {
          let i = this.parseWithError(a);
          i && this.onParse(Fr(e, i));
        }
      }, throw: (a) => {
        if (this.alive) {
          let i = this.parseWithError(a);
          i && this.onParse(Cr(e, i));
        }
        this.popPendingState();
      }, return: (a) => {
        if (this.alive) {
          let i = this.parseWithError(a);
          i && this.onParse(Tr(e, i));
        }
        this.popPendingState();
      } }), t;
    }
    handleAbortSignal(e, r) {
      if (this.alive) {
        let t = this.parseWithError(r.reason);
        t && this.onParse(p(36, e, s, s, s, s, s, s, [this.parseSpecialReference(6), t], s, s, s));
      }
      this.popPendingState();
    }
    parseAbortSignal(e, r) {
      return r.aborted ? this.parseAbortSignalSync(e, r) : (this.pushPendingState(), r.addEventListener("abort", this.handleAbortSignal.bind(this, e, r), { once: true }), this.createAbortSignalConstructorNode(e));
    }
    parseWithError(e) {
      try {
        return this.parse(e);
      } catch (r) {
        return this.onError(r), s;
      }
    }
    start(e) {
      let r = this.parseWithError(e);
      r && (this.onParseInternal(r, true), this.initial = false, this.flush(), this.pending <= 0 && this.destroy());
    }
    destroy() {
      this.alive && (this.onDone(), this.alive = false);
    }
    isAlive() {
      return this.alive;
    }
  }, ut = class extends lt {
    constructor() {
      super(...arguments), this.mode = "cross";
    }
  };
  function ct(e, r) {
    let t = pe(r.plugins), a = new ut({ plugins: t, refs: r.refs, disabledFeatures: r.disabledFeatures, onParse(i, n) {
      let o = new nt({ plugins: t, features: a.features, scopeId: r.scopeId, markedRefs: a.marked }), l;
      try {
        l = o.serializeTop(i);
      } catch (u) {
        r.onError && r.onError(u);
        return;
      }
      r.onSerialize(l, n);
    }, onError: r.onError, onDone: r.onDone });
    return a.start(e), a.destroy.bind(a);
  }
  var ht = class extends Yr {
    constructor(e) {
      super(e), this.mode = "vanilla", this.marked = new Set(e.markedRefs);
    }
    assignIndexedValue(e, r) {
      return this.marked.has(e) && this.refs.set(e, r), r;
    }
  };
  function xe(e, r = {}) {
    let t = pe(r.plugins);
    return new ht({ plugins: t, markedRefs: e.m }).deserialize(e.t);
  }
  function H(e) {
    return { detail: e.detail, bubbles: e.bubbles, cancelable: e.cancelable, composed: e.composed };
  }
  var pt = { tag: "seroval-plugins/web/CustomEvent", test(e) {
    return typeof CustomEvent > "u" ? false : e instanceof CustomEvent;
  }, parse: { sync(e, r) {
    return { type: r.parse(e.type), options: r.parse(H(e)) };
  }, async async(e, r) {
    return { type: await r.parse(e.type), options: await r.parse(H(e)) };
  }, stream(e, r) {
    return { type: r.parse(e.type), options: r.parse(H(e)) };
  } }, serialize(e, r) {
    return "new CustomEvent(" + r.serialize(e.type) + "," + r.serialize(e.options) + ")";
  }, deserialize(e, r) {
    return new CustomEvent(r.deserialize(e.type), r.deserialize(e.options));
  } }, K = pt, ft = { tag: "seroval-plugins/web/DOMException", test(e) {
    return typeof DOMException > "u" ? false : e instanceof DOMException;
  }, parse: { sync(e, r) {
    return { name: r.parse(e.name), message: r.parse(e.message) };
  }, async async(e, r) {
    return { name: await r.parse(e.name), message: await r.parse(e.message) };
  }, stream(e, r) {
    return { name: r.parse(e.name), message: r.parse(e.message) };
  } }, serialize(e, r) {
    return "new DOMException(" + r.serialize(e.message) + "," + r.serialize(e.name) + ")";
  }, deserialize(e, r) {
    return new DOMException(r.deserialize(e.message), r.deserialize(e.name));
  } }, G = ft;
  function X(e) {
    return { bubbles: e.bubbles, cancelable: e.cancelable, composed: e.composed };
  }
  var dt = { tag: "seroval-plugins/web/Event", test(e) {
    return typeof Event > "u" ? false : e instanceof Event;
  }, parse: { sync(e, r) {
    return { type: r.parse(e.type), options: r.parse(X(e)) };
  }, async async(e, r) {
    return { type: await r.parse(e.type), options: await r.parse(X(e)) };
  }, stream(e, r) {
    return { type: r.parse(e.type), options: r.parse(X(e)) };
  } }, serialize(e, r) {
    return "new Event(" + r.serialize(e.type) + "," + r.serialize(e.options) + ")";
  }, deserialize(e, r) {
    return new Event(r.deserialize(e.type), r.deserialize(e.options));
  } }, Y = dt, gt = { tag: "seroval-plugins/web/File", test(e) {
    return typeof File > "u" ? false : e instanceof File;
  }, parse: { async async(e, r) {
    return { name: await r.parse(e.name), options: await r.parse({ type: e.type, lastModified: e.lastModified }), buffer: await r.parse(await e.arrayBuffer()) };
  } }, serialize(e, r) {
    return "new File([" + r.serialize(e.buffer) + "]," + r.serialize(e.name) + "," + r.serialize(e.options) + ")";
  }, deserialize(e, r) {
    return new File([r.deserialize(e.buffer)], r.deserialize(e.name), r.deserialize(e.options));
  } }, mt = gt;
  function J(e) {
    let r = [];
    return e.forEach((t, a) => {
      r.push([a, t]);
    }), r;
  }
  var x = {}, yt = { tag: "seroval-plugins/web/FormDataFactory", test(e) {
    return e === x;
  }, parse: { sync() {
  }, async async() {
    return await Promise.resolve(void 0);
  }, stream() {
  } }, serialize(e, r) {
    return r.createEffectfulFunction(["e", "f", "i", "s", "t"], "f=new FormData;for(i=0,s=e.length;i<s;i++)f.append((t=e[i])[0],t[1]);return f");
  }, deserialize() {
    return x;
  } }, bt = { tag: "seroval-plugins/web/FormData", extends: [mt, yt], test(e) {
    return typeof FormData > "u" ? false : e instanceof FormData;
  }, parse: { sync(e, r) {
    return { factory: r.parse(x), entries: r.parse(J(e)) };
  }, async async(e, r) {
    return { factory: await r.parse(x), entries: await r.parse(J(e)) };
  }, stream(e, r) {
    return { factory: r.parse(x), entries: r.parse(J(e)) };
  } }, serialize(e, r) {
    return "(" + r.serialize(e.factory) + ")(" + r.serialize(e.entries) + ")";
  }, deserialize(e, r) {
    let t = new FormData(), a = r.deserialize(e.entries);
    for (let i = 0, n = a.length; i < n; i++) {
      let o = a[i];
      t.append(o[0], o[1]);
    }
    return t;
  } }, Z = bt;
  function Q(e) {
    let r = [];
    return e.forEach((t, a) => {
      r.push([a, t]);
    }), r;
  }
  var zt = { tag: "seroval-plugins/web/Headers", test(e) {
    return typeof Headers > "u" ? false : e instanceof Headers;
  }, parse: { sync(e, r) {
    return r.parse(Q(e));
  }, async async(e, r) {
    return await r.parse(Q(e));
  }, stream(e, r) {
    return r.parse(Q(e));
  } }, serialize(e, r) {
    return "new Headers(" + r.serialize(e) + ")";
  }, deserialize(e, r) {
    return new Headers(r.deserialize(e));
  } }, R = zt, k = {}, St = { tag: "seroval-plugins/web/ReadableStreamFactory", test(e) {
    return e === k;
  }, parse: { sync() {
  }, async async() {
    return await Promise.resolve(void 0);
  }, stream() {
  } }, serialize(e, r) {
    return r.createFunction(["d"], "new ReadableStream({start:" + r.createEffectfulFunction(["c"], "d.on({next:" + r.createEffectfulFunction(["v"], "c.enqueue(v)") + ",throw:" + r.createEffectfulFunction(["v"], "c.error(v)") + ",return:" + r.createEffectfulFunction([], "c.close()") + "})") + "})");
  }, deserialize() {
    return k;
  } };
  function Re(e) {
    let r = P(), t = e.getReader();
    async function a() {
      try {
        let i = await t.read();
        i.done ? r.return(i.value) : (r.next(i.value), await a());
      } catch (i) {
        r.throw(i);
      }
    }
    return a().catch(() => {
    }), r;
  }
  var wt = { tag: "seroval/plugins/web/ReadableStream", extends: [St], test(e) {
    return typeof ReadableStream > "u" ? false : e instanceof ReadableStream;
  }, parse: { sync(e, r) {
    return { factory: r.parse(k), stream: r.parse(P()) };
  }, async async(e, r) {
    return { factory: await r.parse(k), stream: await r.parse(Re(e)) };
  }, stream(e, r) {
    return { factory: r.parse(k), stream: r.parse(Re(e)) };
  } }, serialize(e, r) {
    return "(" + r.serialize(e.factory) + ")(" + r.serialize(e.stream) + ")";
  }, deserialize(e, r) {
    let t = r.deserialize(e.stream);
    return new ReadableStream({ start(a) {
      t.on({ next(i) {
        a.enqueue(i);
      }, throw(i) {
        a.error(i);
      }, return() {
        a.close();
      } });
    } });
  } }, F = wt;
  function ke(e, r) {
    return { body: r, cache: e.cache, credentials: e.credentials, headers: e.headers, integrity: e.integrity, keepalive: e.keepalive, method: e.method, mode: e.mode, redirect: e.redirect, referrer: e.referrer, referrerPolicy: e.referrerPolicy };
  }
  var vt = { tag: "seroval-plugins/web/Request", extends: [F, R], test(e) {
    return typeof Request > "u" ? false : e instanceof Request;
  }, parse: { async async(e, r) {
    return { url: await r.parse(e.url), options: await r.parse(ke(e, e.body ? await e.clone().arrayBuffer() : null)) };
  }, stream(e, r) {
    return { url: r.parse(e.url), options: r.parse(ke(e, e.clone().body)) };
  } }, serialize(e, r) {
    return "new Request(" + r.serialize(e.url) + "," + r.serialize(e.options) + ")";
  }, deserialize(e, r) {
    return new Request(r.deserialize(e.url), r.deserialize(e.options));
  } }, ee = vt;
  function Fe(e) {
    return { headers: e.headers, status: e.status, statusText: e.statusText };
  }
  var At = { tag: "seroval-plugins/web/Response", extends: [F, R], test(e) {
    return typeof Response > "u" ? false : e instanceof Response;
  }, parse: { async async(e, r) {
    return { body: await r.parse(e.body ? await e.clone().arrayBuffer() : null), options: await r.parse(Fe(e)) };
  }, stream(e, r) {
    return { body: r.parse(e.clone().body), options: r.parse(Fe(e)) };
  } }, serialize(e, r) {
    return "new Response(" + r.serialize(e.body) + "," + r.serialize(e.options) + ")";
  }, deserialize(e, r) {
    return new Response(r.deserialize(e.body), r.deserialize(e.options));
  } }, re = At, Et = { tag: "seroval-plugins/web/URLSearchParams", test(e) {
    return typeof URLSearchParams > "u" ? false : e instanceof URLSearchParams;
  }, parse: { sync(e, r) {
    return r.parse(e.toString());
  }, async async(e, r) {
    return await r.parse(e.toString());
  }, stream(e, r) {
    return r.parse(e.toString());
  } }, serialize(e, r) {
    return "new URLSearchParams(" + r.serialize(e) + ")";
  }, deserialize(e, r) {
    return new URLSearchParams(r.deserialize(e));
  } }, te = Et, Pt = { tag: "seroval-plugins/web/URL", test(e) {
    return typeof URL > "u" ? false : e instanceof URL;
  }, parse: { sync(e, r) {
    return r.parse(e.href);
  }, async async(e, r) {
    return await r.parse(e.href);
  }, stream(e, r) {
    return r.parse(e.href);
  } }, serialize(e, r) {
    return "new URL(" + r.serialize(e) + ")";
  }, deserialize(e, r) {
    return new URL(r.deserialize(e));
  } }, se = Pt;
  const ae$1 = "Invariant Violation", { setPrototypeOf: It = function(e, r) {
    return e.__proto__ = r, e;
  } } = Object;
  class ie extends Error {
    constructor(r = ae$1) {
      super(typeof r == "number" ? `${ae$1}: ${r} (see https://github.com/apollographql/invariant-packages)` : r);
      __publicField$1(this, "framesToPop", 1);
      __publicField$1(this, "name", ae$1);
      It(this, ie.prototype);
    }
  }
  function xt(e, r) {
    if (!e) throw new ie(r);
  }
  const ne = "solidFetchEvent";
  function Rt(e) {
    return { request: ae(e), response: Ct(e), clientAddress: D$1(e), locals: {}, nativeEvent: e };
  }
  le = function(e) {
    return { ...e };
  };
  function kt(e) {
    if (!e.context[ne]) {
      const r = Rt(e);
      e.context[ne] = r;
    }
    return e.context[ne];
  }
  function Ce(e, r) {
    for (const [t, a] of r.entries()) Z$1(e, t, a);
  }
  class Ft {
    constructor(r) {
      __publicField$1(this, "event");
      this.event = r;
    }
    get(r) {
      const t = X$1(this.event, r);
      return Array.isArray(t) ? t.join(", ") : t || null;
    }
    has(r) {
      return this.get(r) !== void 0;
    }
    set(r, t) {
      return Y$1(this.event, r, t);
    }
    delete(r) {
      return se$1(this.event, r);
    }
    append(r, t) {
      Z$1(this.event, r, t);
    }
    getSetCookie() {
      const r = X$1(this.event, "Set-Cookie");
      return Array.isArray(r) ? r : [r];
    }
    forEach(r) {
      return Object.entries(V$1(this.event)).forEach(([t, a]) => r(Array.isArray(a) ? a.join(", ") : a, t, this));
    }
    entries() {
      return Object.entries(V$1(this.event)).map(([r, t]) => [r, Array.isArray(t) ? t.join(", ") : t])[Symbol.iterator]();
    }
    keys() {
      return Object.keys(V$1(this.event))[Symbol.iterator]();
    }
    values() {
      return Object.values(V$1(this.event)).map((r) => Array.isArray(r) ? r.join(", ") : r)[Symbol.iterator]();
    }
    [Symbol.iterator]() {
      return this.entries()[Symbol.iterator]();
    }
  }
  function Ct(e) {
    return { get status() {
      return G$1(e);
    }, set status(r) {
      F$1(e, r);
    }, get statusText() {
      return K$1(e);
    }, set statusText(r) {
      F$1(e, G$1(e), r);
    }, headers: new Ft(e) };
  }
  const v = { NORMAL: 0, WILDCARD: 1, PLACEHOLDER: 2 };
  function Tt(e = {}) {
    const r = { options: e, rootNode: Oe(), staticRoutesMap: {} }, t = (a) => e.strictTrailingSlash ? a : a.replace(/\/$/, "") || "/";
    if (e.routes) for (const a in e.routes) Te(r, t(a), e.routes[a]);
    return { ctx: r, lookup: (a) => Ot(r, t(a)), insert: (a, i) => Te(r, t(a), i), remove: (a) => jt(r, t(a)) };
  }
  function Ot(e, r) {
    const t = e.staticRoutesMap[r];
    if (t) return t.data;
    const a = r.split("/"), i = {};
    let n = false, o = null, l = e.rootNode, u = null;
    for (let c = 0; c < a.length; c++) {
      const f = a[c];
      l.wildcardChildNode !== null && (o = l.wildcardChildNode, u = a.slice(c).join("/"));
      const A = l.children.get(f);
      if (A === void 0) {
        if (l && l.placeholderChildren.length > 1) {
          const b = a.length - c;
          l = l.placeholderChildren.find((h) => h.maxDepth === b) || null;
        } else l = l.placeholderChildren[0] || null;
        if (!l) break;
        l.paramName && (i[l.paramName] = f), n = true;
      } else l = A;
    }
    return (l === null || l.data === null) && o !== null && (l = o, i[l.paramName || "_"] = u, n = true), l ? n ? { ...l.data, params: n ? i : void 0 } : l.data : null;
  }
  function Te(e, r, t) {
    let a = true;
    const i = r.split("/");
    let n = e.rootNode, o = 0;
    const l = [n];
    for (const u of i) {
      let c;
      if (c = n.children.get(u)) n = c;
      else {
        const f = Vt(u);
        c = Oe({ type: f, parent: n }), n.children.set(u, c), f === v.PLACEHOLDER ? (c.paramName = u === "*" ? `_${o++}` : u.slice(1), n.placeholderChildren.push(c), a = false) : f === v.WILDCARD && (n.wildcardChildNode = c, c.paramName = u.slice(3) || "_", a = false), l.push(c), n = c;
      }
    }
    for (const [u, c] of l.entries()) c.maxDepth = Math.max(l.length - u, c.maxDepth || 0);
    return n.data = t, a === true && (e.staticRoutesMap[r] = n), n;
  }
  function jt(e, r) {
    let t = false;
    const a = r.split("/");
    let i = e.rootNode;
    for (const n of a) if (i = i.children.get(n), !i) return t;
    if (i.data) {
      const n = a.at(-1) || "";
      i.data = null, Object.keys(i.children).length === 0 && i.parent && (i.parent.children.delete(n), i.parent.wildcardChildNode = null, i.parent.placeholderChildren = []), t = true;
    }
    return t;
  }
  function Oe(e = {}) {
    return { type: e.type || v.NORMAL, maxDepth: 0, parent: e.parent || null, children: /* @__PURE__ */ new Map(), data: e.data || null, paramName: e.paramName || null, wildcardChildNode: null, placeholderChildren: [] };
  }
  function Vt(e) {
    return e.startsWith("**") ? v.WILDCARD : e[0] === ":" || e === "*" ? v.PLACEHOLDER : v.NORMAL;
  }
  const je = [{ page: true, path: "/(app)", filePath: "/root/code/ToramCalculator/src/routes/(app).tsx" }, { page: true, path: "/(app)/(functionPage)", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage).tsx" }, { page: true, path: "/(app)/", filePath: "/root/code/ToramCalculator/src/routes/(app)/index.tsx" }, { page: true, path: "/(app)/repl", filePath: "/root/code/ToramCalculator/src/routes/(app)/repl.jsx" }, { page: false, $POST: { src: "src/routes/api/changes.ts?pick=POST", build: () => import('../build/changes.mjs'), import: () => import('../build/changes.mjs') }, path: "/api/changes", filePath: "/root/code/ToramCalculator/src/routes/api/changes.ts" }, { page: false, $GET: { src: "src/routes/api/envLog.ts?pick=GET", build: () => import('../build/envLog.mjs'), import: () => import('../build/envLog.mjs') }, $HEAD: { src: "src/routes/api/envLog.ts?pick=GET", build: () => import('../build/envLog.mjs'), import: () => import('../build/envLog.mjs') }, path: "/api/envLog", filePath: "/root/code/ToramCalculator/src/routes/api/envLog.ts" }, { page: true, path: "/(app)/(functionPage)/*404", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/[...404].tsx" }, { page: true, path: "/(app)/(functionPage)/petCalculator", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/petCalculator.tsx" }, { page: false, $GET: { src: "src/routes/api/auth/[...solidauth].ts?pick=GET", build: () => import('../build/_...solidauth_.mjs'), import: () => import('../build/_...solidauth_.mjs') }, $HEAD: { src: "src/routes/api/auth/[...solidauth].ts?pick=GET", build: () => import('../build/_...solidauth_.mjs'), import: () => import('../build/_...solidauth_.mjs') }, $POST: { src: "src/routes/api/auth/[...solidauth].ts?pick=POST", build: () => import('../build/_...solidauth_2.mjs'), import: () => import('../build/_...solidauth_2.mjs') }, path: "/api/auth/*solidauth", filePath: "/root/code/ToramCalculator/src/routes/api/auth/[...solidauth].ts" }, { page: false, $POST: { src: "src/routes/api/auth/login.ts?pick=POST", build: () => import('../build/login.mjs'), import: () => import('../build/login.mjs') }, path: "/api/auth/login", filePath: "/root/code/ToramCalculator/src/routes/api/auth/login.ts" }, { page: false, $GET: { src: "src/routes/api/auth/logout.ts?pick=GET", build: () => import('../build/logout.mjs'), import: () => import('../build/logout.mjs') }, $HEAD: { src: "src/routes/api/auth/logout.ts?pick=GET", build: () => import('../build/logout.mjs'), import: () => import('../build/logout.mjs') }, path: "/api/auth/logout", filePath: "/root/code/ToramCalculator/src/routes/api/auth/logout.ts" }, { page: true, path: "/api/auth/qq", filePath: "/root/code/ToramCalculator/src/routes/api/auth/qq.ts" }, { page: false, $POST: { src: "src/routes/api/auth/register.ts?pick=POST", build: () => import('../build/register.mjs'), import: () => import('../build/register.mjs') }, path: "/api/auth/register", filePath: "/root/code/ToramCalculator/src/routes/api/auth/register.ts" }, { page: true, path: "/(app)/(functionPage)/character/(character)", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/character/(character).tsx" }, { page: true, path: "/(app)/(functionPage)/character/:characterId", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/character/[characterId].tsx" }, { page: true, path: "/(app)/(functionPage)/profile/(profile)", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/profile/(profile).tsx" }, { page: true, path: "/(app)/(functionPage)/wiki/(wiki)", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/wiki/(wiki).tsx" }, { page: true, path: "/(app)/(functionPage)/wiki/mob/(mob)", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/wiki/mob/(mob).tsx" }, { page: true, path: "/(app)/(functionPage)/wiki/pet/(pet)", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/wiki/pet/(pet).tsx" }, { page: true, path: "/(app)/(functionPage)/wiki/skill/(skill)", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/wiki/skill/(skill).tsx" }], Dt = Nt(je.filter((e) => e.page));
  function Nt(e) {
    function r(t, a, i, n) {
      const o = Object.values(t).find((l) => i.startsWith(l.id + "/"));
      return o ? (r(o.children || (o.children = []), a, i.slice(o.id.length)), t) : (t.push({ ...a, id: i, path: i.replace(/\([^)/]+\)/g, "").replace(/\/+/g, "/") }), t);
    }
    return e.sort((t, a) => t.path.length - a.path.length).reduce((t, a) => r(t, a, a.path, a.path), []);
  }
  function $t(e) {
    return e.$HEAD || e.$GET || e.$POST || e.$PUT || e.$PATCH || e.$DELETE;
  }
  Tt({ routes: je.reduce((e, r) => {
    if (!$t(r)) return e;
    let t = r.path.replace(/\([^)/]+\)/g, "").replace(/\/+/g, "/").replace(/\*([^/]*)/g, (a, i) => `**:${i}`).split("/").map((a) => a.startsWith(":") || a.startsWith("*") ? a : encodeURIComponent(a)).join("/");
    if (/:[^/]*\?/g.test(t)) throw new Error(`Optional parameters are not supported in API routes: ${t}`);
    if (e[t]) throw new Error(`Duplicate API routes for "${t}" found at "${e[t].route.path}" and "${r.path}"`);
    return e[t] = { route: r }, e;
  }, {}) });
  var Ut = " ";
  const _t = { style: (e) => ssrElement("style", e.attrs, () => e.children, true), link: (e) => ssrElement("link", e.attrs, void 0, true), script: (e) => e.attrs.src ? ssrElement("script", mergeProps(() => e.attrs, { get id() {
    return e.key;
  } }), () => ssr(Ut), true) : null, noscript: (e) => ssrElement("noscript", e.attrs, () => escape(e.children), true) };
  function Lt(e, r) {
    let { tag: t, attrs: { key: a, ...i } = { key: void 0 }, children: n } = e;
    return _t[t]({ attrs: { ...i, nonce: r }, key: a, children: n });
  }
  function Bt(e, r, t, a = "default") {
    return lazy(async () => {
      var _a;
      {
        const i = (await e.import())[a], n = (await ((_a = r.inputs) == null ? void 0 : _a[e.src].assets())).filter((o) => o.tag === "style" || o.attrs.rel === "stylesheet");
        return { default: (o) => [...n.map((l) => Lt(l)), createComponent(i, o)] };
      }
    });
  }
  function Ve() {
    function e(r) {
      return { ...r, ...r.$$route ? r.$$route.require().route : void 0, info: { ...r.$$route ? r.$$route.require().route.info : {}, filesystem: true }, component: r.$component && Bt(r.$component, globalThis.MANIFEST.client, globalThis.MANIFEST.ssr), children: r.children ? r.children.map(e) : void 0 };
    }
    return Dt.map(e);
  }
  let De;
  Ke = isServer ? () => getRequestEvent().routes : () => De || (De = Ve());
  function Wt(e) {
    const r = Q$1(e.nativeEvent, "flash");
    if (r) try {
      let t = JSON.parse(r);
      if (!t || !t.result) return;
      const a = [...t.input.slice(0, -1), new Map(t.input[t.input.length - 1])], i = t.error ? new Error(t.result) : t.result;
      return { input: a, url: t.url, pending: false, result: t.thrown ? void 0 : i, error: t.thrown ? i : void 0 };
    } catch (t) {
      console.error(t);
    } finally {
      ee$1(e.nativeEvent, "flash", "", { maxAge: 0 });
    }
  }
  async function qt(e) {
    const r = globalThis.MANIFEST.client;
    return globalThis.MANIFEST.ssr, e.response.headers.set("Content-Type", "text/html"), Object.assign(e, { manifest: await r.json(), assets: [...await r.inputs[r.handler].assets()], router: { submission: Wt(e) }, routes: Ve(), complete: false, $islands: /* @__PURE__ */ new Set() });
  }
  const Ht = /* @__PURE__ */ new Set([301, 302, 303, 307, 308]);
  function Kt(e) {
    return e.status && Ht.has(e.status) ? e.status : 302;
  }
  const Gt = { "src_lib_session_ts--getUserByCookie_1": { functionName: "getUserByCookie_1", importer: () => import('../build/session-gJxBGr18.mjs') }, "src_lib_session_ts--emailExists_1": { functionName: "emailExists_1", importer: () => import('../build/session-gJxBGr18.mjs') } };
  function Xt(e) {
    const r = new TextEncoder().encode(e), t = r.length, a = t.toString(16), i = "00000000".substring(0, 8 - a.length) + a, n = new TextEncoder().encode(`;0x${i};`), o = new Uint8Array(12 + t);
    return o.set(n), o.set(r, 12), o;
  }
  function Ne(e, r) {
    return new ReadableStream({ start(t) {
      ct(r, { scopeId: e, plugins: [K, G, Y, Z, R, F, ee, re, te, se], onSerialize(a, i) {
        t.enqueue(Xt(i ? `(${Ze(e)},${a})` : a));
      }, onDone() {
        t.close();
      }, onError(a) {
        t.error(a);
      } });
    } });
  }
  async function Yt(e) {
    const r = kt(e), t = r.request, a = t.headers.get("X-Server-Id"), i = t.headers.get("X-Server-Instance"), n = t.headers.has("X-Single-Flight"), o = new URL(t.url);
    let l, u;
    if (a) xt(typeof a == "string", "Invalid server function"), [l, u] = a.split("#");
    else if (l = o.searchParams.get("id"), u = o.searchParams.get("name"), !l || !u) return new Response(null, { status: 404 });
    const c = Gt[l];
    let f;
    if (!c) return new Response(null, { status: 404 });
    f = await c.importer();
    const A = f[c.functionName];
    let b = [];
    if (!i || e.method === "GET") {
      const h = o.searchParams.get("args");
      if (h) {
        const d = JSON.parse(h);
        (d.t ? xe(d, { plugins: [K, G, Y, Z, R, F, ee, re, te, se] }) : d).forEach((j) => b.push(j));
      }
    }
    if (e.method === "POST") {
      const h = t.headers.get("content-type"), d = e.node.req, j = d instanceof ReadableStream, Zt = d.body instanceof ReadableStream, Ue = j && d.locked || Zt && d.body.locked, _e = j ? d : d.body;
      if ((h == null ? void 0 : h.startsWith("multipart/form-data")) || (h == null ? void 0 : h.startsWith("application/x-www-form-urlencoded"))) b.push(await (Ue ? t : new Request(t, { ...t, body: _e })).formData());
      else if (h == null ? void 0 : h.startsWith("application/json")) {
        const Qt = Ue ? t : new Request(t, { ...t, body: _e });
        b = xe(await Qt.json(), { plugins: [K, G, Y, Z, R, F, ee, re, te, se] });
      }
    }
    try {
      let h = await provideRequestEvent(r, async () => (sharedConfig.context = { event: r }, r.locals.serverFunctionMeta = { id: l + "#" + u }, A(...b)));
      if (n && i && (h = await Me(r, h)), h instanceof Response) {
        if (h.headers && h.headers.has("X-Content-Raw")) return h;
        i && (h.headers && Ce(e, h.headers), h.status && (h.status < 300 || h.status >= 400) && F$1(e, h.status), h.customBody ? h = await h.customBody() : h.body == null && (h = null));
      }
      return i ? (ne$1(e, "content-type", "text/javascript"), Ne(i, h)) : $e(h, t, b);
    } catch (h) {
      if (h instanceof Response) n && i && (h = await Me(r, h)), h.headers && Ce(e, h.headers), h.status && (!i || h.status < 300 || h.status >= 400) && F$1(e, h.status), h.customBody ? h = h.customBody() : h.body == null && (h = null), ne$1(e, "X-Error", "true");
      else if (i) {
        const d = h instanceof Error ? h.message : typeof h == "string" ? h : "true";
        ne$1(e, "X-Error", d.replace(/[\r\n]+/g, ""));
      } else h = $e(h, t, b, true);
      return i ? (ne$1(e, "content-type", "text/javascript"), Ne(i, h)) : h;
    }
  }
  function $e(e, r, t, a) {
    const i = new URL(r.url), n = e instanceof Error;
    let o = 302, l;
    return e instanceof Response ? (l = new Headers(e.headers), e.headers.has("Location") && (l.set("Location", new URL(e.headers.get("Location"), i.origin + "").toString()), o = Kt(e))) : l = new Headers({ Location: new URL(r.headers.get("referer")).toString() }), e && l.append("Set-Cookie", `flash=${encodeURIComponent(JSON.stringify({ url: i.pathname + i.search, result: n ? e.message : e, thrown: a, error: n, input: [...t.slice(0, -1), [...t[t.length - 1].entries()]] }))}; Secure; HttpOnly;`), new Response(null, { status: o, headers: l });
  }
  let oe;
  function Jt(e) {
    var _a;
    const r = new Headers(e.request.headers), t = J$1(e.nativeEvent), a = e.response.headers.getSetCookie();
    r.delete("cookie");
    let i = false;
    return ((_a = e.nativeEvent.node) == null ? void 0 : _a.req) && (i = true, e.nativeEvent.node.req.headers.cookie = ""), a.forEach((n) => {
      if (!n) return;
      const o = n.split(";")[0], [l, u] = o.split("=");
      l && u && (t[l] = u);
    }), Object.entries(t).forEach(([n, o]) => {
      r.append("cookie", `${n}=${o}`), i && (e.nativeEvent.node.req.headers.cookie += `${n}=${o};`);
    }), r;
  }
  async function Me(e, r) {
    let t, a = new URL(e.request.headers.get("referer")).toString();
    r instanceof Response && (r.headers.has("X-Revalidate") && (t = r.headers.get("X-Revalidate").split(",")), r.headers.has("Location") && (a = new URL(r.headers.get("Location"), new URL(e.request.url).origin + "").toString()));
    const i = le(e);
    return i.request = new Request(a, { headers: Jt(e) }), await provideRequestEvent(i, async () => {
      await qt(i), oe || (oe = (await import('../build/app-DK5u2c7Z.mjs')).default), i.router.dataOnly = t || true, i.router.previousUrl = e.request.headers.get("referer");
      try {
        renderToString(() => {
          sharedConfig.context.event = i, oe();
        });
      } catch (l) {
        console.log(l);
      }
      const n = i.router.data;
      if (!n) return r;
      let o = false;
      for (const l in n) n[l] === void 0 ? delete n[l] : o = true;
      return o && (r instanceof Response ? r.customBody && (n._$value = r.customBody()) : (n._$value = r, r = new Response(null, { status: 200 })), r.customBody = () => n, r.headers.set("X-Single-Flight", "true")), r;
    });
  }
  Ge = eventHandler(Yt);
})();

function j(t = {}) {
  let e, o = false;
  const r = (n) => {
    if (e && e !== n) throw new Error("Context conflict");
  };
  let a;
  if (t.asyncContext) {
    const n = t.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    n ? a = new n() : console.warn("[unctx] `AsyncLocalStorage` is not provided.");
  }
  const l = () => {
    if (a) {
      const n = a.getStore();
      if (n !== void 0) return n;
    }
    return e;
  };
  return { use: () => {
    const n = l();
    if (n === void 0) throw new Error("Context is not available");
    return n;
  }, tryUse: () => l(), set: (n, i) => {
    i || r(n), e = n, o = true;
  }, unset: () => {
    e = void 0, o = false;
  }, call: (n, i) => {
    r(n), e = n;
    try {
      return a ? a.run(n, i) : i();
    } finally {
      o || (e = void 0);
    }
  }, async callAsync(n, i) {
    e = n;
    const w = () => {
      e = n;
    }, f = () => e === n ? w : void 0;
    p.add(f);
    try {
      const v = a ? a.run(n, i) : i();
      return o || (e = void 0), await v;
    } finally {
      p.delete(f);
    }
  } };
}
function B(t = {}) {
  const e = {};
  return { get(o, r = {}) {
    return e[o] || (e[o] = j({ ...t, ...r })), e[o];
  } };
}
const u = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof global < "u" ? global : {}, d = "__unctx__", I$1 = u[d] || (u[d] = B()), M = (t, e = {}) => I$1.get(t, e), y = "__unctx_async_handlers__", p = u[y] || (u[y] = /* @__PURE__ */ new Set());
function N(t) {
  let e;
  const o = h(t), r = { duplex: "half", method: t.method, headers: t.headers };
  return t.node.req.body instanceof ArrayBuffer ? new Request(o, { ...r, body: t.node.req.body }) : new Request(o, { ...r, get body() {
    return e || (e = te(t), e);
  } });
}
function O(t) {
  var _a;
  return (_a = t.web) != null ? _a : t.web = { request: N(t), url: h(t) }, t.web.request;
}
function W() {
  return re();
}
const g = Symbol("$HTTPEvent");
function $(t) {
  return typeof t == "object" && (t instanceof H3Event || (t == null ? void 0 : t[g]) instanceof H3Event || (t == null ? void 0 : t.__is_event__) === true);
}
function s(t) {
  return function(...e) {
    var _a;
    let o = e[0];
    if ($(o)) e[0] = o instanceof H3Event || o.__is_event__ ? o : o[g];
    else {
      if (!((_a = globalThis.app.config.server.experimental) == null ? void 0 : _a.asyncContext)) throw new Error("AsyncLocalStorage was not enabled. Use the `server.experimental.asyncContext: true` option in your app configuration to enable it. Or, pass the instance of HTTPEvent that you have as the first argument to the function.");
      if (o = W(), !o) throw new Error("No HTTPEvent found in AsyncLocalStorage. Make sure you are using the function within the server runtime.");
      e.unshift(o);
    }
    return t(...e);
  };
}
const h = s(getRequestURL), z = s(getRequestIP), D = s(setResponseStatus), F = s(getResponseStatus), K = s(getResponseStatusText), Q = s(getResponseHeaders), V = s(getResponseHeader), X = s(setResponseHeader), Y = s(appendResponseHeader), Z = s(sendRedirect), G = s(getCookie), J = s(setCookie), ee = s(deleteCookie), te = s(getRequestWebStream), ne = s(removeResponseHeader), oe = s(O);
function se() {
  var _a;
  return M("nitro-app", { asyncContext: !!((_a = globalThis.app.config.server.experimental) == null ? void 0 : _a.asyncContext), AsyncLocalStorage: AsyncLocalStorage });
}
function re() {
  return se().use().event;
}

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, key + "" , value);
let I; (async () => {
  const R = isServer ? (t) => {
    const e = getRequestEvent();
    return e.response.status = t.code, e.response.statusText = t.text, onCleanup(() => !e.nativeEvent.handled && !e.complete && (e.response.status = 200)), null;
  } : (t) => null;
  var H = ["<span", ' style="font-size:1.5em;text-align:center;position:fixed;left:0px;bottom:55%;width:100%;">500 | Internal Server Error</span>'];
  const q = (t) => {
    let e = false;
    const r = catchError(() => t.children, (a) => {
      console.error(a), e = !!a;
    });
    return e ? [ssr(H, ssrHydrationKey()), createComponent$1(R, { code: 500 })] : r;
  };
  var G = " ";
  const M = { style: (t) => ssrElement("style", t.attrs, () => t.children, true), link: (t) => ssrElement("link", t.attrs, void 0, true), script: (t) => t.attrs.src ? ssrElement("script", mergeProps(() => t.attrs, { get id() {
    return t.key;
  } }), () => ssr(G), true) : null, noscript: (t) => ssrElement("noscript", t.attrs, () => escape(t.children), true) };
  function W(t, e) {
    let { tag: r, attrs: { key: a, ...s } = { key: void 0 }, children: i } = t;
    return M[r]({ attrs: { ...s, nonce: e }, key: a, children: i });
  }
  var b = ["<script", ">", "<\/script>"], x = ["<script", ' type="module"', "><\/script>"];
  const F$1 = ssr("<!DOCTYPE html>");
  function _(t) {
    const e = getRequestEvent(), r = e.nonce;
    return createComponent$1(NoHydration, { get children() {
      return [F$1, createComponent$1(q, { get children() {
        return createComponent$1(t.document, { get assets() {
          return e.assets.map((a) => W(a));
        }, get scripts() {
          return r ? [ssr(b, ssrHydrationKey() + ssrAttribute("nonce", escape(r, true), false), `window.manifest = ${JSON.stringify(e.manifest)}`), ssr(x, ssrHydrationKey(), ssrAttribute("src", escape(globalThis.MANIFEST.client.inputs[globalThis.MANIFEST.client.handler].output.path, true), false))] : [ssr(b, ssrHydrationKey(), `window.manifest = ${JSON.stringify(e.manifest)}`), ssr(x, ssrHydrationKey(), ssrAttribute("src", escape(globalThis.MANIFEST.client.inputs[globalThis.MANIFEST.client.handler].output.path, true), false))];
        } });
      } })];
    } });
  }
  const m = { NORMAL: 0, WILDCARD: 1, PLACEHOLDER: 2 };
  function z$1(t = {}) {
    const e = { options: t, rootNode: A(), staticRoutesMap: {} }, r = (a) => t.strictTrailingSlash ? a : a.replace(/\/$/, "") || "/";
    if (t.routes) for (const a in t.routes) k(e, r(a), t.routes[a]);
    return { ctx: e, lookup: (a) => J(e, r(a)), insert: (a, s) => k(e, r(a), s), remove: (a) => U(e, r(a)) };
  }
  function J(t, e) {
    const r = t.staticRoutesMap[e];
    if (r) return r.data;
    const a = e.split("/"), s = {};
    let i = false, p = null, o = t.rootNode, c = null;
    for (let n = 0; n < a.length; n++) {
      const u = a[n];
      o.wildcardChildNode !== null && (p = o.wildcardChildNode, c = a.slice(n).join("/"));
      const g = o.children.get(u);
      if (g === void 0) {
        if (o && o.placeholderChildren.length > 1) {
          const lt = a.length - n;
          o = o.placeholderChildren.find((pt) => pt.maxDepth === lt) || null;
        } else o = o.placeholderChildren[0] || null;
        if (!o) break;
        o.paramName && (s[o.paramName] = u), i = true;
      } else o = g;
    }
    return (o === null || o.data === null) && p !== null && (o = p, s[o.paramName || "_"] = c, i = true), o ? i ? { ...o.data, params: i ? s : void 0 } : o.data : null;
  }
  function k(t, e, r) {
    let a = true;
    const s = e.split("/");
    let i = t.rootNode, p = 0;
    const o = [i];
    for (const c of s) {
      let n;
      if (n = i.children.get(c)) i = n;
      else {
        const u = B(c);
        n = A({ type: u, parent: i }), i.children.set(c, n), u === m.PLACEHOLDER ? (n.paramName = c === "*" ? `_${p++}` : c.slice(1), i.placeholderChildren.push(n), a = false) : u === m.WILDCARD && (i.wildcardChildNode = n, n.paramName = c.slice(3) || "_", a = false), o.push(n), i = n;
      }
    }
    for (const [c, n] of o.entries()) n.maxDepth = Math.max(o.length - c, n.maxDepth || 0);
    return i.data = r, a === true && (t.staticRoutesMap[e] = i), i;
  }
  function U(t, e) {
    let r = false;
    const a = e.split("/");
    let s = t.rootNode;
    for (const i of a) if (s = s.children.get(i), !s) return r;
    if (s.data) {
      const i = a.at(-1) || "";
      s.data = null, Object.keys(s.children).length === 0 && s.parent && (s.parent.children.delete(i), s.parent.wildcardChildNode = null, s.parent.placeholderChildren = []), r = true;
    }
    return r;
  }
  function A(t = {}) {
    return { type: t.type || m.NORMAL, maxDepth: 0, parent: t.parent || null, children: /* @__PURE__ */ new Map(), data: t.data || null, paramName: t.paramName || null, wildcardChildNode: null, placeholderChildren: [] };
  }
  function B(t) {
    return t.startsWith("**") ? m.WILDCARD : t[0] === ":" || t === "*" ? m.PLACEHOLDER : m.NORMAL;
  }
  const S = [{ page: true, path: "/(app)", filePath: "/root/code/ToramCalculator/src/routes/(app).tsx" }, { page: true, path: "/(app)/(functionPage)", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage).tsx" }, { page: true, path: "/(app)/", filePath: "/root/code/ToramCalculator/src/routes/(app)/index.tsx" }, { page: true, path: "/(app)/repl", filePath: "/root/code/ToramCalculator/src/routes/(app)/repl.jsx" }, { page: false, $POST: { src: "src/routes/api/changes.ts?pick=POST", build: () => import('../build/changes2.mjs'), import: () => import('../build/changes2.mjs') }, path: "/api/changes", filePath: "/root/code/ToramCalculator/src/routes/api/changes.ts" }, { page: false, $GET: { src: "src/routes/api/envLog.ts?pick=GET", build: () => import('../build/envLog2.mjs'), import: () => import('../build/envLog2.mjs') }, $HEAD: { src: "src/routes/api/envLog.ts?pick=GET", build: () => import('../build/envLog2.mjs'), import: () => import('../build/envLog2.mjs') }, path: "/api/envLog", filePath: "/root/code/ToramCalculator/src/routes/api/envLog.ts" }, { page: true, path: "/(app)/(functionPage)/*404", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/[...404].tsx" }, { page: true, path: "/(app)/(functionPage)/petCalculator", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/petCalculator.tsx" }, { page: false, $GET: { src: "src/routes/api/auth/[...solidauth].ts?pick=GET", build: () => import('../build/_...solidauth_3.mjs'), import: () => import('../build/_...solidauth_3.mjs') }, $HEAD: { src: "src/routes/api/auth/[...solidauth].ts?pick=GET", build: () => import('../build/_...solidauth_3.mjs'), import: () => import('../build/_...solidauth_3.mjs') }, $POST: { src: "src/routes/api/auth/[...solidauth].ts?pick=POST", build: () => import('../build/_...solidauth_22.mjs'), import: () => import('../build/_...solidauth_22.mjs') }, path: "/api/auth/*solidauth", filePath: "/root/code/ToramCalculator/src/routes/api/auth/[...solidauth].ts" }, { page: false, $POST: { src: "src/routes/api/auth/login.ts?pick=POST", build: () => import('../build/login2.mjs'), import: () => import('../build/login2.mjs') }, path: "/api/auth/login", filePath: "/root/code/ToramCalculator/src/routes/api/auth/login.ts" }, { page: false, $GET: { src: "src/routes/api/auth/logout.ts?pick=GET", build: () => import('../build/logout2.mjs'), import: () => import('../build/logout2.mjs') }, $HEAD: { src: "src/routes/api/auth/logout.ts?pick=GET", build: () => import('../build/logout2.mjs'), import: () => import('../build/logout2.mjs') }, path: "/api/auth/logout", filePath: "/root/code/ToramCalculator/src/routes/api/auth/logout.ts" }, { page: true, path: "/api/auth/qq", filePath: "/root/code/ToramCalculator/src/routes/api/auth/qq.ts" }, { page: false, $POST: { src: "src/routes/api/auth/register.ts?pick=POST", build: () => import('../build/register2.mjs'), import: () => import('../build/register2.mjs') }, path: "/api/auth/register", filePath: "/root/code/ToramCalculator/src/routes/api/auth/register.ts" }, { page: true, path: "/(app)/(functionPage)/character/(character)", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/character/(character).tsx" }, { page: true, path: "/(app)/(functionPage)/character/:characterId", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/character/[characterId].tsx" }, { page: true, path: "/(app)/(functionPage)/profile/(profile)", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/profile/(profile).tsx" }, { page: true, path: "/(app)/(functionPage)/wiki/(wiki)", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/wiki/(wiki).tsx" }, { page: true, path: "/(app)/(functionPage)/wiki/mob/(mob)", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/wiki/mob/(mob).tsx" }, { page: true, path: "/(app)/(functionPage)/wiki/pet/(pet)", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/wiki/pet/(pet).tsx" }, { page: true, path: "/(app)/(functionPage)/wiki/skill/(skill)", filePath: "/root/code/ToramCalculator/src/routes/(app)/(functionPage)/wiki/skill/(skill).tsx" }];
  K$1(S.filter((t) => t.page));
  function K$1(t) {
    function e(r, a, s, i) {
      const p = Object.values(r).find((o) => s.startsWith(o.id + "/"));
      return p ? (e(p.children || (p.children = []), a, s.slice(p.id.length)), r) : (r.push({ ...a, id: s, path: s.replace(/\([^)/]+\)/g, "").replace(/\/+/g, "/") }), r);
    }
    return t.sort((r, a) => r.path.length - a.path.length).reduce((r, a) => e(r, a, a.path, a.path), []);
  }
  function Y$1(t, e) {
    const r = V$1.lookup(t);
    if (r && r.route) {
      const a = e === "HEAD" ? r.route.$HEAD || r.route.$GET : r.route[`$${e}`];
      return a === void 0 ? void 0 : { handler: a, params: r.params };
    }
  }
  function Q$1(t) {
    return t.$HEAD || t.$GET || t.$POST || t.$PUT || t.$PATCH || t.$DELETE;
  }
  const V$1 = z$1({ routes: S.reduce((t, e) => {
    if (!Q$1(e)) return t;
    let r = e.path.replace(/\([^)/]+\)/g, "").replace(/\/+/g, "/").replace(/\*([^/]*)/g, (a, s) => `**:${s}`).split("/").map((a) => a.startsWith(":") || a.startsWith("*") ? a : encodeURIComponent(a)).join("/");
    if (/:[^/]*\?/g.test(r)) throw new Error(`Optional parameters are not supported in API routes: ${r}`);
    if (t[r]) throw new Error(`Duplicate API routes for "${r}" found at "${t[r].route.path}" and "${e.path}"`);
    return t[r] = { route: e }, t;
  }, {}) }), E = "solidFetchEvent";
  function X$1(t) {
    return { request: oe(t), response: et(t), clientAddress: z(t), locals: {}, nativeEvent: t };
  }
  function Z$1(t) {
    if (!t.context[E]) {
      const e = X$1(t);
      t.context[E] = e;
    }
    return t.context[E];
  }
  class tt {
    constructor(e) {
      __publicField(this, "event");
      this.event = e;
    }
    get(e) {
      const r = V(this.event, e);
      return Array.isArray(r) ? r.join(", ") : r || null;
    }
    has(e) {
      return this.get(e) !== void 0;
    }
    set(e, r) {
      return X(this.event, e, r);
    }
    delete(e) {
      return ne(this.event, e);
    }
    append(e, r) {
      Y(this.event, e, r);
    }
    getSetCookie() {
      const e = V(this.event, "Set-Cookie");
      return Array.isArray(e) ? e : [e];
    }
    forEach(e) {
      return Object.entries(Q(this.event)).forEach(([r, a]) => e(Array.isArray(a) ? a.join(", ") : a, r, this));
    }
    entries() {
      return Object.entries(Q(this.event)).map(([e, r]) => [e, Array.isArray(r) ? r.join(", ") : r])[Symbol.iterator]();
    }
    keys() {
      return Object.keys(Q(this.event))[Symbol.iterator]();
    }
    values() {
      return Object.values(Q(this.event)).map((e) => Array.isArray(e) ? e.join(", ") : e)[Symbol.iterator]();
    }
    [Symbol.iterator]() {
      return this.entries()[Symbol.iterator]();
    }
  }
  function et(t) {
    return { get status() {
      return F(t);
    }, set status(e) {
      D(t, e);
    }, get statusText() {
      return K(t);
    }, set statusText(e) {
      D(t, F(t), e);
    }, headers: new tt(t) };
  }
  const rt = /* @__PURE__ */ new Set([301, 302, 303, 307, 308]);
  function at(t) {
    return t.status && rt.has(t.status) ? t.status : 302;
  }
  function it(t, e, r = {}, a) {
    return eventHandler({ handler: (s) => {
      const i = Z$1(s);
      return provideRequestEvent(i, async () => {
        const p = Y$1(new URL(i.request.url).pathname, i.request.method);
        if (p) {
          const n = await p.handler.import(), u = i.request.method === "HEAD" ? n.HEAD || n.GET : n[i.request.method];
          i.params = p.params || {}, sharedConfig.context = { event: i };
          const g = await u(i);
          if (g !== void 0) return g;
          if (i.request.method !== "GET") throw new Error(`API handler for ${i.request.method} "${i.request.url}" did not return a response.`);
        }
        const o = await e(i), c = typeof r == "function" ? await r(o) : { ...r };
        c.mode, c.nonce && (o.nonce = c.nonce);
        {
          const n = renderToString(() => (sharedConfig.context.event = o, t(o)), c);
          if (o.complete = true, o.response && o.response.headers.get("Location")) {
            const u = at(o.response);
            return Z(s, o.response.headers.get("Location"), u);
          }
          return n;
        }
      });
    } });
  }
  function ot(t, e, r) {
    return it(t, st, e);
  }
  async function st(t) {
    const e = globalThis.MANIFEST.client;
    return Object.assign(t, { manifest: await e.json(), assets: [...await e.inputs[e.handler].assets()], routes: [], complete: false, $islands: /* @__PURE__ */ new Set() });
  }
  var nt = ['<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="icon" href="/icons/48.ico"><title>ToramCalculator</title><meta name="theme-color" content="#ffffff"><meta name="application-name"', '><meta name="description"', '><meta name="mobile-web-app-capable" content="yes"><meta name="mobile-web-app-status-bar-style" content="default"><meta name="mobile-web-app-title"', '><meta property="og:title"', '><meta property="og:description"', '><meta property="og:type" content="website"><meta property="og:site_name"', '><meta name="twitter:card" content="summary"><meta name="twitter:title"', '><meta name="twitter:description"', '><link rel="manifest" href="/manifest.json"><script>const storeStr = localStorage.getItem("store"); const storeCache = storeStr ? JSON.parse(storeStr) : undefined; const root = document.documentElement; let theme = "light"; if (storeCache) theme = storeCache.theme; root.classList.add(theme); let isAnimationEnabled = true; if (storeCache) isAnimationEnabled = storeCache.settings.userInterface.isAnimationEnabled; !isAnimationEnabled && root.classList.add("transitionNone"); let language = "zh-CN"; if (storeCache) language = storeCache.settings.language; root.lang = language;<\/script>', "</head>"], ct = ["<html", " lang class>", '<body><div id="loader" class="bg-primary-color fixed top-0 left-0 z-50 flex h-dvh w-dvw flex-col items-end justify-end"><div id="resource-list" class="w-dvw overflow-hidden p-6 text-xs text-nowrap text-ellipsis"></div><div id="loadingBox"><div class="Shadow shadow-none"><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div></div><div id="maskElement2"></div><div id="maskElement3"></div><div class="line"><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div><div class="Circle"></div></div></div></div><div id="app" class="flex h-dvh w-dvw flex-col-reverse lg:flex-row">', `</div><script>try {
                storeCache.resourcesLoaded; document.getElementById("loader").remove();
                // console.log("\u8D44\u6E90\u52A0\u8F7D\u5B8C\u6210");
              } catch (error) {
                // console.log("\u521D\u6B21\u52A0\u8F7D\u8D44\u6E90");
              }<\/script><!--$-->`, "<!--/--></body></html>"];
  let C, y, T;
  C = "\u6258\u62C9\u59C6\u8BA1\u7B97\u5668-ToramCalculator:\u4E00\u4E2A\u7B80\u5355\u7684\u6258\u62C9\u59C6\u6570\u503C\u8BA1\u7B97\u5668", y = "\u6258\u62C9\u59C6\u8BA1\u7B97\u5668-ToramCalculator", T = "Wiki\u3001\u89D2\u8272\u914D\u7F6E\u3001\u8FDE\u51FB\u8BA1\u7B97\u7B49", I = ot(() => createComponent$1(_, { document: ({ assets: t, children: e, scripts: r }) => ssr(ct, ssrHydrationKey(), createComponent$1(NoHydration, { get children() {
    return ssr(nt, ssrAttribute("content", escape(C, true), false), ssrAttribute("content", escape(T, true), false), ssrAttribute("content", escape(C, true), false), ssrAttribute("content", escape(y, true), false), ssrAttribute("content", escape(T, true), false), ssrAttribute("content", escape(C, true), false), ssrAttribute("content", escape(y, true), false), ssrAttribute("content", escape(T, true), false), escape(t));
  } }), escape(e), escape(r)) }));
})();

const handlers = [
  { route: '', handler: _ccXNhT, lazy: false, middleware: true, method: undefined },
  { route: '/_server', handler: Ge, lazy: false, middleware: true, method: undefined },
  { route: '/', handler: I, lazy: false, middleware: true, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp$1.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => b(nodeHandler, aRequest);
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return O$2(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  {
    const _handler = h3App.handler;
    h3App.handler = (event) => {
      const ctx = { event };
      return nitroAsyncContext.callAsync(ctx, () => _handler(event));
    };
  }
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp$1 = createNitroApp();
function useNitroApp() {
  return nitroApp$1;
}
runNitroPlugins(nitroApp$1);

const debug = (...args) => {
};
function GracefulShutdown(server, opts) {
  opts = opts || {};
  const options = Object.assign(
    {
      signals: "SIGINT SIGTERM",
      timeout: 3e4,
      development: false,
      forceExit: true,
      onShutdown: (signal) => Promise.resolve(signal),
      preShutdown: (signal) => Promise.resolve(signal)
    },
    opts
  );
  let isShuttingDown = false;
  const connections = {};
  let connectionCounter = 0;
  const secureConnections = {};
  let secureConnectionCounter = 0;
  let failed = false;
  let finalRun = false;
  function onceFactory() {
    let called = false;
    return (emitter, events, callback) => {
      function call() {
        if (!called) {
          called = true;
          return Reflect.apply(callback, this, arguments);
        }
      }
      for (const e of events) {
        emitter.on(e, call);
      }
    };
  }
  const signals = options.signals.split(" ").map((s) => s.trim()).filter((s) => s.length > 0);
  const once = onceFactory();
  once(process, signals, (signal) => {
    debug("received shut down signal", signal);
    shutdown(signal).then(() => {
      if (options.forceExit) {
        process.exit(failed ? 1 : 0);
      }
    }).catch((error) => {
      debug("server shut down error occurred", error);
      process.exit(1);
    });
  });
  function isFunction(functionToCheck) {
    const getType = Object.prototype.toString.call(functionToCheck);
    return /^\[object\s([A-Za-z]+)?Function]$/.test(getType);
  }
  function destroy(socket, force = false) {
    if (socket._isIdle && isShuttingDown || force) {
      socket.destroy();
      if (socket.server instanceof http.Server) {
        delete connections[socket._connectionId];
      } else {
        delete secureConnections[socket._connectionId];
      }
    }
  }
  function destroyAllConnections(force = false) {
    debug("Destroy Connections : " + (force ? "forced close" : "close"));
    let counter = 0;
    let secureCounter = 0;
    for (const key of Object.keys(connections)) {
      const socket = connections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        counter++;
        destroy(socket);
      }
    }
    debug("Connections destroyed : " + counter);
    debug("Connection Counter    : " + connectionCounter);
    for (const key of Object.keys(secureConnections)) {
      const socket = secureConnections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        secureCounter++;
        destroy(socket);
      }
    }
    debug("Secure Connections destroyed : " + secureCounter);
    debug("Secure Connection Counter    : " + secureConnectionCounter);
  }
  server.on("request", (req, res) => {
    req.socket._isIdle = false;
    if (isShuttingDown && !res.headersSent) {
      res.setHeader("connection", "close");
    }
    res.on("finish", () => {
      req.socket._isIdle = true;
      destroy(req.socket);
    });
  });
  server.on("connection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = connectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      connections[id] = socket;
      socket.once("close", () => {
        delete connections[socket._connectionId];
      });
    }
  });
  server.on("secureConnection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = secureConnectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      secureConnections[id] = socket;
      socket.once("close", () => {
        delete secureConnections[socket._connectionId];
      });
    }
  });
  process.on("close", () => {
    debug("closed");
  });
  function shutdown(sig) {
    function cleanupHttp() {
      destroyAllConnections();
      debug("Close http server");
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) {
            return reject(err);
          }
          return resolve(true);
        });
      });
    }
    debug("shutdown signal - " + sig);
    if (options.development) {
      debug("DEV-Mode - immediate forceful shutdown");
      return process.exit(0);
    }
    function finalHandler() {
      if (!finalRun) {
        finalRun = true;
        if (options.finally && isFunction(options.finally)) {
          debug("executing finally()");
          options.finally();
        }
      }
      return Promise.resolve();
    }
    function waitForReadyToShutDown(totalNumInterval) {
      debug(`waitForReadyToShutDown... ${totalNumInterval}`);
      if (totalNumInterval === 0) {
        debug(
          `Could not close connections in time (${options.timeout}ms), will forcefully shut down`
        );
        return Promise.resolve(true);
      }
      const allConnectionsClosed = Object.keys(connections).length === 0 && Object.keys(secureConnections).length === 0;
      if (allConnectionsClosed) {
        debug("All connections closed. Continue to shutting down");
        return Promise.resolve(false);
      }
      debug("Schedule the next waitForReadyToShutdown");
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(waitForReadyToShutDown(totalNumInterval - 1));
        }, 250);
      });
    }
    if (isShuttingDown) {
      return Promise.resolve();
    }
    debug("shutting down");
    return options.preShutdown(sig).then(() => {
      isShuttingDown = true;
      cleanupHttp();
    }).then(() => {
      const pollIterations = options.timeout ? Math.round(options.timeout / 250) : 0;
      return waitForReadyToShutDown(pollIterations);
    }).then((force) => {
      debug("Do onShutdown now");
      if (force) {
        destroyAllConnections(force);
      }
      return options.onShutdown(sig);
    }).then(finalHandler).catch((error) => {
      const errString = typeof error === "string" ? error : JSON.stringify(error);
      debug(errString);
      failed = true;
      throw errString;
    });
  }
  function shutdownManual() {
    return shutdown("manual");
  }
  return shutdownManual;
}

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT || "", 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  GracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((error) => {
          console.error(error);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const path = process.env.NITRO_UNIX_SOCKET;
const listener = server.listen(path ? { path } : { port, host }, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const addressInfo = listener.address();
  if (typeof addressInfo === "string") {
    console.log(`Listening on unix socket ${addressInfo}`);
    return;
  }
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${addressInfo.family === "IPv6" ? `[${addressInfo.address}]` : addressInfo.address}:${addressInfo.port}${baseURL}`;
  console.log(`Listening on ${url}`);
});
trapUnhandledNodeErrors();
setupGracefulShutdown(listener, nitroApp);
const nodeServer = {};

export { G, J, Ke as K, Q$1 as Q, ee as a, ee$1 as e, le as l, nodeServer as n, te$1 as t };
//# sourceMappingURL=nitro.mjs.map
